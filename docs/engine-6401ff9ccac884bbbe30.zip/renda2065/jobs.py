"""Tarefas locais iniciadas pelo usuário; cancelamento cooperativo e limites."""
from threading import Thread,Event,RLock
from collections import OrderedDict
import time,uuid
from .models import ValidationError


class JobManager:
    def __init__(self):self._lock=RLock();self._jobs=OrderedDict()
    def submit(self,kind,fn):
        with self._lock:
            if any(j['state'] in ('pending','running') for j in self._jobs.values()):raise ValidationError('E-BUSY','Há uma pesquisa em andamento. Cancele-a ou aguarde a conclusão antes de iniciar outra.')
            while len(self._jobs)>=8:self._jobs.popitem(last=False)
            identity=uuid.uuid4().hex
            j={'id':identity,'kind':kind,'state':'pending','done':0,'total':1,'message':'Preparando','result':None,'error':None,'started':time.time(),'event':Event()};self._jobs[identity]=j
        def progress(done,total,message):
            with self._lock:j.update(done=done,total=total,message=message)
        def worker():
            with self._lock:j['state']='running'
            try:
                result=fn(j['event'],progress)
                with self._lock:
                    if j['event'].is_set():j.update(state='cancelled',error='Cancelado; resultados parciais descartados.')
                    else:j.update(state='completed',result=result,done=j['total'],message='Concluído')
            except ValidationError as exc:
                with self._lock:j.update(state='cancelled' if exc.code=='E-CANCELLED' else 'failed',error=str(exc))
            except Exception:
                import logging
                logging.getLogger('renda2065').exception('Falha em tarefa local.')
                with self._lock:j.update(state='failed',error='Falha na pesquisa. Operações salvas foram preservadas.')
        Thread(target=worker,daemon=True,name='renda-research').start()
        return self.status(identity,include_result=False)
    def status(self,identity,include_result=True):
        with self._lock:
            if identity not in self._jobs:raise ValidationError('E-SESSION','Tarefa ausente ou expirada.')
            j=self._jobs[identity];out={k:v for k,v in j.items() if k!='event' and (include_result or k!='result')};out['elapsed']=time.time()-j['started'];return out
    def cancel(self,identity):
        with self._lock:
            if identity not in self._jobs:raise ValidationError('E-SESSION','Tarefa não encontrada.')
            self._jobs[identity]['event'].set()
        return {'cancel_requested':True}
    def clear(self):
        with self._lock:
            for j in self._jobs.values():j['event'].set()
            self._jobs.clear()
