"""Batch the web screen's date probes through the existing date engine."""
from .calendar_rules import FinancialCalendar
from .market_sim.api import _date, _object, _sequence
from .market_sim.contracts import ValidationError
from .market_sim.dates import resolve_workspace_dates
from .market_sim.workspace import normalize_workspace_input, prepare_workspace_defaults


def resolve_date_batch(body):
    request = _object(body, 'date batch', {'input', 'order_dates'}, {'input', 'order_dates'})
    raw = _object(request['input'], 'input',
                  {'instrument', 'purchase_date', 'analysis_context', 'knowledge', 'intent', 'assumptions'},
                  {'instrument', 'purchase_date', 'knowledge', 'intent', 'assumptions'})
    assumptions = _object(raw['assumptions'], 'assumptions', {'settlement_profile'}, {'settlement_profile'})
    if assumptions['settlement_profile'] not in {'SIMULATED_BUY_D1_SELL_D1', 'SIMULATED_BUY_D1_SELL_D0'}:
        raise ValidationError('INVALID_SETTLEMENT_PROFILE', 'A grade usa somente liquidação simulada.')
    normalized = normalize_workspace_input(prepare_workspace_defaults(raw))
    if normalized.instrument is None or normalized.purchase_date is None or normalized.knowledge is None:
        raise ValidationError('MISSING_FIELD', 'Título, compra e corte de conhecimento são obrigatórios.')
    requested = tuple(_date(value, 'order_date') for value in _sequence(request['order_dates'], 'order_dates', 2048))
    if not requested:
        raise ValidationError('INVALID_DATE_DOMAIN', 'Informe ao menos uma data.')
    calendar = FinancialCalendar(knowledge_date=normalized.knowledge.date)
    resolutions = {}
    for requested_date in requested:
        current = requested_date
        # Same confirmation probes used by eligibleDate in the screen. Returning
        # proposals separately keeps their original labels/status and all gaps.
        for _ in range(3):
            key = current.isoformat()
            if key in resolutions:
                break
            resolved = resolve_workspace_dates(
                instrument=normalized.instrument, purchase_order_date=normalized.purchase_date,
                sale_order_date=current, settlement_profile=assumptions['settlement_profile'],
                calendar=calendar,
            ).to_dict()
            resolutions[key] = {'dates': resolved}
            sale = resolved['sale']
            proposed = sale.get('proposed_order_date')
            minimum = sale.get('minimum_eligible_order_date')
            candidate = max(value for value in (proposed, minimum) if value is not None)
            if candidate <= key:
                break
            current = _date(candidate, 'proposed_order_date')
    return {'version': 1, 'resolutions': resolutions}
