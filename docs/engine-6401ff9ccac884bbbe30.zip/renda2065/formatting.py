"""Parsing localizado e formatação: apresentação nunca define o sinal financeiro."""
import re
from decimal import Decimal as D, InvalidOperation
from datetime import date
from math import isfinite
from .models import ValidationError


def parse_number(text: str, label: str = 'valor') -> D:
    value = str(text).strip().replace('R$', '').replace('%', '').replace('\u00a0','').replace(' ', '')
    if not value:
        raise ValidationError('E-AMOUNT', f'Preencha {label}.')
    if ',' in value:
        if not re.fullmatch(r'[+-]?(?:\d{1,3}(?:\.\d{3})+|\d+)(?:,\d+)?', value):
            raise ValidationError('E-AMOUNT', f'{label}: use 1.234,56 ou 1234,56.')
        value = value.replace('.', '').replace(',', '.')
    elif not re.fullmatch(r'[+-]?(?:\d+(?:\.\d*)?|\.\d+)', value):
        raise ValidationError('E-AMOUNT', f'{label}: número inválido.')
    try:
        result=D(value)
    except InvalidOperation as exc:
        raise ValidationError('E-AMOUNT',f'{label}: número inválido.') from exc
    if not result.is_finite():
        raise ValidationError('E-AMOUNT',f'{label}: número não finito.')
    return result


def parse_rates(text: str) -> tuple[tuple[float, ...], tuple[str, ...]]:
    pieces = [x.strip() for x in re.split(r'[;\n]+',str(text)) if x.strip()]
    if not pieces:
        raise ValidationError('E-YIELD-DOMAIN','Informe ao menos uma taxa, separando-as por ponto e vírgula.')
    rates = tuple(dict.fromkeys(float(parse_number(x,'taxa')/100) for x in pieces))
    if len(rates)>5:
        raise ValidationError('E-YIELD-DOMAIN','No máximo cinco taxas distintas por análise.')
    warnings = ('Taxas duplicadas removidas.',) if len(rates)<len(pieces) else ()
    return rates,warnings


def br_number(value, digits=2) -> str:
    if value is None:
        return '—'
    try:
        if not isfinite(float(value)):
            return '—'
        return f'{value:,.{digits}f}'.replace(',','@').replace('.',',').replace('@','.')
    except (TypeError,ValueError):
        return '—'


def money(value) -> str:
    return '—' if value is None else f'R$ {br_number(value)}'


def pct(value, digits=2) -> str:
    return '—' if value is None else br_number(value*100,digits)+'%'


def day_label(value: date | None) -> str:
    return '—' if value is None else value.strftime('%d/%m/%Y')
