"""Persistência local opt-in, revisões imutáveis e backups validados.

SQLite usa transações; o bloqueio de arquivo também coordena backup/restauração
entre processos no Windows e no POSIX. Nunca desserializa pickle nem executa SQL
fornecido pelo usuário.
"""
from __future__ import annotations
from contextlib import closing, contextmanager
from datetime import datetime, timezone
from hashlib import sha256
from pathlib import Path
import json
import base64
import io
import os
import re
import shutil
import sqlite3
import tempfile
import threading
import time
import uuid
import zipfile
from .models import ValidationError
from .data_paths import resolve_data_dir as user_data_dir

APP_ID = 0x524E4432
SCHEMA = 2
KINDS = {'operation', 'scenario', 'quote', 'reconciliation', 'regression', 'experiment', 'portfolio', 'paper', 'position'}
SCHEMA_SQL = '''
CREATE TABLE IF NOT EXISTS records(id TEXT PRIMARY KEY,kind TEXT NOT NULL,name TEXT NOT NULL,revision INTEGER NOT NULL,created_at TEXT NOT NULL,updated_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS revisions(record_id TEXT NOT NULL,revision INTEGER NOT NULL,payload TEXT NOT NULL,created_at TEXT NOT NULL,PRIMARY KEY(record_id,revision));
CREATE TABLE IF NOT EXISTS datasets(kind TEXT NOT NULL,hash TEXT NOT NULL,content BLOB NOT NULL,metadata TEXT NOT NULL,created_at TEXT NOT NULL,original_content BLOB,PRIMARY KEY(kind,hash));
CREATE TABLE IF NOT EXISTS active_datasets(kind TEXT PRIMARY KEY,hash TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS events(id INTEGER PRIMARY KEY,event TEXT NOT NULL,details TEXT NOT NULL,created_at TEXT NOT NULL);
'''


def utc_now():
    return datetime.now(timezone.utc).isoformat()


def safe_json(value, *, max_bytes=4*1024*1024) -> str:
    try:
        text=json.dumps(value,ensure_ascii=False,allow_nan=False,sort_keys=True,separators=(',',':'))
    except (ValueError,TypeError) as exc:
        raise ValidationError('E-STORAGE','Dados locais contêm valor não serializável ou não finito.') from exc
    if len(text.encode())>max_bytes:
        raise ValidationError('E-STORAGE','Registro excede o limite de armazenamento.')
    return text


class LocalStore:
    def __init__(self, root:Path|None=None):
        self.root=Path(root or user_data_dir()).resolve()
        self.root.mkdir(parents=True,exist_ok=True,mode=0o700)
        self.db_path=self.root/'state.sqlite3'
        self.backups=self.root/'backups';self.backups.mkdir(exist_ok=True,mode=0o700)
        self._mutex=threading.RLock()
        with self._locked():
            if not self.db_path.exists():
                with self._connection() as db:
                    db.executescript(SCHEMA_SQL)
                    db.execute(f'PRAGMA application_id={APP_ID}')
                    db.execute(f'PRAGMA user_version={SCHEMA}')
                if os.name!='nt':self.db_path.chmod(0o600)

    @contextmanager
    def _locked(self):
        with self._mutex:
            with open(self.root/'state.lock','a+b') as handle:
                handle.seek(0,2)
                if handle.tell()==0:handle.write(b'0');handle.flush()
                deadline=time.monotonic()+10
                acquired=False
                while not acquired:
                    try:
                        handle.seek(0)
                        if os.name=='nt':
                            import msvcrt
                            msvcrt.locking(handle.fileno(),msvcrt.LK_NBLCK,1)
                        else:
                            import fcntl
                            fcntl.flock(handle.fileno(),fcntl.LOCK_EX|fcntl.LOCK_NB)
                        acquired=True
                    except OSError:
                        if time.monotonic()>deadline:
                            raise ValidationError('E-STORAGE','Dados ocupados por outra instância; tente novamente.')
                        time.sleep(.05)
                try:yield
                finally:
                    if os.name=='nt':
                        import msvcrt
                        handle.seek(0);msvcrt.locking(handle.fileno(),msvcrt.LK_UNLCK,1)
                    else:
                        import fcntl
                        fcntl.flock(handle.fileno(),fcntl.LOCK_UN)

    @contextmanager
    def _connection(self):
        db=sqlite3.connect(str(self.db_path),timeout=10)
        db.row_factory=sqlite3.Row
        db.execute('PRAGMA foreign_keys=ON')
        try:
            yield db
            db.commit()
        except BaseException:
            db.rollback();raise
        finally:db.close()

    @staticmethod
    def _validate(path:Path):
        """Validate a consistent read-only snapshot without initializing a store."""
        try:
            db=sqlite3.connect(path.as_uri()+'?mode=ro',uri=True)
            try:
                db.execute('BEGIN')
                if db.execute('PRAGMA application_id').fetchone()[0]!=APP_ID or db.execute('PRAGMA user_version').fetchone()[0]!=SCHEMA:
                    raise ValueError('versão incompatível')
                if db.execute('PRAGMA integrity_check').fetchone()[0]!='ok':raise ValueError('integridade')
                if db.execute("SELECT count(*) FROM sqlite_master WHERE type IN ('trigger','view')").fetchone()[0]:raise ValueError('objetos não permitidos')
                tables={x[0] for x in db.execute("SELECT name FROM sqlite_master WHERE type='table'")}
                if tables!={'records','revisions','datasets','active_datasets','events'}:raise ValueError('esquema')
                for raw, in db.execute('SELECT payload FROM revisions'):
                    if not isinstance(json.loads(raw),dict):raise ValueError('registro')
                for content,digest,original,metadata in db.execute('SELECT content,hash,original_content,metadata FROM datasets'):
                    if sha256(content).hexdigest()!=digest:raise ValueError('histórico')
                    meta=json.loads(metadata)
                    if not isinstance(meta,dict):raise ValueError('metadados')
                    if original is not None and meta.get('raw_source_sha256') != sha256(original).hexdigest():raise ValueError('fonte original')
                if db.execute('SELECT count(*) FROM active_datasets a LEFT JOIN datasets d ON d.kind=a.kind AND d.hash=a.hash WHERE d.hash IS NULL').fetchone()[0]:raise ValueError('referência ativa ausente')
                if db.execute('SELECT count(*) FROM records r LEFT JOIN revisions v ON v.record_id=r.id AND v.revision=r.revision WHERE v.record_id IS NULL').fetchone()[0]:raise ValueError('revisão ausente')
            finally:db.close()
        except (sqlite3.Error, ValueError, TypeError, OSError) as exc:
            raise ValidationError('E-STORAGE','Base local inválida ou incompatível. Preserve os arquivos e utilize um backup válido.') from exc

    def check(self):
        with self._locked():self._validate(self.db_path)
        return {'ok':True,'schema':SCHEMA,'path':str(self.root)}

    @staticmethod
    def _save_operation_receipt(db,kind,operation_id,operation_sha256):
        if not isinstance(operation_id,str) or not re.fullmatch(r'[0-9a-f]{32}',operation_id):
            raise ValidationError('E-STORAGE','Identidade de gravação inválida.')
        if not isinstance(operation_sha256,str) or not re.fullmatch(r'[0-9a-f]{64}',operation_sha256):
            raise ValidationError('E-STORAGE','Hash da solicitação de gravação inválido.')
        row=db.execute('SELECT details FROM events WHERE event=? ORDER BY id LIMIT 1',
                       ('save_operation:'+operation_id,)).fetchone()
        if row is None:return None
        receipt=json.loads(row['details'])
        if receipt.get('kind')!=kind or receipt.get('request_sha256')!=operation_sha256:
            raise ValidationError('E-CONFLICT','Identidade de gravação reutilizada com conteúdo diferente.')
        return {**receipt['saved'],'operation_replayed':True}

    def saved_operation(self,kind,operation_id,operation_sha256):
        """Read a receipt committed atomically with its immutable record revision."""
        with self._locked():
            self._validate(self.db_path)
            with self._connection() as db:
                return self._save_operation_receipt(db,kind,operation_id,operation_sha256)

    def save_record(self,kind:str,name:str,payload:dict,*,record_id=None,expected_revision=None,consent=False,
                    operation_id=None,operation_sha256=None,payload_max_bytes=4*1024*1024):
        if not consent:raise ValidationError('E-CONSENT','É necessário consentimento para gravar dados pessoais localmente.')
        if kind not in KINDS or not isinstance(payload,dict):raise ValidationError('E-STORAGE','Tipo de registro inválido.')
        name=str(name).strip()
        if not name or len(name)>120:raise ValidationError('E-STORAGE','Informe um nome de até 120 caracteres.')
        raw=safe_json(payload,max_bytes=payload_max_bytes);when=utc_now()
        with self._locked():
            self._validate(self.db_path)
            with self._connection() as db:
                db.execute('BEGIN IMMEDIATE')
                if operation_id is not None or operation_sha256 is not None:
                    previous=self._save_operation_receipt(db,kind,operation_id,operation_sha256)
                    if previous is not None:return previous
                if record_id:
                    old=db.execute('SELECT * FROM records WHERE id=?',(record_id,)).fetchone()
                    if old is None or old['kind']!=kind:raise ValidationError('E-STORAGE','Registro não encontrado.')
                    if expected_revision!=old['revision']:raise ValidationError('E-CONFLICT','A operação foi modificada. Reabra antes de salvar novamente.')
                    rev=old['revision']+1
                    db.execute('UPDATE records SET revision=?,name=?,updated_at=? WHERE id=?',(rev,name,when,record_id))
                else:
                    record_id=uuid.uuid4().hex;rev=1
                    db.execute('INSERT INTO records VALUES(?,?,?,?,?,?)',(record_id,kind,name,rev,when,when))
                db.execute('INSERT INTO revisions VALUES(?,?,?,?)',(record_id,rev,raw,when))
                db.execute('INSERT INTO events(event,details,created_at) VALUES(?,?,?)',('save_record',safe_json({'id':record_id,'revision':rev}),when))
                saved={'id':record_id,'revision':rev,'name':name,'kind':kind,'created_at':when}
                if operation_id is not None:
                    receipt={'kind':kind,'request_sha256':operation_sha256,'saved':saved}
                    db.execute('INSERT INTO events(event,details,created_at) VALUES(?,?,?)',
                               ('save_operation:'+operation_id,safe_json(receipt),when))
        return saved

    def get_record(self,record_id,revision=None):
        with self._locked(),self._connection() as db:
            row=db.execute('SELECT * FROM records WHERE id=?',(str(record_id),)).fetchone()
            if row is None:raise ValidationError('E-STORAGE','Registro não encontrado.')
            rev=row['revision'] if revision is None else int(revision)
            data=db.execute('SELECT payload,created_at FROM revisions WHERE record_id=? AND revision=?',(record_id,rev)).fetchone()
            if data is None:raise ValidationError('E-STORAGE','Revisão não encontrada.')
            return {**dict(row),'revision':rev,'payload':json.loads(data['payload']),'revision_at':data['created_at']}

    def list_records(self,kind):
        if kind not in KINDS:raise ValidationError('E-STORAGE','Tipo inválido.')
        with self._locked(),self._connection() as db:
            return [dict(x) for x in db.execute('SELECT * FROM records WHERE kind=? ORDER BY updated_at DESC LIMIT 1000',(kind,))]

    def workspace_recovery(self):
        """A single opt-in recovery slot, separate from immutable saved records."""
        with self._locked(), self._connection() as db:
            row = db.execute("SELECT details,created_at FROM events WHERE event='workspace_recovery_v1' ORDER BY id DESC LIMIT 1").fetchone()
            return {**json.loads(row['details']), 'updated_at': row['created_at']} if row else {
                'enabled': False, 'revision': 0, 'token': None, 'draft': None, 'updated_at': None}

    def save_workspace_recovery(self, *, enabled, draft, expected_revision, expected_token=None, consent=False):
        if type(enabled) is not bool or type(expected_revision) is not int or expected_revision < 0:
            raise ValidationError('E-RECOVERY', 'Configuração de recuperação inválida.')
        if enabled and consent is not True:
            raise ValidationError('E-CONSENT', 'Ative a recuperação para guardar uma cópia do rascunho neste computador.')
        if enabled:
            if (not isinstance(draft, dict) or type(draft.get('version')) is not int or draft['version'] != 1
                    or set(draft) - {'version','workspace','analysis','ui'}
                    or any(not isinstance(draft.get(key),dict) for key in ('workspace','analysis','ui'))):
                raise ValidationError('E-RECOVERY', 'Formato de rascunho incompatível; os registros salvos foram preservados.')
            workspace = draft['workspace']
            if (not isinstance(workspace.get('form'),dict) or not isinstance(workspace.get('criteria'),list)
                    or not isinstance(workspace.get('alternatives'),list)):
                raise ValidationError('E-RECOVERY', 'Campos de recuperação incompatíveis; a cópia anterior foi preservada.')
            def check(value, depth=0):
                if depth > 24: raise ValidationError('E-RECOVERY', 'Rascunho muito complexo.')
                if isinstance(value, dict):
                    if any(key in ('__proto__','prototype','constructor') for key in value):
                        raise ValidationError('E-RECOVERY', 'Campo de rascunho inválido.')
                    for item in value.values(): check(item, depth+1)
                elif isinstance(value, list):
                    for item in value: check(item, depth+1)
            check(draft)
            if len(safe_json(draft).encode('utf-8')) > 512*1024:
                raise ValidationError('E-RECOVERY', 'Rascunho excede 512 KB. Salve a análise explicitamente para preservar este trabalho.')
        value = {'enabled': enabled, 'draft': draft if enabled else None, 'revision': expected_revision+1, 'token': uuid.uuid4().hex}
        when = utc_now()
        with self._locked():
            self._validate(self.db_path)
            with self._connection() as db:
                db.execute('BEGIN IMMEDIATE')
                row = db.execute("SELECT id,details FROM events WHERE event='workspace_recovery_v1' ORDER BY id DESC LIMIT 1").fetchone()
                previous = json.loads(row['details']) if row else {'revision':0,'token':None}
                if previous['revision'] != expected_revision or previous.get('token') != expected_token:
                    raise ValidationError('E-CONFLICT', 'O rascunho de recuperação mudou em outra aba ou após uma restauração. Escolha qual trabalho manter.')
                if row:
                    db.execute('UPDATE events SET details=?,created_at=? WHERE id=?', (safe_json(value),when,row['id']))
                else:
                    db.execute('INSERT INTO events(event,details,created_at) VALUES(?,?,?)', ('workspace_recovery_v1',safe_json(value),when))
        return {**value, 'updated_at': when}

    def dataset(self,kind,version_hash=None):
        with self._locked(),self._connection() as db:
            if version_hash is None:
                a=db.execute('SELECT hash FROM active_datasets WHERE kind=?',(kind,)).fetchone()
                if a is None:return None
                version_hash=a[0]
            row=db.execute('SELECT * FROM datasets WHERE kind=? AND hash=?',(kind,version_hash)).fetchone()
            if row is None:raise ValidationError('E-STORAGE','Versão de base não encontrada.')
            data=dict(row);data['metadata']=json.loads(data['metadata']);return data

    def dataset_versions(self,kind):
        with self._locked(),self._connection() as db:
            return [{**dict(x),'metadata':json.loads(x['metadata'])} for x in db.execute('SELECT kind,hash,metadata,created_at FROM datasets WHERE kind=? ORDER BY created_at DESC',(kind,))]

    @staticmethod
    def _update_outcome(db,identity):
        if not isinstance(identity,str) or not re.fullmatch(r'[0-9a-f]{32}',identity):
            raise ValidationError('E-SESSION','Identidade de prévia inválida.')
        row=db.execute('SELECT details FROM events WHERE event=? ORDER BY id LIMIT 1',
                       ('dataset_update:'+identity,)).fetchone()
        return json.loads(row['details']) if row is not None else None

    def update_outcome(self,identity):
        """Read a terminal receipt from the current database/backup timeline."""
        with self._locked(),self._connection() as db:
            return self._update_outcome(db,identity)

    def cancel_dataset_update(self,identity):
        with self._locked():
            self._validate(self.db_path)
            with self._connection() as db:
                db.execute('BEGIN IMMEDIATE')
                previous=self._update_outcome(db,identity)
                if previous is not None:return previous
                outcome={'id':identity,'status':'cancelled'}
                db.execute('INSERT INTO events(event,details,created_at) VALUES(?,?,?)',
                           ('dataset_update:'+identity,safe_json(outcome),utc_now()))
                return outcome

    def commit_dataset(self,kind,content:bytes,metadata:dict,*,expected_hash,original_content=None,
                       source_archive=None,import_receipt=None,update_id=None):
        if kind not in {'market','calendar','vni','benchmark','intraday','comparison','market_sim','market_sim_indexes'}:raise ValidationError('E-STORAGE','Tipo de base inválido.')
        if len(content)>60*1024*1024:raise ValidationError('E-STORAGE','Base excede o limite.')
        metadata=dict(metadata)
        if original_content is not None:
            if len(original_content)>60*1024*1024:raise ValidationError('E-STORAGE','Fonte original excede o limite.')
            metadata['raw_source_sha256']=sha256(original_content).hexdigest()
        archive_kind=archive_hash=archive_metadata_json=None
        archive_content=None
        if source_archive is not None:
            if kind!='market_sim_indexes' or not isinstance(source_archive,dict):
                raise ValidationError('E-STORAGE','Arquivo original separado só pode acompanhar a atualização de índices.')
            archive_kind=source_archive.get('kind')
            archive_content=source_archive.get('content')
            archive_metadata=source_archive.get('metadata')
            if (archive_kind not in {'sidra_xlsx_original','ibge_ipca_original'} or not isinstance(archive_content,bytes)
                    or not archive_content or len(archive_content)>60*1024*1024 or not isinstance(archive_metadata,dict)):
                raise ValidationError('E-STORAGE','Arquivo original de índices ou seus metadados são inválidos.')
            archive_hash=sha256(archive_content).hexdigest()
            archive_metadata={**archive_metadata,'original_sha256':archive_hash}
            archive_metadata_json=safe_json(archive_metadata)
            if import_receipt is None or not isinstance(import_receipt,dict):
                raise ValidationError('E-STORAGE','Recibo de atualização de índices ausente.')
        elif import_receipt is not None:
            raise ValidationError('E-STORAGE','Recibo de atualização requer arquivo original separado.')
        digest=sha256(content).hexdigest();raw=safe_json(metadata);when=utc_now()
        request_hash=sha256(safe_json({'kind':kind,'hash':digest,'metadata':metadata,'expected_hash':expected_hash,
            'original_sha256':sha256(original_content).hexdigest() if original_content is not None else None,
            'archive_kind':archive_kind,'archive_hash':archive_hash}).encode('utf-8')).hexdigest()
        with self._locked():
            self._validate(self.db_path)
            with self._connection() as db:
                db.execute('BEGIN IMMEDIATE')
                if update_id is not None:
                    previous=self._update_outcome(db,update_id)
                    if previous is not None:
                        if previous['status']!='already_committed':
                            raise ValidationError('E-SESSION','A prévia foi cancelada; prepare novamente.')
                        if previous['request_sha256']!=request_hash:
                            raise ValidationError('E-CONFLICT','Identidade de atualização reutilizada com conteúdo diferente.')
                        return {**previous['result'],'confirmation_replayed':True}
                current=db.execute('SELECT hash FROM active_datasets WHERE kind=?',(kind,)).fetchone()
                actual=current[0] if current else None
                if actual!=expected_hash:raise ValidationError('E-CONFLICT','A base mudou durante a preparação. Refaça a prévia.')
                if archive_kind is not None:
                    db.execute('INSERT OR IGNORE INTO datasets(kind,hash,content,metadata,created_at,original_content) VALUES(?,?,?,?,?,NULL)',
                               (archive_kind,archive_hash,archive_content,archive_metadata_json,when))
                    archived=db.execute('SELECT metadata,created_at FROM datasets WHERE kind=? AND hash=?',
                                         (archive_kind,archive_hash)).fetchone()
                    archived_metadata=json.loads(archived['metadata'])
                    archived_created_at=archived['created_at']
                db.execute('INSERT OR IGNORE INTO datasets(kind,hash,content,metadata,created_at,original_content) VALUES(?,?,?,?,?,?)',
                           (kind,digest,content,raw,when,original_content))
                stored=db.execute('SELECT metadata,created_at FROM datasets WHERE kind=? AND hash=?',(kind,digest)).fetchone()
                stored_metadata=json.loads(stored['metadata'])
                stored_created_at=stored['created_at']
                db.execute('INSERT INTO active_datasets VALUES(?,?) ON CONFLICT(kind) DO UPDATE SET hash=excluded.hash',(kind,digest))
                db.execute('INSERT INTO events(event,details,created_at) VALUES(?,?,?)',
                           ('dataset',safe_json({'kind':kind,'from':actual,'to':digest}),when))
                if archive_kind is not None:
                    receipt={
                        **import_receipt,
                        'original':{'kind':archive_kind,'sha256':archive_hash,
                                    'stored_metadata':archived_metadata,'stored_created_at':archived_created_at},
                        'normalized':{'kind':kind,'hash':digest,
                                      'stored_metadata':stored_metadata,'stored_created_at':stored_created_at},
                    }
                    db.execute('INSERT INTO events(event,details,created_at) VALUES(?,?,?)',
                               ('sidra_xlsx_import' if archive_kind=='sidra_xlsx_original' else 'ibge_ipca_import',safe_json(receipt),when))
                result={'kind':kind,'hash':digest,'metadata':stored_metadata,'created_at':stored_created_at}
                if archive_kind is not None:result['import_receipt']=receipt
                if update_id is not None:
                    outcome={'id':update_id,'status':'already_committed','request_sha256':request_hash,'result':result}
                    db.execute('INSERT INTO events(event,details,created_at) VALUES(?,?,?)',
                               ('dataset_update:'+update_id,safe_json(outcome),when))
        return result

    def backup_path(self,backup_id):
        if not isinstance(backup_id,str) or not re.fullmatch('[a-f0-9]{32}',backup_id):
            raise ValidationError('E-BACKUP','Identificador de backup inválido.')
        return self.backups/(backup_id+'.sqlite3')

    def _backup_locked(self,reason='manual'):
        self._validate(self.db_path)
        identity=uuid.uuid4().hex;p=self.backup_path(identity);tmp=p.with_suffix('.tmp')
        try:
            with self._connection() as src:
                dest=sqlite3.connect(str(tmp))
                try:src.backup(dest)
                finally:dest.close()
            self._validate(tmp)
            digest=sha256(tmp.read_bytes()).hexdigest();os.replace(tmp,p)
            meta={'id':identity,'created_at':utc_now(),'reason':reason,'sha256':digest,'bytes':p.stat().st_size,'schema':SCHEMA}
            p.with_suffix('.json').write_text(safe_json(meta),encoding='utf8')
            return meta
        finally:
            if tmp.exists():tmp.unlink()

    def create_backup(self,reason='manual'):
        with self._locked():return self._backup_locked(reason)

    def list_backups(self):
        results=[]
        for p in self.backups.glob('*.json'):
            try:
                meta=json.loads(p.read_text(encoding='utf8'))
                if self.backup_path(meta['id']).is_file():results.append(meta)
            except (OSError,ValueError,KeyError,ValidationError):continue
        return sorted(results,key=lambda x:x['created_at'],reverse=True)

    def export_backup(self):
        """Portable copy; never exposes arbitrary server paths."""
        with self._locked():
            meta=self._backup_locked('cópia portátil')
            raw=self.backup_path(meta['id']).read_bytes()
            if len(raw)>128*1024*1024:
                raise ValidationError('E-SIZE','Base maior que 128 MB. Use a pasta de backups indicada em Dados locais.')
            target=io.BytesIO()
            with zipfile.ZipFile(target,'w',compression=zipfile.ZIP_DEFLATED) as archive:
                archive.writestr('state.sqlite3',raw)
                archive.writestr('manifest.json',safe_json({'format':'RENDA_BACKUP_V1',**meta}))
            content=target.getvalue()
            if len(content)>60*1024*1024:
                raise ValidationError('E-SIZE','Cópia compactada maior que 60 MB. Use a pasta de backups indicada em Dados locais.')
            return {'filename':'tesouro-backup-'+meta['id']+'.zip','metadata':meta,
                    'content_base64':base64.b64encode(content).decode('ascii'),
                    'package_sha256':sha256(content).hexdigest()}

    def import_backup(self,content):
        """Validate in quarantine, then register a new local copy; no activation."""
        if not isinstance(content,bytes) or not content or len(content)>60*1024*1024:
            raise ValidationError('E-BACKUP','Escolha uma cópia portátil ZIP de até 60 MB.')
        temporary=None
        with self._locked():
            try:
                with zipfile.ZipFile(io.BytesIO(content)) as archive:
                    entries=archive.infolist()
                    if len(entries)!=2 or {e.filename for e in entries}!={'state.sqlite3','manifest.json'}:
                        raise ValueError('entries')
                    for entry in entries:
                        limit=128*1024*1024 if entry.filename=='state.sqlite3' else 16*1024
                        if entry.file_size>limit or entry.flag_bits&1:raise ValueError('size')
                    manifest=json.loads(archive.read('manifest.json'))
                    raw=archive.read('state.sqlite3')
                digest=sha256(raw).hexdigest()
                if (manifest.get('format')!='RENDA_BACKUP_V1' or manifest.get('schema')!=SCHEMA
                        or manifest.get('sha256')!=digest or manifest.get('bytes')!=len(raw)):
                    raise ValueError('manifest')
                identity=uuid.uuid4().hex
                destination=self.backup_path(identity);temporary=destination.with_suffix('.tmp')
                temporary.write_bytes(raw)
                self._validate(temporary)
                meta={'id':identity,'created_at':utc_now(),'reason':'cópia portátil importada e verificada',
                      'sha256':digest,'bytes':len(raw),'schema':SCHEMA}
                destination.with_suffix('.json').write_text(safe_json(meta),encoding='utf8')
                os.replace(temporary,destination)
                return {**meta,'verified':True,'activated':False}
            except (OSError,ValueError,KeyError,TypeError,AttributeError,RuntimeError,RecursionError,NotImplementedError,zipfile.BadZipFile,ValidationError) as exc:
                raise ValidationError('E-BACKUP','Cópia inválida, incompatível ou corrompida. A base atual foi preservada. Escolha o ZIP exportado pelo programa.') from exc
            finally:
                if temporary is not None and temporary.exists():temporary.unlink()

    @staticmethod
    def _renew_recovery_token(path):
        try:
            with closing(sqlite3.connect(str(path))) as db, db:
                row = db.execute("SELECT id,details FROM events WHERE event='workspace_recovery_v1' ORDER BY id DESC LIMIT 1").fetchone()
                if row is None:
                    return
                identity, details = row
                value = json.loads(details)
                if not isinstance(value, dict) or type(value.get('revision')) is not int or value['revision'] < 1:
                    raise ValueError('revisão de recuperação inválida')
                value.update(revision=value['revision']+1, token=uuid.uuid4().hex)
                db.execute('UPDATE events SET details=?,created_at=? WHERE id=?', (safe_json(value), utc_now(), identity))
        except (sqlite3.Error, ValueError, RecursionError, ValidationError) as exc:
            raise ValidationError('E-BACKUP','Não foi possível preparar o rascunho da cópia. A base atual foi preservada.') from exc

    def restore_backup(self,backup_id,*,confirmed=False):
        if not confirmed:
            raise ValidationError('E-CONSENT','Para restaurar, confirme a substituição dos dados atuais.')
        with self._locked():
            backup_path = self.backup_path(backup_id)
            try:
                metadata = json.loads(backup_path.with_suffix('.json').read_text(encoding='utf8'))
                digest = sha256(backup_path.read_bytes()).hexdigest()
                if digest != metadata['sha256']:
                    raise ValueError('hash')
            except (OSError,KeyError,ValueError) as exc:
                raise ValidationError('E-BACKUP','Backup ausente ou corrompido. Base atual preservada.') from exc
            self._validate(backup_path)
            try:
                before = self._backup_locked('antes da restauração')
            except ValidationError:
                # Preservar até uma base danificada antes da recuperação.
                damaged = self.root / ('state_danificado_' + uuid.uuid4().hex + '.sqlite3')
                shutil.copy2(self.db_path, damaged)
                before = {'quarantine': damaged.name}
            fd, name = tempfile.mkstemp(prefix='restore_',suffix='.sqlite3',dir=self.root)
            os.close(fd)
            temporary_path = Path(name)
            try:
                shutil.copyfile(backup_path, temporary_path)
                self._validate(temporary_path)
                # Invalidate writers using the restored token before the database swap.
                self._renew_recovery_token(temporary_path)
                with temporary_path.open('r+b') as handle:
                    handle.flush()
                    os.fsync(handle.fileno())
                os.replace(temporary_path, self.db_path)
            finally:
                if temporary_path.exists():
                    temporary_path.unlink()
            return {'restored':backup_id,'previous':before}
