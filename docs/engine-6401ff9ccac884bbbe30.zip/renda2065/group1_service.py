"""Serviço do grupo 1. Mesma fotografia alimenta gráficos, auditoria e persistência."""
from __future__ import annotations
from collections import OrderedDict
from dataclasses import asdict,replace,is_dataclass
from datetime import date,datetime,timedelta
from decimal import Decimal as D
from hashlib import sha256
from pathlib import Path
from threading import RLock
from zoneinfo import ZoneInfo
import json
import math
import re
import uuid
import numpy as np
from .models import ValidationError,VERSION
from .storage import LocalStore,safe_json
from .market_sim.memo import scoped_calculation
from .csv_loader import load_treasury_csv
from .calendar_data import parse_calendar_pack
from .calendar_rules import FinancialCalendar
from .market_data import prepare_history,download_official,parse_vni_csv,OFFICIAL_URL
from .controller import build_request,ANCHORS
from .analysis_service import build_analysis
from .policies import policy_manifest,PROFILES,RULES
from .formatting import parse_number,parse_rates
from .pricing import PricingEngine,solve_yield
from .reconciliation import reconcile,compare_vni
from .sensitivity import sensitivity_at_date
from .charts import condition_chart,profit_chart,PLOT_CONFIG

ROOT=Path(__file__).resolve().parents[1]
TZ=ZoneInfo('America/Sao_Paulo')
DATE_KEYS=('asof','trade','settlement','release','start','end','a_date','a_known','q_date','q_settle')


def json_ready(x):
    if is_dataclass(x):return json_ready(asdict(x))
    if isinstance(x,(date,datetime)):return x.isoformat()
    if isinstance(x,D):return float(x)
    if isinstance(x,dict):return {str(k):json_ready(v) for k,v in x.items()}
    if isinstance(x,(tuple,list)):return [json_ready(v) for v in x]
    if isinstance(x,np.ndarray):return json_ready(x.tolist())
    if isinstance(x,(np.integer,)):return int(x)
    if isinstance(x,(float,np.floating)):return float(x) if math.isfinite(x) else None
    return x


def _canonical_hash(value):
    raw=json.dumps(value,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False).encode('utf-8')
    return sha256(raw).hexdigest()


def _resolved_ipca_fingerprint(fingerprint, sources):
    identities=[]
    def visit(value, path=''):
        if isinstance(value,dict):
            for key,item in value.items():
                if key=='ipca_monthly_cache_sha256':identities.append((path,item))
                else:visit(item,path+'/'+key)
        elif isinstance(value,(tuple,list)):
            for index,item in enumerate(value):visit(item,path+'/'+str(index))
    visit(sources)
    return _canonical_hash({'input_fingerprint':fingerprint,'monthly_ipca_sources':sorted(identities)}) if identities else fingerprint


def _g5_fiscal_alternative_input(base_input, fiscal_config, sale_day):
    """Build the AC05 tax-date alternative from its explicit frozen rate basis."""
    from copy import deepcopy

    native=deepcopy(base_input)
    native['sale_date']=sale_day.isoformat() if isinstance(sale_day,date) else str(sale_day)
    native['exit_price']={
        'mode':'MANUAL_RATE',
        'annual_real_rate':str(fiscal_config['real_rate']),
        'quoted_side':'SELL',
    }
    native['assumptions']=dict(native.get('assumptions') or {})
    projection=deepcopy(fiscal_config['inflation_projection'])
    for field in ('annual_rate','anchor_level'):
        projection[field]=str(projection[field])
    anchor_date=projection['anchor_date']
    projection['anchor_date']=anchor_date.isoformat() if isinstance(anchor_date,date) else str(anchor_date)
    native['assumptions']['inflation_projection']=projection
    return native


def _g5_cached_evaluation(evaluation_cache, budget, basis_id, input_fingerprint, build):
    """Reuse one result only for the same G5 basis and financial fingerprint."""
    key=(basis_id,input_fingerprint)
    if key in evaluation_cache:
        cached=evaluation_cache[key]
        budget.record_cache_hit(
            basis_id=basis_id,input_fingerprint=input_fingerprint,
            cached_outcome=cached.get('status','unknown'),
        )
        return cached
    record=build()
    # A refusal says that no calculation was admitted. Do not turn that
    # absence into a cache hit if this point is requested again in the ledger.
    if record.get('status')!='not_evaluated' and record.get('completed_after_deadline') is not True:
        evaluation_cache[key]=record
    return record


def _g5_direct_attempt_outcome(budget, direct_called, evaluation):
    """Classify admission and timing before a direct value reaches consumers."""
    if not direct_called:
        reason_code=budget.reason or 'EVALUATION_LIMIT'
        return {
            'status':'not_evaluated','evaluation':None,'completed_after_deadline':False,
            'reason':{
                'code':reason_code,
                'message':'O orcamento G5 terminou antes da admissao da avaliacao direta.',
            },
        }
    if budget.last_direct_attempt_completed_after_deadline is True:
        return {
            'status':'partial','evaluation':None,'completed_after_deadline':True,
            'reason':{
                'code':'DEADLINE_EXCEEDED',
                'message':'A avaliacao direta terminou depois do prazo e nao certifica este ponto.',
            },
        }
    if evaluation is None:
        return {
            'status':'partial','evaluation':None,'completed_after_deadline':False,
            'reason':{
                'code':'G5_DIRECT_EVALUATION_UNAVAILABLE',
                'message':'A chamada direta nao produziu um resultado certificavel.',
            },
        }
    return {
        'status':'ready','evaluation':evaluation,'completed_after_deadline':False,'reason':None,
    }


def _g5_evaluate_after_resolution(budget, basis_id, input_fingerprint, *, evaluator):
    """Use the request budget for the exact resolved-evaluation admission seam."""
    direct_called,evaluation=budget.evaluate_direct(
        basis_id=basis_id,input_fingerprint=input_fingerprint,evaluator=evaluator,
    )
    return _g5_direct_attempt_outcome(budget,direct_called,evaluation)


def _g5_comparison_case_unavailable_row(case, *, reference=False):
    """Keep non-evaluated and late results out of fixed-position comparison."""
    fallback={
        'code':'G5_REFERENCE_UNAVAILABLE' if reference else 'G5_POINT_UNAVAILABLE',
        'message':'A referencia nao ficou disponivel.' if reference else 'Ponto sem avaliacao direta.',
    }
    if case is None:
        return {'status':'UNKNOWN','reason':fallback}
    if case.get('evaluation') is None:
        return {'status':'UNKNOWN','reason':case.get('reason') or fallback}
    return None


def _g5_fiscal_day_from_comparison(row, *, expected_holding_days, sale_day):
    """Keep fiscal coverage tied to a ready, reconciliable comparison row."""
    from copy import deepcopy

    if not isinstance(row,dict):
        return {
            'status':'UNKNOWN',
            'reason':{'code':'G5_FISCAL_DAY_UNAVAILABLE','message':'O dia fiscal nao produziu uma comparacao.'},
        }
    operation=row.get('operation')
    operation=operation if isinstance(operation,dict) else {}
    dates=row.get('dates')
    dates=dates if isinstance(dates,dict) else {}
    resources=row.get('total_resources_at_horizon')
    resources=resources if isinstance(resources,dict) else {}
    detail={
        'holding_days':operation.get('holding_days'),
        'availability_date':dates.get('cash_available_at'),
        'operation':deepcopy(operation),
        'total_resources_at_horizon':resources.get('value'),
    }
    if row.get('status')=='UNKNOWN':
        return {
            'status':'UNKNOWN',**detail,
            'reason':deepcopy(row.get('reason') or {
                'code':'G5_FISCAL_DAY_UNAVAILABLE','message':'O dia fiscal nao ficou avaliado.'
            }),
        }
    if row.get('status')!='ready':
        return {
            'status':'partial',**detail,
            'reason':deepcopy(row.get('reason') or {
                'code':'G5_FISCAL_COMPARISON_PARTIAL','message':'A comparacao do dia fiscal nao ficou reconciliavel.'
            }),
        }
    if not operation or detail['availability_date'] is None or detail['total_resources_at_horizon'] is None:
        return {
            'status':'partial',**detail,
            'reason':deepcopy(row.get('reason') or {
                'code':'G5_FISCAL_RECONCILIATION_UNAVAILABLE',
                'message':'O dia fiscal nao tem operacao, disponibilidade e patrimonio reconciliados.',
            }),
        }
    observed=detail['holding_days']
    if observed != expected_holding_days:
        return {
            'status':'inconsistent',**detail,
            'reason':{
                'code':'G5_FISCAL_HOLDING_PERIOD_MISMATCH',
                'message':f"A data fiscal {sale_day.isoformat()} produziu {observed} dias; esperados {expected_holding_days}.",
            },
        }
    return {'status':'ready',**detail,'reason':None}


_G5_FISCAL_BRIDGE_FIELDS=frozenset({
    'income_tax_rate_day_180','income_tax_rate_day_181',
    'taxable_base_day_180_brl','taxable_base_day_181_brl',
    'tax_at_day_181_base_and_day_180_rate_brl','tax_base_effect_brl',
    'rate_change_benefit_brl','net_tax_reduction_brl','gross_change_brl',
    'iof_change_brl','custody_change_brl','exit_expense_change_brl',
    'cash_timing_effect_brl','wealth_advantage_change_brl',
    'reconciled_delta_brl','observed_residual_brl',
})


def _g5_fiscal_pair_bridge(days, fiscal_config, bridge_builder):
    """Call the fiscal bridge only after both expected days are reconciled."""
    if len(days)!=2 or any(day.get('status')!='ready' for day in days):
        return {
            'status':'partial',
            'bridge':{
                'status':'partial',
                'reason':{
                    'code':'G5_FISCAL_PAIR_UNAVAILABLE',
                    'message':'O par fiscal nao ficou completamente avaliado e reconciliado.',
                    'days':[
                        {'status':day.get('status'),'reason':day.get('reason')}
                        for day in days
                    ],
                },
            },
        }
    day180,day181=days
    bridge=bridge_builder(
        day180['operation'],day181['operation'],
        day180_total_at_horizon=day180['total_resources_at_horizon'],
        day181_total_at_horizon=day181['total_resources_at_horizon'],
        day180_availability=day180['availability_date'],
        day181_availability=day181['availability_date'],
        common_horizon=fiscal_config['common_horizon'],
        cash_growth_rate=fiscal_config['cash_growth_rate'],
    )
    if not isinstance(bridge,dict) or not _G5_FISCAL_BRIDGE_FIELDS.issubset(bridge):
        bridge=dict(bridge) if isinstance(bridge,dict) else {}
        bridge['status']='partial'
        bridge.setdefault('reason',{
            'code':'G5_FISCAL_BRIDGE_UNAVAILABLE',
            'message':'A ponte fiscal nao produziu a estrutura reconciliada esperada.',
        })
        return {'status':'partial','bridge':bridge}
    return {'status':'ready','bridge':bridge}


def _g5_fiscal_transition_result(days, fiscal_config, bridge_builder, validation_error_type):
    """Map comparisons' validation failures to the public partial fiscal result."""
    try:
        return _g5_fiscal_pair_bridge(days,fiscal_config,bridge_builder)
    except validation_error_type as exc:
        return {
            'status':'partial',
            'bridge':{'status':'partial','reason':{'code':exc.code,'message':str(exc)}},
        }


def _g5_fiscal_coverage_count(days):
    """Count only fiscal days with usable, reconciled outcome evidence."""
    return sum(isinstance(day,dict) and day.get('status')=='ready' for day in days)


def _simulator_source_versions(value):
    versions=set()
    def visit(item):
        if isinstance(item,dict):
            pinned=item.get('source_versions')
            if isinstance(pinned,dict):
                for kind,digest in pinned.items():
                    if kind in {'market_sim','market_sim_indexes'} and isinstance(digest,str) and re.fullmatch(r'[0-9a-f]{64}',digest):
                        versions.add((kind,digest))
            source=item.get('source_id')
            digest=item.get('sha256') or item.get('version')
            kind={'USER_SUPPLIED_TREASURY_CSV':'market_sim','USER_SUPPLIED_INDEX_CSV':'market_sim_indexes'}.get(source)
            if kind and isinstance(digest,str) and re.fullmatch(r'[0-9a-f]{64}',digest):
                versions.add((kind,digest))
            for child in item.values():visit(child)
        elif isinstance(item,(tuple,list)):
            for child in item:visit(child)
        elif isinstance(item,str):
            match=re.search(r'conhecimento declarado .*?vers[aã]o ([0-9a-f]{64})',item,re.IGNORECASE)
            if match:versions.add(('market_sim_indexes',match.group(1).lower()))
    visit(value)
    return [{'kind':kind,'hash':digest} for kind,digest in sorted(versions)]


def form_defaults(today):
    return dict(mode='Compra real',anchor_mode=ANCHORS[0],asof=today.isoformat(),trade='',settlement='',
      selected=None,entry_fee='0',inflation='4',target='10,9',qmode='Quantidade',quantity='',pu='',basis='',entry_yield='',release='',intermediate=False,
      start='',end='',rates='6,8; 7,0; 7,2',custody='0,50',exit_fixed='0',exit_rate='0',spread='0,12',spread_source='Hipótese informada; confirmar no canal de execução',
      snapshot_mode='Última cotação do histórico',inflation_ok=False,kind='resgate',lag='D+0',entry_ref='7,17',budget='',
      a_date='',a_known='',a_ref='',vni='',a_pu='',a_yield='',a_side='resgate',q_date='',q_time='',q_settle='',q_active=False,q_pu='',q_custody='',q_net='',
      history_date='',history_hash='',calendar_hash='',vni_hash='',financial_profile='RENDA_CENTS_ESTIMATED_2026',profile_id='original_10_9_v1',
      compare_targets='0; 5,5; 10,9',sensitivity_cost='0',sensitivity_bps='0',show_sensitivity=False,inflation_monthly='')


class Group1Service:
    def __init__(self,data_dir=None,*,now=None):
        self.store=LocalStore(data_dir);self.now=now or (lambda:datetime.now(TZ))
        self._lock=RLock();self.results=OrderedDict();self.pending={};self.update_outcomes=OrderedDict();self.recovery_error=None
        self._market_sim_cache={}
        try:
            self.store.check()
            if not self.store.dataset('market'):
                raw=(ROOT/'data/historico_renda2065.csv').read_bytes()
                self.store.commit_dataset('market',raw,{'source':'Histórico fornecido pelo usuário na construção; até 18/09/2026','bundled':True},expected_hash=None,original_content=raw)
            if not self.store.dataset('calendar'):
                raw=(ROOT/'data/calendars/td_2026.json').read_bytes()
                self.store.commit_dataset('calendar',raw,{'source':'B3 — fechamentos programados 2026, conferidos em 28/09/2026','bundled':True},expected_hash=None)
        except Exception:
            # O painel de restauração continua acessível se a base estiver danificada.
            self.recovery_error='Base local indisponível. Use um backup válido; os arquivos foram preservados.'

    def _ensure(self):
        if self.recovery_error:raise ValidationError('E-STORAGE',self.recovery_error)

    def _offline_monthly_ipca(self):
        """Read bundled IPCA inputs only; never fetch online or alter user data."""
        from .market_sim.market_data import parse_index_csv
        q=ROOT/'data/ipca_monthly_ibge.csv'
        if not q.is_file():return None
        raw=q.read_bytes()
        digest=sha256(raw).hexdigest()
        key=('bundled_ipca',digest)
        if key not in self._market_sim_cache:
            rows,_=parse_index_csv(raw,imported_on=self.now().date())
            self._market_sim_cache[key]=tuple(replace(row,source=row.source+' cache SHA256 '+digest) for row in rows)
        return self._market_sim_cache[key]

    def simulator_evaluate(self,body):
        """Prévia MTM sem SQLite, sem rede e sem inserir análise em memória."""
        from .market_sim.api import evaluate_payload
        from .market_sim.contracts import ValidationError as MarketValidationError
        try:return evaluate_payload(body)
        except MarketValidationError as exc:
            message=str(exc).partition(':')[2].strip() or 'Verifique os campos da simulação.'
            raise ValidationError(exc.code,message) from exc

    def simulator_surface(self,body):
        """Curvas MTM sem persistência; compartilhamento limitado ao motor puro."""
        from .market_sim.api import surface_payload
        from .market_sim.contracts import ValidationError as MarketValidationError
        try:return surface_payload(body)
        except MarketValidationError as exc:
            message=str(exc).partition(':')[2].strip() or 'Verifique os campos da superfície.'
            raise ValidationError(exc.code,message) from exc

    def simulator_resolve_workspace(self,body):
        """Resolve workspace dates and only the explicitly pinned local sources."""
        from .market_sim.contracts import ValidationError as MarketValidationError
        from .market_sim.workspace import PriceMode,normalize_workspace_input,prepare_workspace_defaults,resolve_workspace
        try:
            prepared=prepare_workspace_defaults(body)
            normalized=normalize_workspace_input(prepared)
            versions=dict(normalized.source_versions)
            calendar=FinancialCalendar(
                knowledge_date=normalized.knowledge.date if normalized.knowledge else self.now().date()
            )
            price_rows=None;index_rows=None
            price_error=None;index_error=None
            needs_price=any(selection is not None and selection.mode is PriceMode.AUTO_LOCAL
                            for selection in (normalized.entry_price,normalized.exit_price))
            # Monthly IPCA also supplies purchasing-power deflation for manual PUs.
            needs_index=True
            if needs_price:
                digest=versions.get('market_sim')
                if digest is None:
                    price_error='SOURCE_VERSION_NOT_PINNED'
                else:
                    try:
                        _,parsed=self._market_sim_parsed('market_sim',digest)
                        if parsed is None:price_error='SOURCE_VERSION_MISSING'
                        else:price_rows=parsed[0]
                    except ValidationError as exc:
                        if exc.code=='E-STORAGE':price_error='SOURCE_VERSION_MISSING'
                        else:raise
            if needs_index:
                digest=versions.get('market_sim_indexes')
                if digest is not None:
                    try:
                        _,parsed=self._market_sim_parsed('market_sim_indexes',digest)
                        if parsed is None:index_error='SOURCE_VERSION_MISSING'
                        else:index_rows=parsed[0]
                    except ValidationError as exc:
                        if exc.code=='E-STORAGE':index_error='SOURCE_VERSION_MISSING'
                        else:raise
            if needs_index and versions.get('market_sim_indexes') is None:
                index_rows=self._offline_monthly_ipca()
            elif needs_index and index_rows is not None and not any(row.kind=='IPCA_MONTHLY_INDEX' for row in index_rows):
                # A legacy nominal/general-index file is not a monthly IPCA selection.
                # Preserve it as evidence, but calculate VNA/VNI from the offline cache.
                index_rows=tuple(index_rows)+(self._offline_monthly_ipca() or ())
            return resolve_workspace(
                prepared,calendar=calendar,price_observations=price_rows,index_observations=index_rows,
                price_source_error=price_error,index_source_error=index_error,
                require_automatic_nominal=True,
            )
        except MarketValidationError as exc:
            message=str(exc).partition(':')[2].strip() or 'Verifique os dados do workspace.'
            raise ValidationError(exc.code,message) from exc

    def simulator_unit_price(self,input_value,query,include_unit_price=True):
        """Resolve a unit quote from pinned sources without creating an operation."""
        from .market_sim.workspace import (
            PriceMode, normalize_unit_price_input, prepare_workspace_defaults,
            resolve_workspace_unit_price,
        )
        prepared=prepare_workspace_defaults(input_value)
        normalized=normalize_unit_price_input(prepared)
        versions=dict(normalized.source_versions)
        calendar=FinancialCalendar(
            knowledge_date=normalized.knowledge.date if normalized.knowledge else self.now().date()
        )
        price_rows=None;index_rows=None
        price_error=None;index_error=None
        selection=normalized.entry_price
        needs_price=selection is not None and selection.mode is PriceMode.AUTO_LOCAL
        needs_index=(selection is not None and selection.mode is PriceMode.MANUAL_RATE) or query.get('kind')=='RATE_CURVE'
        if needs_price:
            digest=versions.get('market_sim')
            if digest is None:
                price_error='SOURCE_VERSION_NOT_PINNED'
            else:
                try:
                    _,parsed=self._market_sim_parsed('market_sim',digest)
                    if parsed is None:price_error='SOURCE_VERSION_MISSING'
                    else:price_rows=parsed[0]
                except ValidationError as exc:
                    if exc.code=='E-STORAGE':price_error='SOURCE_VERSION_MISSING'
                    else:raise
        if needs_index:
            digest=versions.get('market_sim_indexes')
            if digest is not None:
                try:
                    _,parsed=self._market_sim_parsed('market_sim_indexes',digest)
                    if parsed is None:index_error='SOURCE_VERSION_MISSING'
                    else:index_rows=parsed[0]
                except ValidationError as exc:
                    if exc.code=='E-STORAGE':index_error='SOURCE_VERSION_MISSING'
                    else:raise
        if needs_index and versions.get('market_sim_indexes') is None:
            index_rows=self._offline_monthly_ipca()
        elif needs_index and index_rows is not None and not any(row.kind=='IPCA_MONTHLY_INDEX' for row in index_rows):
            index_rows=tuple(index_rows)+(self._offline_monthly_ipca() or ())
        return resolve_workspace_unit_price(
            prepared,query,calendar=calendar,price_observations=price_rows,
            index_observations=index_rows,price_source_error=price_error,
            index_source_error=index_error,require_automatic_nominal=True,
            include_unit_price=include_unit_price,
        )

    def _simulator_workspace_g5_stress(self,request,raw_request=None):
        """Evaluate the frozen, bounded G5 fixed-position sensitivity domains."""
        from copy import deepcopy
        from decimal import Decimal
        from .market_sim.api import (
            _json_ready, workspace_fingerprint, workspace_stress_fingerprint,
            G5_MANUAL_BASIS_ID, G5_REFERENCE_BASIS_ID, G5_REPRICED_BASIS_ID,
        )
        from .market_sim.comparisons import (
            compare_workspace_evaluations, g5_decompose_metric,
            g5_fiscal_transition_bridge, g5_tax_bracket_control,
            g5_threshold_margin,
        )
        from .market_sim.contracts import ValidationError as MarketValidationError
        from .market_sim.service import engine_manifest
        from .market_sim.workspace import (
            EvaluationBudget, apply_workspace_stress, evaluate_resolved_workspace,
            normalize_workspace_input, prepare_workspace_defaults,
            prepare_workspace_stress_base,
        )
        base_input,excluded_overrides=prepare_workspace_stress_base(request['input'])
        fixed=request['fixed_position']
        controls=request['decision_margins']
        context=fixed['comparison_context']
        reference_spec=fixed['reference']
        reference_input=reference_spec['input']
        basis_semantics=controls['basis_semantics']
        request_fingerprint=workspace_stress_fingerprint(
            request['input'],request['shocks'],request['margin_searches'],
            fixed_position=fixed,decision_margins=controls,
        )
        budget=EvaluationBudget(
            max_evaluations=request['max_evaluations'],
            deadline_seconds=request['deadline_ms']/1000,
            ledger_context={
                'request_id':request['request_id'],
                'request_fingerprint':request_fingerprint,
                'revision':request['revision'],
                'engine_manifest':engine_manifest(),
                'basis_ids':{
                    'reference':G5_REFERENCE_BASIS_ID,
                    'manual':G5_MANUAL_BASIS_ID,
                    'repriced':G5_REPRICED_BASIS_ID,
                },
            },
        )
        evaluation_cache={}
        warnings=[]

        def evaluate_case(case_input,basis_id):
            fingerprint=workspace_fingerprint('EVALUATE',case_input)
            basis_fingerprint=_canonical_hash({'basis_id':basis_id,'input_fingerprint':fingerprint})
            return _g5_cached_evaluation(
                evaluation_cache,budget,basis_id,fingerprint,
                lambda:evaluate_case_uncached(case_input,basis_id,fingerprint,basis_fingerprint),
            )

        def evaluate_case_uncached(case_input,basis_id,fingerprint,basis_fingerprint):
            stopped=budget.refuse_if_stopped(basis_id=basis_id,input_fingerprint=fingerprint)
            if stopped is not None:
                return {
                    'id':None,'status':'not_evaluated','input_fingerprint':fingerprint,
                    'basis_id':basis_id,'basis_fingerprint':basis_fingerprint,
                    'normalized_input':None,'resolution':None,'evaluation':None,
                    'source_versions':{},'reason':{
                        'code':stopped,
                        'message':'O orcamento G5 terminou antes da avaliacao direta deste ponto.',
                    },
                }
            try:
                resolution=self.simulator_resolve_workspace(case_input)
                normalized=normalize_workspace_input(prepare_workspace_defaults(case_input))
                normalized_input=normalized.to_dict()['normalized_input']
                required=('input_resolution','date_resolution','price_resolution','nominal_evaluation','purchase_sizing')
                can_evaluate=all(
                    resolution.get('capabilities',{}).get(name,{}).get('status')=='available'
                    for name in required
                )
                evaluation=None
                reason=None
                record_status='partial'
                completed_after_deadline=False
                if can_evaluate:
                    calendar=FinancialCalendar(
                        knowledge_date=normalized.knowledge.date if normalized.knowledge else self.now().date()
                    )
                    try:
                        direct_outcome=_g5_evaluate_after_resolution(
                            budget,basis_id,fingerprint,
                            evaluator=lambda:evaluate_resolved_workspace(case_input,resolution,calendar=calendar),
                        )
                        evaluation=direct_outcome['evaluation']
                    except MarketValidationError as exc:
                        reason={
                            'code':exc.code,'message':str(exc),
                        }
                        record={
                            'id':None,'status':'partial','input_fingerprint':fingerprint,
                            'basis_id':basis_id,'basis_fingerprint':basis_fingerprint,
                            'normalized_input':normalized_input,'resolution':resolution,
                            'evaluation':None,'source_versions':resolution.get('source_resolution',{}),
                            'reason':reason,
                        }
                        if budget.last_direct_attempt_completed_after_deadline is True:
                            record['completed_after_deadline']=True
                        return record
                    except Exception as exc:
                        reason={
                            'code':'G5_DIRECT_EVALUATION_EXCEPTION',
                            'message':f"Falha na avaliacao direta ({type(exc).__name__}); o ponto nao foi certificado.",
                        }
                        warnings.append({'code':reason['code'],'message':reason['message']})
                        record={
                            'id':None,'status':'partial','input_fingerprint':fingerprint,
                            'basis_id':basis_id,'basis_fingerprint':basis_fingerprint,
                            'normalized_input':normalized_input,'resolution':resolution,
                            'evaluation':None,'source_versions':resolution.get('source_resolution',{}),
                            'reason':reason,
                        }
                        if budget.last_direct_attempt_completed_after_deadline is True:
                            record['completed_after_deadline']=True
                        return record
                    reason=direct_outcome['reason']
                    record_status=direct_outcome['status']
                    completed_after_deadline=direct_outcome['completed_after_deadline']
                else:
                    reason={
                        'code':'EVALUATION_PREREQUISITE_UNAVAILABLE',
                        'message':'A resolucao nao disponibilizou todas as capacidades necessarias para avaliar este ponto.',
                    }
                    budget.record_not_evaluated(
                        basis_id=basis_id,input_fingerprint=fingerprint,
                        outcome='prerequisite_unavailable',reason_code=reason['code'],
                    )
                record={
                    'id':None,'status':record_status,
                    'input_fingerprint':fingerprint,'basis_id':basis_id,
                    'basis_fingerprint':basis_fingerprint,'normalized_input':normalized_input,
                    'resolution':resolution,'evaluation':evaluation,
                    'source_versions':resolution.get('source_resolution',{}),
                    'reason':reason,
                }
                if completed_after_deadline:
                    record['completed_after_deadline']=True
                if evaluation is not None:
                    warnings.extend(
                        {'code':'EVALUATION_WARNING','message':message}
                        for message in evaluation.warnings
                    )
                return record
            except MarketValidationError as exc:
                budget.record_not_evaluated(
                    basis_id=basis_id,input_fingerprint=fingerprint,
                    outcome='resolution_exception',reason_code=exc.code,
                )
                record={
                    'id':None,'status':'partial','input_fingerprint':fingerprint,
                    'basis_id':basis_id,'basis_fingerprint':basis_fingerprint,
                    'normalized_input':None,'resolution':None,'evaluation':None,
                    'source_versions':{},'reason':{'code':exc.code,'message':str(exc)},
                }
                return record

        def comparison_context(base_context,cash_rate):
            result=deepcopy(base_context)
            growth=deepcopy(result.get('cash_growth') or {})
            growth['annual_net_rate']=cash_rate
            result['cash_growth']=growth
            return result

        def compare_case(case_input,case,cash_rate,*,horizon=None):
            unavailable=_g5_comparison_case_unavailable_row(case)
            if unavailable is not None:
                return unavailable
            reference_unavailable=_g5_comparison_case_unavailable_row(reference,reference=True)
            if reference_unavailable is not None:
                return reference_unavailable
            common_context=deepcopy(context)
            if horizon is not None:
                common_context['horizon']=horizon
            pair_context=comparison_context(common_context,cash_rate)
            reference_item={
                **reference_spec,'input_fingerprint':reference['input_fingerprint'],
                'normalized_input':reference['normalized_input'],
                'resolution':reference['resolution'],'evaluation':reference['evaluation'],
                'comparison_context':pair_context,
            }
            alternative_item={
                'id':'alternative','label':'Alternativa G5',
                'input':case_input,'input_fingerprint':case['input_fingerprint'],
                'normalized_input':case['normalized_input'],'resolution':case['resolution'],
                'evaluation':case['evaluation'],'comparison_context':pair_context,
            }
            try:
                compared=compare_workspace_evaluations(
                    [reference_item,alternative_item],comparison_mode='FIXED_POSITION',
                )
            except MarketValidationError as exc:
                return {'status':'UNKNOWN','reason':{'code':exc.code,'message':str(exc)}}
            row=(compared.get('alternatives') or [None,None])[1]
            if not isinstance(row,dict):
                return {'status':'UNKNOWN','reason':{'code':'G5_COMPARISON_UNAVAILABLE','message':'A comparacao de posicao fixa nao produziu a alternativa.'}}
            return row

        def metric_point(row,field,value,basis_id):
            point={field:str(value),'basis_id':basis_id}
            wealth=None
            if row is not None:
                item=row.get('wealth_advantage_vs_reference')
                if isinstance(item,dict):
                    wealth=item.get('value')
            if wealth is None:
                reason=(row or {}).get('reason') or {'code':'G5_POINT_UNAVAILABLE','message':'Ponto ainda nao avaliado com comparacao patrimonial completa.'}
                point.update({'status':'UNKNOWN','wealth_advantage_brl':None,'margin':None,'reason':reason})
                return point
            margin=g5_threshold_margin(
                metric='wealth_advantage_vs_reference',condition_id='sell_wait_indifference',
                actual_value=wealth,threshold='0',unit='BRL',
            )
            point.update({'status':margin['status'],'wealth_advantage_brl':margin['actual_value'],'margin':margin})
            return point

        reference=evaluate_case(reference_input,G5_REFERENCE_BASIS_ID)
        reference['id']='reference'
        reference['label']=reference_spec['label']
        base_case=evaluate_case(base_input,G5_MANUAL_BASIS_ID)
        base_case['id']='base'
        base_case['label']='Saida G3 manual'
        repriced_input=deepcopy(base_input)
        repriced_input['exit_price']={
            'mode':'MANUAL_RATE','annual_real_rate':str(basis_semantics['repriced_base_rate']),
            'quoted_side':'SELL',
        }
        repriced_input['assumptions']=dict(repriced_input.get('assumptions') or {})
        repriced_projection=deepcopy(basis_semantics['repriced_inflation_projection'])
        for field in ('annual_rate','anchor_level'):
            repriced_projection[field]=str(repriced_projection[field])
        repriced_projection['anchor_date']=repriced_projection['anchor_date'].isoformat()
        repriced_input['assumptions']['inflation_projection']=repriced_projection
        repriced_base_case=evaluate_case(repriced_input,G5_REPRICED_BASIS_ID)
        repriced_base_case['id']='repriced-base'
        repriced_base_case['label']='Base G5 reprecificada explicita'

        cash_rates=controls['cash_rate_domain']['values']
        cash_points=[]
        cash_rows={}
        for rate in cash_rates:
            key=str(rate)
            row=compare_case(base_input,base_case,rate)
            point=metric_point(row,'rate',rate,G5_MANUAL_BASIS_ID)
            cash_points.append(point)
            cash_rows[key]=row

        base_rate=controls['exit_real_rate_domain']['base']
        rate_points=[]
        rate_rows={}
        for delta in controls['exit_real_rate_domain']['values']:
            case=repriced_base_case
            case_input=repriced_input
            if delta != 0:
                shock_id=f"g5-rate-{delta}"
                case_input=apply_workspace_stress(repriced_input,{
                    'id':shock_id,'rate_shock_ratio':delta,
                })
                case_input['intent']=repriced_input.get('intent')
                case=evaluate_case(case_input,G5_REPRICED_BASIS_ID)
            row=compare_case(case_input,case,cash_rates[9])
            absolute_rate=base_rate+delta
            point=metric_point(row,'annual_real_rate',absolute_rate,G5_REPRICED_BASIS_ID)
            point['delta']=str(delta)
            rate_points.append(point)
            rate_rows[delta]=row

        base_projection=(repriced_input.get('assumptions') or {}).get('inflation_projection') or {}
        base_inflation=Decimal(str(base_projection.get('annual_rate')))
        inflation_points=[]
        inflation_rows={}
        for level in controls['annual_inflation_levels']:
            case=repriced_base_case
            case_input=repriced_input
            if level != base_inflation:
                case_input=apply_workspace_stress(repriced_input,{
                    'id':f'g5-inflation-{level}','annual_inflation_ratio':level-base_inflation,
                })
                case_input['intent']=repriced_input.get('intent')
                case=evaluate_case(case_input,G5_REPRICED_BASIS_ID)
            row=compare_case(case_input,case,cash_rates[9])
            point=metric_point(row,'annual_inflation_rate',level,G5_REPRICED_BASIS_ID)
            inflation_points.append(point)
            inflation_rows[level]=row

        base_expense=Decimal(str((base_input.get('assumptions') or {}).get('exit_fee_brl')))
        expense_points=[]
        expense_rows={}
        expense_domain=controls['exit_expense_domain']
        for expense in expense_domain['values']:
            case=base_case
            case_input=base_input
            if expense != base_expense:
                case_input=apply_workspace_stress(base_input,{
                    'id':f'g5-expense-{expense}','exit_expense_delta_brl':expense-base_expense,
                })
                case_input['intent']=base_input.get('intent')
                case=evaluate_case(case_input,G5_MANUAL_BASIS_ID)
            row=compare_case(case_input,case,cash_rates[9])
            point=metric_point(row,'exit_expense_brl',expense,G5_MANUAL_BASIS_ID)
            expense_points.append(point)
            expense_rows[str(expense)]=row

        decomp=controls['decomposition']
        rate_a=decomp['rate_a_delta']
        inflation_b=decomp['inflation_b_level']
        rate_row=rate_rows.get(rate_a)
        inflation_row=inflation_rows.get(inflation_b)
        cross_input=apply_workspace_stress(repriced_input,{
            'id':'g5-rate-inflation-cross',
            'rate_shock_ratio':rate_a,
            'annual_inflation_ratio':inflation_b-base_inflation,
        })
        cross_input['intent']=repriced_input.get('intent')
        cross_case=repriced_base_case if cross_input==repriced_input else evaluate_case(cross_input,G5_REPRICED_BASIS_ID)
        cross_row=compare_case(cross_input,cross_case,cash_rates[9])
        base_row=rate_rows.get(Decimal('0'))
        metric_values=[]
        for row in (base_row,rate_row,inflation_row,cross_row):
            item=row.get('wealth_advantage_vs_reference') if isinstance(row,dict) else None
            metric_values.append(item.get('value') if isinstance(item,dict) else None)
        if all(value is not None for value in metric_values):
            decomposition={
                **g5_decompose_metric(*metric_values),
                'status':'ready',
                'metric':'wealth_advantage_vs_reference',
                'basis_id':G5_REPRICED_BASIS_ID,
                'cells':{
                    'Y0':metric_values[0],'YA':metric_values[1],
                    'YB':metric_values[2],'YAB':metric_values[3],
                },
                'components':{
                    'isolated_a':g5_decompose_metric(*metric_values)['isolated_a'],
                    'isolated_b':g5_decompose_metric(*metric_values)['isolated_b'],
                    'interaction':g5_decompose_metric(*metric_values)['interaction'],
                    'total_delta':g5_decompose_metric(*metric_values)['total_delta'],
                },
            }
        else:
            decomposition={
                'status':'partial','metric':'wealth_advantage_vs_reference',
                'basis_id':G5_REPRICED_BASIS_ID,
                'components':{'isolated_a':None,'isolated_b':None,'interaction':None,'total_delta':None},
                'displayed':{'observed_rounding_residual':None},
                'cells':{'Y0':metric_values[0],'YA':metric_values[1],'YB':metric_values[2],'YAB':metric_values[3]},
            }

        fiscal_config=controls['fiscal_pair']
        fiscal_days=[]
        for index,sale_day in enumerate(fiscal_config['sale_dates']):
            native=_g5_fiscal_alternative_input(base_input,fiscal_config,sale_day)
            native['intent']=base_input.get('intent')
            fiscal_case=evaluate_case(native,'G5_AC05_FISCAL_PAIR')
            fiscal_case['id']=f'day_{180+index}'
            fiscal_case['label']=f'Dia {180+index}'
            fiscal_context=deepcopy(context)
            fiscal_context['horizon']=fiscal_config['common_horizon']
            row=compare_case(
                native,fiscal_case,fiscal_config['cash_growth_rate'],
                horizon=fiscal_config['common_horizon'],
            )
            day=_g5_fiscal_day_from_comparison(
                row,expected_holding_days=180+index,sale_day=sale_day,
            )
            fiscal_days.append(day)
            if day.get('status')=='inconsistent':
                warnings.append(deepcopy(day['reason']))
        fiscal_pair=_g5_fiscal_transition_result(
            fiscal_days,fiscal_config,g5_fiscal_transition_bridge,MarketValidationError,
        )
        fiscal_status=fiscal_pair['status']
        fiscal_bridge=fiscal_pair['bridge']
        fiscal_result={
            'status':fiscal_status,
            'basis_id':'G5_AC05_FISCAL_PAIR',
            'days':{'day_180':fiscal_days[0] if len(fiscal_days)>0 else None,'day_181':fiscal_days[1] if len(fiscal_days)>1 else None},
            'bridge':fiscal_bridge,
            'tax_control':g5_tax_bracket_control('100.00'),
        }

        goal_value=None
        base_evaluation=base_case.get('evaluation')
        if base_evaluation is not None and base_evaluation.operation is not None:
            goal_value=base_evaluation.operation.nominal_profit
        goal_margin=(
            g5_threshold_margin(
                metric='nominal_profit',condition_id='nominal_profit_goal',
                actual_value=goal_value,threshold=controls['nominal_profit_goal_brl'],unit='BRL',
            ) if goal_value is not None else None
        )
        if goal_margin is not None:
            goal_margin['basis_id']=G5_MANUAL_BASIS_ID
        wealth_margin=metric_point(cash_rows.get(str(Decimal('0.09'))),'rate',Decimal('0.09'),G5_MANUAL_BASIS_ID)
        wealth_margin_payload=wealth_margin.get('margin')
        if wealth_margin_payload is not None:
            wealth_margin_payload['basis_id']=G5_MANUAL_BASIS_ID
        margins={
            'nominal_profit_goal':goal_margin,
            'wealth_at_9_percent':wealth_margin_payload,
        }
        groups={
            'cash_rate_sensitivity':cash_points,
            'exit_rate_sensitivity':rate_points,
            'inflation_sensitivity':inflation_points,
            'exit_expense_sensitivity':expense_points,
        }
        all_grid_points=[point for group in groups.values() for point in group]
        grids_complete=all(point['status']!='UNKNOWN' for point in all_grid_points)
        budget.check_deadline()
        complete=(
            goal_margin is not None and grids_complete
            and decomposition.get('status')=='ready' and fiscal_status=='ready'
            and budget.reason is None
        )
        result={
            'status':'ready' if complete else 'partial',
            'comparison_mode':'FIXED_POSITION',
            'basis_semantics':{
                'version':basis_semantics['version'],
                'manual_basis_id':G5_MANUAL_BASIS_ID,
                'reference_basis_id':G5_REFERENCE_BASIS_ID,
                'repriced_basis_id':G5_REPRICED_BASIS_ID,
                'repriced_base_rate':str(basis_semantics['repriced_base_rate']),
                'repriced_base_inflation':str(basis_semantics['repriced_base_inflation']),
                'pu_to_yield_inference':False,
            },
            'decision_margins':margins,
            'cash_rate_sensitivity':{'metric':'wealth_advantage_vs_reference','unit':'BRL','basis_id':G5_MANUAL_BASIS_ID,'points':cash_points},
            'exit_rate_sensitivity':{'metric':'wealth_advantage_vs_reference','unit':'BRL','basis_id':G5_REPRICED_BASIS_ID,'points':rate_points},
            'inflation_sensitivity':{'metric':'wealth_advantage_vs_reference','unit':'BRL','basis_id':G5_REPRICED_BASIS_ID,'points':inflation_points},
            'exit_expense_sensitivity':{'metric':'wealth_advantage_vs_reference','unit':'BRL','basis_id':G5_MANUAL_BASIS_ID,'points':expense_points},
            'rate_inflation_decomposition':decomposition,
            'fiscal_transition':fiscal_result,
            'reference':{
                'id':'reference','status':reference['status'],
                'basis_id':reference['basis_id'],'basis_fingerprint':reference['basis_fingerprint'],
                'input_fingerprint':reference['input_fingerprint'],
                'reason':reference.get('reason'),
            },
            'alternative':{
                'id':'base','status':base_case['status'],
                'basis_id':base_case['basis_id'],'basis_fingerprint':base_case['basis_fingerprint'],
                'input_fingerprint':base_case['input_fingerprint'],
                'reason':base_case.get('reason'),
            },
            'repriced_alternative':{
                'id':'repriced-base','status':repriced_base_case['status'],
                'basis_id':repriced_base_case['basis_id'],'basis_fingerprint':repriced_base_case['basis_fingerprint'],
                'input_fingerprint':repriced_base_case['input_fingerprint'],
                'annual_real_rate':str(basis_semantics['repriced_base_rate']),
                'annual_inflation':str(basis_semantics['repriced_base_inflation']),
                'reason':repriced_base_case.get('reason'),
            },
            'limits':{
                'cash_rate_points':len(cash_points),'exit_rate_points':len(rate_points),
                'inflation_points':len(inflation_points),'exit_expense_points':len(expense_points),
                'two_by_two_cells':4,'cartesian_product_generated':False,
            },
        }
        budget_summary=budget.to_dict()
        budget_summary.update({'workers':1,'execution':'serial','cache_hits':budget.cache_hits})
        coverage={
            'complete':complete,
            'cash_rate_points':{'requested':len(cash_points),'evaluated':sum(p['status']!='UNKNOWN' for p in cash_points)},
            'exit_rate_points':{'requested':len(rate_points),'evaluated':sum(p['status']!='UNKNOWN' for p in rate_points)},
            'inflation_points':{'requested':len(inflation_points),'evaluated':sum(p['status']!='UNKNOWN' for p in inflation_points)},
            'exit_expense_points':{'requested':len(expense_points),'evaluated':sum(p['status']!='UNKNOWN' for p in expense_points)},
            'decomposition_cells':sum(value is not None for value in metric_values),
            'fiscal_days':_g5_fiscal_coverage_count(fiscal_days),
        }
        result['coverage']=coverage
        result['computation_budget']=budget_summary
        if excluded_overrides:
            warnings.append({
                'code':'POINT_OVERRIDE_NOT_REUSED',
                'message':'Overrides institucionais pontuais foram removidos da alternativa-base antes das sensibilidades.',
                'fields':list(excluded_overrides),
            })
        if budget.reason is not None:
            warnings.append({'code':budget.reason,'message':'Cobertura G5 parcial: os pontos sem avaliacao permanecem UNKNOWN.'})
        source_versions={
            value['basis_fingerprint']:value.get('source_versions',{})
            for value in evaluation_cache.values()
        }
        fingerprint=request_fingerprint
        resolved_fingerprint=_resolved_ipca_fingerprint(
            fingerprint,[item.get('source_versions',{}) for item in evaluation_cache.values()],
        )
        return {
            'schema_version':2,'action':'STRESS','request_id':request['request_id'],'revision':request['revision'],
            'status':result['status'],'warnings':warnings,
            'request_fingerprint':request_fingerprint,
            'input_fingerprint':resolved_fingerprint,'engine_manifest':engine_manifest(),
            'computation_budget':budget_summary,'source_versions':source_versions,
            'capabilities':{'stress':{'status':'available' if complete else 'partial'}},
            'resolved':{
                'comparison_mode':'FIXED_POSITION','reference':reference.get('resolution'),
                'alternative':base_case.get('resolution'),
            },
            'result':_json_ready(result),'coverage':coverage,
        }

    @scoped_calculation
    def simulator_workspace(self,body):
        """Strict v2 workspace orchestration; previews never write snapshots."""
        from .market_sim.api import (
            _json_ready, workspace_fingerprint, workspace_comparison_fingerprint,
            workspace_stress_fingerprint, workspace_request, WORKSPACE_SEARCH_BUDGET,
        )
        from .market_sim.contracts import ValidationError as MarketValidationError
        from .market_sim.service import engine_manifest
        from .market_sim.workspace import (
            build_workspace_surface, evaluate_resolved_workspace, prepare_workspace_surface_domain,
            normalize_workspace_input, prepare_workspace_defaults,
            resolve_workspace_exit_constraints, find_workspace_first_date,
            find_workspace_entry_boundary, EvaluationBudget, prepare_workspace_stress_base,
            apply_workspace_stress,
        )
        try:
            request=workspace_request(body)
            action=request['action']
            if action=='STRESS' and request.get('fixed_position') is not None:
                return self._simulator_workspace_g5_stress(request,body)
            frontier_evaluation_budget=None
            frontier_evaluation_cache=None
            if action=='GROSS_DV01':
                from .market_sim.workspace import (
                    evaluate_workspace_gross_dv01, normalize_unit_price_input,
                    prepare_workspace_defaults,
                )
                unit_resolution=self.simulator_unit_price(
                    request['input'],{'kind':'POINT'},include_unit_price=False
                )
                normalized=normalize_unit_price_input(prepare_workspace_defaults(request['input']))
                calendar=FinancialCalendar(
                    knowledge_date=normalized.knowledge.date if normalized.knowledge else self.now().date()
                )
                dv01=evaluate_workspace_gross_dv01(
                    request['input'],unit_resolution,calendar,normalized.entry_price,
                    quantity=request.get('quantity'),
                )
                result_status='ready' if dv01.get('status')=='available' else 'partial'
                source_versions=unit_resolution.get('source_versions',{})
                return {
                    'schema_version':2,'action':action,'request_id':request['request_id'],'revision':request['revision'],
                    'status':result_status,
                    'warnings':[] if result_status=='ready' else [{
                        'code':'GROSS_DV01_PARTIAL',
                        'message':'DV01 bruto indisponivel para as condicoes resolvidas; nenhuma metrica ausente foi substituida por zero.',
                    }],
                    'input_fingerprint':_resolved_ipca_fingerprint(
                        workspace_fingerprint(action,request['input'],quantity=request.get('quantity')),
                        source_versions,
                    ),
                    'engine_manifest':engine_manifest(),'computation_budget':dict(WORKSPACE_SEARCH_BUDGET),
                    'source_versions':source_versions,
                    'capabilities':{'gross_dv01':{
                        'status':dv01.get('status'),'reason':None if dv01.get('status')=='available' else {
                            'code':dv01.get('reason_code'),'message':'Taxa aplicada, data financeira e nominal compativel sao necessarios.'
                        },
                    }},
                    'resolved':{
                        'status':result_status,'analysis_context':normalized.analysis_context.to_dict(),
                        'instrument':unit_resolution.get('instrument'),
                        'price_context':unit_resolution.get('points',[None])[0] if unit_resolution.get('points') else None,
                    },
                    'result':_json_ready(dv01),
                }
            if action=='UNIT_PRICE':
                from .market_sim.workspace import normalize_unit_price_input
                unit_result=self.simulator_unit_price(request['input'],request['query'])
                normalized_input=normalize_unit_price_input(request['input']).to_dict()['normalized_input']
                result_status=unit_result['status']
                warnings=[] if result_status=='ready' else [{
                    'code':'UNIT_PRICE_PARTIAL',
                    'message':'A cotação unitária contém datas ou evidências pendentes; nenhum resultado patrimonial foi calculado.',
                }]
                return {
                    'schema_version':2,'action':action,'request_id':request['request_id'],'revision':request['revision'],
                    'status':result_status,'warnings':warnings,
                    'input_fingerprint':_resolved_ipca_fingerprint(workspace_fingerprint(action,request['input'],query=request['query']),unit_result.get('source_versions',{})),
                    'engine_manifest':engine_manifest(),'computation_budget':dict(WORKSPACE_SEARCH_BUDGET),
                    'source_versions':unit_result.get('source_versions',{}),
                    'capabilities':unit_result.get('capabilities',{}),
                    'resolved':{
                        'status':result_status,'analysis_context':normalized_input['analysis_context'],
                        'instrument':unit_result.get('instrument'),
                        'reference_price':unit_result.get('reference_price'),
                        'capabilities':unit_result.get('capabilities',{}),
                    },
                    'result':_json_ready(unit_result),'coverage':unit_result.get('coverage'),
                }
            if action=='COMPARE':
                from .market_sim.comparisons import compare_workspace_evaluations
                items=[]
                resolved_items=[]
                warnings=[]
                required=('input_resolution','date_resolution','price_resolution','nominal_evaluation','purchase_sizing')
                for spec in (request['reference'],*request['alternatives']):
                    alternative_resolution=self.simulator_resolve_workspace(spec['input'])
                    alternative_input=normalize_workspace_input(prepare_workspace_defaults(spec['input']))
                    alternative_calendar=FinancialCalendar(
                        knowledge_date=alternative_input.knowledge.date if alternative_input.knowledge else self.now().date()
                    )
                    can_evaluate=all(
                        alternative_resolution.get('capabilities',{}).get(name,{}).get('status')=='available'
                        for name in required
                    )
                    evaluation=(
                        evaluate_resolved_workspace(spec['input'],alternative_resolution,calendar=alternative_calendar)
                        if can_evaluate else None
                    )
                    items.append({
                        **spec,
                        'normalized_input':alternative_input.to_dict()['normalized_input'],
                        'resolution':alternative_resolution,
                        'evaluation':evaluation,
                        'input_fingerprint':_resolved_ipca_fingerprint(workspace_fingerprint('EVALUATE',spec['input']),alternative_resolution.get('source_resolution',{})),
                    })
                    resolved_items.append({
                        'id':spec['id'],'status':alternative_resolution.get('status','partial'),
                        'dates':alternative_resolution.get('dates'),
                        'capabilities':alternative_resolution.get('capabilities',{}),
                        'source_resolution':alternative_resolution.get('source_resolution',{}),
                    })
                    if evaluation is not None:
                        warnings.extend({'alternative_id':spec['id'],'code':'EVALUATION_WARNING','message':message}
                                        for message in evaluation.warnings)
                result=compare_workspace_evaluations(items,comparison_mode=request['comparison_mode'])
                warnings.extend(
                    {'code':reason['code'],'message':reason['message']}
                    for reason in result['ranking']['reasons']
                )
                comparison_status=result['status']
                return {
                    'schema_version':2,'action':action,'request_id':request['request_id'],'revision':request['revision'],
                    'status':comparison_status,'warnings':warnings,
                    'input_fingerprint':_resolved_ipca_fingerprint(workspace_comparison_fingerprint((request['reference'],*request['alternatives']),comparison_mode=request['comparison_mode']),[item['source_resolution'] for item in resolved_items]),
                    'engine_manifest':engine_manifest(),'computation_budget':{
                        'max_alternatives':3,'evaluations_requested':len(items),
                    },
                    'source_versions':{item['id']:item['source_resolution'] for item in resolved_items},
                    'capabilities':{'comparison':{'status':'available' if comparison_status=='ready' else 'partial'}},
                    'resolved':{'comparison_mode':request['comparison_mode'],'common_budget':None if request['common_budget'] is None else str(request['common_budget']),'alternatives':resolved_items},
                    'result':_json_ready(result),
                    'coverage':{'complete':comparison_status=='ready','alternatives':len(items)},
                }
            if action=='STRESS':
                from .market_sim.comparisons import summarize_workspace_stresses
                from .market_sim.constraints import search_stress_margin

                evaluation_budget=EvaluationBudget(
                    max_evaluations=request['max_evaluations'],
                    deadline_seconds=request['deadline_ms']/1000,
                )
                base_input,excluded_overrides=prepare_workspace_stress_base(request['input'])

                def evaluate_stress_case(case_id, case_input, shock=None):
                    if not evaluation_budget.try_consume():
                        return {
                            'id':case_id,'status':'not_evaluated',
                            'reason':{
                                'code':evaluation_budget.reason or 'EVALUATION_LIMIT',
                                'message':'A avaliação direta excedeu o orçamento declarado do pedido.',
                            },
                            'shock':shock,
                        }
                    try:
                        resolution=self.simulator_resolve_workspace(case_input)
                        normalized=normalize_workspace_input(prepare_workspace_defaults(case_input))
                        calendar=FinancialCalendar(
                            knowledge_date=normalized.knowledge.date if normalized.knowledge else self.now().date()
                        )
                        required=('input_resolution','date_resolution','price_resolution','nominal_evaluation','purchase_sizing')
                        available=all(
                            resolution.get('capabilities',{}).get(name,{}).get('status')=='available'
                            for name in required
                        )
                        if not available:
                            missing={
                                name:resolution.get('capabilities',{}).get(name,{})
                                for name in required
                                if resolution.get('capabilities',{}).get(name,{}).get('status')!='available'
                            }
                            return {
                                'id':case_id,'status':'partial','reason':{
                                    'code':'STRESS_SCENARIO_INCOMPLETE',
                                    'message':'O cenário não pode ser contado como aprovado sem todas as avaliações requeridas.',
                                    'capabilities':missing,
                                },'shock':shock,'resolved':{
                                    'status':resolution.get('status'),
                                    'dates':resolution.get('dates'),
                                    'capabilities':resolution.get('capabilities',{}),
                                },'source_versions':resolution.get('source_resolution'),
                            }
                        evaluation=evaluate_resolved_workspace(case_input,resolution,calendar=calendar)
                        status='ready' if evaluation.operation is not None else 'partial'
                        return {
                            'id':case_id,'status':status,'evaluation':evaluation,'shock':shock,
                            'resolved':{
                                'status':resolution.get('status'),
                                'dates':resolution.get('dates'),
                                'capabilities':resolution.get('capabilities',{}),
                            },
                            'source_versions':resolution.get('source_resolution'),
                        }
                    except MarketValidationError as exc:
                        message=str(exc).partition(':')[2].strip() or 'Premissa do cenário de estresse inválida.'
                        return {
                            'id':case_id,'status':'ineligible',
                            'reason':{'code':exc.code,'message':message},
                            'shock':shock,
                        }

                reference=evaluate_stress_case('reference',base_input)
                stress_cases=[]
                for shock in request['shocks']:
                    try:
                        stress_input=apply_workspace_stress(base_input,shock)
                    except MarketValidationError as exc:
                        message=str(exc).partition(':')[2].strip() or 'Choque não aplicável à entrada-base.'
                        stress_cases.append({
                            'id':shock['id'],'status':'ineligible',
                            'reason':{'code':exc.code,'message':message},'shock':shock,
                        })
                        continue
                    stress_cases.append(evaluate_stress_case(shock['id'],stress_input,shock))

                margin_results=[]
                constraint_definition=request.get('constraints')
                for search in request['margin_searches']:
                    probe_failure=None

                    def evaluate_margin_at_shift(shift, search=search):
                        nonlocal probe_failure
                        signed_shift=shift if search['direction']=='INCREASE' else -shift
                        probe_shock={'id':search['id'],search['dimension']:signed_shift}
                        try:
                            stress_input=apply_workspace_stress(base_input,probe_shock)
                        except MarketValidationError as exc:
                            message=str(exc).partition(':')[2].strip() or 'Ponto da busca de folga não aplicável.'
                            probe_failure={'code':exc.code,'message':message}
                            return None
                        case=evaluate_stress_case(
                            f"margin:{search['id']}:{signed_shift}",stress_input,probe_shock,
                        )
                        evaluation=case.get('evaluation')
                        constraint_evaluation=getattr(evaluation,'constraint_evaluation',None)
                        if case.get('status')!='ready' or constraint_evaluation is None:
                            probe_failure=case.get('reason') or {
                                'code':'STRESS_MARGIN_POINT_UNAVAILABLE',
                                'message':'Ponto da busca de folga sem avaliação financeira completa.',
                            }
                            return None
                        return constraint_evaluation

                    baseline_evaluation=getattr(reference.get('evaluation'),'constraint_evaluation',None)
                    margin=search_stress_margin(
                        constraint_definition,
                        criterion_id=search['criterion_id'],
                        dimension=search['dimension'],
                        direction=search['direction'],
                        maximum_magnitude=search['maximum_magnitude'],
                        resolution=search['resolution'],
                        evaluate_at_shift=evaluate_margin_at_shift,
                        baseline=baseline_evaluation,
                    )
                    if probe_failure is not None:
                        margin['probe_failure']=probe_failure
                    if evaluation_budget.reason is not None and margin['status']=='UNKNOWN':
                        margin['status']='INCOMPLETE'
                        margin['reason']='Orçamento ou prazo terminou antes de cobrir a grade de margem declarada.'
                    margin['id']=search['id']
                    margin_results.append(margin)

                result=summarize_workspace_stresses(
                    reference,stress_cases,margins=margin_results,
                    excluded_point_overrides=excluded_overrides,
                    computation_budget=evaluation_budget.to_dict(),
                    constraints_present=constraint_definition is not None and bool(constraint_definition.criteria),
                )
                comparison_status=result['status']
                warnings=[]
                if excluded_overrides:
                    warnings.append({
                        'code':'POINT_OVERRIDE_NOT_REUSED',
                        'message':'Overrides institucionais de ponto foram removidos da referência e dos cenários de estresse.',
                        'fields':list(excluded_overrides),
                    })
                for item in (result['reference'],*result['scenarios']):
                    if item['reason'] is not None:
                        warnings.append({'scenario_id':item['id'],'code':item['reason']['code'],'message':item['reason']['message']})
                    warnings.extend(
                        {'scenario_id':item['id'],'code':'EVALUATION_WARNING','message':message}
                        for message in item['warnings']
                    )
                return {
                    'schema_version':2,'action':action,'request_id':request['request_id'],'revision':request['revision'],
                    'status':comparison_status,'warnings':warnings,
                    'input_fingerprint':_resolved_ipca_fingerprint(workspace_stress_fingerprint(
                        request['input'],request['shocks'],request['margin_searches'],
                    ),reference.get('source_versions',{})),
                    'engine_manifest':engine_manifest(),
                    'computation_budget':evaluation_budget.to_dict(),
                    'source_versions':{
                        'reference':result['reference']['source_versions'],
                        **{item['id']:item['source_versions'] for item in result['scenarios']},
                    },
                    'capabilities':{'stress':{'status':'available' if comparison_status=='ready' else 'partial'}},
                    'resolved':result['reference']['resolved'],
                    'result':_json_ready(result),
                    'coverage':result['coverage'],
                }
            resolved=self.simulator_resolve_workspace(request['input'])
            parsed=normalize_workspace_input(prepare_workspace_defaults(request['input']))
            calendar=FinancialCalendar(knowledge_date=parsed.knowledge.date if parsed.knowledge else self.now().date())
            result=None
            coverage=None
            surface_domain=None
            input_fingerprint=None
            warnings=[]
            if resolved.get('calendar',{}).get('warning'):
                warnings.append({'code':'CALENDAR_LIMITATION','message':resolved['calendar']['warning']})
            if resolved.get('dates'):
                warnings.extend({'code':'DATE_RESOLUTION','message':message} for message in resolved['dates'].get('warnings',[]))
            if action=='EVALUATE':
                required=('input_resolution','date_resolution','price_resolution','nominal_evaluation','purchase_sizing')
                can_evaluate=all(resolved.get('capabilities',{}).get(name,{}).get('status')=='available' for name in required)
                if can_evaluate:
                    parsed=normalize_workspace_input(prepare_workspace_defaults(request['input']))
                    calendar=FinancialCalendar(knowledge_date=parsed.knowledge.date if parsed.knowledge else self.now().date())
                    evaluation=evaluate_resolved_workspace(request['input'],resolved,calendar=calendar)
                    result=_json_ready(evaluation)
                    warnings.extend({'code':'EVALUATION_WARNING','message':message} for message in evaluation.warnings)
            if action=='SURFACE':
                required=('input_resolution','date_resolution','purchase_sizing')
                can_surface=all(resolved.get('capabilities',{}).get(name,{}).get('status')=='available' for name in required)
                if can_surface:
                    parsed=normalize_workspace_input(prepare_workspace_defaults(request['input']))
                    calendar=FinancialCalendar(knowledge_date=parsed.knowledge.date if parsed.knowledge else self.now().date())
                    fixed_position_frontier=None
                    if request.get('fixed_position') is not None:
                        frontier_evaluation_budget=EvaluationBudget(max_evaluations=512,deadline_seconds=10.0)
                        frontier_evaluation_cache={}
                        fixed=request['fixed_position']
                        reference=fixed['reference']
                        reference_resolution=None
                        reference_resolution_error=None
                        reference_calendar=calendar
                        try:
                            reference_resolution=self.simulator_resolve_workspace(reference['input'])
                            reference_input=normalize_workspace_input(prepare_workspace_defaults(reference['input']))
                            reference_calendar=FinancialCalendar(
                                knowledge_date=reference_input.knowledge.date if reference_input.knowledge else self.now().date(),
                            )
                        except (ValidationError,MarketValidationError) as exc:
                            reference_resolution_error=str(exc).partition(':')[2].strip() or getattr(exc,'code','REFERENCE_RESOLUTION_FAILED')
                        fixed_position_frontier={
                            **fixed,
                            'reference_resolution':reference_resolution,
                            'reference_resolution_error':reference_resolution_error,
                            'reference_calendar':reference_calendar,
                        }
                    surface_domain=prepare_workspace_surface_domain(
                        request['input'],resolved,request['surface'],calendar=calendar,
                    )
                    fingerprint_surface=surface_domain
                    if request.get('fixed_position') is not None:
                        fingerprint_surface={**surface_domain,'fixed_position':request['fixed_position']}
                    input_fingerprint=workspace_fingerprint('SURFACE',request['input'],surface=fingerprint_surface)
                    surface_result=build_workspace_surface(
                        request['input'],resolved,surface_domain,calendar=calendar,
                        input_fingerprint=input_fingerprint,
                        evaluation_cache=frontier_evaluation_cache,
                        evaluation_budget=frontier_evaluation_budget,
                        fixed_position_frontier=fixed_position_frontier,
                    )
                    coverage=surface_result.pop('coverage')
                    result=_json_ready(surface_result)
                    if result['status']!='ready':
                        warnings.append({'code':'SURFACE_PARTIAL','message':'A superfície contém pontos indisponíveis ou bloqueados.'})
            if action=='CONSTRAINTS' and request.get('query',{}).get('kind')=='FIRST_DATE':
                def resolve_candidate(candidate_input):
                    try:
                        return self.simulator_resolve_workspace(candidate_input)
                    except ValidationError as exc:
                        raise MarketValidationError(getattr(exc,'code','CANDIDATE_RESOLUTION_FAILED'),str(exc)) from exc
                first_date=find_workspace_first_date(
                    request['input'],resolved,request['query'],calendar=calendar,
                    resolve_candidate=resolve_candidate,
                )
                result=_json_ready(first_date)
                coverage=result.get('coverage')
                if result.get('status') not in ('FOUND','NO_SOLUTION','OUTSIDE_DOMAIN'):
                    warnings.append({'code':'FIRST_DATE_PARTIAL','message':result.get('reason') or 'A busca por primeira data não teve cobertura verificável completa.'})
            elif action=='CONSTRAINTS' and request.get('query',{}).get('kind')=='ENTRY_BOUNDARY':
                def resolve_candidate(candidate_input):
                    try:
                        return self.simulator_resolve_workspace(candidate_input)
                    except ValidationError as exc:
                        raise MarketValidationError(getattr(exc,'code','CANDIDATE_RESOLUTION_FAILED'),str(exc)) from exc
                entry_boundary=find_workspace_entry_boundary(
                    request['input'],resolved,request['query'],calendar=calendar,
                    resolve_candidate=resolve_candidate,
                )
                result=_json_ready(entry_boundary)
                coverage=result.get('coverage')
                if result.get('status') not in ('SOLVED','NO_SOLUTION','OUTSIDE_DOMAIN'):
                    warnings.append({'code':'ENTRY_BOUNDARY_PARTIAL','message':result.get('reason') or 'A busca de entrada não cobriu o domínio suficiente para confirmar o limite.'})
            elif action=='CONSTRAINTS':
                required=('input_resolution','date_resolution','price_resolution','nominal_evaluation','purchase_sizing')
                can_resolve=all(resolved.get('capabilities',{}).get(name,{}).get('status')=='available' for name in required)
                if can_resolve:
                    parsed=normalize_workspace_input(prepare_workspace_defaults(request['input']))
                    calendar=FinancialCalendar(knowledge_date=parsed.knowledge.date if parsed.knowledge else self.now().date())
                    limit=resolve_workspace_exit_constraints(request['input'],resolved,calendar=calendar)
                    result=_json_ready(limit.to_dict())
                    if result.get('status')!='SOLVED':
                        warnings.append({'code':'CONSTRAINT_LIMIT_PARTIAL','message':result.get('reason') or 'O limite combinado não foi resolvido em todo o domínio declarado.'})
            core=('input_resolution','date_resolution','price_resolution','nominal_evaluation','purchase_sizing')
            status='ready' if all(resolved.get('capabilities',{}).get(name,{}).get('status')=='available' for name in core) else 'partial'
            if action=='EVALUATE' and result is not None and result.get('operation') is None and result.get('status')!='MARKED_ONLY':
                status='partial'
            if action=='SURFACE' and result is not None:
                status='ready' if result.get('status')=='ready' else 'partial'
            if action=='CONSTRAINTS' and result is not None:
                status='ready' if result.get('status') in ('SOLVED','FOUND','NO_SOLUTION','OUTSIDE_DOMAIN') else 'partial'
            source_versions=resolved.get('source_resolution',{})
            return {
                'schema_version':2,'action':action,'request_id':request['request_id'],'revision':request['revision'],
                'status':status,'warnings':warnings,'input_fingerprint':_resolved_ipca_fingerprint(input_fingerprint or workspace_fingerprint(
                    action,request['input'],surface=({**(surface_domain or request.get('surface')), 'fixed_position':request['fixed_position']}
                                                       if request.get('fixed_position') is not None else surface_domain or request.get('surface')),
                    query=request.get('query')),source_versions),
                'engine_manifest':engine_manifest(),'computation_budget':frontier_evaluation_budget.to_dict() if frontier_evaluation_budget is not None else dict(WORKSPACE_SEARCH_BUDGET),
                'source_versions':source_versions,'capabilities':resolved.get('capabilities',{}),
                'resolved':resolved,'result':result,'coverage':coverage,
            }
        except MarketValidationError as exc:
            message=str(exc).partition(':')[2].strip() or 'Verifique os dados do workspace.'
            raise ValidationError(exc.code,message) from exc

    def _market_sim_parsed(self,kind,digest=None):
        from .market_sim.market_data import parse_index_csv,parse_price_csv
        from .market_sim.provenance import EvidenceMode
        row=self._dataset(kind,digest)
        if row is None:return None,None
        key=(kind,row['hash'])
        cached=self._market_sim_cache.get(key)
        if cached is None:
            imported_on=date.fromisoformat(row['metadata'].get('imported_on',row['created_at'][:10]))
            parser=parse_price_csv if kind=='market_sim' else parse_index_csv
            parsed,metadata=parser(row['content'],imported_on=imported_on)
            cached=(parsed,metadata)
            self._market_sim_cache={key:cached}
        return row,cached

    def simulator_history(self,body):
        """Read one pinned local history version; never downloads or mutates storage."""
        from .market_sim.market_data import filter_index_history,filter_price_history
        from .market_sim.provenance import EvidenceMode
        if not isinstance(body,dict) or type(body.get('schema_version')) is not int or body.get('schema_version')!=1:
            raise ValidationError('E-SCHEMA','Consulta histórica requer schema_version 1.')
        allowed={'schema_version','dataset_kind','version_hash','instrument_id','index_kind','start_date','end_date','as_of','mode','limit'}
        unknown=set(body)-allowed
        if unknown:raise ValidationError('E-SCHEMA','Campo não reconhecido: '+', '.join(sorted(unknown)))
        kind=body.get('dataset_kind')
        if kind not in ('market_sim','market_sim_indexes'):
            raise ValidationError('E-DATASET','Escolha uma versão de preços ou de índices do simulador.')
        digest=body.get('version_hash')
        if digest is not None and (not isinstance(digest,str) or len(digest)!=64 or any(c not in '0123456789abcdef' for c in digest)):
            raise ValidationError('E-DATASET','Hash de versão inválido.')
        try:
            as_of=date.fromisoformat(body['as_of'])
            start=date.fromisoformat(body['start_date']) if body.get('start_date') else None
            end=date.fromisoformat(body['end_date']) if body.get('end_date') else None
            mode=EvidenceMode(body.get('mode','CAUSAL'))
            limit=body.get('limit',1260)
            if type(limit) is not int:raise ValueError('limit')
        except (ValueError,TypeError,KeyError) as exc:
            raise ValidationError('E-HISTORY-QUERY','Informe as_of ISO, intervalo válido, modo CAUSAL/EX_POST e limite inteiro.') from exc
        if start and end and start>end:raise ValidationError('E-HISTORY-QUERY','Início do intervalo deve anteceder o fim.')
        row,parsed=self._market_sim_parsed(kind,digest)
        if row is None:raise ValidationError('E-DATASET-MISSING','Ainda não há versão importada desta base.')
        observations,metadata=parsed
        if kind=='market_sim':
            instrument_id=body.get('instrument_id')
            if not isinstance(instrument_id,str) or not instrument_id.strip() or len(instrument_id)>256:
                raise ValidationError('E-INSTRUMENT','Selecione um identificador exato do arquivo.')
            points=filter_price_history(observations,instrument_id=instrument_id.strip(),start=start,end=end,as_of=as_of,mode=mode,limit=limit)
        else:
            index_kind=body.get('index_kind')
            if not isinstance(index_kind,str):raise ValidationError('E-INDEX','Selecione VNA, VNI, IPCA_LEVEL ou IPCA_PROJECTION.')
            points=filter_index_history(observations,kind=index_kind,start=start,end=end,as_of=as_of,mode=mode,limit=limit)
        return {'schema_version':1,'dataset_kind':kind,'version_hash':row['hash'],'source':row['metadata'].get('source','Arquivo local informado'),
                'imported_on':row['metadata'].get('imported_on'),'metadata':metadata,'mode':mode.value,
                'points':points,'warnings':[row['metadata'].get('knowledge_time',''),
                  'Arquivo local compatível com o formato; fonte declarada, não autenticada. Não representa cotação intradiária executável.']}

    def simulator_save(self,body):
        """Persist an explicitly consented, server-evaluated simulator snapshot."""
        self._ensure()
        if isinstance(body,dict) and type(body.get('schema_version')) is int and body.get('schema_version')==2:
            return self._simulator_save_v2(body)
        if not isinstance(body,dict) or type(body.get('schema_version')) is not int or body.get('schema_version')!=1:
            raise ValidationError('E-SCHEMA','Salvar cenário requer schema_version 1 ou 2.')
        allowed={'schema_version','name','scenario','context','decision','consent','record_id','expected_revision'}
        unknown=set(body)-allowed
        if unknown:raise ValidationError('E-SCHEMA','Campo não reconhecido: '+', '.join(sorted(unknown)))
        if body.get('consent') is not True:
            raise ValidationError('E-CONSENT','Marque o consentimento para salvar este snapshot neste computador.')
        name=body.get('name')
        if not isinstance(name,str) or not name.strip() or len(name.strip())>120:
            raise ValidationError('E-STORAGE','Informe um nome de até 120 caracteres.')
        record_id=body.get('record_id')
        expected=body.get('expected_revision')
        if record_id is not None:
            if not isinstance(record_id,str) or not re.fullmatch(r'[0-9a-f]{32}',record_id):
                raise ValidationError('E-STORAGE','Identificador de cenário inválido.')
            if type(expected) is not int or expected<1:
                raise ValidationError('E-CONFLICT','Informe a revisão carregada antes de salvar uma nova revisão.')
        elif expected is not None:
            raise ValidationError('E-CONFLICT','Revisão só pode acompanhar um cenário existente.')
        request={'schema_version':1,'scenario':body.get('scenario'),'context':body.get('context',{})}
        decision=body.get('decision',{})
        decision_fields={'metric','target_metric','target','target_date','rate_min','rate_max','rate_step','frontier_end','frontier_axis','view',
                         'goal_profit','goal_return','goal_net','goal_annual','decision_end','decision_span','decision_metric'}
        if not isinstance(decision,dict) or set(decision)-decision_fields or any(not isinstance(value,str) for value in decision.values()):
            raise ValidationError('E-SCHEMA','Configuração visual do snapshot contém campos ou valores inválidos.')
        if len(json.dumps(decision,ensure_ascii=False))>4096:
            raise ValidationError('E-SCHEMA','Configuração visual do snapshot excede o limite.')
        evaluation=self.simulator_evaluate(request)
        from .market_sim.service import engine_manifest
        snapshot={
            'application':'renda2065.market_sim',
            'snapshot_version':1,
            'schema_version':1,
            'captured_at':self.now().isoformat(),
            'request':request,
            'decision':decision,
            'evaluation':evaluation,
            'engine':engine_manifest(),
            'source_versions':_simulator_source_versions(request),
        }
        digest=_canonical_hash(snapshot)
        payload={**snapshot,'snapshot_sha256':digest}
        saved=self.store.save_record('scenario',name.strip(),payload,record_id=record_id,
                                     expected_revision=expected,consent=True)
        return {**saved,'snapshot_sha256':digest,'evaluation':evaluation}

    def _simulator_snapshot_point(self,input_value,selection):
        """Resolve one direct point from a snapshot input; never accepts its old result."""
        from .market_sim.workspace import PriceMode, normalize_workspace_input, prepare_workspace_defaults

        analysis_context=input_value.get('analysis_context')
        if isinstance(analysis_context,dict) and analysis_context.get('kind')=='UNIT_PRICE':
            if selection is not None:
                raise ValidationError('INVALID_SELECTION','Preço unitário não aceita uma seleção de venda.')
            point_input=input_value
            timeline=analysis_context.get('timeline')
            if isinstance(timeline,dict) and timeline.get('mode','POINT')!='POINT':
                point_input={**input_value,'analysis_context':{**analysis_context,'timeline':{'mode':'POINT'}}}
            request={
                'schema_version':2,'action':'UNIT_PRICE','request_id':'snapshot-unit-price',
                'revision':1,'input':point_input,'query':{'kind':'POINT'},
            }
            evaluated=self.simulator_workspace(request)
            point=None
        else:
            point=selection
            if point is None:
                normalized=normalize_workspace_input(prepare_workspace_defaults(input_value))
                exit_price=normalized.exit_price
                sale_date=input_value.get('sale_date')
                if sale_date is None:
                    return {'status':'unavailable','reason':'NO_POINT_SELECTION','selection':None,'result':None}
                if exit_price is not None:
                    if exit_price.mode is PriceMode.MANUAL_PU and exit_price.pu is not None:
                        point={'sale_date':sale_date,'exit_pu':str(exit_price.pu)}
                    elif exit_price.mode is PriceMode.MANUAL_RATE and exit_price.annual_real_rate is not None:
                        point={'sale_date':sale_date,'annual_real_rate':str(exit_price.annual_real_rate)}
                    elif exit_price.mode is PriceMode.SAME_ENTRY_RATE:
                        entry=normalized.entry_price
                        rate=entry.annual_real_rate if entry is not None else None
                        if rate is None and entry is not None and entry.rate_check is not None:
                            rate=entry.rate_check.annual_real_rate
                        if rate is not None:
                            point={'sale_date':sale_date,'annual_real_rate':str(rate)}
                    elif exit_price.mode is PriceMode.AUTO_LOCAL:
                        resolved=self.simulator_resolve_workspace(input_value)
                        quote=(resolved.get('resolved_prices') or {}).get('exit_price') or {}
                        value=quote.get('value') if quote.get('status')=='available' else None
                        if value is not None:
                            point={'sale_date':sale_date,'exit_pu':str(value)}
                if point is None:
                    return {'status':'unavailable','reason':'NO_POINT_SELECTION','selection':None,'result':None}

            from .market_sim.api import _json_ready
            point_input=input_value
            if (isinstance(analysis_context,dict) and analysis_context.get('kind','OPERATION')=='OPERATION'
                    and isinstance(analysis_context.get('timeline'),dict)
                    and analysis_context['timeline'].get('mode')=='WINDOW'):
                point_input={**input_value,'analysis_context':{**analysis_context,'timeline':{'mode':'POINT'}}}
            request={
                'schema_version':2,'action':'EVALUATE','request_id':'snapshot-point',
                'revision':1,'input':point_input,
                'selection':{key:point[key] for key in ('sale_date','exit_pu','annual_real_rate') if key in point},
            }
            evaluated=self.simulator_workspace(request)

        from .market_sim.api import _json_ready
        saved={
            'status':evaluated.get('status'),
            'reason':None if evaluated.get('result') is not None else 'POINT_UNAVAILABLE',
            'selection':point,
            'input_fingerprint':evaluated.get('input_fingerprint'),
            'source_versions':evaluated.get('source_versions'),
            'capabilities':evaluated.get('capabilities'),
            'result':evaluated.get('result'),
            'warnings':evaluated.get('warnings',[]),
        }
        encoded=json.dumps(_json_ready(saved),ensure_ascii=False,separators=(',',':'),allow_nan=False).encode('utf-8')
        if len(encoded)>48*1024:
            raise ValidationError('SNAPSHOT_RESULT_LIMIT','Resultado pontual excede o limite de 48 KiB.')
        return _json_ready(saved)

    def _verify_decision_chart(self, decision):
        """Check cached chart values against COMPARE; never trust posted money."""
        from decimal import localcontext, ROUND_HALF_UP
        cache=(decision or {}).get('result')
        if not cache:return
        for series in cache['series']:
            for index,group in enumerate(series['groups']):
                if group['horizon'] is None:
                    if any(group[key] is not None for key in ('base','minimum','maximum')):
                        raise ValidationError('E-COMPARISON-RESULT','Gráfico sem horizonte confirmado contém valores. Atualize a comparação.')
                    continue
                input_value=json.loads(json.dumps(series['input']))
                if cache['in_time']:
                    input_value['sale_date']=cache['dates'][index]
                    input_value['exit_price']={'mode':'MANUAL_RATE','annual_real_rate':series['baseRate']}
                alternatives=[]
                if series['baseRate'] is None:
                    alternatives=[{'id':'same-exit','label':'Mesma saída','input':input_value}]
                else:
                    for point_id,rate in [('lower',series['rates'][0]),('upper',series['rates'][2])]:
                        other=json.loads(json.dumps(input_value))
                        other['exit_price']={'mode':'MANUAL_RATE','annual_real_rate':rate}
                        alternatives.append({'id':point_id,'label':point_id,'input':other})
                response=self.simulator_workspace({
                    'schema_version':2,'action':'COMPARE','request_id':'snapshot-comparison','revision':1,
                    'reference':{'id':'reference','label':'Taxa-base','input':input_value},'alternatives':alternatives,
                    'horizon':group['horizon'],'cash_growth':{'annual_net_rate':cache['config']['cashRate'],
                        'profile':'ACT_365_COMPOUND_v1','origin_date':cache['config']['origin']},
                })
                items=(response.get('result') or {}).get('alternatives',[])
                ready=[item for item in items if item.get('status')=='ready'
                       and (item.get('total_resources_at_horizon') or {}).get('value') is not None]
                ready.sort(key=lambda item:D(str(item['total_resources_at_horizon']['value'])))
                reference=next((item for item in ready if item['id']=='reference'),None)
                expected=[reference,ready[0] if ready else None,ready[-1] if ready else None]
                consistent=group['complete']==(len(items)==3 and len(ready)==3)
                for key,item in zip(('base','minimum','maximum'),expected):
                    point=group[key]
                    if item is None or point is None:
                        consistent=consistent and item is None and point is None
                        continue
                    wealth=D(str(item['total_resources_at_horizon']['value']))
                    budget=D(str(series['budget']))
                    with localcontext() as ctx:
                        ctx.prec=256
                        change=(wealth/budget-1).quantize(D('0.000000000001'),rounding=ROUND_HALF_UP)
                    consistent=consistent and D(point['wealth'])==wealth and D(point['budget'])==budget and D(point['change'])==change
                    for metric,value in (point.get('metrics') or {}).items():
                        actual=(item.get('operation') or {}).get(metric)
                        consistent=consistent and ((actual is None and value is None)
                            or actual is not None and value is not None and D(str(actual))==D(value))
                    rate=series['baseRate'] if item['id']=='reference' else series['rates'][0] if item['id']=='lower' else series['rates'][2] if item['id']=='upper' else None
                    consistent=consistent and ((rate is None and point['rate'] is None) or rate is not None and point['rate'] is not None and D(str(rate))==D(point['rate']))
                operation=(reference or {}).get('operation') or {}
                for key,value in (group.get('operation') or {}).items():
                    actual=operation.get(key)
                    consistent=consistent and ((actual is None and value is None)
                        or actual is not None and value is not None and D(str(actual))==D(value))
                if not consistent:
                    raise ValidationError('E-COMPARISON-RESULT','O gráfico mudou em relação ao motor ou às fontes disponíveis. Atualize a comparação antes de salvar; seu rascunho foi preservado.')

    def _simulator_save_v2(self,body):
        from .market_sim.api import workspace_snapshot_request
        from .market_sim.contracts import ValidationError as MarketValidationError
        from .market_sim.service import engine_manifest

        try:
            request=workspace_snapshot_request(body)
        except MarketValidationError as exc:
            message=str(exc).partition(':')[2].strip() or 'Verifique os campos do snapshot.'
            raise ValidationError(exc.code,message) from exc
        operation_id=request.get('operation_id')
        operation_sha256=_canonical_hash(request) if operation_id is not None else None
        if operation_id is not None:
            previous=self.store.saved_operation('scenario',operation_id,operation_sha256)
            if previous is not None:
                _full,stored,_compatibility=self._load_simulator_snapshot(previous['id'],previous['revision'])
                return {**previous,'snapshot_sha256':stored['snapshot_sha256'],
                        'point_evaluations':stored['point_evaluations']}
        points={'current':self._simulator_snapshot_point(request['input'],request['selection'])}
        if request['reference'] is not None:
            item=request['reference']
            points['reference']=self._simulator_snapshot_point(item['input'],item['selection'])
        for item in request['alternatives']:
            points[item['id']]=self._simulator_snapshot_point(item['input'],item['selection'])
        self._verify_decision_chart(request['view'].get('decision'))
        if 'single_screen' in request['view']:
            from .simple_screen import capture_snapshot
            request['view']['single_screen'] = capture_snapshot(self, request['view']['single_screen'], request['input'], request['reference']['input'] if request['reference'] else None)

        selection=points['current'].get('selection')
        reference=request['reference']
        if reference is not None:
            reference={**reference,'selection':points['reference'].get('selection')}
        alternatives=[{**item,'selection':points[item['id']].get('selection')} for item in request['alternatives']]

        contexts={'current':request['input']}
        if reference is not None:
            contexts['reference']=reference['input']
        contexts.update({item['id']:item['input'] for item in alternatives})
        source_versions_by_context={key:_simulator_source_versions(value) for key,value in contexts.items()}
        all_sources=sorted({(item['kind'],item['hash']) for sources in source_versions_by_context.values()
                            for item in sources})
        decision=request['view'].get('decision') or {}
        decision_inputs=[item['seed'] for item in decision.get('cards',[])]
        decision_inputs.extend(item['input'] for item in (decision.get('result') or {}).get('series',[]))
        all_sources=sorted(set(all_sources) | {
            (source['kind'],source['hash']) for value in decision_inputs
            for source in _simulator_source_versions(value)
        })
        snapshot={
            'application':'renda2065.market_sim','snapshot_version':2,'schema_version':2,
            'captured_at':self.now().isoformat(),
            'input':request['input'],'selection':selection,
            'reference':reference,'alternatives':alternatives,
            'analysis':request['analysis'],'view':request['view'],
            'point_evaluations':points,
            'source_versions':[{'kind':kind,'hash':digest} for kind,digest in all_sources],
            'source_versions_by_context':source_versions_by_context,
            'engine':engine_manifest(),
        }
        encoded=json.dumps(snapshot,ensure_ascii=False,separators=(',',':'),allow_nan=False).encode('utf-8')
        from .simple_screen import snapshot_size_limit
        if len(encoded)>snapshot_size_limit(request['view']):
            raise ValidationError('SNAPSHOT_SIZE_LIMIT','Snapshot calculado excede o limite de armazenamento desta resolução.')
        digest=_canonical_hash(snapshot)
        try:
            saved=self.store.save_record(
                'scenario',request['name'],{**snapshot,'snapshot_sha256':digest},
                record_id=request.get('record_id'),expected_revision=request.get('expected_revision'),consent=True,
                operation_id=operation_id,operation_sha256=operation_sha256,
                payload_max_bytes=snapshot_size_limit(request['view'])+1024,
            )
        except ValidationError as exc:
            if exc.code=='E-CONFLICT':
                raise ValidationError('STALE_REVISION',str(exc)) from exc
            raise
        if operation_id is not None:
            # A concurrent retry may have won the transaction. Return that exact stored revision.
            _full,stored,_compatibility=self._load_simulator_snapshot(saved['id'],saved['revision'])
            return {**saved,'snapshot_sha256':stored['snapshot_sha256'],
                    'point_evaluations':stored['point_evaluations']}
        return {**saved,'snapshot_sha256':digest,'point_evaluations':points}

    def saved_catalog(self):
        """One metadata catalog; opening continues to use each record's own tools."""
        self._ensure()
        simulator = {row['id']: row for row in self.simulator_scenarios()['scenarios']}
        names = {'operation':'Análise detalhada','scenario':'Cenário da análise detalhada',
                 'quote':'Cotação','reconciliation':'Conferência','regression':'Caso de conferência',
                 'experiment':'Experimento','portfolio':'Carteira','paper':'Regra de acompanhamento'}
        rows = []
        for kind, label in names.items():
            for record in self.store.list_records(kind):
                is_simulator = record['id'] in simulator
                rows.append({**record, 'origin': 'simulator' if is_simulator else kind,
                    'label': 'Simulação' if is_simulator else label,
                    'open_behavior': 'Abrir sem recalcular' if is_simulator else
                        'Abrir e calcular com versões salvas' if kind in ('operation','scenario') else 'Abrir registro',
                    'instrument_id': simulator.get(record['id'],{}).get('instrument_id')})
        return {'records': sorted(rows, key=lambda row: row['updated_at'], reverse=True)}

    def simulator_scenarios(self):
        """List only versioned MTM snapshots; legacy scenario records stay untouched."""
        self._ensure()
        result=[]
        for row in self.store.list_records('scenario'):
            full=self.store.get_record(row['id'])
            snapshot=full.get('payload')
            version=snapshot.get('snapshot_version') if isinstance(snapshot,dict) else None
            if (not isinstance(snapshot,dict) or snapshot.get('application')!='renda2065.market_sim'
                    or type(version) is not int or version not in (1,2)):
                continue
            if version==1:
                request=snapshot.get('request') or {};scenario=request.get('scenario') or {};instrument=scenario.get('instrument') or {}
                family=instrument.get('family');instrument_id=instrument.get('instrument_id')
                as_of=(scenario.get('as_of') or {}).get('date')
                context_kind='OPERATION';timeline_mode='POINT';quality=None;source_versions=[];source_labels=[]
            else:
                workspace_input=snapshot.get('input') or {}
                if not isinstance(workspace_input,dict):workspace_input={}
                instrument=workspace_input.get('instrument') or {}
                if not isinstance(instrument,dict):instrument={}
                family=instrument.get('family');instrument_id=instrument.get('instrument_id')
                analysis_context=workspace_input.get('analysis_context') or {}
                if not isinstance(analysis_context,dict):analysis_context={}
                context_kind=analysis_context.get('kind') if analysis_context.get('kind') in ('OPERATION','UNIT_PRICE') else 'OPERATION'
                timeline=analysis_context.get('timeline') or {}
                if not isinstance(timeline,dict):timeline={}
                timeline_mode=timeline.get('mode') if timeline.get('mode') in ('POINT','WINDOW') else 'POINT'
                if analysis_context.get('kind')=='UNIT_PRICE':
                    as_of=workspace_input.get('purchase_date')
                else:
                    as_of=(snapshot.get('selection') or {}).get('sale_date') or workspace_input.get('sale_date')
                point_evaluations=snapshot.get('point_evaluations') or {}
                if not isinstance(point_evaluations,dict):point_evaluations={}
                point=point_evaluations.get('current') or {}
                if not isinstance(point,dict):point={}
                point_result=point.get('result') or {}
                if not isinstance(point_result,dict):point_result={}
                unit_price=point_result.get('unit_price') or {}
                if not isinstance(unit_price,dict):unit_price={}
                operation=point_result.get('operation') or {}
                if not isinstance(operation,dict):operation={}
                raw_quality=unit_price.get('quality') or operation.get('quality')
                quality=raw_quality if isinstance(raw_quality,str) and len(raw_quality)<=64 else None
                source_labels=[]
                input_data=workspace_input.get('data') or {}
                if not isinstance(input_data,dict):input_data={}
                index_anchors=input_data.get('index_anchors') or []
                price_index_levels=input_data.get('price_index_levels') or []
                if not isinstance(index_anchors,list):index_anchors=[]
                if not isinstance(price_index_levels,list):price_index_levels=[]
                for source_item in [*index_anchors, *price_index_levels]:
                    source_ref=source_item.get('source_ref') if isinstance(source_item,dict) else None
                    if isinstance(source_ref,str) and source_ref.strip():source_labels.append(source_ref.strip()[:120])
                for price in (workspace_input.get('entry_price') or {},workspace_input.get('exit_price') or {}):
                    source_ref=(price.get('provenance') or {}).get('source_ref') if isinstance(price,dict) else None
                    if isinstance(source_ref,str) and source_ref.strip():source_labels.append(source_ref.strip()[:120])
                source_labels=list(dict.fromkeys(source_labels))[:4]
                source_versions=[]
                saved_sources=snapshot.get('source_versions') or []
                if not isinstance(saved_sources,list):saved_sources=[]
                for source in saved_sources:
                    if not isinstance(source,dict):continue
                    kind=source.get('kind');digest=source.get('hash')
                    if (kind in ('market_sim','market_sim_indexes') and isinstance(digest,str)
                            and re.fullmatch(r'[0-9a-f]{64}',digest)):
                        source_versions.append({'kind':kind,'hash':digest})
            result.append({'id':full['id'],'name':full['name'],'revision':full['revision'],
                           'created_at':full['created_at'],'updated_at':full['updated_at'],
                           'family':family,'instrument_id':instrument_id,'as_of':as_of,
                           'context_kind':context_kind,'timeline_mode':timeline_mode,
                           'quality':quality,'source_labels':source_labels,'source_versions':source_versions,
                           'snapshot_version':version,
                           'single_screen':isinstance((snapshot.get('view') or {}).get('single_screen'),dict),
                           'snapshot_sha256':snapshot.get('snapshot_sha256')})
        return {'schema_version':1,'scenarios':result}

    def _load_simulator_snapshot(self,record_id,revision=None):
        self._ensure()
        if not isinstance(record_id,str) or not re.fullmatch(r'[0-9a-f]{32}',record_id):
            raise ValidationError('E-STORAGE','Identificador de cenário inválido.')
        if revision is not None and (type(revision) is not int or revision<1):
            raise ValidationError('E-STORAGE','Revisão de cenário inválida.')
        full=self.store.get_record(record_id,revision)
        snapshot=full.get('payload')
        version=snapshot.get('snapshot_version') if isinstance(snapshot,dict) else None
        if (full.get('kind')!='scenario' or not isinstance(snapshot,dict)
                or snapshot.get('application')!='renda2065.market_sim'
                or type(version) is not int or version not in (1,2)
                or snapshot.get('schema_version')!=version):
            raise ValidationError('E-SCENARIO','O registro não é um snapshot do simulador MTM.')
        unsigned={key:value for key,value in snapshot.items() if key!='snapshot_sha256'}
        digest=snapshot.get('snapshot_sha256')
        if not isinstance(digest,str) or not re.fullmatch(r'[0-9a-f]{64}',digest) or _canonical_hash(unsigned)!=digest:
            raise ValidationError('E-SNAPSHOT-INTEGRITY','A verificação do snapshot falhou. A fotografia foi preservada; não recalcule.')
        if snapshot['snapshot_version']==2:
            from .market_sim.api import workspace_snapshot_request
            from .market_sim.contracts import ValidationError as MarketValidationError
            expected_keys={
                'application','snapshot_version','schema_version','captured_at','input','selection',
                'reference','alternatives','analysis','view','point_evaluations','source_versions',
                'source_versions_by_context','engine','snapshot_sha256',
            }
            if set(snapshot)!=expected_keys:
                raise ValidationError('E-SNAPSHOT-INTEGRITY','Campos do snapshot v2 não correspondem ao schema guardado.')
            try:
                workspace_snapshot_request({
                    'schema_version':2,'name':full['name'],'consent':True,
                    'input':snapshot.get('input'),'selection':snapshot.get('selection'),
                    'reference':snapshot.get('reference'),'alternatives':snapshot.get('alternatives'),
                    'analysis':snapshot.get('analysis'),'view':snapshot.get('view'),
                })
            except MarketValidationError as exc:
                message=str(exc).partition(':')[2].strip() or 'Snapshot incompatível com o contrato v2.'
                raise ValidationError('E-SNAPSHOT-INTEGRITY',message) from exc
            contexts={'current':snapshot['input']}
            if snapshot['reference'] is not None:
                contexts['reference']=snapshot['reference']['input']
            contexts.update({item['id']:item['input'] for item in snapshot['alternatives']})
            expected_by_context={key:_simulator_source_versions(value) for key,value in contexts.items()}
            expected_sources=sorted({(item['kind'],item['hash']) for group in expected_by_context.values() for item in group})
            expected_sources=[{'kind':kind,'hash':digest} for kind,digest in expected_sources]
            if snapshot.get('source_versions_by_context')!=expected_by_context or snapshot.get('source_versions')!=expected_sources:
                raise ValidationError('E-SNAPSHOT-INTEGRITY','Referências de fontes do snapshot v2 não correspondem às entradas guardadas.')
            if not isinstance(snapshot.get('point_evaluations'),dict) or set(snapshot['point_evaluations'])!=set(contexts):
                raise ValidationError('E-SNAPSHOT-INTEGRITY','Avaliações pontuais não correspondem aos contextos guardados.')
            for evaluation in snapshot['point_evaluations'].values():
                if (not isinstance(evaluation,dict) or evaluation.get('status') not in {'ready','partial','unavailable'}
                        or ('result' not in evaluation) or (evaluation['result'] is not None and not isinstance(evaluation['result'],dict))):
                    raise ValidationError('E-SNAPSHOT-INTEGRITY','Avaliação pontual armazenada tem formato inválido.')
        missing=[]
        for source in snapshot.get('source_versions',[]):
            try:self.store.dataset(source['kind'],source['hash'])
            except (ValidationError,KeyError,TypeError):missing.append(source)
        from .market_sim.service import engine_manifest
        current=engine_manifest();saved=snapshot.get('engine') or {}
        changed={key:{'saved':saved.get(key),'current':current.get(key)} for key in sorted(set(saved)|set(current) if isinstance(saved,dict) else set(current)) if not isinstance(saved,dict) or saved.get(key)!=current.get(key)}
        state='MISSING_DATA_VERSION' if missing else 'RULE_VERSION_CHANGED' if changed else 'EXACT_SNAPSHOT_AVAILABLE'
        return full,snapshot,{'state':state,'integrity_verified':True,'missing_source_versions':missing,
                              'engine_changes':changed,'current_engine':current}

    def simulator_scenario(self,record_id,revision=None):
        full,snapshot,compatibility=self._load_simulator_snapshot(record_id,revision)
        return {'schema_version':snapshot['snapshot_version'],'id':full['id'],'name':full['name'],'kind':full['kind'],
                'revision':full['revision'],'revision_at':full['revision_at'],
                'snapshot':snapshot,'compatibility':compatibility}

    def simulator_recalculate(self,body):
        if not isinstance(body,dict) or type(body.get('schema_version')) is not int or body.get('schema_version') not in (1,2):
            raise ValidationError('E-SCHEMA','Recálculo requer schema_version 1 ou 2.')
        if set(body)-{'schema_version','id','revision'}:
            raise ValidationError('E-SCHEMA','Campo não reconhecido na solicitação de recálculo.')
        full,snapshot,compatibility=self._load_simulator_snapshot(body.get('id'),body.get('revision'))
        if compatibility['missing_source_versions']:
            raise ValidationError('E-SNAPSHOT-DEPENDENCY','Uma ou mais versões de dados do snapshot não estão disponíveis; resultado original permanece intacto.')
        if body['schema_version']==2:
            if snapshot['snapshot_version']!=2:
                raise ValidationError('E-SCHEMA','Recálculo v2 exige um snapshot v2.')
            contexts={'current':(snapshot['input'],snapshot.get('selection'))}
            if snapshot.get('reference') is not None:
                contexts['reference']=(snapshot['reference']['input'],snapshot['reference'].get('selection'))
            contexts.update({item['id']:(item['input'],item.get('selection')) for item in snapshot.get('alternatives',[])})
            current={key:self._simulator_snapshot_point(input_value,selection)
                     for key,(input_value,selection) in contexts.items()}
            previous=snapshot.get('point_evaluations',{})
            comparison={key:{
                'status_changed':(previous.get(key) or {}).get('status')!=value.get('status'),
                'result_changed':(previous.get(key) or {}).get('result')!=value.get('result'),
                'saved_status':(previous.get(key) or {}).get('status'),
                'current_status':value.get('status'),
            } for key,value in current.items()}
            from .market_sim.service import engine_manifest
            return {'schema_version':2,'id':full['id'],'revision':full['revision'],
                    'snapshot_sha256':snapshot['snapshot_sha256'],'compatibility':compatibility,
                    'saved_engine':snapshot.get('engine'),'current_engine':engine_manifest(),
                    'current_evaluations':current,'comparison':comparison}
        if snapshot['snapshot_version']!=1:
            raise ValidationError('E-SCHEMA','Recálculo v1 exige um snapshot v1.')
        evaluation=self.simulator_evaluate(snapshot['request'])
        old=snapshot['evaluation'];new=evaluation
        keys=('status','entry_pu','exit_pu','marked_value')
        comparison={'status_changed':old.get('status')!=new.get('status'),
                    'scenario_fields':{key:{'saved':old.get(key),'current':new.get(key),'changed':old.get(key)!=new.get(key)} for key in keys}}
        old_op=old.get('operation') or {};new_op=new.get('operation') or {}
        comparison['operation_fields']={key:{'saved':old_op.get(key),'current':new_op.get(key),'changed':old_op.get(key)!=new_op.get(key)}
            for key in ('status','gross_redemption','net_redemption','nominal_profit','nominal_return','annualized_nominal_return','real_profit','real_return')}
        return {'schema_version':1,'id':full['id'],'revision':full['revision'],'snapshot_sha256':snapshot['snapshot_sha256'],
                'compatibility':compatibility,'saved_engine':snapshot.get('engine'),'current_evaluation':new,'comparison':comparison}

    def _dataset(self,kind,digest=None):
        if digest=='none':return None
        return self.store.dataset(kind,digest or None)

    def bootstrap(self):
        from .market_sim.renda_plus import SUPPORTED_CONVERSION_YEARS
        defaults=form_defaults(self.now().date())
        if self.recovery_error:return {'recovery_error':self.recovery_error,'defaults':defaults,'backups':self.store.list_backups(),'version':VERSION,'data_dir':str(self.store.root),'profiles':PROFILES,'policies':policy_manifest()}
        hist=self._dataset('market');cal=self._dataset('calendar');vni=self._dataset('vni')
        defaults.update(history_hash=hist['hash'],calendar_hash=cal['hash'],vni_hash=vni['hash'] if vni else '')
        parsed=load_treasury_csv(hist['content'])
        active_sim={kind:(self._dataset(kind) or {}).get('hash') for kind in ('market_sim','market_sim_indexes')}
        return {'version':VERSION,'defaults':defaults,'profiles':PROFILES,'policies':policy_manifest(),'data_dir':str(self.store.root),
          'history':{'hash':hist['hash'],'first':parsed.quotes[0].observation_date.isoformat(),'last':parsed.quotes[-1].observation_date.isoformat(),'count':len(parsed.quotes),'source':hist['metadata'].get('source','Fonte identificada')},
          'dates':[{'date':q.observation_date.isoformat(),'buy_yield':q.buy_yield,'buy_pu':str(q.buy_pu) if q.buy_pu else None} for q in parsed.quotes if q.buy_pu is not None],
          'versions':{kind:self.store.dataset_versions(kind) for kind in ('market','calendar','vni','market_sim','market_sim_indexes')},
          'market_sim_active':active_sim,
          'simple_screen':{'max_dates':2048,'default_dates':61,'aligned_dates':True,'date_step_days':15,'converged_dates':True,'outside_period':True,'outside_original':True},
          'instrument_series_options':{'RENDA_PLUS':sorted(SUPPORTED_CONVERSION_YEARS)},
          'records':{kind:self.store.list_records(kind) for kind in ('operation','scenario','quote','reconciliation','regression')},
          'backups':self.store.list_backups()}

    def demo_form(self):
        self._ensure();v=form_defaults(self.now().date());b=self.bootstrap()['defaults']
        v.update(mode='Histórico / período',history_hash=b['history_hash'],calendar_hash=b['calendar_hash'],
          trade='2026-06-08',history_date='2026-06-08',settlement='2026-06-09',pu='172,89',quantity='100',entry_yield='7,27',
          asof='2026-09-18',start='2026-08-10',end='2028-08-10',inflation_ok=True,budget='20000')
        return v

    def _request(self,form):
        self._ensure()
        allowed=set(form_defaults(self.now().date()))
        unknown=set(form)-allowed
        if unknown:raise ValidationError('E-FORM','Campo não reconhecido: '+', '.join(sorted(unknown)))
        v={**form_defaults(self.now().date()),**form}
        for name in DATE_KEYS:
            try:v[name]=date.fromisoformat(str(v[name])) if v[name] else None
            except (TypeError,ValueError) as exc:raise ValidationError('E-DATE',f'Data inválida: {name}.') from exc
        for name in ('intermediate','inflation_ok','q_active','show_sensitivity'):
            if not isinstance(v[name],bool):raise ValidationError('E-FORM',f'O campo {name} deve ser verdadeiro ou falso.')
        calendar_data=self._dataset('calendar',v['calendar_hash'])
        pack=parse_calendar_pack(calendar_data['content']) if calendar_data else None
        calendar=FinancialCalendar(knowledge_date=v['asof'] or self.now().date(),overlay=pack)
        hist=self._dataset('market',v['history_hash'])
        history=load_treasury_csv(hist['content']) if hist else None
        if v['mode']=='Histórico / período':
            try:d=date.fromisoformat(v['history_date'])
            except ValueError as exc:raise ValidationError('E-DATE','Selecione uma cotação no período.') from exc
            q=next((q for q in history.quotes if q.observation_date==d and q.buy_pu is not None),None) if history else None
            if q is None:raise ValidationError('E-DATE','Cotação não encontrada na versão selecionada.')
            v['selected']=q;v['trade']=d
        else:v['selected']=None
        vni_data=None
        independent_anchors=None
        if v['anchor_mode']=='VNI independente importado':
            vni_data=self._dataset('vni',v['vni_hash'])
            if not vni_data:raise ValidationError('E-ANCHOR','Importe uma série de VNI independente ou escolha outra referência.')
            independent_anchors=parse_vni_csv(vni_data['content'])
        req,leftover,warnings=build_request(v,history,self.now(),calendar=calendar,independent_anchors=independent_anchors)
        clean={**form_defaults(self.now().date()),**form}
        # Pinar as versões públicas usadas, mesmo quando o cliente pediu a ativa.
        clean['history_hash']=hist['hash'] if hist else 'none';clean['calendar_hash']=calendar_data['hash'] if calendar_data else 'none'
        if vni_data:clean['vni_hash']=vni_data['hash']
        elif v['vni_hash']:clean['vni_hash']=self._dataset('vni',v['vni_hash'])['hash']
        profile=next((p for p in PROFILES if p['id']==clean['profile_id']),None)
        if profile is None:raise ValidationError('E-POLICY','Perfil de meta desconhecido.')
        if profile['target'] is not None and parse_number(profile['target'],'perfil')/100 != req.target:
            clean['profile_id']='custom_v1'
        clean['selected']=None
        return req,calendar,clean,leftover,warnings

    def analyze(self,form):
        req,calendar,clean,leftover,warnings=self._request(form)
        result=build_analysis(req,calendar)
        # Comparações são curvas auxiliares, nunca mudam o sinal da regra principal.
        if str(clean['compare_targets']).strip():
            targets,_=parse_rates(clean['compare_targets'])
            if any(not 0<=g<=2 for g in targets):raise ValidationError('E-AMOUNT','Metas comparadas devem ficar entre 0% e 200%.')
        else:targets=()
        condition=condition_chart(result)
        comparisons=[]
        for g in targets:
            if abs(g-float(req.target))<1e-10:continue
            other=build_analysis(replace(req,target=D(str(g)),scenario_yields=(req.scenario_yields[0],)),calendar)
            rows=[d for d in other.daily if d.eligible]
            line={'x':[d.date.isoformat() for d in rows],'y':[100*d.maximum_yield if d.maximum_yield is not None else None for d in rows],
              'type':'scatter','mode':'lines','name':f'Meta auxiliar {100*g:g}% líquidos','line':{'dash':'dot','width':1.5},'connectgaps':False,
              'hovertemplate':'%{x|%d/%m/%Y}<br>Taxa de resgate: %{y:.4f}%<extra></extra>'}
            condition.add_trace(line)
            comparisons.append({'target':g,'dates':[d.date.isoformat() for d in other.daily],'prices':[float(d.target_pu) for d in other.daily],
              'yields':[d.maximum_yield for d in other.daily]})
        price_chart=condition_chart(result,view='price')
        for c in comparisons:
            indices=[i for i,d in enumerate(result.daily) if d.eligible]
            price_chart.add_scatter(x=[c['dates'][i] for i in indices],y=[c['prices'][i] for i in indices],name=f"Meta auxiliar {c['target']*100:g}%",mode='lines',line={'dash':'dot','width':1.5})
        sensitivity=[]
        if clean['show_sensitivity']:
            extra=parse_number(clean['sensitivity_cost'],'incerteza de custo');bps=float(parse_number(clean['sensitivity_bps'],'oscilação de preço'))
            engine=PricingEngine(calendar)
            for d in result.daily:
                row={'date':d.date.isoformat(),**sensitivity_at_date(req.lot,d.settlement_date,req.target,req.fees,fee_uncertainty=extra,price_slippage_bps=bps)}
                for side in ('optimistic','pessimistic'):
                    pu=D(str(row[side+'_pu']))
                    row[side+'_yield']=solve_yield(engine,d.valuation_date,d.vni,pu,pu).verified_boundary if d.vni is not None else None
                sensitivity.append(row)
            for side,name in (('optimistic','favorável'),('pessimistic','desfavorável')):
                condition.add_scatter(x=[x['date'] for x in sensitivity],y=[100*x[side+'_yield'] if x[side+'_yield'] is not None else None for x in sensitivity],name='Hipótese '+name+' de custo/preço',line={'dash':'dash'},mode='lines',connectgaps=False)
            price_chart.add_scatter(x=[s['date'] for s in sensitivity],y=[s['optimistic_pu'] for s in sensitivity],name='Hipótese favorável de custo/preço',line={'dash':'dash'},mode='lines')
            price_chart.add_scatter(x=[s['date'] for s in sensitivity],y=[s['pessimistic_pu'] for s in sensitivity],name='Hipótese desfavorável de custo/preço',line={'dash':'dash'},mode='lines')
        snap=result.snapshot
        summary={'fingerprint':result.fingerprint,'input_hash':sha256(safe_json(clean).encode()).hexdigest(),
          'quantity':str(req.lot.quantity),'purchase_pu':str(req.lot.unit_price),'initial_outflow':float(req.lot.initial_outflow),
          'source_kind':req.lot.source_kind,'purchase_date':req.lot.trade_date.isoformat(),'settlement_date':req.lot.settlement_date.isoformat(),
          'first_eligible':result.first_eligible.isoformat(),'lock_end':req.lot.lock_end.isoformat(),'target':float(req.target),
          'target_net':float(req.lot.initial_outflow*(1+req.target)),'net':float(snap.financial.net) if snap else None,
          'profit':float(snap.financial.profit) if snap else None,'net_return':float(snap.financial.net_return) if snap else None,
          'annualized':snap.financial.annualized if snap else None,'quote_date':snap.quote.observation_date.isoformat() if snap else None,
          'stale':not snap.recent if snap else True,'message':snap.message if snap else 'Sem cotação válida para avaliar a posição.',
          'gap_money':float(req.lot.initial_outflow*(1+req.target)-snap.financial.net) if snap else None,
          'gap_return':float(req.target-snap.financial.net_return) if snap else None,'leftover':str(leftover) if leftover is not None else None,
          'calendar':calendar.coverage(req.as_of),'financial_policy':req.fees.policy_id,'elapsed_seconds':result.elapsed_seconds,
          'calculation_version':VERSION,'as_of':req.as_of.isoformat()}
        public={'id':uuid.uuid4().hex,'summary':summary,'input':clean,'warnings':list(result.warnings)+list(warnings),
          'daily':json_ready(result.daily),'scenarios':json_ready(result.scenarios),'crossings':json_ready(result.crossings),
          'target_comparisons':comparisons,'sensitivity':sensitivity,'policy':policy_manifest(),
          'figures':{'condition':json.loads(condition.to_json()),'price':json.loads(price_chart.to_json()),
            'profit':json.loads(profit_chart(result).to_json()),'money':json.loads(profit_chart(result,'money').to_json()),'annualized':json.loads(profit_chart(result,'annualized').to_json())},
          'plot_config':PLOT_CONFIG}
        with self._lock:
            self.results[public['id']]={'public':public,'result':result,'calendar':calendar}
            while len(self.results)>12:self.results.popitem(last=False)
        return public

    def get_analysis(self,identity,private=False):
        with self._lock:
            row=self.results.get(identity)
            if row is None:raise ValidationError('E-SESSION','Análise não está mais na sessão. Recalcule ou reabra a operação salva.')
            return row if private else row['public']

    def save_analysis(self,identity,name,kind,consent,record_id=None,expected_revision=None):
        if kind not in ('operation','scenario'):raise ValidationError('E-STORAGE','Escolha operação ou cenário.')
        a=self.get_analysis(identity)
        payload={'input':a['input'],'policy':a['policy'],'summary_at_save':a['summary'],'calculation_version':VERSION,
          'result_fingerprint':a['summary']['fingerprint'],'saved_asof':a['summary']['as_of']}
        saved=self.store.save_record(kind,name,payload,record_id=record_id,expected_revision=expected_revision,consent=consent)
        warning=self._daily_backup()
        if warning:saved['backup_warning']=warning
        return saved

    def _daily_backup(self):
        current=self.now().date().isoformat()
        backups=self.store.list_backups()
        if not any(x['created_at'][:10]==current for x in backups):
            try:self.store.create_backup('automático após gravação')
            except (OSError,ValidationError):return 'Não foi possível criar backup automático; faça um backup manual.'
        return None

    def _prepare_sidra_xlsx_update(self,raw,source,declared_acquired_on,original_filename):
        from .market_sim.market_data import parse_index_csv
        from .market_sim.sidra_xlsx import SIDRA_NUMBER_INDEX_SOURCE,convert_sidra_xlsx
        now=self.now()
        if not isinstance(now,datetime) or now.tzinfo is None:
            raise ValidationError('E-IMPORT-CLOCK','A importação XLSX requer horário local com fuso configurado.')
        imported_on=now.date()
        description=str(source or '').strip()
        if not description:description='Arquivo XLSX fornecido pelo usuário'
        if len(description)>250 or any(char in description for char in '\r\n'):
            raise ValidationError('E-SOURCE','Informe uma descrição de origem com até 250 caracteres.')
        filename=str(original_filename or 'arquivo.xlsx').strip()
        filename=re.split(r'[\\/]',filename)[-1][:255] or 'arquivo.xlsx'
        acquired=None
        if declared_acquired_on not in (None,''):
            try:acquired=date.fromisoformat(str(declared_acquired_on))
            except (ValueError,TypeError) as exc:
                raise ValidationError('E-ACQUISITION-DATE','A data declarada de obtenção é inválida.') from exc
            if acquired>imported_on:
                raise ValidationError('E-ACQUISITION-DATE','A data declarada de obtenção não pode estar no futuro.')
        canonical,workbook_details=convert_sidra_xlsx(raw,known_on=imported_on)
        parsed,details=parse_index_csv(canonical,imported_on=imported_on)
        if not parsed or any(row.kind!='IPCA_MONTHLY_INDEX' for row in parsed):
            raise ValidationError('E-SIDRA-XLSX','A planilha não produziu somente índices mensais IPCA.')
        current=self._dataset('market_sim_indexes')
        metadata={
            **details,
            'source':SIDRA_NUMBER_INDEX_SOURCE,
            'imported_on':imported_on.isoformat(),
            'known_on_policy':'data local da confirmação da importação; sem retrodatação',
            'institutional_publication':'unknown',
            'source_authenticated':False,
            'source_format':'SIDRA_XLSX_NUMBER_INDEX_V1',
            'coverage':{'first_reference':details['first_reference'],'last_reference':details['last_reference'],
                       'months':details['rows']},
        }
        if current:
            old_imported_on=date.fromisoformat(current['metadata'].get('imported_on',current['created_at'][:10]))
            old,old_details=parse_index_csv(current['content'],imported_on=old_imported_on)
            key=lambda row:(row.kind,row.reference_date)
            old_map={key(row):row for row in old};new_map={key(row):row for row in parsed}
            removed=sorted(old_map.keys()-new_map.keys())
            added=sorted(new_map.keys()-old_map.keys())
            changed=sorted(item for item in old_map.keys()&new_map.keys() if old_map[item]!=new_map[item])
            previous_coverage={'first_reference':old_details['first_reference'],
                               'last_reference':old_details['last_reference'],'rows':old_details['rows']}
            metadata['changes']={
                'added':len(added),'removed':len(removed),'changed':len(changed),
                'previous_hash':current['hash'],'previous_rows':old_details['rows'],
                'removed_reference_dates':[{'kind':kind,'date':reference.isoformat()} for kind,reference in removed],
                'coverage_loss':{
                    'previous':previous_coverage,
                    'next':metadata['coverage'],
                    'first_reference_moved_forward':date.fromisoformat(metadata['coverage']['first_reference'])>date.fromisoformat(previous_coverage['first_reference']),
                    'last_reference_moved_backward':date.fromisoformat(metadata['coverage']['last_reference'])<date.fromisoformat(previous_coverage['last_reference']),
                },
            }
        identity=uuid.uuid4().hex
        original_sha=sha256(raw).hexdigest()
        archive={
            'kind':'sidra_xlsx_original','content':raw,
            'metadata':{'source_profile':'SIDRA_XLSX_NUMBER_INDEX_V1','original_filename':filename,
                        'source_description':description,'source_authenticated':False},
        }
        import_details={
            'import_id':identity,'source_description':description,'original_filename':filename,
            'declared_acquired_on':acquired.isoformat() if acquired else None,
            'declared_acquisition_status':'user_declared_unverified' if acquired else None,
            'known_on':imported_on.isoformat(),'institutional_publication':'unknown',
            'source_authenticated':False,'adapter_metadata':workbook_details,
        }
        preview_metadata={
            **metadata,
            'provenance':{
                **import_details,'original_sha256':original_sha,
                'prepared_at_local':now.isoformat(),
                'imported_at_local':'Será registrado no momento da confirmação.',
            },
        }
        with self._lock:
            if len(self.pending)>5:self.pending.clear()
            self.pending[identity]={
                'kind':'market_sim_indexes','content':canonical,'original':None,'meta':metadata,
                'expected':current['hash'] if current else None,'source_archive':archive,
                'import_details':import_details,'known_on':imported_on,
            }
        return {'id':identity,'kind':'market_sim_indexes','metadata':preview_metadata,
                'expected_hash':current['hash'] if current else None,'requires_confirmation':True}

    def prepare_update(self,kind,raw,source,*,file_format=None,declared_acquired_on=None,original_filename=None):
        self._ensure()
        if file_format=='sidra_xlsx':
            if kind!='market_sim_indexes':
                raise ValidationError('E-IMPORT-FORMAT','XLSX SIDRA só pode ser importado como índice do simulador.')
            from .market_sim.contracts import ValidationError as MarketSimValidationError
            try:
                return self._prepare_sidra_xlsx_update(raw,source,declared_acquired_on,original_filename)
            except MarketSimValidationError as exc:
                prefix=f'{exc.code}: '
                message=str(exc)
                if message.startswith(prefix):message=message[len(prefix):]
                raise ValidationError(exc.code,message) from exc
        if file_format is not None:
            raise ValidationError('E-IMPORT-FORMAT','Formato de arquivo não reconhecido para esta atualização.')
        current=self._dataset(kind)
        if kind=='market':
            p=prepare_history(raw,current['content'] if current else None,today=self.now().date(),source=source)
            content=p.pop('content');original=p.pop('original_content');meta=p
        elif kind=='calendar':
            p=parse_calendar_pack(raw)
            if p.known_on>self.now().date():raise ValidationError('E-CALENDAR','A data de conhecimento do calendário está no futuro.')
            content=original=raw;meta={'source':source,'version':p.version,'known_on':p.known_on.isoformat(),'coverage':[p.valid_from.isoformat(),p.valid_until.isoformat()],
              'closures':len(p.closures),'note':'Pacote de fonte informada. Confirme a publicação; não autentica a fonte nem suspensões futuras.'}
        elif kind=='vni':
            rows=parse_vni_csv(raw)
            if any(a.known_on>self.now().date() for a in rows):raise ValidationError('E-ANCHOR','Série de VNI contém publicação futura.')
            content=original=raw;meta={'source':source,'rows':len(rows),'first':rows[0].valuation_date.isoformat(),'last':rows[-1].valuation_date.isoformat()}
        elif kind in ('market_sim','market_sim_indexes'):
            from .market_sim.market_data import parse_index_csv,parse_price_csv
            current=self._dataset(kind)
            parser=parse_price_csv if kind=='market_sim' else parse_index_csv
            parsed,details=parser(raw,imported_on=self.now().date())
            meta={**details,'source':source,'imported_on':self.now().date().isoformat(),
                  'raw_source_sha256':sha256(raw).hexdigest(),'source_authenticated':False}
            if current:
                old,old_details=parser(current['content'],imported_on=date.fromisoformat(current['metadata'].get('imported_on',current['created_at'][:10])))
                if kind=='market_sim':
                    key=lambda x:(x.instrument_id,x.observation_date)
                    old_map={key(x):x for x in old};new_map={key(x):x for x in parsed}
                else:
                    key=lambda x:(x.kind,x.reference_date)
                    old_map={key(x):x for x in old};new_map={key(x):x for x in parsed}
                meta['changes']={'added':len(new_map.keys()-old_map.keys()),'removed':len(old_map.keys()-new_map.keys()),
                                 'changed':sum(old_map[k]!=new_map[k] for k in old_map.keys()&new_map.keys()),
                                 'previous_hash':current['hash'],'previous_rows':old_details['rows']}
            content=original=raw
        else:raise ValidationError('E-STORAGE','Tipo de atualização inválido.')
        identity=uuid.uuid4().hex
        with self._lock:
            if len(self.pending)>5:self.pending.clear()
            self.pending[identity]={'kind':kind,'content':content,'original':original,'meta':meta,'expected':current['hash'] if current else None}
        return {'id':identity,'kind':kind,'metadata':meta,'expected_hash':current['hash'] if current else None,'requires_confirmation':True}

    def fetch_official(self):
        return self.prepare_update('market',download_official(),OFFICIAL_URL)

    def fetch_official_ipca(self):
        """Explicit acquisition only: retain the original and prepare, never activate."""
        from .market_sim.ibge_ipca import SOURCE_LABEL,fetch_ipca,convert_ipca
        from .market_sim.contracts import ValidationError as MarketValidationError
        try:
            raw,source_info=fetch_ipca()
            now=self.now()
            if not isinstance(now,datetime) or now.tzinfo is None:
                raise ValidationError('E-IMPORT-CLOCK','A atualização IPCA requer horário local com fuso configurado.')
            canonical,details=convert_ipca(raw,known_on=now.date(),content_encoding=source_info.get('content_encoding'))
            prepared=self.prepare_update('market_sim_indexes',canonical,SOURCE_LABEL)
        except MarketValidationError as exc:
            raise ValidationError(exc.code,str(exc).partition(':')[2].strip() or str(exc)) from exc
        identity=prepared['id']
        with self._lock:
            pending=self.pending[identity]
            metadata={**pending['meta'],'source_format':'IBGE_IPCA_JSON_V1',
                'source_authenticated':False,'institutional_publication':'unknown',
                'known_on_policy':'data local da confirmação; sem retrodatação',
                'coverage':{'first_reference':pending['meta']['first_reference'],
                            'last_reference':pending['meta']['last_reference'],'months':pending['meta']['rows']},
                'adapter_metadata':details}
            import_details={'import_id':identity,'source_description':SOURCE_LABEL,
                'original_filename':'ibge-ipca-1737-2266.json',
                'known_on':now.date().isoformat(),'obtained_at_local':now.isoformat(),
                'institutional_publication':'unknown','source_authenticated':False,
                'acquisition':source_info,'adapter_metadata':details}
            pending.update(meta=metadata,original=None,known_on=now.date(),
                source_archive={'kind':'ibge_ipca_original','content':raw,
                    'metadata':{'source_profile':'IBGE_IPCA_JSON_V1','acquisition':source_info}},
                import_details=import_details)
            prepared['metadata']={**metadata,'provenance':{
                **import_details,'original_sha256':sha256(raw).hexdigest(),
                'prepared_at_local':now.isoformat(),
                'imported_at_local':'Será registrado ao confirmar.'}}
        return prepared

    def _remember_update_outcome(self,identity,outcome):
        self.update_outcomes[identity]=outcome
        self.update_outcomes.move_to_end(identity)
        while len(self.update_outcomes)>128:self.update_outcomes.popitem(last=False)

    def _update_outcome(self,identity):
        # Another service may have restored this store. RAM cannot certify that a
        # receipt still belongs to the currently installed backup timeline.
        outcome=self.store.update_outcome(identity)
        if outcome is None:self.update_outcomes.pop(identity,None)
        else:self._remember_update_outcome(identity,outcome)
        return outcome

    def cancel_update(self,identity):
        if not isinstance(identity,str) or not re.fullmatch(r'[0-9a-f]{32}',identity):
            raise ValidationError('E-SESSION','Identidade de prévia inválida.')
        with self._lock:
            if identity in self.pending:
                outcome=self.store.cancel_dataset_update(identity)
                del self.pending[identity]
                self._remember_update_outcome(identity,outcome)
            outcome=self._update_outcome(identity)
            if outcome and outcome.get('status')=='already_committed':
                return {'id':identity,'status':'already_committed','result':outcome.get('result')}
            if outcome:return {'id':identity,'status':outcome.get('status','not_pending')}
            return {'id':identity,'status':'not_pending'}

    def commit_update(self,identity,confirmed=False):
        if not confirmed:raise ValidationError('E-CONSENT','Confira a prévia e confirme antes de ativar a atualização.')
        if not isinstance(identity,str) or not re.fullmatch(r'[0-9a-f]{32}',identity):
            raise ValidationError('E-SESSION','Identidade de prévia inválida.')
        with self._lock:
            outcome=self._update_outcome(identity)
            if outcome and outcome.get('status')=='already_committed':
                return {**outcome['result'],'confirmation_replayed':True}
            p=self.pending.get(identity)
            if p is None or outcome is not None:
                raise ValidationError('E-SESSION','Prévia expirada. Prepare a atualização novamente.')
            now=self.now()
            if p.get('known_on') is not None:
                if not isinstance(now,datetime) or now.tzinfo is None:
                    raise ValidationError('E-IMPORT-CLOCK','A confirmação de índices requer horário local com fuso configurado.')
                if now.date()!=p['known_on']:
                    raise ValidationError('E-IMPORT-DATE-CHANGED','A data mudou desde a prévia. Prepare novamente para registrar o conhecimento no dia real da importação.')
            # Backup de dados ativos antes de qualquer mudança de referência.
            self.store.create_backup('antes de atualizar '+p['kind'])
            if p.get('source_archive') is not None:
                receipt={**p['import_details'],'imported_at_local':now.isoformat()}
                row=self.store.commit_dataset(p['kind'],p['content'],p['meta'],expected_hash=p['expected'],
                    source_archive=p['source_archive'],import_receipt=receipt,update_id=identity)
            else:
                row=self.store.commit_dataset(p['kind'],p['content'],p['meta'],expected_hash=p['expected'],original_content=p['original'],update_id=identity)
            del self.pending[identity]
            self._remember_update_outcome(identity,{'id':identity,'status':'already_committed','result':row})
        return row

    def reconciliation(self,identity,observed,settlement=None):
        x=self.get_analysis(identity,True);r=x['result'];snap=r.snapshot
        try:day=date.fromisoformat(settlement) if settlement else (snap.quote.redemption_settlement_date if snap else None)
        except (ValueError,TypeError) as exc:raise ValidationError('E-DATE','Data de liquidação da conferência inválida.') from exc
        if day is None:
            qdate=snap.quote.observation_date if snap else r.request.as_of
            day=x['calendar'].redemption_settlement(qdate,r.request.settlement_lag)
        report=reconcile(r.request.lot,day,r.request.fees,observed,r.request.target)
        report['settlement']=day.isoformat();report['analysis_id']=identity
        return report

    def independent_vni(self,identity,value,day,source):
        x=self.get_analysis(identity,True);r=x['result'];d=date.fromisoformat(day)
        if d>r.request.as_of:raise ValidationError('E-ANCHOR','VNI posterior à referência da análise.')
        q=next((q for q in r.request.quotes if q.observation_date==d),None)
        if not q:raise ValidationError('E-ANCHOR','Não há cotação pareada nessa data na versão escolhida.')
        return compare_vni(float(parse_number(value,'VNI')),d,q,PricingEngine(x['calendar']),source)

    def save_reconciliation(self,identity,observed,settlement,name,kind,consent,quote_metadata=None):
        if kind not in ('quote','reconciliation','regression'):raise ValidationError('E-STORAGE','Tipo de conferência inválido.')
        report=self.reconciliation(identity,observed,settlement)
        data=self.get_analysis(identity)
        metadata={k:str((quote_metadata or {}).get(k,'')).strip() for k in ('date','time','source')}
        try:
            if metadata['date']:
                observed_day=date.fromisoformat(metadata['date'])
                if observed_day>self.now().date():raise ValueError('observação futura')
            if metadata['time']:datetime.strptime(metadata['time'],'%H:%M')
            if len(metadata['source'])>250:raise ValueError('fonte extensa')
        except (ValueError,TypeError) as exc:raise ValidationError('E-DATE','Confira data, horário e origem da cotação registrada.') from exc
        payload={'quote_metadata':metadata,'analysis_input':data['input'],'observed':report['observed'],'settlement':report['settlement'],
          'report':report,'policy':data['policy'],'calculation_version':VERSION,'provenance':'Dados informados; conferir no comprovante; não certificados pelo aplicativo'}
        saved=self.store.save_record(kind,name,payload,consent=consent)
        warning=self._daily_backup()
        if warning:saved['backup_warning']=warning
        return saved

    def check_saved_reconciliations(self):
        reports=[]
        for entry in self.store.list_records('regression'):
            record=self.store.get_record(entry['id'])['payload']
            try:
                result=self.analyze(record['analysis_input'])
                report=self.reconciliation(result['id'],record['observed'],record['settlement'])
                gap=report['net_gap']
                ok=report['components_consistent'] is True and gap is not None and abs(gap)<=.02
                reports.append({'name':entry['name'],'status':'Coincidente na tolerância' if ok else 'Divergência ou dados incompletos','gap':gap})
            except (ValidationError,KeyError) as exc:reports.append({'name':entry['name'],'status':str(exc),'gap':None})
        return reports

    def restore_backup(self,backup_id,confirmed=False):
        with self._lock:
            r=self.store.restore_backup(backup_id,confirmed=confirmed)
            self.results.clear();self.pending.clear();self.update_outcomes.clear();self.recovery_error=None
        return r
