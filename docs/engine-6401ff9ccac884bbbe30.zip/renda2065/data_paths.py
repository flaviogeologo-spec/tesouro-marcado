"""Local data stays beside the project or the packaged executable."""
from pathlib import Path
import os
import sys

PROJECT_ROOT = Path(__file__).resolve().parents[2]


def resolve_data_dir(data_dir=None):
    if data_dir is None:
        data_dir = os.environ.get('RENDA2065_DATA_DIR')
        if not data_dir:
            root = Path(sys.executable).resolve().parent if getattr(sys, 'frozen', False) else PROJECT_ROOT
            data_dir = root / 'dados-locais'
    return Path(data_dir).expanduser().resolve()
