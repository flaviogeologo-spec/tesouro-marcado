"""Orquestração pura: uma fotografia de entradas produz todos os painéis."""
from __future__ import annotations
from dataclasses import dataclass
from datetime import date, datetime, timedelta
from decimal import Decimal as D, ROUND_DOWN
from hashlib import sha256
from zoneinfo import ZoneInfo
from math import isfinite
import time
from .models import (AnalysisRequest, PurchaseLot, Quote, PricingAnchor,
                     ValidationError, VERSION, decimal_value)
from .calendar_rules import FinancialCalendar
from .exit_targets import target_price
from .tax_and_fees import NetResult, net_proceeds, annualized_return
from .pricing import (PricingEngine, select_anchor, infer_anchor, projected_vni,
                      solve_yield, validate_yield)


@dataclass(frozen=True)
class DailyResult:
    date: date
    valuation_date: date
    settlement_date: date
    age_days: int
    is_session: bool
    lock_expired: bool
    eligible: bool
    tax_rate: D
    target_pu_continuous: D
    target_pu: D
    target_net: D
    target_custody: D
    target_tax: D
    vni: float | None
    vni_source: str
    anchor_source: str
    maximum_yield: float | None
    conservative_yield: float | None
    continuous_yield: float | None
    root_status: str
    root_residual_pu: float | None
    target_annualized: float | None
    root_bracket: tuple[float,float] | None = None


@dataclass(frozen=True)
class ScenarioResult:
    date: date
    input_yield: float
    effective_yield: float
    pu: D | None
    financial: NetResult | None
    target_met: bool
    eligible: bool
    source_kind: str
    reason: str = ''


@dataclass(frozen=True)
class Crossing:
    input_yield: float
    status: str
    first_date: date | None
    last_return: D | None
    last_annualized: float | None
    last_evaluable_date: date | None


@dataclass(frozen=True)
class SnapshotResult:
    quote: Quote
    financial: NetResult
    target_met: bool
    eligible_at_quote: bool
    recent: bool
    message: str
    narrow_margin: bool


@dataclass(frozen=True)
class AnalysisResult:
    request: AnalysisRequest
    daily: tuple[DailyResult,...]
    scenarios: tuple[ScenarioResult,...]
    crossings: tuple[Crossing,...]
    snapshot: SnapshotResult | None
    observations: tuple[Quote,...]
    first_eligible: date
    warnings: tuple[str,...]
    fingerprint: str
    elapsed_seconds: float
    version: str = VERSION


def anchors_from_quotes(quotes:tuple[Quote,...],as_of:date,engine:PricingEngine)->tuple[PricingAnchor,...]:
    anchors=[]
    for q in quotes:
        if q.observation_date>as_of:
            continue
        try:
            anchors.append(infer_anchor(q,engine))
        except ValidationError:
            continue
    return tuple(anchors)


def lot_from_budget(trade:date,settlement:date,pu:D,budget:D,entry_fee:D=D(0),entry_yield:float|None=None,
                    source:str='HIPOTETICA')->tuple[PurchaseLot,D]:
    pu=decimal_value(pu);budget=decimal_value(budget);entry_fee=decimal_value(entry_fee)
    if pu<=0 or budget<=entry_fee or entry_fee<0:
        raise ValidationError('E-AMOUNT','O orçamento deve cobrir o título e as despesas iniciais.')
    q=((budget-entry_fee)/pu).quantize(D('.01'),rounding=ROUND_DOWN)
    if q<=0:
        raise ValidationError('E-AMOUNT','Orçamento insuficiente para 0,01 título.')
    lot=PurchaseLot(trade,settlement,q,pu,entry_fee=entry_fee,entry_yield=entry_yield,source_kind=source)
    return lot,budget-lot.initial_outflow


def hypothetical_by_yield(trade:date,settlement:date,y:float,budget:D,anchors:tuple[PricingAnchor,...],
                          engine:PricingEngine,inflation:float,entry_fee:D=D(0))->tuple[PurchaseLot,D]:
    if not engine.calendar.is_session(trade):
        raise ValidationError('E-DATE','Data da compra hipotética sem sessão; escolha outra data explicitamente.')
    anchor=select_anchor(anchors,settlement,trade,trade)
    if anchor is None:
        raise ValidationError('E-ANCHOR','Não há âncora conhecida até a compra para reconstruir o preço.')
    vni=projected_vni(anchor,settlement,inflation)
    pu=engine.price(settlement,y,vni)
    if pu<=0:
        raise ValidationError('E-YIELD-DOMAIN','A taxa produz PU inferior a um centavo no modelo.')
    return lot_from_budget(trade,settlement,pu,budget,entry_fee,y,'HIPOTETICA_POR_TAXA')


def evaluate_snapshot(request:AnalysisRequest,calendar:FinancialCalendar)->SnapshotResult|None:
    if request.as_of < request.lot.settlement_date:
        return None  # Compra pendente: apenas cenários futuros, sem valor de resgate atual.
    q=request.snapshot
    if q is None:
        valid=[x for x in request.quotes if request.lot.settlement_date<=x.observation_date<=request.as_of
               and (x.redemption_pu is not None or x.net_total is not None)]
        q=max(valid,key=lambda x:x.observation_date) if valid else None
    if q is None:
        return None
    if q.observation_date<request.lot.settlement_date:
        raise ValidationError('E-DATE','A cotação de avaliação é anterior à liquidação da compra.')
    if q.observation_date>request.as_of:
        raise ValidationError('E-DATE','Cotação posterior à referência da análise.')
    settlement=q.redemption_settlement_date or calendar.redemption_settlement(q.observation_date,request.settlement_lag)
    r=net_proceeds(request.lot,q.redemption_pu,settlement,request.fees,
                   custody_override=q.custody_override,net_override=q.net_total)
    economic=r.meets(request.lot,request.target)
    eligible=calendar.eligible(request.lot,q.observation_date)
    now=request.now or datetime.now(ZoneInfo('America/Sao_Paulo'))
    recent=False
    if q.observed_at is not None and q.source_kind=='COTACAO_INFORMADA':
        age=(now-q.observed_at).total_seconds()
        recent=(0<=age<=request.quote_fresh_minutes*60 and request.as_of==now.date()
                and q.observation_date==request.as_of and q.session_declared_active)
    when=f'{q.observation_date:%d/%m/%Y}'
    if not eligible:
        message=(f'Meta atendida na avaliação de {when}, mas sem elegibilidade de resgate nessa data.' if economic
                 else f'Meta não atendida na avaliação de {when}; sem elegibilidade de resgate nessa data.')
    elif recent:
        message=('Meta atendida na cotação informada; confirme preço, custos e liberação na instituição.' if economic
                 else 'Liberado pelo calendário; meta não atendida na cotação informada.')
    else:
        message=f"Meta {'atendida' if economic else 'não atendida'} na cotação de {when}; não é um sinal atual."
    if request.lot.source_kind!='REAL_COMPRA':
        message='Compra hipotética — '+message
    return SnapshotResult(q,r,economic,eligible,recent,message,abs(r.net_return-request.target)<D('.0005'))


def first_crossing(rate:float,rows:tuple[ScenarioResult,...])->Crossing:
    matching=[x for x in rows if x.input_yield==rate]
    valid=[x for x in matching if x.financial is not None]
    if not valid:
        return Crossing(rate,'INSUFFICIENT',None,None,None,None)
    eligible=[x for x in valid if x.eligible]
    first=next((x for x in eligible if x.target_met),None)
    last=valid[-1]
    status='CROSSED' if first else 'NOT_REACHED' if eligible else 'NO_ELIGIBLE_DATE'
    return Crossing(rate,status,first.date if first else None,last.financial.net_return,
                    last.financial.annualized,last.date)


def build_analysis(request:AnalysisRequest, calendar:FinancialCalendar|None=None)->AnalysisResult:
    start_clock=time.perf_counter()
    calendar=calendar or FinancialCalendar(knowledge_date=request.as_of)
    engine=PricingEngine(calendar)
    last_settlement=calendar.redemption_settlement(request.end_date,request.settlement_lag)
    if last_settlement>request.lot.max_redemption_date:
        raise ValidationError('E-HORIZON','A liquidação da última data alcança dez anos/conversão; reduza o horizonte.')
    warnings=[calendar.warning,'Custódia: estimativa linear ACT/365 sobre o valor bruto de resgate; IR conforme política vigente parametrizada.']
    if request.as_of < request.lot.settlement_date:
        warnings.append('Compra aguardando liquidação: somente cenários futuros; ainda não há avaliação de resgate do lote.')
    if request.lot.entry_yield is not None and request.lot.entry_yield+1e-12<request.entry_reference:
        warnings.append('Compra abaixo da referência histórica de entrada; o alvo continua sendo calculado normalmente.')
    if not request.anchors:
        warnings.append('Preço mínimo disponível; taxa equivalente e cenários por taxa exigem VNI ou cotação pareada.')
    if request.inflation<0:
        warnings.append('Deflação é hipótese explícita; a trajetória do resultado não precisa ser crescente.')
    if request.start_date<request.lot.lock_end:
        warnings.append('Datas em carência são avaliações teóricas não executáveis; antes de 30 dias não incluem IOF.')
    if request.lot.institution_release_date and request.lot.institution_release_date!=request.lot.theoretical_lock_end:
        warnings.append('Data de liberação informada diverge do cálculo de 60 dias; adotada a mais tardia.')
    if request.inflation_monthly:
        warnings.append('Inflação mensal informada é cenário; os meses ausentes usam a hipótese anual. Não é IPCA oficial.')
    daily=[];scenario=[];diagnostics=set()
    # A fotografia admite taxas inválidas isoladas sem apagar os demais cenários.
    scenario_valid={}
    for y in request.scenario_yields:
        effective=float(D(str(y))+D(str(request.spread or 0))) if request.scenario_kind=='compra' else y
        try:
            validate_yield(effective);scenario_valid[y]=(effective,'')
        except ValidationError as exc:
            scenario_valid[y]=(effective,str(exc));diagnostics.add(str(exc))
    current=request.start_date
    while current<=request.end_date:
        settlement=calendar.redemption_settlement(current,request.settlement_lag)
        valuation=settlement
        age=(settlement-request.lot.settlement_date).days
        session=calendar.is_session(current)
        eligible=calendar.eligible(request.lot,current)
        target=target_price(request.lot,settlement,request.target,request.fees)
        at_target=net_proceeds(request.lot,target.tick,settlement,request.fees)
        anchor=select_anchor(request.anchors,valuation,request.as_of,current)
        vni=None;source='SEM_ANCORA';anchor_source='';root=None
        if anchor:
            try:
                vni=projected_vni(anchor,valuation,request.inflation,request.inflation_monthly)
                source=anchor.source_kind if valuation==anchor.valuation_date else 'PROJECAO'
                anchor_source=f'{anchor.valuation_date:%d/%m/%Y}: {anchor.source_ref}'
                root=solve_yield(engine,valuation,vni,target.continuous,target.tick)
                if root.status!='OK':diagnostics.add(root.reason)
            except ValidationError as exc:
                diagnostics.add(str(exc));vni=None
        if anchor and anchor.quality_flags and current>=request.as_of:
            diagnostics.update(anchor.quality_flags)
        day=DailyResult(current,valuation,settlement,age,session,current>=request.lot.lock_end,eligible,
                        at_target.tax_rate,target.continuous,target.tick,target.target_amount,at_target.custody,
                        at_target.tax,vni,source,anchor_source,root.verified_boundary if root else None,
                        root.tick if root else None,root.continuous if root else None,
                        root.status if root else 'NO_ANCHOR',root.residual_pu if root else None,
                        annualized_return(target.target_amount,request.lot.initial_outflow,age),root.bracket if root else None)
        daily.append(day)
        for rate,(effective,error) in scenario_valid.items():
            pu=financial=None;reason=error;met=False
            if vni is not None and not error:
                try:
                    pu=engine.price(valuation,effective,vni)
                    if pu<=0:
                        raise ValidationError('E-YIELD-DOMAIN','O preço do cenário é inferior a R$ 0,01.')
                    financial=net_proceeds(request.lot,pu,settlement,request.fees)
                    met=financial.meets(request.lot,request.target)
                except ValidationError as exc:
                    reason=str(exc);diagnostics.add(reason)
            elif not error:
                reason='Dados insuficientes para preço/taxa nesta data.'
            scenario.append(ScenarioResult(current,rate,effective,pu,financial,met,eligible,'CENARIO_HIPOTETICO',reason))
        current+=timedelta(days=1)
    rows=tuple(scenario)
    snapshot=evaluate_snapshot(request,calendar)
    if snapshot and snapshot.narrow_margin:
        warnings.append('Margem estreita na cotação: custos e execução efetivos podem mudar o atendimento da meta.')
    observations=tuple(q for q in request.quotes if request.start_date<=q.observation_date<=min(request.end_date,request.as_of))
    # Hash apenas dos insumos conhecidos: dados futuros excluídos não alteram a identidade.
    known_quotes=tuple(q for q in request.quotes if q.observation_date<=request.as_of)
    identity=(request.lot,request.as_of,request.start_date,request.end_date,request.target,
              request.scenario_yields,request.scenario_kind,request.spread,request.inflation,
              request.fees,request.settlement_lag,request.anchors,known_quotes,request.snapshot,repr(calendar),VERSION)
    fingerprint=sha256(repr(identity).encode()).hexdigest()[:16]
    return AnalysisResult(request,tuple(daily),rows,tuple(first_crossing(y,rows) for y in request.scenario_yields),
                          snapshot,observations,calendar.first_eligible(request.lot),
                          tuple(dict.fromkeys(warnings+sorted(diagnostics))),fingerprint,time.perf_counter()-start_clock)
