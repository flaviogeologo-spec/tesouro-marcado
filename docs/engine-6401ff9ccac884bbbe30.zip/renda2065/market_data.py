"""Atualização somente por ação explícita. Preparar não altera o histórico ativo."""
from __future__ import annotations
from datetime import date,datetime
from decimal import Decimal as D
from hashlib import sha256
import csv
import io
import socket
import ssl
import time
from http.client import HTTPException
from urllib.error import URLError,HTTPError
from urllib.parse import urlparse
from urllib.request import Request,build_opener,HTTPSHandler,HTTPRedirectHandler
from .csv_loader import load_treasury_csv,normalized
from .models import PricingAnchor,ValidationError
from .formatting import parse_number

OFFICIAL_URL='https://www.tesourotransparente.gov.br/ckan/dataset/df56aa42-484a-4a59-8184-7676580c81e3/resource/796d2059-14e9-44e3-80c9-2d9e30b405c1/download/precotaxatesourodireto.csv'
MAX_DOWNLOAD=60*1024*1024

class RestrictedRedirect(HTTPRedirectHandler):
    def redirect_request(self,req,fp,code,msg,headers,newurl):
        u=urlparse(newurl)
        if u.scheme!='https' or u.hostname not in {'www.tesourotransparente.gov.br','tesourotransparente.gov.br'}:
            raise ValidationError('E-DOWNLOAD','Redirecionamento fora da fonte oficial bloqueado; importe o CSV manualmente.')
        return super().redirect_request(req,fp,code,msg,headers,newurl)


def download_official(*,opener=None)->bytes:
    req=Request(OFFICIAL_URL,headers={'User-Agent':'Renda2065-Local/2.0 (historical CSV)','Accept':'text/csv, application/octet-stream, text/plain'})
    open_fn=opener or build_opener(RestrictedRedirect(),HTTPSHandler(context=ssl.create_default_context())).open
    started=time.monotonic()
    try:
        with open_fn(req,timeout=15) as response:
            ctype=str(response.headers.get('Content-Type','')).lower()
            if 'html' in ctype:raise ValidationError('E-DOWNLOAD','A fonte retornou uma página, não o histórico. A base anterior foi preservada.')
            length=response.headers.get('Content-Length')
            if length and int(length)>MAX_DOWNLOAD:raise ValidationError('E-DOWNLOAD','Arquivo remoto excede 60 MB.')
            chunks=[];size=0
            while True:
                if time.monotonic()-started>45:raise TimeoutError('prazo total')
                piece=response.read(128*1024)
                if not piece:break
                size+=len(piece)
                if size>MAX_DOWNLOAD:raise ValidationError('E-DOWNLOAD','Arquivo remoto excede 60 MB.')
                chunks.append(piece)
            raw=b''.join(chunks)
            if length and len(raw)!=int(length):raise ValidationError('E-DOWNLOAD','A fonte enviou um arquivo incompleto. Tente novamente; a base anterior foi preservada.')
            if not raw or raw.lstrip().startswith(b'<'):raise ValidationError('E-DOWNLOAD','Resposta inválida da fonte; nenhuma alteração aplicada.')
            return raw
    except ValidationError:raise
    except (URLError,HTTPError,TimeoutError,socket.timeout,OSError,ValueError,HTTPException) as exc:
        raise ValidationError('E-DOWNLOAD','Não foi possível obter o CSV oficial agora. Confira internet/proxy ou importe o arquivo; os dados anteriores foram preservados.') from exc


def _key(q):
    return (q.buy_yield,q.redemption_yield,q.buy_pu,q.redemption_pu,q.reference_pu)


def canonical_csv(quotes):
    out=io.StringIO(newline='');w=csv.writer(out,delimiter=';',lineterminator='\n')
    w.writerow(['Tipo Titulo','Data Vencimento','Data Base','Taxa Compra Manha','Taxa Venda Manha','PU Compra Manha','PU Venda Manha','PU Base Manha'])
    def fmt(v,rate=False):
        if v is None:return ''
        x=D(str(v))*100 if rate else v
        return format(x,'f').replace('.',',')
    for q in sorted(quotes,key=lambda q:q.observation_date):
        w.writerow(['Tesouro Renda+ Aposentadoria Extra','15/12/2084',q.observation_date.strftime('%d/%m/%Y'),fmt(q.buy_yield,True),fmt(q.redemption_yield,True),fmt(q.buy_pu),fmt(q.redemption_pu),fmt(q.reference_pu)])
    return out.getvalue().encode('utf-8-sig')


def prepare_history(raw:bytes,previous:bytes|None=None,*,today:date,source='Arquivo informado'):
    if len(raw)>MAX_DOWNLOAD:raise ValidationError('E-CSV-SCHEMA','Arquivo excede 60 MB.')
    # A base consolidada pode conter vários títulos: filtrar em streaming antes do
    # parser estrito de 25 MB. Os bytes originais continuam preservados no estágio.
    if len(raw)>25*1024*1024:
        try:text=raw.decode('utf-8-sig')
        except UnicodeDecodeError:text=raw.decode('cp1252')
        reader=csv.DictReader(io.StringIO(text),delimiter=';');buf=io.StringIO();writer=csv.DictWriter(buf,fieldnames=reader.fieldnames or [],delimiter=';');writer.writeheader()
        count=0
        for row in reader:
            count+=1
            if count>1500000:raise ValidationError('E-CSV-SCHEMA','Limite de linhas excedido.')
            if normalized(row.get('Tipo Titulo',''))=='tesouro renda+ aposentadoria extra' and row.get('Data Vencimento')=='15/12/2084':writer.writerow(row)
        filtered=buf.getvalue().encode('utf8')
    else:filtered=raw
    parsed=load_treasury_csv(filtered)
    if any('inválidos' in w for w in parsed.warnings):raise ValidationError('E-CSV-SCHEMA','Há valores inválidos no título selecionado; corrija o arquivo antes de ativar.')
    if any(q.observation_date>today for q in parsed.quotes):raise ValidationError('E-DATE','Histórico contém observações futuras; nenhuma alteração aplicada.')
    old={q.observation_date:q for q in load_treasury_csv(previous).quotes} if previous else {}
    incoming={q.observation_date:q for q in parsed.quotes}
    changed=[];added=0
    for day,q in incoming.items():
        if q.buy_pu is None and q.redemption_pu is None:raise ValidationError('E-CSV-SCHEMA','Uma observação do título não tem preço utilizável.')
        if day not in old:added+=1
        elif _key(old[day])!=_key(q):
            # Nunca substituir dado existente por ausência sem resolução explícita.
            if any(a is not None and b is None for a,b in zip(_key(old[day]),_key(q))):
                raise ValidationError('E-DATA-LOSS','Atualização removeria campos existentes; base anterior preservada.')
            changed.append({'date':day.isoformat(),'before':[str(x) if x is not None else None for x in _key(old[day])],'after':[str(x) if x is not None else None for x in _key(q)]})
    merged={**old,**incoming};content=canonical_csv(merged.values())
    return {'content':content,'original_content':raw,'original_hash':sha256(raw).hexdigest(),
      'previous_original_hash':sha256(previous).hexdigest() if previous else None,'hash':sha256(content).hexdigest(),
      'row_count':len(merged),'first_date':min(merged).isoformat(),'last_date':max(merged).isoformat(),
      'source':source,'changes':{'added':added,'revised':len(changed),'preserved_missing':len(set(old)-set(incoming)),'details':changed[:100]},
      'warnings':list(parsed.warnings),'same_values':not added and not changed and bool(previous)}


def parse_vni_csv(raw:bytes):
    try:
        if len(raw)>1024*1024:raise ValueError('limite')
        text=raw.decode('utf-8-sig');reader=csv.DictReader(io.StringIO(text),delimiter=';')
        mapping={normalized(k):k for k in reader.fieldnames or []}
        if not {'data','conhecido em','vni','fonte'}<=set(mapping):raise ValueError('cabeçalho')
        result=[];seen=set()
        for row in reader:
            get=lambda k:row[mapping[k]].strip()
            day=datetime.strptime(get('data'),'%d/%m/%Y').date();known=datetime.strptime(get('conhecido em'),'%d/%m/%Y').date()
            source=get('fonte');value=float(parse_number(get('vni'),'VNI'))
            if not source or (day,known) in seen:raise ValueError('fonte ou duplicata')
            seen.add((day,known))
            result.append(PricingAnchor(day,value,known,'VNI_OFICIAL_INFORMADO',source,quality_flags=('VNI independente informado/importado; fonte não autenticada pelo aplicativo.',)))
        if not result:raise ValueError('vazio')
        return tuple(sorted(result,key=lambda a:(a.valuation_date,a.known_on)))
    except (ValueError,KeyError,TypeError,UnicodeError) as exc:
        raise ValidationError('E-ANCHOR','CSV de VNI inválido. Use Data;Conhecido em;VNI;Fonte, datas dd/mm/aaaa e valores positivos.') from exc
