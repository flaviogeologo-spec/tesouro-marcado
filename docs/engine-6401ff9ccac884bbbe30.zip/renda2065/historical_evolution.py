"""Gross history and optional explicit future scenario of one fixed purchase."""
from datetime import date, datetime, timedelta
from decimal import Decimal, InvalidOperation, ROUND_DOWN, localcontext
import re
from zoneinfo import ZoneInfo

from .calendar_rules import FinancialCalendar
from .models import ValidationError
from .market_sim.contracts import ValidationError as MarketError
from .market_sim.nominal_index import MonthlyIPCA, prepare_nominal_index, shift_month
from .market_sim.operation import size_purchase_from_budget, size_purchase_from_quantity
from .market_sim.policies import round_money
from .market_sim.principal import business_days_to_maturity, price_principal
from .market_sim.provenance import EvidenceMode, Quality
from .market_sim.projections import InflationProjection
from .market_sim.renda_plus import RendaPlusSeries, price_renda_plus, projected_continuous_pu, sale_eligibility

D = Decimal
TITLES = {
    'IPCA_PRINCIPAL_2050': ('Tesouro IPCA+', '2050-08-15', 'IPCA+ 2050'),
    'RENDA_PLUS_2065': ('Tesouro Renda+ Aposentadoria Extra', '2084-12-15', 'RendA+ 2065'),
}


def _fail(message):
    raise ValidationError('E-HISTORY', message)


def _day(value):
    if not isinstance(value, str) or not re.fullmatch(r'\d{4}-\d{2}-\d{2}', value):
        _fail('Data histórica inválida.')
    try:
        return date.fromisoformat(value)
    except ValueError:
        _fail('Data histórica inválida.')


def _number(value, *, positive=True):
    if not isinstance(value, str) or len(value) > 48 or not re.fullmatch(r'-?\d+(?:\.\d+)?', value):
        _fail('Informe números decimais válidos.')
    try:
        result = D(value)
    except InvalidOperation:
        _fail('Número inválido.')
    if not result.is_finite() or abs(result) > D('1000000000000') or positive and result <= 0:
        _fail('Valores monetários e índices devem ser positivos e de até 1 trilhão.')
    return result


def _source(data, today):
    if not isinstance(data, dict) or data.get('schema_version') != 1:
        _fail('Formato de fonte histórica inválido.')
    source = data.get('source')
    if not isinstance(source, dict) or not isinstance(source.get('sha256'), str) or not re.fullmatch(r'[a-f0-9]{64}', source['sha256']):
        _fail('Fonte histórica sem identificação.')
    try:
        instant = datetime.fromisoformat(data['retrieved_at'].replace('Z', '+00:00'))
        if instant.tzinfo is None:
            _fail('A coleta histórica precisa identificar o fuso horário.')
        collected = instant.astimezone(ZoneInfo('America/Sao_Paulo')).date()
    except (KeyError, ValueError, TypeError, AttributeError):
        _fail('Data de atualização inválida.')
    if collected > today:
        _fail('Fonte histórica com coleta futura.')
    return collected


def _ipca(data, today):
    known = _source(data, today)
    if data.get('kind') != 'IPCA_MONTHLY_INDEX':
        _fail('Use o número índice mensal de IPCA.')
    rows = data.get('observations')
    if not isinstance(rows, list) or not 1 <= len(rows) <= 1020:
        _fail('Série de IPCA inválida.')
    expected, result = date(2000, 6, 1), []
    for row in rows:
        if not isinstance(row, list) or len(row) != 2:
            _fail('Registro de IPCA inválido.')
        month, value = _day(row[0]), _number(row[1])
        if month != expected or month >= known.replace(day=1):
            _fail('IPCA contém lacuna, duplicata ou mês ainda não encerrado.')
        if not result and value != D('1614.62'):
            _fail('O IPCA deve usar a base junho/2000 = 1614,62.')
        result.append(MonthlyIPCA(month, value, known, 'IBGE 1737 v2266', data['source']['sha256']))
        expected = shift_month(expected, 1)
    if data.get('as_of') != rows[-1][0]:
        _fail('Cobertura do IPCA inconsistente.')
    return tuple(result)


def _market(data, title_id, today):
    collected = _source(data, today)
    if data.get('price_unit') != 'BRL' or data.get('rate_unit') != 'basis_points' or data.get('observation') != 'morning':
        _fail('Atualize a base pública: o histórico precisa conter preços de venda.')
    titles = data.get('series')
    if (not isinstance(titles, list) or len(titles) != 2
            or any(not isinstance(s, dict) or not isinstance(s.get('id'), str) for s in titles)
            or {s['id'] for s in titles} != set(TITLES)):
        _fail('Títulos históricos inválidos.')
    series = next(s for s in titles if s['id'] == title_id)
    expected_type, maturity, _ = TITLES[title_id]
    if series.get('type') != expected_type or series.get('maturity') != maturity:
        _fail('Identidade do título inconsistente.')
    observations, prices = series.get('observations'), series.get('prices')
    if not isinstance(observations, list) or not 1 <= len(observations) <= 30000 or not isinstance(prices, list) or len(prices) != len(observations):
        _fail('Cobertura de preços inconsistente.')
    previous, result = date.min, {}
    for row, price in zip(observations, prices):
        if not isinstance(row, list) or len(row) != 3 or not isinstance(price, list) or len(price) != 4 or price[0] != row[0]:
            _fail('Preço histórico sem cotação correspondente.')
        day = _day(row[0])
        if not previous < day <= min(today, collected):
            _fail('Histórico contém duplicata, ordem inválida ou data futura.')
        if not all(v is None or type(v) is int and -10000 < v <= 10000 for v in row[1:]):
            _fail('Taxa histórica inválida.')
        values = [None if v is None else _number(v) for v in price[1:]]
        result[day] = {'rate': None if row[2] is None else D(row[2]) / D(10000), 'buy': values[0], 'sell': values[1], 'base': values[2]}
        previous = day
    calendar = data.get('market_dates')
    if not isinstance(calendar, list) or not calendar or len(calendar) > 30000:
        _fail('Histórico sem calendário de observações.')
    days = [_day(day) for day in calendar]
    if days != sorted(set(days)) or days[-1] > min(today, collected) or not set(result).issubset(days):
        _fail('Calendário de observações inválido.')
    return result, days


def _projection_inflation(raw, monthly):
    if not isinstance(raw, dict) or set(raw) != {'end_date', 'annual_inflation', 'market_yield'}:
        _fail('Projeção exige data final, inflação anual e taxa de mercado final.')
    inflation = _number(raw['annual_inflation'], positive=False)
    if not -1 < inflation <= 1:
        _fail('Inflação deve superar −100% e ser de até 100%.')
    return InflationProjection('CONSTANT_ANNUAL', inflation, monthly[-1].month,
                               monthly[-1].value, 'Inflação anual explicitamente informada para este cenário')


def _projection_options(raw, monthly, calendar, today, horizon):
    if raw is None:
        return None
    assumption = _projection_inflation(raw, monthly)
    end = _day(raw['end_date'])
    target = _number(raw['market_yield'], positive=False)
    if not D('-0.95') <= target <= 1:
        _fail('Taxa de mercado deve estar entre −95% e 100%.')
    if not today < end < horizon:
        _fail('Escolha uma data futura anterior ao vencimento ou ao início da renda do título.')
    requested_end = end
    while not calendar.is_session(end):
        end -= timedelta(days=1)
    if end <= today:
        _fail('A data final precisa incluir ao menos uma sessão futura.')
    return {'end': end, 'requested_end': requested_end, 'inflation': assumption.annual_rate,
            'target': target, 'assumption': assumption}


def _sale_block_reason(series, settlement, day, calendar):
    if day <= settlement:
        return 'A venda matinal só pode ser simulada após a data de liquidação da compra.'
    if series is not None:
        return sale_eligibility(series, settlement, day, calendar).reason
    if not calendar.is_session(day):
        return 'Sem sessão elegível'
    return None


def _extend_projection(result, options, *, nominal_index, market, calendar, entry_nominal, observed_nominals, series, maturity, today, dates=None):
    """Keep observed quotes intact; calibrate the scenario to the last official PU."""
    purchase = result['purchase']
    settlement = _day(purchase['settlement_date'])
    quantity, entry_pu, rate = D(purchase['quantity']), D(purchase['pu']), D(purchase['yield'])
    initial, end = D(purchase['initial_outflow']), options['end']
    if end < settlement:
        _fail('A projeção precisa alcançar a liquidação da compra.')
    candidates = [(day, quote) for day, quote in market.items() if quote['sell'] is not None]
    if not candidates:
        _fail('Não há preço e taxa de venda oficiais para iniciar a projeção.')
    anchor_day, anchor = max(candidates, key=lambda item: item[0])
    if anchor['rate'] is None:
        _fail('O último preço de venda oficial está sem taxa correspondente. Atualize a base ou consulte somente o histórico.')
    if not D('-0.95') <= anchor['rate'] <= 1:
        _fail('A taxa observada está fora do domínio desta projeção.')

    payments = tuple(calendar.roll_payment(day) for day in series.payment_dates) if series is not None else ()

    def nominal(day):
        return observed_nominals.get(day) or nominal_index(day, projection=options['assumption'])

    def model(day, index, yield_):
        if series is not None:
            return price_renda_plus(series, day, index, yield_, calendar, Quality.HYPOTHETICAL).continuous_pu
        return price_principal(index, yield_, business_days_to_maturity(day, maturity, calendar)).continuous_pu

    anchor_nominal = nominal(anchor_day)
    anchor_model = model(anchor_day, anchor_nominal.value, anchor['rate'])

    def sale_value(day, index, yield_):
        if payments and day < payments[0] and yield_ >= D('-.20') and index.adjusted() <= 18:
            days = calendar.days_to_payments(day, payments)
            price = projected_continuous_pu(series, index, yield_, days)
            sale = quantity * anchor['sell'] * price / anchor_model
            # Use the canonical path near a half-cent, where the order of
            # Decimal operations can affect the monetary result.
            if sale.adjusted() < 30:
                fraction = sale - sale.quantize(D('.01'), rounding=ROUND_DOWN)
                if abs(fraction - D('.005')) > max(abs(sale), D(1)) * D('1e-35'):
                    return round_money(sale)
        return round_money(quantity * anchor['sell'] * model(day, index, yield_) / anchor_model)

    historical_last = max(market)
    # Additional sessions are sampled, including both ends, at most 121 dates.
    first = max(settlement, calendar.next_session(historical_last))
    stride = max(15, ((end - first).days + 118) // 119)
    future_dates, cursor = set(), first
    while cursor <= end:
        rolled = calendar.next_session(cursor, include=True)
        if rolled <= end:
            future_dates.add(rolled)
        cursor += timedelta(days=stride)
    future_dates.add(end)
    if dates is not None:
        future_dates.intersection_update(dates)
    existing = {point['date']: point for point in result['points']}
    for day in sorted(future_dates):
        existing.setdefault(day.isoformat(), {'date': day.isoformat(), 'settlement_date': day.isoformat(),
                                             'reference': None, 'market': None, 'market_yield': None,
                                             'observed_index_available': False, 'status': ''})
    if not existing:
        return
    log_rate = (1 + rate).ln()
    reference_estimate_start, additional_locked = None, 0
    for key in sorted(existing):
        point, day = existing[key], _day(key)
        index = nominal(day)
        reference_hypothetical = index.projected_months > 0 or entry_nominal.projected_months > 0
        if reference_hypothetical or point['reference'] is None:
            du = D(calendar.business_days(settlement, day))
            reference = round_money(quantity * entry_pu * index.value / entry_nominal.value * (log_rate * du / D(252)).exp())
            point['reference'] = str(reference)
        point['reference_kind'] = 'HYPOTHETICAL' if reference_hypothetical else 'RECONSTRUCTED'
        if reference_hypothetical and reference_estimate_start is None:
            reference_estimate_start = key
        point['market_kind'] = 'OBSERVED' if point['market'] is not None else 'MISSING'
        if day > historical_last:
            weight = D((day - anchor_day).days) / D((end - anchor_day).days)
            yield_ = anchor['rate'] + (options['target'] - anchor['rate']) * weight
            point['market_yield'] = str(yield_)
            reason = _sale_block_reason(series, settlement, day, calendar)
            if reason is None:
                sale = sale_value(day, index.value, yield_)
                point['market'] = str(sale)
                point['market_kind'] = 'HYPOTHETICAL'
                point['status'] = 'Venda projetada; taxa de mercado em transição até a taxa selecionada'
            else:
                point['status'] = reason
                additional_locked += 1
        if reference_hypothetical:
            old = point['status'].replace('IPCA ainda não disponível para a referência', '').strip('; ')
            point['status'] = '; '.join(filter(None, [old if old != 'Comparável' else '', 'Referência com inflação estimada']))
        reference = D(point['reference'])
        sale = None if point['market'] is None else D(point['market'])
        delta = None if sale is None else sale - reference
        point.update(reference_return=str((reference / initial - 1) * 100),
                     market_return=None if sale is None else str((sale / initial - 1) * 100),
                     delta=None if delta is None else str(delta),
                     delta_percent=None if delta is None or reference == 0 else str(delta / reference * 100),
                     missing_month=None if index.missing_month is None else index.missing_month.strftime('%Y-%m'),
                     period='FUTURE' if day > today else 'PAST')
    points = [existing[key] for key in sorted(existing)]
    result['points'] = points
    result['coverage'].update(first=points[0]['date'], last=points[-1]['date'], dates=len(points),
                              comparable=sum(p['delta'] is not None for p in points),
                              historical_last=historical_last.isoformat(),
                              estimated_reference=sum(p['reference_kind'] == 'HYPOTHETICAL' for p in points),
                              projected_market=sum(p['market_kind'] == 'HYPOTHETICAL' for p in points),
                              unavailable_sales=result['coverage']['unavailable_sales'] + additional_locked,
                              missing_ipca=0)
    result['projection'] = {'annual_inflation': str(options['inflation']), 'selected_yield': str(options['target']),
                            'initial_yield': str(anchor['rate']), 'anchor_date': anchor_day.isoformat(),
                            'anchor_pu': str(anchor['sell']), 'end_date': end.isoformat(),
                            'requested_end_date': options['requested_end'].isoformat(), 'today': today.isoformat(),
                            'reference_estimate_start': reference_estimate_start, 'market_estimate_start': first.isoformat(),
                            'transition': 'LINEAR_RATE_TO_END', 'market_basis': 'LAST_OFFICIAL_PU_CALIBRATED_MODEL_RATIO',
                            'sample_dates': len(future_dates), 'step_days': stride, 'final_point': points[-1]}
    result['method'] += '+EXPLICIT_FUTURE_v1'
    return result


def evaluate_history(body, *, today=None, dates=None, allow_projected=False, include_cash=True):
    """Accept explicit public snapshots; never read/write the personal data store."""
    try:
        with localcontext() as ctx:
            ctx.prec = 40
            as_of = today or date.today()
            cash_deferred = False
            if isinstance(body, dict) and 'cash_dates' in body:
                selection = body['cash_dates']
                if dates is not None or not isinstance(selection, list) or len(selection) > 2:
                    _fail('Informe até duas datas para consultar o líquido.')
                if selection:
                    dates = tuple(_day(value) for value in selection)
                    allow_projected = True
                else:
                    cash_deferred = True
            result, market, sessions = _evaluate(body, today=as_of, dates=dates, allow_projected=allow_projected)
            if include_cash and (body.get('position') is True or body['purchase'].get('quantity') is not None):
                from .position_analysis import enrich_position
                enrich_position(result, body, today=as_of, market=market, market_dates=sessions, include_cash=not cash_deferred)
                if cash_deferred:
                    result['cash_deferred'] = True
            return result
    except MarketError as error:
        raise ValidationError(error.code, str(error)) from error
    except ArithmeticError as error:
        raise ValidationError('E-HISTORY', 'O cenário excede o domínio numérico; revise taxas e valores.') from error


def _evaluate(body, *, today, dates, allow_projected):
    if (not isinstance(body, dict) or type(body.get('schema_version')) is not int or body['schema_version'] != 1
            or set(body) - {'schema_version', 'purchase', 'market', 'ipca', 'projection', 'position', 'costs', 'reconciliation', 'cash_dates'}):
        _fail('Pedido de histórico inválido.')
    if 'position' in body and type(body['position']) is not bool:
        _fail('Modo de posição inválido.')
    inputs = body.get('purchase')
    if not isinstance(inputs, dict) or set(inputs) - {'title_id', 'date', 'yield', 'budget', 'pu', 'quantity', 'settlement_date'}:
        _fail('Informe apenas os campos previstos para a compra.')
    title_id = inputs.get('title_id')
    if not isinstance(title_id, str) or title_id not in TITLES:
        _fail('Escolha IPCA+ 2050 ou RendA+ 2065.')
    purchase_date, rate = _day(inputs.get('date')), _number(inputs.get('yield'), positive=False)
    if not -1 < rate <= 1:
        _fail('Taxa da compra deve ser maior que −100% e de até 100% ao ano.')
    if purchase_date > today:
        _fail('Este gráfico aceita somente compras passadas.')
    market, sessions = _market(body.get('market'), title_id, today)
    monthly = _ipca(body.get('ipca'), today)
    actual = inputs.get('quantity') is not None
    if not actual and body.get('position') is not True and any(body.get(key) is not None for key in ('costs','reconciliation')):
        _fail('Custos e conferência exigem o modo de posição.')
    if not actual and (purchase_date not in market or market[purchase_date]['buy'] is None):
        _fail('Não há cotação de compra deste título nessa data. Escolha uma data coberta pelo histórico.')
    calendar = FinancialCalendar(knowledge_date=today)
    if not actual and not calendar.is_session(purchase_date):
        _fail('A data da compra não é uma sessão elegível. Nenhuma data foi deslocada.')
    settlement = calendar.next_session(purchase_date)
    from .position_analysis import normalize_actual_purchase, normalize_costs
    if actual:
        normalized = normalize_actual_purchase(inputs, today=today)
        settlement = _day(normalized['settlement_date'])
    elif inputs.get('settlement_date') is not None:
        _fail('Liquidação informada exige a quantidade e o PU do comprovante.')
    costs = normalize_costs(body.get('costs'))
    last = max(market)
    is_renda = title_id == 'RENDA_PLUS_2065'
    series = RendaPlusSeries.for_conversion_year(2065) if is_renda else None
    maturity = _day(TITLES[title_id][1])
    horizon = series.first_income_date if is_renda else maturity
    observed_subset = dates is not None and (not allow_projected or max(dates) <= last)
    raw_projection = body.get('projection')
    options = None if observed_subset else _projection_options(raw_projection, monthly, calendar, today, horizon)
    if not observed_subset and settlement > last and options is None:
        _fail('Ainda não há histórico posterior à liquidação dessa compra.')

    nominal_index = prepare_nominal_index(monthly, as_of=today, evidence_mode=EvidenceMode.EX_POST)
    entry_nominal = nominal_index(settlement)
    if entry_nominal.value is None and raw_projection is not None and (not observed_subset or inputs.get('pu') is None):
        # Preserve the original purchase sizing from the same IPCA snapshot.
        # Historical quotes do not depend on the scenario's end date or exit rate.
        assumption = _projection_inflation(raw_projection, monthly) if observed_subset else options['assumption']
        entry_nominal = nominal_index(settlement, projection=assumption)
    entry_model = None
    if entry_nominal.value is not None and inputs.get('pu') is None:
        if is_renda:
            entry_model = price_renda_plus(series, settlement, entry_nominal.value, rate, calendar, Quality.RECONSTRUCTED)
        else:
            entry_model = price_principal(entry_nominal.value, rate, business_days_to_maturity(settlement, maturity, calendar))
    if inputs.get('pu') is not None:
        entry_pu, price_basis = _number(inputs['pu']), 'INFORMED'
    elif entry_model is not None and entry_model.published_pu > 0:
        entry_pu = entry_model.published_pu
        price_basis = 'MODELED_WITH_ESTIMATED_IPCA' if entry_nominal.projected_months else 'MODELED_EX_POST'
    else:
        _fail('Falta IPCA divulgado para calcular o preço dessa compra. Informe o preço do comprovante ou aguarde a atualização do índice.')
    if entry_pu < D('0.01'):
        _fail('O preço de compra deve ser de pelo menos R$ 0,01.')
    budget = None if inputs.get('budget') is None else _number(inputs['budget'])
    if budget is not None and (budget < D('0.01') or budget != budget.quantize(D('0.01'))):
        _fail('Informe um valor investido de pelo menos R$ 0,01, com até duas casas decimais.')
    if actual:
        sized = size_purchase_from_quantity(normalized['quantity'], entry_pu, entry_fee_fixed=costs['entry_fee'])
        quantity, initial, remainder = sized.quantity, sized.total_outflow, None
    elif budget is None:
        quantity, initial, remainder = D(1), round_money(entry_pu + costs['entry_fee']), None
    else:
        sized = size_purchase_from_budget(budget, entry_pu, entry_fee_fixed=costs['entry_fee'])
        quantity, initial, remainder = sized.quantity, sized.total_outflow, sized.unspent_cash
    if initial <= 0:
        _fail('A compra precisa ter um desembolso positivo em centavos.')
    entry_gross = quantity * entry_pu
    log_rate = (1 + rate).ln()
    observed_nominals = {}
    rows, missing_ipca, missing_prices, locked = [], 0, 0, 0
    historical_dates = sessions if dates is None else sorted(set(dates).intersection(sessions))
    for day in historical_dates:
        if day < settlement or day > last or day >= horizon:
            continue
        quote = market.get(day)
        index = nominal_index(day)
        if options is not None and index.value is not None:
            observed_nominals[day] = index
        # Before any amortization, all discounted flows accrue by the same DU/252
        # factor. This is the ratio of fixed-yield continuous prices and avoids
        # repricing 240 RendA+ cashflows for each historical day.
        reference = None
        if index.value is not None and entry_nominal.value is not None:
            du = D(calendar.business_days(settlement, day))
            reference = round_money(entry_gross * index.value / entry_nominal.value * (log_rate * du / D(252)).exp())
        notes = []
        if reference is None:
            notes.append('IPCA ainda não disponível para a referência'); missing_ipca += 1
        reason = _sale_block_reason(series, settlement, day, calendar)
        if reason is not None:
            notes.append(reason); locked += 1
        sale = None
        if quote is None or quote['sell'] is None:
            notes.append('Sem preço de venda'); missing_prices += 1
        elif reason is None:
            sale = round_money(quantity * quote['sell'])
        delta = None if sale is None or reference is None else sale - reference
        rows.append({'date': day.isoformat(), 'settlement_date': day.isoformat(),
                     'reference': None if reference is None else str(reference),
                     'market': None if sale is None else str(sale),
                     'reference_return': None if reference is None else str((reference / initial - 1) * 100),
                     'market_return': None if sale is None else str((sale / initial - 1) * 100),
                     'delta': None if delta is None else str(delta),
                     'delta_percent': None if delta is None or reference == 0 else str(delta / reference * 100),
                     'market_yield': None if quote is None or quote['rate'] is None else str(quote['rate']),
                     'observed_index_available': index.value is not None,
                     'missing_month': None if index.missing_month is None else index.missing_month.strftime('%Y-%m'),
                     'status': '; '.join(notes) or 'Comparável'})
    if not rows and options is None and not observed_subset:
        _fail('Sem datas históricas de avaliação após a compra.')
    comparable = [row for row in rows if row['delta'] is not None]
    result = {'schema_version': 1, 'title_id': title_id, 'label': TITLES[title_id][2],
            'purchase': {'date': purchase_date.isoformat(), 'settlement_date': settlement.isoformat(),
                         'yield': str(rate), 'pu': str(entry_pu), 'price_basis': price_basis,
                         'budget': None if budget is None else str(budget), 'quantity': str(quantity),
                         'initial_outflow': str(initial), 'unspent_cash': None if remainder is None else str(remainder)},
            'display': 'BRL' if actual or budget is not None else 'PERCENT', 'points': rows,
            'coverage': {'first': rows[0]['date'] if rows else None, 'last': rows[-1]['date'] if rows else None, 'dates': len(rows),
                         'comparable': len(comparable), 'missing_ipca': missing_ipca, 'missing_prices': missing_prices,
                         'unavailable_sales': locked, 'ipca_last_month': monthly[-1].month.strftime('%Y-%m'),
                         'reference_last': next((row['date'] for row in reversed(rows) if row['reference'] is not None), None)},
            'sources': {'market': body['market']['source'], 'ipca': body['ipca']['source'],
                        'market_retrieved_at': body['market']['retrieved_at'], 'ipca_retrieved_at': body['ipca']['retrieved_at']},
            'method': 'PURCHASE_ANCHORED_FIXED_YIELD_DU252_EX_POST_v1',
            'warnings': ['Valores brutos, antes de impostos e custos.',
                         'Referência reconstruída com IPCA realizado; não é cotação de resgate.',
                         'Compra matinal D+1; venda matinal D+0. Calendário por regras do motor.']}
    if body.get('position') is True or actual:
        result['purchase'].update(quantity_basis='INFORMED' if actual else 'BUDGET_ESTIMATE' if budget is not None else 'ONE_TITLE',
                                  settlement_basis='INFORMED' if actual else 'CALENDAR_D1',
                                  entry_fee=str(costs['entry_fee']),
                                  tax_cost_basis=str(costs['tax_cost_basis'] if costs['tax_cost_basis'] is not None else round_money(entry_gross)))
    if options is not None:
        _extend_projection(result, options, nominal_index=nominal_index, market=market, calendar=calendar,
                           entry_nominal=entry_nominal, observed_nominals=observed_nominals,
                           series=series, maturity=maturity, today=today, dates=dates)
    return result, market, sessions
