"""Caixa, tributos e retorno de uma compra seguida de uma venda total."""
from __future__ import annotations

from dataclasses import dataclass
from datetime import date
from decimal import Decimal, localcontext
from typing import Sequence

from .contracts import ProductFamily, Scenario, Side, ValidationError, decimal_value
from .policies import (
    IR_POLICY_ID, IOF_POLICY_ID, PRINCIPAL_CUSTODY_POLICY_ID,
    RENDA_CUSTODY_POLICY_ID, PolicyAmount, calculate_income_tax,
    calculate_iof, estimate_custody, round_money,
)
from .provenance import Quality
from .renda_plus import (
    Calendar, RendaPlusSeries, SaleEligibilityStatus, sale_eligibility,
)

D = Decimal


@dataclass(frozen=True, slots=True)
class CashFlow:
    date: date
    amount: Decimal
    label: str

    def __post_init__(self) -> None:
        value = decimal_value(self.amount, "fluxo monetário")
        if value > 0:
            raise ValidationError("INVALID_CASH_FLOW", "Custos já pagos devem ser fluxos negativos ou zero.")
        if not self.label.strip():
            raise ValidationError("INVALID_CASH_FLOW", "Fluxo precisa de descrição.")
        object.__setattr__(self, "amount", value)


@dataclass(frozen=True, slots=True)
class IndexLevel:
    date: date
    value: Decimal
    source_ref: str

    def __post_init__(self) -> None:
        value = decimal_value(self.value, "nível do índice")
        if value <= 0 or not self.source_ref.strip():
            raise ValidationError("INVALID_INDEX", "Índice precisa ser positivo e indicar fonte.")
        object.__setattr__(self, "value", value)


@dataclass(frozen=True, slots=True)
class OperationRequest:
    scenario: Scenario
    entry_pu: Decimal
    exit_pu: Decimal
    tax_cost_basis: Decimal | None = None
    entry_expense_paid: Decimal = D(0)
    exit_expense: Decimal = D(0)
    custody_override: Decimal | None = None
    institution_net_override: Decimal | None = None
    intermediate_paid_costs: tuple[CashFlow, ...] = ()
    index_levels: tuple[IndexLevel, ...] = ()
    calendar: Calendar | None = None
    institution_release_date: date | None = None
    custody_value_days: Decimal | None = None

    def __post_init__(self) -> None:
        entry_pu = decimal_value(self.entry_pu, "PU de compra")
        exit_pu = decimal_value(self.exit_pu, "PU de venda")
        if entry_pu <= 0 or exit_pu <= 0:
            raise ValidationError("INVALID_PRICE", "PUs de entrada e saída precisam ser positivos.")
        object.__setattr__(self, "entry_pu", entry_pu)
        object.__setattr__(self, "exit_pu", exit_pu)
        for name in ("entry_expense_paid", "exit_expense"):
            value = decimal_value(getattr(self, name), name)
            if value < 0:
                raise ValidationError("INVALID_AMOUNT", f"{name} não pode ser negativo.")
            object.__setattr__(self, name, value)
        if self.tax_cost_basis is not None:
            basis = decimal_value(self.tax_cost_basis, "custo fiscal")
            if basis < 0:
                raise ValidationError("INVALID_AMOUNT", "Custo fiscal não pode ser negativo.")
            object.__setattr__(self, "tax_cost_basis", basis)
        for name in ("custody_override", "institution_net_override"):
            raw = getattr(self, name)
            if raw is not None:
                value = decimal_value(raw, name)
                if value < 0:
                    raise ValidationError("INVALID_AMOUNT", f"{name} não pode ser negativo.")
                object.__setattr__(self, name, value)
        if self.institution_net_override is not None and (
            self.custody_override is not None or self.custody_value_days is not None or self.exit_expense != 0
        ):
            raise ValidationError(
                "DOUBLE_DEDUCTION",
                "Líquido informado pela instituição substitui a apuração; não combine com deduções da saída.",
            )
        if self.custody_value_days is not None:
            value_days = decimal_value(self.custody_value_days, "soma das posições diárias")
            if self.custody_override is not None:
                raise ValidationError("DOUBLE_DEDUCTION", "Escolha uma única base de custódia.")
            if self.scenario.instrument.family is not ProductFamily.IPCA_PRINCIPAL or value_days < 0:
                raise ValidationError("INVALID_AMOUNT", "Trajetória de custódia exige valores não negativos do IPCA+ Principal.")
            object.__setattr__(self, "custody_value_days", value_days)
        entry_day = self.scenario.entry.settlement_date
        exit_day = self.scenario.exit.settlement_date
        if any(not entry_day < item.date <= exit_day for item in self.intermediate_paid_costs):
            raise ValidationError(
                "INVALID_CASH_FLOW",
                "Custos intermediários devem ocorrer depois da liquidação da compra e até a saída.",
            )
        if self.scenario.exit.side is not Side.SELL:
            raise ValidationError("BASE_NOT_CASH", "PU Base serve para marcação; não gera caixa de venda.")


@dataclass(frozen=True, slots=True)
class OperationResult:
    quantity: Decimal
    entry_pu: Decimal
    exit_pu: Decimal
    entry_gross: Decimal
    initial_outflow: Decimal
    tax_cost_basis: Decimal
    gross_redemption: Decimal
    iof: Decimal | None
    income_tax: Decimal | None
    custody: Decimal | None
    exit_expense: Decimal | None
    net_redemption: Decimal | None
    nominal_profit: Decimal | None
    nominal_return: Decimal | None
    annualized_nominal_return: Decimal | None
    real_profit_in_exit_date_currency: Decimal | None
    real_return: Decimal | None
    holding_days: int
    status: str
    quality: Quality
    policies: tuple[str, ...]
    warnings: tuple[str, ...] = ()


@dataclass(frozen=True, slots=True)
class BudgetSizing:
    budget: Decimal
    unit_price: Decimal
    quantity: Decimal
    purchase_gross: Decimal
    entry_expense: Decimal
    total_outflow: Decimal
    unspent_cash: Decimal
    quantity_step: Decimal


@dataclass(frozen=True, slots=True)
class QuantitySizing:
    quantity: Decimal
    unit_price: Decimal
    purchase_gross: Decimal
    entry_expense: Decimal
    total_outflow: Decimal
    quantity_step: Decimal


def _entry_cash_values(
    quantity: Decimal,
    unit_price: Decimal,
    entry_fee_fixed: Decimal,
    entry_fee_rate: Decimal,
) -> tuple[Decimal, Decimal, Decimal]:
    purchase_gross = quantity * unit_price
    entry_expense = round_money(entry_fee_fixed + purchase_gross * entry_fee_rate)
    total_outflow = round_money(purchase_gross + entry_expense)
    return purchase_gross, entry_expense, total_outflow


def size_purchase_from_budget(
    budget: Decimal | str | int,
    unit_price: Decimal | str | int,
    quantity_step: Decimal | str | int = "0.01",
    entry_fee_fixed: Decimal | str | int = 0,
    entry_fee_rate: Decimal | str | int = 0,
) -> BudgetSizing:
    cash = decimal_value(budget, "orçamento")
    pu = decimal_value(unit_price, "PU")
    step = decimal_value(quantity_step, "passo de quantidade")
    fixed = decimal_value(entry_fee_fixed, "despesa fixa")
    fee_rate = decimal_value(entry_fee_rate, "taxa de entrada")
    if cash <= 0 or pu <= 0 or step <= 0 or fixed < 0 or fee_rate < 0:
        raise ValidationError("INVALID_BUDGET", "Orçamento e PU devem ser positivos; taxas e passo válidos.")
    if fee_rate >= 1:
        raise ValidationError("INVALID_BUDGET", "Taxa percentual de entrada precisa ser menor que 100%.")
    def total_for_steps(steps: int) -> Decimal:
        if steps <= 0:
            return D(0)
        return _entry_cash_values(D(steps) * step, pu, fixed, fee_rate)[2]

    if total_for_steps(1) > cash:
        raise ValidationError("INSUFFICIENT_BUDGET", "Orçamento não cobre a menor quantidade e despesas.")
    # Find the last affordable fraction with monotonic integer search. This
    # accounts for cent rounding in both the fee and final cash outflow.
    low = 1
    high = 2
    while total_for_steps(high) <= cash:
        low = high
        high *= 2
    while high - low > 1:
        middle = (low + high) // 2
        if total_for_steps(middle) <= cash:
            low = middle
        else:
            high = middle
    quantity = D(low) * step
    purchase_gross, entry_expense, total = _entry_cash_values(quantity, pu, fixed, fee_rate)
    return BudgetSizing(
        budget=cash,
        unit_price=pu,
        quantity=quantity,
        purchase_gross=purchase_gross,
        entry_expense=entry_expense,
        total_outflow=total,
        unspent_cash=cash - total,
        quantity_step=step,
    )


def size_purchase_from_quantity(
    quantity: Decimal | str | int,
    unit_price: Decimal | str | int,
    quantity_step: Decimal | str | int = "0.01",
    entry_fee_fixed: Decimal | str | int = 0,
    entry_fee_rate: Decimal | str | int = 0,
) -> QuantitySizing:
    """Resolve a declared title quantity into the same cent-rounded cash basis."""
    titles = decimal_value(quantity, "quantidade")
    pu = decimal_value(unit_price, "PU")
    step = decimal_value(quantity_step, "passo de quantidade")
    fixed = decimal_value(entry_fee_fixed, "despesa fixa")
    fee_rate = decimal_value(entry_fee_rate, "taxa de entrada")
    if titles <= 0 or pu <= 0 or step <= 0 or fixed < 0 or fee_rate < 0:
        raise ValidationError("INVALID_QUANTITY", "Quantidade e PU devem ser positivos; taxas e passo válidos.")
    if fee_rate >= 1:
        raise ValidationError("INVALID_QUANTITY", "Taxa percentual de entrada precisa ser menor que 100%.")
    if titles % step != 0:
        raise ValidationError("INVALID_QUANTITY", "Quantidade precisa respeitar o passo selecionado.")
    purchase_gross, entry_expense, total_outflow = _entry_cash_values(titles, pu, fixed, fee_rate)
    return QuantitySizing(titles, pu, purchase_gross, entry_expense, total_outflow, step)


def _annualized_return(net: Decimal, initial: Decimal, days: int) -> Decimal | None:
    if days <= 0 or initial <= 0 or net <= 0:
        return None
    with localcontext() as ctx:
        ctx.prec = 36
        return ((net / initial).ln() * D(365) / D(days)).exp() - D(1)


def calculate_operation(request: OperationRequest) -> OperationResult:
    scenario = request.scenario
    quantity = scenario.entry.quantity
    # Convert unit-price products to cash once at the transaction boundary.
    # These same cent values feed the tax basis, cash ledger, and displayed result.
    entry_gross = round_money(quantity * request.entry_pu)
    initial_outflow = round_money(entry_gross + request.entry_expense_paid)
    tax_basis = round_money(request.tax_cost_basis) if request.tax_cost_basis is not None else entry_gross
    gross = round_money(quantity * request.exit_pu)
    holding_days = (scenario.exit.settlement_date - scenario.entry.settlement_date).days
    if holding_days <= 0:
        raise ValidationError("INVALID_HOLDING_DAYS", "Venda precisa liquidar depois da compra.")

    if scenario.instrument.family is ProductFamily.RENDA_PLUS:
        if request.calendar is None:
            raise ValidationError("CALENDAR_REQUIRED", "RendA+ exige calendário para validar sessão e carência.")
        series = RendaPlusSeries.for_conversion_year(scenario.instrument.conversion_date.year)
        eligibility = sale_eligibility(
            series,
            scenario.entry.settlement_date,
            scenario.exit.order_date,
            request.calendar,
            request.institution_release_date,
        )
        if eligibility.status is not SaleEligibilityStatus.ELIGIBLE:
            return OperationResult(
                quantity, request.entry_pu, request.exit_pu, round_money(entry_gross),
                round_money(initial_outflow), round_money(tax_basis), round_money(gross),
                None, None, None, None, None, None, None, None, None, None,
                holding_days, "BLOCKED_POLICY", Quality.HYPOTHETICAL, (),
                (eligibility.reason or eligibility.status.value,),
            )

    if request.institution_net_override is not None:
        net = round_money(request.institution_net_override)
        prior_total = sum((item.amount for item in request.intermediate_paid_costs), D(0))
        profit = round_money(net - initial_outflow + prior_total)
        has_intermediate = bool(request.intermediate_paid_costs)
        nominal_return = None if has_intermediate else net / initial_outflow - D(1)
        annualized = None if has_intermediate else _annualized_return(net, initial_outflow, holding_days)
        warnings = ["Líquido informado substitui impostos e custos estimados nesta fotografia; decomposição indisponível."]
        real_profit, real_return = _real_metrics(request, net, initial_outflow, profit)
        return OperationResult(
            quantity, request.entry_pu, request.exit_pu, round_money(entry_gross),
            round_money(initial_outflow), round_money(tax_basis), round_money(gross),
            None, None, None, None, net, profit, nominal_return, annualized,
            real_profit, real_return, holding_days, "READY_INFORMED_NET", Quality.INFORMED,
            (), tuple(warnings),
        )

    taxable_gain = max(gross - tax_basis, D(0))
    iof_result = calculate_iof(gross, taxable_gain, holding_days)
    tax_result = calculate_income_tax(taxable_gain, iof_result.amount, holding_days)
    if request.custody_override is not None:
        custody_result = PolicyAmount(
            round_money(request.custody_override), "USER_CUSTODY_OVERRIDE_v1",
            Quality.INFORMED, "INFORMED", "Valor de custódia informado substitui a estimativa nesta operação."
        )
    else:
        custody_result = estimate_custody(
            scenario.instrument.family,
            scenario.entry.settlement_date,
            scenario.exit.settlement_date,
            gross,
            position_value_days=request.custody_value_days,
        )
    exit_expense = round_money(request.exit_expense)
    net = round_money(
        gross - iof_result.amount - tax_result.amount - custody_result.amount - exit_expense
    )
    prior_total = sum((item.amount for item in request.intermediate_paid_costs), D(0))
    profit = round_money(net - initial_outflow + prior_total)
    has_intermediate = bool(request.intermediate_paid_costs)
    nominal_return = None if has_intermediate else (net / initial_outflow - D(1))
    annualized = None if has_intermediate else _annualized_return(net, initial_outflow, holding_days)
    real_profit, real_return = _real_metrics(request, net, initial_outflow, profit)
    warnings = [custody_result.explanation]
    if has_intermediate:
        warnings.append("Há custos pagos em datas intermediárias; retorno simples e anualizado não usam fórmula de dois fluxos.")
    status = "ESTIMATED_NET" if custody_result.quality is Quality.ESTIMATED else "READY_HYPOTHETICAL"
    return OperationResult(
        quantity=quantity,
        entry_pu=request.entry_pu,
        exit_pu=request.exit_pu,
        entry_gross=round_money(entry_gross),
        initial_outflow=round_money(initial_outflow),
        tax_cost_basis=round_money(tax_basis),
        gross_redemption=round_money(gross),
        iof=iof_result.amount,
        income_tax=tax_result.amount,
        custody=custody_result.amount,
        exit_expense=exit_expense,
        net_redemption=net,
        nominal_profit=profit,
        nominal_return=nominal_return,
        annualized_nominal_return=annualized,
        real_profit_in_exit_date_currency=real_profit,
        real_return=real_return,
        holding_days=holding_days,
        status=status,
        quality=Quality.ESTIMATED if custody_result.quality is Quality.ESTIMATED else Quality.HYPOTHETICAL,
        policies=(iof_result.policy_id, tax_result.policy_id, custody_result.policy_id),
        warnings=tuple(warnings),
    )


def _real_metrics(
    request: OperationRequest,
    net_redemption: Decimal,
    initial_outflow: Decimal,
    nominal_profit: Decimal,
) -> tuple[Decimal | None, Decimal | None]:
    if not request.index_levels:
        return None, None
    levels = {point.date: point.value for point in request.index_levels}
    entry_date = request.scenario.entry.settlement_date
    exit_date = request.scenario.exit.settlement_date
    if entry_date not in levels or exit_date not in levels:
        return None, None
    exit_index = levels[exit_date]
    initial_index = levels[entry_date]
    real_profit = net_redemption - initial_outflow * exit_index / initial_index
    for cost in request.intermediate_paid_costs:
        if cost.date not in levels:
            return None, None
        real_profit += cost.amount * exit_index / levels[cost.date]
    if request.intermediate_paid_costs or initial_outflow <= 0:
        return real_profit, None
    real_return = (net_redemption / initial_outflow) / (exit_index / initial_index) - D(1)
    return real_profit, real_return
