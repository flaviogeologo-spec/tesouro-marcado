"""Pure input normalization and workspace resolution for the unified experience.

This module validates request shape and resolves dates plus parsed, pinned
observations supplied by an adapter. It opens no files, database, or network.
"""
from __future__ import annotations

from dataclasses import dataclass, replace
from collections import OrderedDict
from copy import deepcopy
from datetime import date, datetime, timedelta, timezone
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP
from enum import StrEnum
import math
import re
from time import monotonic
from threading import RLock
from types import MappingProxyType
from typing import Any, Mapping

from .contracts import (
    AsOf,
    Entry,
    Exit,
    Instrument,
    ProductFamily,
    Scenario,
    ScenarioIntent,
    Side,
    ValidationError,
)
from .provenance import EvidenceMode, EvidenceStatus, Provenance, Quality, assess_evidence
from .dates import resolve_workspace_dates, resolve_workspace_reference_date
from .market_data import IndexObservation, PriceObservation, lookup_index_exact, lookup_price_exact
from .projections import InflationProjection
from .service import ScenarioEvaluation


class CapitalMode(StrEnum):
    BUDGET = "BUDGET"
    QUANTITY = "QUANTITY"


class PriceMode(StrEnum):
    MANUAL_PU = "MANUAL_PU"
    MANUAL_RATE = "MANUAL_RATE"
    AUTO_LOCAL = "AUTO_LOCAL"
    SAME_ENTRY_RATE = "SAME_ENTRY_RATE"


class CapabilityStatus(StrEnum):
    AVAILABLE = "available"
    NEEDS_INPUT = "needs_input"
    BLOCKED_POLICY = "blocked_policy"


@dataclass(frozen=True, slots=True)
class WorkspaceAnalysisContext:
    kind: str
    timeline_mode: str
    start: date | None = None
    end: date | None = None
    missing_fields: tuple[str, ...] = ()

    @property
    def is_operation_window(self) -> bool:
        return self.kind == "OPERATION" and self.timeline_mode == "WINDOW"

    def to_dict(self) -> dict[str, Any]:
        timeline: dict[str, Any] = {"mode": self.timeline_mode}
        if self.start is not None:
            timeline["start"] = self.start.isoformat()
        if self.end is not None:
            timeline["end"] = self.end.isoformat()
        return {"kind": self.kind, "timeline": timeline}


WORKSPACE_SEARCH_BUDGET = MappingProxyType({"max_evaluations": 4096, "deadline_seconds": 10})

# Refined visual regions reuse direct operation results across requests. Each
# complete financial input gets at most one 256-point LRU; only eight input
# namespaces are retained, so this cache remains bounded and process-local.
_SURFACE_CACHE_LOCK = RLock()
_SURFACE_EVALUATION_CACHES: OrderedDict[str, tuple[OrderedDict[str, Any], RLock]] = OrderedDict()
_SURFACE_CACHE_INPUT_LIMIT = 8
_SURFACE_CACHE_POINT_LIMIT = 256


def _surface_evaluation_cache_for(namespace: str) -> tuple[OrderedDict[str, Any], RLock]:
    """Return an LRU for one complete financial identity, evicting old inputs."""
    if not isinstance(namespace, str) or not namespace:
        raise ValueError("namespace financeiro precisa ser texto não vazio")
    with _SURFACE_CACHE_LOCK:
        bucket = _SURFACE_EVALUATION_CACHES.get(namespace)
        if bucket is None:
            bucket = (OrderedDict(), RLock())
            _SURFACE_EVALUATION_CACHES[namespace] = bucket
        else:
            _SURFACE_EVALUATION_CACHES.move_to_end(namespace)
        while len(_SURFACE_EVALUATION_CACHES) > _SURFACE_CACHE_INPUT_LIMIT:
            _SURFACE_EVALUATION_CACHES.popitem(last=False)
    return bucket


def _trim_surface_evaluation_cache(cache: OrderedDict[str, Any]) -> None:
    while len(cache) > _SURFACE_CACHE_POINT_LIMIT:
        cache.popitem(last=False)


class EvaluationBudget:
    """Per-request direct-evaluation budget for future bounded search actions."""

    def __init__(self, *, max_evaluations: int = WORKSPACE_SEARCH_BUDGET["max_evaluations"],
                 deadline_seconds: float = WORKSPACE_SEARCH_BUDGET["deadline_seconds"], clock: Any = monotonic,
                 ledger_context: Mapping[str, Any] | None = None):
        if type(max_evaluations) is not int or max_evaluations <= 0:
            raise ValueError("max_evaluations precisa ser inteiro positivo")
        if isinstance(deadline_seconds, bool) or not isinstance(deadline_seconds, (int, float)) or not math.isfinite(deadline_seconds) or deadline_seconds <= 0:
            raise ValueError("deadline_seconds precisa ser finito e positivo")
        self.max_evaluations = max_evaluations
        self.deadline_seconds = float(deadline_seconds)
        self._clock = clock
        self._started_at = clock()
        self._deadline = self._started_at + self.deadline_seconds
        self.evaluated_points = 0
        self.reason: str | None = None
        self.cache_hits = 0
        self._ledger_context = deepcopy(dict(ledger_context)) if isinstance(ledger_context, Mapping) else None
        self._ledger_events: list[dict[str, Any]] = []
        self._ledger_by_ordinal: dict[int, dict[str, Any]] = {}
        self._last_direct_attempt_completed_after_deadline: bool | None = None

    @property
    def last_direct_attempt_completed_after_deadline(self) -> bool | None:
        """Expose timing qualification to the request-local result consumer."""
        return self._last_direct_attempt_completed_after_deadline

    def _append_ledger_event(self, event: Mapping[str, Any]) -> dict[str, Any] | None:
        if self._ledger_context is None:
            return None
        elapsed = self._elapsed_seconds()
        row = {
            "sequence": len(self._ledger_events) + 1, **dict(event),
            "elapsed_at_event_seconds": elapsed,
        }
        if row.get("direct") is True and row.get("outcome") == "in_progress":
            row["started_at_elapsed_seconds"] = elapsed
        self._ledger_events.append(row)
        return row

    def _elapsed_seconds(self, now: float | None = None) -> float:
        elapsed = (self._clock() if now is None else now) - self._started_at
        return round(max(0.0, elapsed), 6)

    def record_cache_hit(self, *, basis_id: str, input_fingerprint: str, cached_outcome: str) -> None:
        self.cache_hits += 1
        self._append_ledger_event({
            "direct": False, "direct_ordinal": None, "basis_id": basis_id,
            "input_fingerprint": input_fingerprint, "cache": "HIT",
            "outcome": "cached", "cached_outcome": cached_outcome,
        })

    def record_not_evaluated(
        self, *, basis_id: str, input_fingerprint: str, outcome: str, reason_code: str | None = None,
    ) -> None:
        self._append_ledger_event({
            "direct": False, "direct_ordinal": None, "basis_id": basis_id,
            "input_fingerprint": input_fingerprint, "cache": "MISS",
            "outcome": outcome, "reason_code": reason_code,
        })

    def refuse_if_stopped(self, *, basis_id: str, input_fingerprint: str) -> str | None:
        if self.reason is None:
            if self.check_deadline():
                pass
            elif self.evaluated_points >= self.max_evaluations:
                self.reason = "EVALUATION_LIMIT"
        if self.reason is not None:
            self._append_ledger_event({
                "direct": False, "direct_ordinal": None,
                "requested_direct_ordinal": self.evaluated_points + 1,
                "basis_id": basis_id, "input_fingerprint": input_fingerprint,
                "cache": "MISS", "outcome": "refused", "reason_code": self.reason,
            })
            return self.reason
        return None

    def evaluate_direct(
        self, *, basis_id: str, input_fingerprint: str, evaluator: Any,
    ) -> tuple[bool, Any]:
        """Reserve and record a direct attempt before invoking the evaluator."""
        self._last_direct_attempt_completed_after_deadline = None
        if not self.try_consume():
            self._append_ledger_event({
                "direct": False, "direct_ordinal": None,
                "requested_direct_ordinal": self.evaluated_points + 1,
                "basis_id": basis_id, "input_fingerprint": input_fingerprint,
                "cache": "MISS", "outcome": "refused", "reason_code": self.reason,
            })
            return False, None
        ordinal = self.evaluated_points
        event = self._append_ledger_event({
            "direct": True, "direct_ordinal": ordinal, "basis_id": basis_id,
            "input_fingerprint": input_fingerprint, "cache": "MISS", "outcome": "in_progress",
        })
        if event is not None:
            self._ledger_by_ordinal[ordinal] = event
        try:
            value = evaluator()
        except BaseException as exc:
            name = type(exc).__name__
            outcome = "cancelled" if name in {"CancelledError", "KeyboardInterrupt", "GeneratorExit"} else "exception"
            self.finish_direct_attempt(
                ordinal, outcome=outcome, exception_type=name,
                reason_code=getattr(exc, "code", None),
            )
            raise
        self.finish_direct_attempt(ordinal, outcome="completed")
        return True, value

    def finish_direct_attempt(
        self, ordinal: int, *, outcome: str, exception_type: str | None = None,
        reason_code: str | None = None,
    ) -> None:
        now = self._clock()
        elapsed = self._elapsed_seconds(now)
        late = now >= self._deadline
        self._last_direct_attempt_completed_after_deadline = late
        if late and self.reason is None:
            self.reason = "DEADLINE_EXCEEDED"
        event = self._ledger_by_ordinal.get(ordinal)
        if event is None:
            return
        event["outcome"] = outcome
        event["finished_at_elapsed_seconds"] = elapsed
        event["elapsed_seconds"] = elapsed - event.get("started_at_elapsed_seconds", elapsed)
        event["completed_after_deadline"] = late
        if exception_type is not None:
            event["exception_type"] = exception_type
        if reason_code is not None:
            event["reason_code"] = reason_code

    def try_consume(self) -> bool:
        if self.reason is not None:
            return False
        if self.check_deadline():
            return False
        if self.evaluated_points >= self.max_evaluations:
            self.reason = "EVALUATION_LIMIT"
            return False
        self.evaluated_points += 1
        return True

    def check_deadline(self) -> bool:
        """Record and report deadline expiry without consuming an evaluation."""
        if self.reason is not None:
            return self.reason == "DEADLINE_EXCEEDED"
        if self._clock() >= self._deadline:
            self.reason = "DEADLINE_EXCEEDED"
            return True
        return False

    def to_dict(self) -> dict[str, Any]:
        result: dict[str, Any] = {
            "max_evaluations": self.max_evaluations,
            "deadline_seconds": self.deadline_seconds,
            "elapsed_seconds": self._elapsed_seconds(),
            "evaluated_points": self.evaluated_points,
            "incomplete_reason": self.reason,
        }
        if self._ledger_context is not None:
            result["cache_hits"] = self.cache_hits
            result["evaluation_ledger"] = {
                **deepcopy(self._ledger_context),
                "max_direct_calls": self.max_evaluations,
                "direct_attempts": self.evaluated_points,
                "cache_hits": self.cache_hits,
                "events": deepcopy(self._ledger_events),
            }
        return result


@dataclass(frozen=True, slots=True)
class CapitalInput:
    mode: CapitalMode
    value: Decimal

    @property
    def unit(self) -> str:
        return "BRL" if self.mode is CapitalMode.BUDGET else "TITLE"


@dataclass(frozen=True, slots=True)
class PriceSelection:
    mode: PriceMode
    pu: Decimal | None = None
    annual_real_rate: Decimal | None = None
    quoted_side: Side | None = None
    provenance: Provenance | None = None
    rate_check: "PriceSelection | None" = None
    dataset_kind: str | None = None
    version_hash: str | None = None
    observation_date: date | None = None
    spread: Decimal | None = None
    spread_source: str | None = None
    evidence_status: EvidenceStatus | None = None
    quality: Quality = Quality.MISSING

    def to_dict(self) -> dict[str, Any]:
        result: dict[str, Any] = {"mode": self.mode.value, "quality": self.quality.value}
        for key, value in (
            ("pu", self.pu), ("annual_real_rate", self.annual_real_rate),
            ("quoted_side", self.quoted_side.value if self.quoted_side else None),
            ("dataset_kind", self.dataset_kind), ("version_hash", self.version_hash),
            ("observation_date", self.observation_date.isoformat() if self.observation_date else None),
            ("spread", self.spread), ("spread_source", self.spread_source),
            ("evidence_status", self.evidence_status.value if self.evidence_status else None),
        ):
            if value is not None:
                result[key] = str(value) if isinstance(value, Decimal) else value
        if self.provenance is not None:
            result["provenance"] = _provenance_dict(self.provenance)
        if self.rate_check is not None:
            result["rate_check"] = self.rate_check.to_dict()
        return result


@dataclass(frozen=True, slots=True)
class Capability:
    capability_id: str
    status: CapabilityStatus
    reason_code: str | None = None
    message: str | None = None
    missing_fields: tuple[str, ...] = ()

    def to_dict(self) -> dict[str, Any]:
        reason = None if self.reason_code is None else {
            "code": self.reason_code,
            "message": self.message,
        }
        return {
            "status": self.status.value,
            "reason": reason,
            "missing_fields": list(self.missing_fields),
        }


@dataclass(frozen=True, slots=True)
class WorkspaceInput:
    instrument: Instrument | None
    capital: CapitalInput | None
    purchase_date: date | None
    sale_date: date | None
    entry_price: PriceSelection | None
    exit_price: PriceSelection | None
    knowledge: AsOf | None
    intent: ScenarioIntent
    source_versions: tuple[tuple[str, str | None], ...]
    assumptions: Mapping[str, Any]
    data: Mapping[str, Any]
    analysis_context: WorkspaceAnalysisContext | None
    missing_fields: tuple[str, ...]
    capabilities: tuple[Capability, ...]

    @property
    def status(self) -> str:
        if self.missing_fields or any(
            item.status is not CapabilityStatus.AVAILABLE for item in self.capabilities
        ):
            return "partial"
        return "ready"

    def capability(self, capability_id: str) -> Capability:
        for item in self.capabilities:
            if item.capability_id == capability_id:
                return item
        raise KeyError(capability_id)

    def to_dict(self) -> dict[str, Any]:
        instrument = None
        if self.instrument is not None:
            instrument = {
                "family": self.instrument.family.value,
                "instrument_id": self.instrument.instrument_id,
                "maturity_date": self.instrument.maturity_date.isoformat(),
                "conversion_date": self.instrument.conversion_date.isoformat() if self.instrument.conversion_date else None,
                "first_income_date": self.instrument.first_income_date.isoformat() if self.instrument.first_income_date else None,
            }
        normalized_input = {
            "instrument": instrument,
            "capital": None if self.capital is None else {
                "mode": self.capital.mode.value,
                "value": str(self.capital.value),
                "unit": self.capital.unit,
            },
            "purchase_date": self.purchase_date.isoformat() if self.purchase_date else None,
            "sale_date": self.sale_date.isoformat() if self.sale_date else None,
            "entry_price": self.entry_price.to_dict() if self.entry_price else None,
            "exit_price": self.exit_price.to_dict() if self.exit_price else None,
            "knowledge": None if self.knowledge is None else {
                "date": self.knowledge.date.isoformat(), "mode": self.knowledge.mode.value,
            },
            "intent": self.intent.value,
            "source_versions": dict(self.source_versions),
            "assumptions": _thaw_json(self.assumptions),
            "data": _thaw_json(self.data),
        }
        if self.analysis_context is not None:
            normalized_input["analysis_context"] = self.analysis_context.to_dict()
        return {
            "status": self.status,
            "missing_fields": list(self.missing_fields),
            "capabilities": {
                item.capability_id: item.to_dict() for item in self.capabilities
            },
            "normalized_input": normalized_input,
        }


@dataclass(frozen=True, slots=True)
class UnitPriceInput:
    instrument: Instrument | None
    requested_date: date | None
    entry_price: PriceSelection | None
    knowledge: AsOf | None
    intent: ScenarioIntent
    source_versions: tuple[tuple[str, str | None], ...]
    assumptions: Mapping[str, Any]
    data: Mapping[str, Any]
    analysis_context: WorkspaceAnalysisContext
    missing_fields: tuple[str, ...]

    def to_dict(self) -> dict[str, Any]:
        instrument = None
        if self.instrument is not None:
            instrument = {
                "family": self.instrument.family.value,
                "instrument_id": self.instrument.instrument_id,
                "maturity_date": self.instrument.maturity_date.isoformat(),
                "conversion_date": self.instrument.conversion_date.isoformat() if self.instrument.conversion_date else None,
                "first_income_date": self.instrument.first_income_date.isoformat() if self.instrument.first_income_date else None,
            }
        return {
            "status": "partial" if self.missing_fields else "ready",
            "missing_fields": list(self.missing_fields),
            "normalized_input": {
                "analysis_context": self.analysis_context.to_dict(),
                "instrument": instrument,
                "purchase_date": self.requested_date.isoformat() if self.requested_date else None,
                "entry_price": self.entry_price.to_dict() if self.entry_price else None,
                "knowledge": None if self.knowledge is None else {
                    "date": self.knowledge.date.isoformat(), "mode": self.knowledge.mode.value,
                },
                "intent": self.intent.value,
                "source_versions": dict(self.source_versions),
                "assumptions": _thaw_json(self.assumptions),
                "data": _thaw_json(self.data),
            },
        }


_INPUT_FIELDS = {
    "instrument", "capital", "purchase_date", "sale_date", "entry_price",
    "exit_price", "knowledge", "intent", "assumptions", "data", "source_versions", "constraints",
    "analysis_context",
}
_INSTRUMENT_FIELDS = {"family", "series_year", "instrument_id", "maturity_date", "conversion_date", "first_income_date"}
_PRICE_COMMON = {"mode", "provenance"}
_PROVENANCE_FIELDS = {
    "source_id", "source_ref", "quality", "observed_on", "published_at", "version",
    "sha256", "revision_id", "supersedes_revision", "settlement_date",
}
_ASSUMPTION_FIELDS = {
    "settlement_profile", "entry_fee", "exit_fee_brl", "tax_cost_basis_brl",
    "custody_override_brl", "institution_net_brl", "institution_release_date",
    "inflation_projection", "explicit_settlements", "ipca_monthly_rates",
}
_DATA_FIELDS = {"index_anchors", "price_index_levels", "intermediate_paid_costs", "ipca_monthly_indexes"}


def parse_workspace_analysis_context(raw: object) -> WorkspaceAnalysisContext:
    """Validate the bounded analysis mode without changing the financial input."""
    value = _object(raw, "analysis_context", {"kind", "timeline"})
    kind = _text(value.get("kind", "OPERATION"), "analysis_context.kind", 32)
    if kind not in {"OPERATION", "UNIT_PRICE"}:
        raise ValidationError("INVALID_ANALYSIS_CONTEXT", "analysis_context.kind precisa ser OPERATION ou UNIT_PRICE.")
    raw_timeline = value.get("timeline", {})
    timeline = _object(raw_timeline, "analysis_context.timeline", {"mode", "start", "end"})
    mode = _text(timeline.get("mode", "POINT"), "analysis_context.timeline.mode", 16)
    if mode not in {"POINT", "WINDOW"}:
        raise ValidationError("INVALID_ANALYSIS_CONTEXT", "timeline.mode precisa ser POINT ou WINDOW.")
    if mode == "POINT" and ("start" in timeline or "end" in timeline):
        raise ValidationError("INVALID_ANALYSIS_CONTEXT", "POINT não aceita start nem end.")
    start = _date(timeline["start"], "analysis_context.timeline.start") if "start" in timeline else None
    end = _date(timeline["end"], "analysis_context.timeline.end") if "end" in timeline else None
    if start is not None and end is not None and end < start:
        raise ValidationError("INVALID_ANALYSIS_CONTEXT", "timeline.end não pode preceder timeline.start.")
    missing = () if mode == "POINT" else tuple(
        f"analysis_context.timeline.{field}"
        for field, current in (("start", start), ("end", end)) if current is None
    )
    return WorkspaceAnalysisContext(kind, mode, start, end, missing)


def normalize_workspace_input(payload: object) -> WorkspaceInput:
    """Validate and normalize a complete or partial v2 financial input.

    Missing fields become capability guidance. Malformed or unknown fields are
    rejected; they are never silently discarded or replaced with numeric zero.
    """
    _reject_non_json_numbers(payload, "input")
    root = _object(payload, "input", _INPUT_FIELDS)
    if "constraints" in root:
        from .constraints import parse_constraint_set

        parse_constraint_set(root["constraints"])
    base_missing: list[str] = []
    price_missing: list[str] = []

    analysis_context = (
        parse_workspace_analysis_context(root["analysis_context"])
        if "analysis_context" in root else None
    )
    operation_window = bool(analysis_context and analysis_context.is_operation_window)
    if analysis_context is not None:
        base_missing.extend(analysis_context.missing_fields)

    instrument = _parse_instrument(root.get("instrument"), base_missing)
    capital = _parse_capital(root.get("capital"), base_missing)
    purchase_date = _optional_date(root.get("purchase_date"), "purchase_date")
    sale_date = _optional_date(root.get("sale_date"), "sale_date")
    if purchase_date is None:
        base_missing.append("purchase_date")
    if sale_date is None and not operation_window:
        base_missing.append("sale_date")
    if purchase_date is not None and sale_date is not None and sale_date <= purchase_date:
        raise ValidationError("INVALID_DATES", "Venda precisa ocorrer depois da compra.")

    intent_supplied = "intent" in root
    if not intent_supplied:
        base_missing.append("intent")
    intent = _enum(ScenarioIntent, root.get("intent", "HISTORICAL_REVIEW"), "intent")
    knowledge = _parse_knowledge(root.get("knowledge"), base_missing)
    family = instrument.family if instrument is not None else None
    entry_price = _parse_price(
        root.get("entry_price"), "entry_price", price_missing, is_exit=False,
        knowledge=knowledge, intent=intent, family=family,
    )
    exit_price = (
        None if operation_window and "exit_price" not in root else _parse_price(
            root.get("exit_price"), "exit_price", price_missing, is_exit=True,
            knowledge=knowledge, intent=intent, family=family,
        )
    )
    if exit_price is not None and exit_price.mode is PriceMode.SAME_ENTRY_RATE:
        if entry_price is None or entry_price.annual_real_rate is None:
            price_missing.append("entry_price.annual_real_rate")

    if knowledge is not None and intent_supplied and intent is not ScenarioIntent.HYPOTHETICAL:
        future_order = any(
            event_date is not None and event_date > knowledge.date
            for event_date in (purchase_date, sale_date)
        )
        if future_order:
            raise ValidationError(
                "HYPOTHETICAL_INTENT_REQUIRED",
                "Compra ou venda depois do corte de conhecimento exige intent HYPOTHETICAL explícito.",
            )

    assumptions, assumption_missing = _parse_assumptions(root.get("assumptions"))
    base_missing.extend(assumption_missing)
    data = _parse_data(root.get("data"))
    source_versions = _parse_source_versions(root.get("source_versions"))
    version_map = dict(source_versions)

    for path, selection in (("entry_price", entry_price), ("exit_price", exit_price)):
        if selection is not None and selection.mode is PriceMode.AUTO_LOCAL:
            if "source_versions" not in root:
                price_missing.append("source_versions.market_sim")
            elif version_map.get("market_sim") != selection.version_hash:
                raise ValidationError(
                    "INPUT_FINGERPRINT_MISMATCH",
                    f"{path} precisa usar a versão de fonte fixada em source_versions.market_sim.",
                )

    price_block = next(
        (
            (path, selection)
            for path, selection in (("entry_price", entry_price), ("exit_price", exit_price))
            if selection is not None and selection.evidence_status in (
                EvidenceStatus.PUBLISHED_AFTER_AS_OF,
                EvidenceStatus.PUBLICATION_DATE_UNKNOWN,
                EvidenceStatus.OBSERVATION_AFTER_AS_OF,
            )
        ),
        None,
    )
    core_missing = tuple(dict.fromkeys(base_missing))
    all_missing = tuple(dict.fromkeys((*base_missing, *price_missing)))
    if price_block is not None:
        path, selection = price_block
        price_capability = Capability(
            "price_resolution", CapabilityStatus.BLOCKED_POLICY,
            selection.evidence_status.value,
            "Fonte excluída do corte causal; escolha EX_POST ou informe um preço hipotético.",
            (),
        )
    elif entry_price is None or (exit_price is None and not operation_window):
        price_capability = Capability(
            "price_resolution", CapabilityStatus.NEEDS_INPUT, "MISSING_PRICE",
            "Informe PU, taxa e âncora compatível, ou escolha uma cotação local exata.",
            tuple(price_missing),
        )
    elif any(item.mode is PriceMode.AUTO_LOCAL for item in ((entry_price,) if operation_window else (entry_price, exit_price))):
        price_capability = Capability(
            "price_resolution", CapabilityStatus.NEEDS_INPUT, "MISSING_PRICE",
            "Cotação local exige resolução exata de título, lado, data e versão.",
            ("instrument", "market_data[exact_instrument_side_date]"),
        )
    elif any(item.mode in (PriceMode.MANUAL_RATE, PriceMode.SAME_ENTRY_RATE) for item in ((entry_price,) if operation_window else (entry_price, exit_price))):
        price_capability = Capability(
            "price_resolution", CapabilityStatus.NEEDS_INPUT, "MISSING_INDEX",
            "Taxa precisa de âncora VNA/VNI da família e liquidação correspondentes.",
            ("data.index_anchors[matching_kind_and_settlement]",),
        )
    else:
        price_capability = Capability("price_resolution", CapabilityStatus.AVAILABLE)

    rate_check = entry_price.rate_check if entry_price is not None else None
    if rate_check is not None:
        if rate_check.evidence_status in (
            EvidenceStatus.PUBLISHED_AFTER_AS_OF,
            EvidenceStatus.PUBLICATION_DATE_UNKNOWN,
            EvidenceStatus.OBSERVATION_AFTER_AS_OF,
        ):
            rate_check_capability = Capability(
                "rate_check", CapabilityStatus.BLOCKED_POLICY,
                rate_check.evidence_status.value,
                "Taxa de conferência excluída do corte causal; PU principal permanece intacto.",
                (),
            )
        else:
            rate_check_capability = Capability(
                "rate_check", CapabilityStatus.NEEDS_INPUT, "MISSING_INDEX",
                "PU manual continua principal; a taxa de conferência aguarda âncora exata.",
                ("data.index_anchors[matching_kind_and_settlement]",),
            )
    else:
        rate_check_capability = Capability("rate_check", CapabilityStatus.AVAILABLE)

    if core_missing:
        input_capability = Capability(
            "input_resolution", CapabilityStatus.NEEDS_INPUT, "MISSING_FIELD",
            "Preencha somente os campos necessários para identificar a próxima capacidade.",
            core_missing,
        )
    else:
        input_capability = Capability("input_resolution", CapabilityStatus.AVAILABLE)

    nominal_ready = (
        not core_missing
        and price_block is None
        and entry_price is not None
        and exit_price is not None
        and entry_price.mode is PriceMode.MANUAL_PU
        and exit_price.mode is PriceMode.MANUAL_PU
    )
    if core_missing:
        nominal_code = "MISSING_FIELD"
        nominal_missing = core_missing
    elif price_block is not None:
        nominal_code = price_block[1].evidence_status.value
        nominal_missing = ()
    elif operation_window:
        nominal_code = "MISSING_SELECTION"
        nominal_missing = ("surface.selected",)
    elif entry_price is not None and exit_price is not None and any(
        item.mode in (PriceMode.MANUAL_RATE, PriceMode.SAME_ENTRY_RATE)
        for item in (entry_price, exit_price)
    ):
        nominal_code = "MISSING_INDEX"
        nominal_missing = ("data.index_anchors[matching_kind_and_settlement]",)
    elif entry_price is not None and exit_price is not None and any(
        item.mode is PriceMode.AUTO_LOCAL for item in (entry_price, exit_price)
    ):
        nominal_code = "MISSING_PRICE"
        nominal_missing = ("market_data[exact_instrument_side_date]",)
    else:
        nominal_code = "MISSING_PRICE"
        nominal_missing = tuple(price_missing)
    nominal_capability = Capability(
        "nominal_evaluation",
        CapabilityStatus.AVAILABLE if nominal_ready else CapabilityStatus.NEEDS_INPUT,
        None if nominal_ready else nominal_code,
        None if nominal_ready else "Cálculo nominal aguarda a entrada mínima compatível.",
        () if nominal_ready else nominal_missing,
    )

    return WorkspaceInput(
        instrument=instrument,
        capital=capital,
        purchase_date=purchase_date,
        sale_date=sale_date,
        entry_price=entry_price,
        exit_price=exit_price,
        knowledge=knowledge,
        intent=intent,
        source_versions=source_versions,
        assumptions=assumptions,
        data=data,
        analysis_context=analysis_context,
        missing_fields=all_missing,
        capabilities=(input_capability, price_capability, rate_check_capability, nominal_capability),
    )


def normalize_unit_price_input(payload: object) -> UnitPriceInput:
    """Validate only the inputs that can affect a unit-price quote."""
    prepared = prepare_workspace_defaults(payload)
    _reject_non_json_numbers(prepared, "input")
    root = _object(prepared, "input", _INPUT_FIELDS)
    if "analysis_context" not in root:
        raise ValidationError("INVALID_ANALYSIS_CONTEXT", "UNIT_PRICE exige analysis_context explícito.")
    analysis_context = parse_workspace_analysis_context(root["analysis_context"])
    if analysis_context.kind != "UNIT_PRICE":
        raise ValidationError("INVALID_ANALYSIS_CONTEXT", "Cotação unitária exige kind UNIT_PRICE.")
    missing: list[str] = list(analysis_context.missing_fields)
    instrument = _parse_instrument(root.get("instrument"), missing)
    requested_date = _optional_date(root.get("purchase_date"), "purchase_date")
    if requested_date is None:
        missing.append("purchase_date")
    intent_supplied = "intent" in root
    if not intent_supplied:
        missing.append("intent")
    intent = _enum(ScenarioIntent, root.get("intent", "HISTORICAL_REVIEW"), "intent")
    knowledge = _parse_knowledge(root.get("knowledge"), missing)
    family = instrument.family if instrument is not None else None
    price_missing: list[str] = []
    entry_price = _parse_price(
        root.get("entry_price"), "entry_price", price_missing, is_exit=False,
        knowledge=knowledge, intent=intent, family=family,
    )
    missing.extend(price_missing)
    if entry_price is not None and entry_price.mode is PriceMode.SAME_ENTRY_RATE:
        raise ValidationError("INVALID_PRICE_MODE", "UNIT_PRICE aceita PU, taxa de entrada ou cotação local exata.")
    if knowledge is not None and requested_date is not None and requested_date > knowledge.date and intent is not ScenarioIntent.HYPOTHETICAL:
        raise ValidationError(
            "HYPOTHETICAL_INTENT_REQUIRED",
            "Data de referência depois do corte de conhecimento exige intent HYPOTHETICAL explícito.",
        )

    assumptions, assumption_missing = _parse_assumptions(root.get("assumptions"))
    missing.extend(field for field in assumption_missing if not (
        field == "assumptions.entry_fee" or field.startswith("assumptions.entry_fee.")
        or field == "assumptions.exit_fee_brl" or field.startswith("assumptions.explicit_settlements.sale")
    ))
    assumption_values = _thaw_json(assumptions)
    unit_assumptions = {
        "settlement_profile": assumption_values.get("settlement_profile"),
        "inflation_projection": assumption_values.get("inflation_projection"),
        "ipca_monthly_rates": assumption_values.get("ipca_monthly_rates"),
        "explicit_settlements": None,
    }
    explicit = assumption_values.get("explicit_settlements")
    if isinstance(explicit, Mapping):
        unit_assumptions["explicit_settlements"] = {
            "reference": explicit["purchase"],
        } if "purchase" in explicit else {}
    parsed_data = _thaw_json(_parse_data(root.get("data")))
    data = {key: parsed_data.get(key, []) for key in ("index_anchors", "price_index_levels", "ipca_monthly_indexes")}
    source_versions = _parse_source_versions(root.get("source_versions"))
    versions = dict(source_versions)
    if entry_price is not None and entry_price.mode is PriceMode.AUTO_LOCAL:
        if "source_versions" not in root:
            missing.append("source_versions.market_sim")
        elif versions.get("market_sim") != entry_price.version_hash:
            raise ValidationError(
                "INPUT_FINGERPRINT_MISMATCH",
                "entry_price precisa usar a versão de fonte fixada em source_versions.market_sim.",
            )
    return UnitPriceInput(
        instrument, requested_date, entry_price, knowledge, intent, source_versions,
        _freeze_json(unit_assumptions), _freeze_json(data), analysis_context,
        tuple(dict.fromkeys(missing)),
    )


def _unit_price_assumptions_summary(
    normalized: UnitPriceInput,
    unit_price: Mapping[str, Any] | None,
    reference_price: Mapping[str, Any] | None,
) -> tuple[dict[str, Any], ...]:
    selection = normalized.entry_price
    rows: list[dict[str, Any]] = []

    def add(assumption_id: str, value: Any, unit: str, status: str, *, quality: Any = None,
            source: Mapping[str, Any] | None = None, control_id: str | None = None) -> None:
        rows.append({
            "assumption_id": assumption_id, "label_key": "assumption." + assumption_id,
            "value": None if value is None else str(value), "unit": unit, "status": status,
            "quality": getattr(quality, "value", quality), "source": None if source is None else dict(source),
            "control_id": control_id,
        })

    price_source = None
    if selection is not None:
        provenance = _provenance_dict(selection.provenance) if selection.provenance else None
        price_source = {"kind": selection.mode.value, "provenance": provenance,
                        "source_ref": selection.provenance.source_ref if selection.provenance else "Entrada manual"}
    price_value = unit_price.get("value") if unit_price is not None else None
    if price_value is None and reference_price is not None:
        price_value = reference_price.get("unit_price")
    price_status = unit_price.get("status") if unit_price is not None else None
    if price_status is None and reference_price is not None:
        price_status = reference_price.get("status")
    price_quality = unit_price.get("quality") if unit_price is not None else None
    if price_quality is None and reference_price is not None:
        price_quality = reference_price.get("quality")
    add("entry_price", price_value, "BRL_PER_TITLE",
        "AVAILABLE" if price_value is not None else "MISSING",
        quality=price_quality, source=price_source, control_id="entry_price")
    rate = (
        selection.annual_real_rate
        if selection is not None and selection.mode is not PriceMode.MANUAL_PU
        else None
    )
    add("entry_rate", rate, "ratio", "AVAILABLE" if rate is not None else "NOT_APPLIED",
        quality=selection.quality if rate is not None else None,
        source=price_source if rate is not None else None, control_id="entry_price")
    rate_check = selection.rate_check if selection is not None else None
    add("entry_rate_check", rate_check.annual_real_rate if rate_check is not None else None,
        "ratio", "NOT_EVALUATED" if rate_check is not None else "NOT_APPLIED",
        quality=rate_check.quality if rate_check is not None else None,
        source={"kind": "USER_INPUT", "evaluation": "NOT_EVALUATED"} if rate_check is not None else None,
        control_id="entry_price")
    add("purchase_date", normalized.requested_date.isoformat() if normalized.requested_date else None,
        "date", "AVAILABLE" if normalized.requested_date else "MISSING",
        quality=Quality.INFORMED if normalized.requested_date else Quality.MISSING,
        source={"kind": "USER_REQUEST"}, control_id="purchase_date")
    financial_date = (unit_price or {}).get("financial_date")
    if financial_date is None and reference_price is not None:
        financial_date = reference_price.get("financial_date")
    add("financial_date", financial_date, "date", "AVAILABLE" if financial_date else "MISSING",
        quality=(unit_price or {}).get("quality") or (reference_price or {}).get("quality"),
        source={"kind": "calendar_resolution"} if financial_date else None,
        control_id="assumptions.settlement_profile")
    assumptions = _thaw_json(normalized.assumptions)
    add("settlement_profile", assumptions.get("settlement_profile"), "enum",
        "AVAILABLE" if assumptions.get("settlement_profile") else "MISSING",
        quality=Quality.INFORMED if assumptions.get("settlement_profile") else Quality.MISSING,
        source={"profile_id": assumptions.get("settlement_profile")} if assumptions.get("settlement_profile") else None,
        control_id="assumptions.settlement_profile")
    add("knowledge_date", normalized.knowledge.date.isoformat() if normalized.knowledge else None, "date",
        "AVAILABLE" if normalized.knowledge else "MISSING",
        quality=Quality.INFORMED if normalized.knowledge else Quality.MISSING,
        source={"mode": normalized.knowledge.mode.value} if normalized.knowledge else None,
        control_id="knowledge.date")
    add("intent", normalized.intent.value, "enum", "AVAILABLE",
        quality=Quality.HYPOTHETICAL if normalized.intent is ScenarioIntent.HYPOTHETICAL else Quality.INFORMED,
        source={"kind": "USER_DECLARED"}, control_id="intent")
    projection = assumptions.get("inflation_projection")
    if isinstance(projection, Mapping):
        add("inflation_projection", projection.get("mode"), "enum", "AVAILABLE",
            quality=Quality.HYPOTHETICAL, source=dict(projection), control_id="assumptions.inflation_projection")
    else:
        add("inflation_projection", None, "enum", "NOT_APPLIED", control_id="assumptions.inflation_projection")
    for kind, version in normalized.source_versions:
        add(f"source_version_{kind}", version, "sha256", "AVAILABLE" if version else "NOT_USED",
            quality=Quality.INFORMED if version else None, source={"key": kind} if version else None,
            control_id=f"source_versions.{kind}")
    for index, anchor in enumerate(_thaw_json(normalized.data).get("index_anchors", [])):
        add(f"index_anchor_{anchor['kind']}_{index + 1}", anchor["value"], anchor["kind"], "AVAILABLE",
            quality=anchor["quality"], source={"source_ref": anchor["source_ref"],
                                               "reference_date": anchor["reference_date"],
                                               "provenance": anchor.get("provenance")},
            control_id="data.index_anchors")
    if normalized.intent is ScenarioIntent.HYPOTHETICAL:
        add("hypothesis", "HYPOTHETICAL", "enum", "AVAILABLE", quality=Quality.HYPOTHETICAL,
            source={"kind": "USER_DECLARED_INTENT"}, control_id="intent")
    return tuple(rows)


def _unit_price_presentation_summary(
    result_status: str,
    unit_price: Mapping[str, Any] | None,
    reference_price: Mapping[str, Any] | None,
) -> dict[str, Any]:
    quote = unit_price if unit_price is not None else reference_price
    value = quote.get("value") if unit_price is not None else quote.get("unit_price") if quote is not None else None
    status = quote.get("status") if quote is not None else "needs_input"
    quality = quote.get("quality") if quote is not None else None
    reason_code = quote.get("reason_code") if quote is not None else None
    metric_reason = None if value is not None else {
        "code": reason_code or "UNIT_PRICE_INCOMPLETE",
        "message": "A cotação unitária aguarda preço, taxa ou evidência compatível.",
        "missing_fields": [],
    }
    forced_status = "BLOCKED_POLICY" if status == "blocked_policy" else "MISSING" if value is None else None
    metric = _presentation_metric(
        "unit_price", value, "BRL_PER_TITLE",
        quality=Quality(quality) if quality in Quality._value2member_map_ else None,
        dependencies=("unit_price.value", "unit_price.financial_date", "entry_price", "data.index_anchors"),
        reason=metric_reason, forced_status=forced_status,
    )
    return {
        "status": "ready" if result_status == "ready" and metric["value"] is not None else "partial",
        "metrics": [metric],
        "headline_metric_id": "unit_price" if metric["value"] is not None else None,
    }


def resolve_workspace_unit_price(
    payload: object,
    query: Mapping[str, Any],
    *,
    calendar: Any,
    price_observations: tuple[PriceObservation, ...] | None = None,
    index_observations: tuple[IndexObservation, ...] | None = None,
    price_source_error: str | None = None,
    index_source_error: str | None = None,
    require_automatic_nominal: bool = False,
    include_unit_price: bool = True,
) -> dict[str, Any]:
    """Resolve a price-only context without constructing an operation.

    ``include_unit_price=False`` returns the eligible rate/index/date context for
    a caller that will perform its own direct repricing, without a preliminary PU call.
    """
    normalized = normalize_unit_price_input(payload)
    raw_instrument = payload.get("instrument") if isinstance(payload, Mapping) else None
    if (price_observations is not None and isinstance(raw_instrument, Mapping)
            and "series_year" in raw_instrument and normalized.instrument is not None):
        normalized = _resolve_instrument_from_catalog(normalized, price_observations)
    missing = list(normalized.missing_fields)
    request_kind = query["kind"]
    instrument = normalized.instrument
    selection = normalized.entry_price
    profile = normalized.assumptions.get("settlement_profile")
    explicit = normalized.assumptions.get("explicit_settlements")
    if not isinstance(explicit, Mapping):
        explicit = None

    def date_record(requested: date) -> dict[str, Any]:
        if not isinstance(profile, str):
            return {
                "requested_date": requested.isoformat(), "financial_date": None,
                "status": "needs_input", "reason_code": "MISSING_SETTLEMENT_PROFILE",
                "missing_fields": ["assumptions.settlement_profile"],
            }
        try:
            resolved = resolve_workspace_reference_date(
                requested_date=requested, settlement_profile=profile,
                calendar=calendar, explicit_settlements=explicit,
            )
        except ValidationError as exc:
            if exc.code == "E-CALENDAR":
                return {
                    "requested_date": requested.isoformat(), "financial_date": None,
                    "status": "blocked_policy", "reason_code": "CALENDAR_OUTSIDE_DOMAIN",
                    "missing_fields": [],
                }
            raise
        financial_date = resolved.settlement_date
        status = resolved.status
        reason_code = resolved.reason_code
        missing_fields = ["reference_date.confirmation"] if resolved.confirmation_required else []
        if (status == "available" and normalized.knowledge is not None
                and requested > normalized.knowledge.date
                and normalized.intent is not ScenarioIntent.HYPOTHETICAL):
            status, reason_code, missing_fields = "blocked_policy", "HYPOTHETICAL_INTENT_REQUIRED", []
        if status == "available" and instrument is not None and financial_date is not None:
            horizon = instrument.maturity_date if instrument.family is ProductFamily.IPCA_PRINCIPAL else instrument.first_income_date
            if horizon is not None and financial_date >= horizon:
                status, reason_code, missing_fields = "blocked_policy", "OUTSIDE_HORIZON", []
        return {
            "requested_date": requested.isoformat(),
            "order_date": resolved.proposed_order_date.isoformat(),
            "financial_date": financial_date.isoformat() if financial_date else None,
            "calendar_id": resolved.calendar_id,
            "profile_id": resolved.profile_id,
            "quality": resolved.quality.value,
            "status": status,
            "reason_code": reason_code,
            "message": resolved.message,
            "missing_fields": missing_fields,
        }

    requested_dates: list[date] = []
    domain: dict[str, Any] | None = None
    if request_kind == "DATE_CURVE":
        start = normalized.analysis_context.start
        end = normalized.analysis_context.end
        if start is None or end is None:
            missing.extend(normalized.analysis_context.missing_fields or (
                "analysis_context.timeline.start", "analysis_context.timeline.end",
            ))
        elif profile == "EXPLICIT":
            raise ValidationError("INVALID_SETTLEMENT_PROFILE", "DATE_CURVE não pode reutilizar uma liquidação explícita única.")
        else:
            if start.year < 2000 or end.year > 2085:
                raise ValidationError("CALENDAR_OUTSIDE_DOMAIN", "Calendário projetado cobre 2000–2085.")
            try:
                current = calendar.next_session(start, include=True)
                while current <= end:
                    requested_dates.append(current)
                    if len(requested_dates) > 1260:
                        raise ValidationError("INVALID_SEARCH_BUDGET", "DATE_CURVE excede o limite de 1.260 datas.")
                    current = calendar.next_session(current, include=False)
            except ValidationError as exc:
                if exc.code == "E-CALENDAR":
                    raise ValidationError("CALENDAR_OUTSIDE_DOMAIN", "Calendário projetado cobre 2000–2085.") from exc
                raise
            domain = {"start": start.isoformat(), "end": end.isoformat(), "sampled_order_dates": len(requested_dates)}
    elif normalized.requested_date is not None:
        requested_dates = [normalized.requested_date]

    records = [date_record(current) for current in requested_dates]
    family_index = None
    projection_context = None
    projection_points: dict[date, Any] = {}
    anchors_by_date: dict[date, Any] = {}
    needs_index = (
        instrument is not None and (
            (selection is not None and selection.mode is PriceMode.MANUAL_RATE)
            or request_kind == "RATE_CURVE"
        )
    )
    if needs_index:
        from .service import EvaluationContext, IndexAnchor, IndexKind, prepare_projection_window
        family_index = IndexKind.VNA if instrument.family is ProductFamily.IPCA_PRINCIPAL else IndexKind.VNI
        context_anchors: list[IndexAnchor] = []
        direct = _thaw_json(normalized.data).get("index_anchors", [])
        direct_keys: set[tuple[IndexKind, date]] = set()
        for index, raw_anchor in enumerate(direct):
            kind = IndexKind(raw_anchor["kind"])
            reference = date.fromisoformat(raw_anchor["reference_date"])
            provenance = _parse_provenance(raw_anchor.get("provenance"), f"data.index_anchors[{index}].provenance")
            context_anchors.append(IndexAnchor(
                kind, Decimal(raw_anchor["value"]), reference,
                Quality(raw_anchor["quality"]), raw_anchor["source_ref"], provenance,
            ))
            direct_keys.add((kind, reference))
        if index_observations is not None:
            for observation in index_observations:
                if observation.kind != family_index.value:
                    continue
                key = (family_index, observation.reference_date)
                if key in direct_keys:
                    continue
                provenance = Provenance(
                    "USER_SUPPLIED_INDEX_CSV", observation.source, Quality.INFORMED,
                    observation.reference_date,
                    datetime.combine(observation.known_on, datetime.min.time(), tzinfo=timezone.utc),
                )
                context_anchors.append(IndexAnchor(
                    family_index, observation.value, observation.reference_date,
                    Quality.INFORMED, observation.source, provenance,
                ))
        projection = None
        raw_projection = normalized.assumptions.get("inflation_projection")
        if isinstance(raw_projection, Mapping) and all(
            field in raw_projection for field in ("mode", "annual_rate", "anchor_date", "anchor_level", "source_ref")
        ) and (raw_projection.get("mode") != "INTERPOLATED_ANNUAL" or all(
            field in raw_projection for field in ("end_annual_rate", "end_date")
        )):
            projection = InflationProjection(
                raw_projection["mode"], Decimal(raw_projection["annual_rate"]),
                date.fromisoformat(raw_projection["anchor_date"]), Decimal(raw_projection["anchor_level"]),
                raw_projection["source_ref"],
                Decimal(raw_projection["end_annual_rate"]) if raw_projection.get("end_annual_rate") is not None else None,
                date.fromisoformat(raw_projection["end_date"]) if raw_projection.get("end_date") is not None else None,
            )
        target_dates = tuple(dict.fromkeys(
            date.fromisoformat(item["financial_date"])
            for item in records if item.get("status") == "available" and item.get("financial_date")
        ))
        if normalized.requested_date is not None:
            reference_record = date_record(normalized.requested_date)
            if reference_record.get("status") == "available" and reference_record.get("financial_date"):
                target_dates = tuple(dict.fromkeys((*target_dates, date.fromisoformat(reference_record["financial_date"]))))
        if target_dates and index_source_error is None:
            projection_context = prepare_projection_window(
                EvaluationContext(calendar=calendar, index_anchors=tuple(context_anchors),
                    ipca_monthly_indexes=_monthly_ipca_inputs(normalized.data, index_observations),
                    ipca_monthly_rates=_monthly_ipca_rates(normalized.assumptions),
                    require_automatic_nominal=require_automatic_nominal),
                index_targets={family_index: target_dates}, projection=projection,
                as_of=normalized.knowledge.date if normalized.knowledge else None,
                evidence_mode=normalized.knowledge.mode if normalized.knowledge else EvidenceMode.CAUSAL,
            )
            projection_points = {
                item.reference_date: item for item in projection_context.index_points
                if item.series_id == family_index.value
            }
            anchors_by_date = {
                item.reference_date: item for item in projection_context.context.index_anchors
                if item.kind is family_index
            }

    def priced_value(
        record: Mapping[str, Any], rate: Decimal | None, *, gate_price_evidence: bool = True,
    ) -> dict[str, Any]:
        if record.get("status") != "available":
            return {
                "status": record.get("status", "needs_input"),
                "reason_code": record.get("reason_code", "MISSING_DATE"),
                "unit_price": None, "missing_fields": list(record.get("missing_fields", ())),
            }
        if instrument is None or selection is None:
            return {"status": "needs_input", "reason_code": "MISSING_FIELD", "unit_price": None,
                    "missing_fields": list(missing)}
        financial_date = date.fromisoformat(record["financial_date"])
        if gate_price_evidence and selection.evidence_status in (
            EvidenceStatus.PUBLISHED_AFTER_AS_OF,
            EvidenceStatus.PUBLICATION_DATE_UNKNOWN,
            EvidenceStatus.OBSERVATION_AFTER_AS_OF,
        ):
            return {"status": "blocked_policy", "reason_code": selection.evidence_status.value,
                    "unit_price": None, "missing_fields": []}
        if selection.mode is PriceMode.MANUAL_PU and request_kind == "POINT":
            rate_check = selection.rate_check
            return {
                "status": "available", "reason_code": "MANUAL_PU", "unit_price": str(selection.pu),
                "unit": "BRL_PER_TITLE", "quality": selection.quality.value,
                "source": selection.provenance.source_ref if selection.provenance else "Entrada manual",
                "financial_date": financial_date.isoformat(), "annual_real_rate": None, "index": None,
                "provenance": _provenance_dict(selection.provenance) if selection.provenance else None,
                "rate_check": None if rate_check is None else {
                    "value": str(rate_check.annual_real_rate), "unit": "ratio",
                    "status": "not_evaluated", "reason_code": "RATE_INVERSION_NOT_AVAILABLE",
                },
            }
        if selection.mode is PriceMode.AUTO_LOCAL and rate is None:
            if price_source_error is not None or price_observations is None:
                return {"status": "needs_input", "reason_code": price_source_error or "SOURCE_VERSION_MISSING",
                        "unit_price": None, "missing_fields": ["source_versions.market_sim"]}
            order_date = date.fromisoformat(record["order_date"])
            observation_date = selection.observation_date if request_kind == "POINT" else order_date
            if request_kind == "POINT" and selection.observation_date != order_date:
                return {"status": "needs_input", "reason_code": "QUOTE_DATE_MISMATCH", "unit_price": None,
                        "missing_fields": ["entry_price.observation_date"]}
            quote = lookup_price_exact(
                price_observations, instrument_id=instrument.instrument_id,
                observation_date=observation_date,
                side=selection.quoted_side.value if selection.quoted_side else "BUY",
                as_of=normalized.knowledge.date if normalized.knowledge else None,
                mode=normalized.knowledge.mode if normalized.knowledge else EvidenceMode.CAUSAL,
            )
            if quote.get("status") != "available":
                status = "blocked_policy" if quote.get("status") == "blocked_policy" else "needs_input"
                return {"status": status, "reason_code": quote.get("reason_code"), "unit_price": None,
                        "missing_fields": [] if status == "blocked_policy" else ["market_data[exact_instrument_side_date]"]}
            if quote.get("family") != instrument.family.value or quote.get("maturity_date") != instrument.maturity_date.isoformat():
                return {"status": "blocked_policy", "reason_code": "INSTRUMENT_MISMATCH", "unit_price": None,
                        "missing_fields": []}
            quote_date = date.fromisoformat(quote["quote_settlement_date"]) if quote.get("quote_settlement_date") else None
            if quote_date != financial_date:
                return {"status": "needs_input", "reason_code": "QUOTE_SETTLEMENT_MISMATCH",
                        "message": "A cotação selecionada e o perfil de liquidação divergem; escolha uma cotação compatível ou informe taxa/PU hipotético recalculado para a data pretendida.",
                        "unit_price": None, "quote_settlement_date": quote_date.isoformat() if quote_date else None,
                        "calendar_settlement_date": financial_date.isoformat() if financial_date else None,
                        "missing_fields": ["entry_price.observation_date"]}
            return {
                "status": "available", "reason_code": quote.get("reason_code"),
                "unit_price": quote["value"], "unit": "BRL_PER_TITLE", "quality": "INFORMED",
                "source": f"Cotação local {observation_date.isoformat()} — {selection.quoted_side.value if selection.quoted_side else 'BUY'}",
                "financial_date": quote_date.isoformat(), "annual_real_rate": None, "index": None,
                "provenance": {
                    "version": selection.version_hash, "source_kind": "LOCAL_MARKET_CSV",
                    "instrument_id": quote.get("instrument_id"),
                    "observation_date": quote.get("observation_date"),
                    "quoted_side": quote.get("side"),
                    "next_market_date": quote.get("next_market_date"),
                    "evidence_status": quote.get("evidence_status"),
                    "evidence_note": quote.get("evidence_note"),
                },
            }
        if rate is None:
            return {"status": "needs_input", "reason_code": "MISSING_RATE", "unit_price": None,
                    "missing_fields": ["entry_price.annual_real_rate"]}
        if index_source_error is not None:
            return {"status": "needs_input", "reason_code": index_source_error, "unit_price": None,
                    "missing_fields": ["source_versions.market_sim_indexes"]}
        if projection_context is None or family_index is None:
            return {"status": "needs_input", "reason_code": "NO_EXACT_INDEX", "unit_price": None,
                    "missing_fields": [f"data.index_anchors[{('VNA' if instrument.family is ProductFamily.IPCA_PRINCIPAL else 'VNI')},{financial_date.isoformat()}]"]}
        index_calculation = next((
            item.to_dict() for item in projection_context.nominal_calculations
            if item.settlement_date == financial_date
        ), None)
        point = projection_points.get(financial_date)
        if point is None or point.status != "available":
            status = "blocked_policy" if point is not None and point.status == "blocked_policy" else "needs_input"
            reason = point.reason_code if point is not None else "NO_EXACT_INDEX"
            field = _index_pending_field(point, f"data.index_anchors[{family_index.value},{financial_date.isoformat()}]")
            return {"status": status, "reason_code": reason, "unit_price": None,
                    "index_calculation": index_calculation,
                    "missing_fields": [] if status == "blocked_policy" else [field]}
        anchor = anchors_by_date.get(financial_date)
        if anchor is None:
            return {"status": "needs_input", "reason_code": "NO_EXACT_INDEX", "unit_price": None,
                    "index_calculation": index_calculation,
                    "missing_fields": [f"data.index_anchors[{family_index.value},{financial_date.isoformat()}]"]}
        quality = (
            Quality.HYPOTHETICAL
            if normalized.intent is ScenarioIntent.HYPOTHETICAL or selection.quality is Quality.HYPOTHETICAL
            or anchor.quality is Quality.HYPOTHETICAL
            else Quality.ESTIMATED if selection.quality is Quality.ESTIMATED or anchor.quality is Quality.ESTIMATED
            else Quality.RECONSTRUCTED
        )
        if not include_unit_price:
            return {
                "status": "available", "reason_code": point.reason_code, "unit_price": None,
                "unit": "BRL_PER_TITLE", "quality": quality.value,
                "source": "Contexto resolvido para reprecificacao direta",
                "index_calculation": index_calculation,
                "financial_date": financial_date.isoformat(), "annual_real_rate": str(rate),
                "rate_provenance": _provenance_dict(selection.provenance) if selection.provenance else None,
                "index": {
                    "kind": family_index.value, "value": str(anchor.value),
                    "reference_date": anchor.reference_date.isoformat(),
                    "quality": anchor.quality.value, "source": anchor.source_ref,
                    "provenance": _provenance_dict(anchor.provenance) if anchor.provenance else None,
                },
                "hypotheses": ["intent HYPOTHETICAL"] if quality is Quality.HYPOTHETICAL else [],
            }
        from .service import price_indexed_security
        try:
            unit_price = price_indexed_security(instrument, calendar, anchor, financial_date, rate)
        except ValidationError as exc:
            return {"status": "blocked_policy", "reason_code": exc.code, "unit_price": None, "missing_fields": []}
        if unit_price is None:
            return {"status": "needs_input", "reason_code": "MISSING_INDEX", "unit_price": None,
                    "missing_fields": [f"data.index_anchors[{family_index.value},{financial_date.isoformat()}]"]}
        return {
            "status": "available", "reason_code": point.reason_code,
            "unit_price": str(unit_price), "unit": "BRL_PER_TITLE", "quality": quality.value,
            "source": "Preço reconstruído pelo motor com taxa e VNA/VNI compatível",
            "index_calculation": index_calculation,
            "financial_date": financial_date.isoformat(), "annual_real_rate": str(rate),
            "rate_provenance": _provenance_dict(selection.provenance) if selection.provenance else None,
            "index": {
                "kind": family_index.value, "value": str(anchor.value),
                "reference_date": anchor.reference_date.isoformat(),
                "quality": anchor.quality.value, "source": anchor.source_ref,
                "provenance": _provenance_dict(anchor.provenance) if anchor.provenance else None,
            },
            "hypotheses": ["intent HYPOTHETICAL"] if quality is Quality.HYPOTHETICAL else [],
        }

    reference_record = date_record(normalized.requested_date) if normalized.requested_date is not None else None
    reference_rate = selection.annual_real_rate if selection is not None else None
    if request_kind == "RATE_CURVE":
        if reference_record is None:
            reference_price = None
        elif selection is not None and selection.mode is PriceMode.MANUAL_PU:
            if selection.evidence_status in (
                EvidenceStatus.PUBLISHED_AFTER_AS_OF,
                EvidenceStatus.PUBLICATION_DATE_UNKNOWN,
                EvidenceStatus.OBSERVATION_AFTER_AS_OF,
            ):
                reference_price = {"status": "blocked_policy", "unit_price": None}
            else:
                reference_price = {
                    "status": "available", "unit_price": str(selection.pu), "unit": "BRL_PER_TITLE",
                    "quality": selection.quality.value, "financial_date": reference_record.get("financial_date"),
                    "source": selection.provenance.source_ref if selection.provenance else "Entrada manual",
                    "provenance": _provenance_dict(selection.provenance) if selection.provenance else None,
                }
        else:
            reference_price = priced_value(reference_record, reference_rate)
    elif request_kind == "DATE_CURVE" and reference_record is not None and selection is not None and selection.mode is PriceMode.MANUAL_PU:
        if selection.evidence_status in (
            EvidenceStatus.PUBLISHED_AFTER_AS_OF,
            EvidenceStatus.PUBLICATION_DATE_UNKNOWN,
            EvidenceStatus.OBSERVATION_AFTER_AS_OF,
        ):
            reference_price = {"status": "blocked_policy", "unit_price": None}
        else:
            reference_price = {
                "status": "available", "unit_price": str(selection.pu), "unit": "BRL_PER_TITLE",
                "quality": selection.quality.value, "financial_date": reference_record.get("financial_date"),
                "source": selection.provenance.source_ref if selection.provenance else "Entrada manual",
                "provenance": _provenance_dict(selection.provenance) if selection.provenance else None,
            }
    elif request_kind == "DATE_CURVE" and reference_record is not None:
        reference_price = priced_value(reference_record, reference_rate)
    else:
        reference_price = None

    reference_value = None
    if isinstance(reference_price, Mapping) and reference_price.get("status") == "available":
        try:
            reference_value = Decimal(reference_price["unit_price"])
        except (InvalidOperation, TypeError, KeyError):
            reference_value = None

    points: list[dict[str, Any]] = []
    if request_kind == "POINT":
        point = priced_value(records[0], reference_rate) if records else {
            "status": "needs_input", "reason_code": "MISSING_DATE", "unit_price": None,
            "missing_fields": ["purchase_date"],
        }
        if records and point.get("financial_date") is None and records[0].get("financial_date"):
            point["financial_date"] = records[0]["financial_date"]
        unit = {
            "status": point["status"], "value": point.get("unit_price"),
            "unit": point.get("unit", "BRL_PER_TITLE"), "quality": point.get("quality"),
            "reason_code": point.get("reason_code"),
            "source": point.get("source"), "requested_date": normalized.requested_date.isoformat() if normalized.requested_date else None,
            "financial_date": point.get("financial_date"), "annual_real_rate": point.get("annual_real_rate"),
            "index": point.get("index"), "index_calculation": point.get("index_calculation"), "provenance": point.get("provenance"),
            "rate_provenance": point.get("rate_provenance"), "rate_check": point.get("rate_check"),
        }
        points.append({"requested_date": unit["requested_date"], "financial_date": unit["financial_date"],
                       "unit_price": unit["value"], "unit": unit["unit"], "status": unit["status"],
                       "quality": unit["quality"], "reason_code": point.get("reason_code")})
        result_status = "ready" if point["status"] == "available" and not missing else "partial"
        coverage = {"requested_points": 1, "priced_points": 1 if point["status"] == "available" else 0,
                    "blocked_points": 1 if point["status"] == "blocked_policy" else 0, "domain": None}
    else:
        if request_kind == "DATE_CURVE":
            curve_rates = [reference_rate] * len(records)
        else:
            raw_domain = query["rate_domain"]
            minimum, maximum, step = raw_domain["minimum"], raw_domain["maximum"], raw_domain["step"]
            count = int((maximum - minimum) / step)
            curve_rates = [minimum + step * index for index in range(count + 1)]
            records = records[:1] * len(curve_rates)
        for index, record in enumerate(records):
            rate = curve_rates[index] if index < len(curve_rates) else None
            point = priced_value(record, rate, gate_price_evidence=request_kind != "RATE_CURVE")
            unit_price = point.get("unit_price")
            ratio = None
            if unit_price is not None and reference_value is not None and reference_value > 0:
                ratio = str(Decimal(unit_price) / reference_value - Decimal(1))
            row = {
                "requested_date": record.get("requested_date"), "order_date": record.get("order_date"),
                "financial_date": point.get("financial_date", record.get("financial_date")),
                "unit_price": unit_price, "unit": "BRL_PER_TITLE", "status": point["status"],
                "quality": point.get("quality"), "reason_code": point.get("reason_code"),
                "price_change_ratio": ratio,
                "source": point.get("source"), "provenance": point.get("provenance"),
                "rate_provenance": point.get("rate_provenance"), "index": point.get("index"), "index_calculation": point.get("index_calculation"),
                "missing_fields": list(point.get("missing_fields", ())),
            }
            if request_kind == "RATE_CURVE":
                row["annual_real_rate"] = str(rate) if rate is not None else None
                if unit_price is not None:
                    row["quality"] = Quality.HYPOTHETICAL.value
            points.append(row)
        priced_count = sum(item["unit_price"] is not None for item in points)
        blocked_count = sum(item["status"] == "blocked_policy" for item in points)
        result_status = "ready" if points and priced_count == len(points) and not missing else "partial"
        if not points:
            missing.append("analysis_context.timeline.eligible_dates")
        coverage = {
            "requested_points": len(points), "priced_points": priced_count,
            "blocked_points": blocked_count,
            "reason": "NO_SESSION_IN_WINDOW" if request_kind == "DATE_CURVE" and not points else None,
            "domain": domain if request_kind == "DATE_CURVE" else {
                "minimum": str(query["rate_domain"]["minimum"]),
                "maximum": str(query["rate_domain"]["maximum"]),
                "step": str(query["rate_domain"]["step"]),
            },
        }
        unit = None

    if request_kind == "POINT":
        missing.extend(point.get("missing_fields", []))
    else:
        for item in points:
            if item["status"] == "needs_input":
                missing.extend(item.get("missing_fields", ()))
                if item.get("reason_code") == "MISSING_RATE":
                    missing.append("entry_price.annual_real_rate")
                elif item.get("reason_code") == "MISSING_PROJECTION":
                    missing.append("assumptions.inflation_projection")
                elif item.get("reason_code") in ("NO_EXACT_INDEX", "NO_PRIOR_ANCHOR"):
                    missing.append("data.index_anchors[matching_kind_and_financial_date]")
    if result_status == "ready":
        capability_status = "available"
    elif request_kind == "POINT" and points and points[0]["status"] == "blocked_policy":
        capability_status = "blocked_policy"
    elif points and all(item["status"] == "blocked_policy" for item in points):
        capability_status = "blocked_policy"
    else:
        capability_status = "needs_input"
    return {
        "status": result_status,
        "query": _thaw_json(query),
        "instrument": None if instrument is None else {
            "family": instrument.family.value, "instrument_id": instrument.instrument_id,
            "maturity_date": instrument.maturity_date.isoformat(),
            "conversion_date": instrument.conversion_date.isoformat() if instrument.conversion_date else None,
            "first_income_date": instrument.first_income_date.isoformat() if instrument.first_income_date else None,
        },
        "unit_price": unit,
        "reference_price": None if reference_price is None else {
            "value": reference_price.get("unit_price"), "unit": "BRL_PER_TITLE",
            "status": reference_price.get("status"), "quality": reference_price.get("quality"),
            "reason_code": reference_price.get("reason_code"),
            "financial_date": reference_price.get("financial_date"), "source": reference_price.get("source"),
            "provenance": reference_price.get("provenance"),
            "rate_provenance": reference_price.get("rate_provenance"),
            "index": reference_price.get("index"),
            "index_calculation": reference_price.get("index_calculation"),
        },
        "points": points,
        "presentation_summary": _unit_price_presentation_summary(result_status, unit, reference_price),
        "assumptions_summary": _unit_price_assumptions_summary(normalized, unit, reference_price),
        "coverage": coverage,
        "capabilities": {"unit_price": {
            "status": capability_status,
            "reason": None if capability_status == "available" else {
                "code": "UNIT_PRICE_INCOMPLETE", "message": "PU unitário aguarda uma data, taxa e evidência compatíveis.",
            },
            "missing_fields": list(dict.fromkeys(missing)),
        }},
        "hypotheses": ["PU unitário não representa resultado patrimonial de uma operação."],
        "source_versions": {**dict(normalized.source_versions),
            **_monthly_ipca_source_identity(_monthly_ipca_inputs(normalized.data, index_observations))},
    }


def evaluate_workspace_gross_dv01(
    payload: object,
    resolution: Mapping[str, Any] | None,
    calendar: Any,
    selection: PriceSelection | None = None,
    *,
    quantity: Decimal | str | None = None,
) -> dict[str, Any]:
    """Evaluate gross DV01 from a price-free, resolved UNIT_PRICE context."""
    from .service import GROSS_DV01_METHOD_VERSION, IndexAnchor, IndexKind, evaluate_gross_dv01

    def unavailable(reason_code: str, *, status: str = "needs_input", extra: Mapping[str, Any] | None = None) -> dict[str, Any]:
        result = {
            "metric": "GROSS_DV01", "method": GROSS_DV01_METHOD_VERSION,
            "status": status, "reason_code": reason_code,
            "instrument": None, "financial_date": None, "nominal": None,
            "base_rate": None, "shocked_rate": None,
            "shock": {"rate_delta": "0.0001", "basis_points": "1", "unit": "ratio"},
            "pu_base": None, "pu_shocked": None, "pu_unit": "BRL_PER_TITLE",
            "signed_unit_delta": None, "reduction_if_yield_up": None,
            "quantity": None, "quantity_unit": "TITLE", "position_base": None,
            "position_unit": "BRL", "position_shocked": None, "gross_position_delta": None,
            "quality": None, "source_versions": {},
            "is_gross": True, "is_analytic_approximation": False,
            "is_net_of_costs_or_taxes": False, "costs_and_taxes_included": False,
        }
        if extra:
            result.update(extra)
        return result

    if calendar is None:
        return unavailable("MISSING_CALENDAR")
    try:
        normalized = normalize_unit_price_input(payload)
    except ValidationError as exc:
        return unavailable(exc.code)
    selected = selection if selection is not None else normalized.entry_price
    if selected is None or selected.mode is not PriceMode.MANUAL_RATE or selected.annual_real_rate is None:
        rate_check = getattr(selected, "rate_check", None)
        return unavailable(
            "APPLIED_RATE_REQUIRED",
            extra={
                "rate_check": None if rate_check is None else {
                    "annual_real_rate": str(rate_check.annual_real_rate) if rate_check.annual_real_rate is not None else None,
                    "status": "not_applied", "reason_code": "RATE_CHECK_IS_NOT_APPLIED",
                },
                "rate_provenance": None if selected is None or selected.provenance is None else _provenance_dict(selected.provenance),
            },
        )
    if not isinstance(resolution, Mapping):
        return unavailable("MISSING_RESOLUTION")
    query = resolution.get("query")
    if not isinstance(query, Mapping) or query.get("kind") != "POINT":
        return unavailable("MISSING_FINANCIAL_DATE")
    unit_context = resolution.get("unit_price")
    if not isinstance(unit_context, Mapping):
        return unavailable("MISSING_FINANCIAL_DATE")
    if unit_context.get("status") != "available":
        return unavailable(str(unit_context.get("reason_code") or "PRICE_CONDITION_INELIGIBLE"), status=str(unit_context.get("status") or "needs_input"))
    # The resolver may omit value when include_unit_price=False; its POINT
    # context still carries the applied rate, date, and index for direct repricing.
    financial_date_raw = unit_context.get("financial_date")
    try:
        financial_date = date.fromisoformat(str(financial_date_raw))
    except (TypeError, ValueError):
        return unavailable("MISSING_FINANCIAL_DATE")
    if normalized.instrument is None:
        return unavailable("MISSING_INSTRUMENT")
    try:
        resolved_rate = Decimal(str(unit_context.get("annual_real_rate")))
    except InvalidOperation:
        return unavailable("APPLIED_RATE_RESOLUTION_MISMATCH")
    if selected.annual_real_rate != resolved_rate:
        return unavailable("APPLIED_RATE_RESOLUTION_MISMATCH")
    raw_index = unit_context.get("index")
    if not isinstance(raw_index, Mapping):
        return unavailable(str(unit_context.get("reason_code") or "NO_EXACT_INDEX"), status="needs_input")
    try:
        index_provenance = _parse_provenance(raw_index.get("provenance"), "resolution.index.provenance")
        anchor = IndexAnchor(
            IndexKind(str(raw_index["kind"])), Decimal(str(raw_index["value"])),
            date.fromisoformat(str(raw_index["reference_date"])),
            Quality(str(raw_index["quality"])), str(raw_index["source"]), index_provenance,
        )
    except (KeyError, TypeError, ValueError, ValidationError):
        return unavailable("INVALID_INDEX_ANCHOR")
    try:
        if quantity is not None:
            try:
                quantity_value = Decimal(str(quantity))
            except InvalidOperation:
                return unavailable("INVALID_QUANTITY")
            if not quantity_value.is_finite() or quantity_value <= 0 or quantity_value % Decimal("0.01") != 0:
                return unavailable("INVALID_QUANTITY")
        else:
            quantity_value = None
        result = evaluate_gross_dv01(
            normalized.instrument, calendar, anchor, financial_date,
            selected.annual_real_rate, quantity_value,
        )
    except ValidationError as exc:
        status = "blocked_policy" if exc.code in {"OUTSIDE_HORIZON", "INDEX_DATE_OR_KIND_MISMATCH"} else "needs_input"
        return unavailable(exc.code, status=status)
    result.update({
        "rate_provenance": _provenance_dict(selected.provenance) if selected.provenance else None,
        "source_versions": dict(resolution.get("source_versions") or {}),
        "quality": unit_context.get("quality") or anchor.quality.value,
        "hypotheses": list(unit_context.get("hypotheses") or []),
        "provenance": {
            "applied_rate": _provenance_dict(selected.provenance) if selected.provenance else None,
            "nominal": result.get("nominal", {}).get("provenance"),
            "price_profile": result.get("price_profile"),
        },
    })
    return result


def prepare_workspace_defaults(payload: object) -> object:
    """Apply the contract's visible D+1/D+1 experience default at the adapter edge."""
    if not isinstance(payload, Mapping):
        return payload
    prepared = dict(payload)
    raw_assumptions = prepared.get("assumptions")
    if raw_assumptions is None:
        prepared["assumptions"] = {"settlement_profile": "SIMULATED_BUY_D1_SELL_D1"}
    elif isinstance(raw_assumptions, Mapping) and "settlement_profile" not in raw_assumptions:
        prepared_assumptions = dict(raw_assumptions)
        prepared_assumptions["settlement_profile"] = "SIMULATED_BUY_D1_SELL_D1"
        prepared["assumptions"] = prepared_assumptions
    return prepared


def prepare_workspace_stress_base(payload: object) -> tuple[dict[str, Any], tuple[str, ...]]:
    """Copy a base input and remove point-specific overrides from stress testing."""
    if not isinstance(payload, Mapping):
        raise ValidationError("INVALID_INPUT", "STRESS exige input de workspace.")
    base = prepare_workspace_defaults(deepcopy(dict(payload)))
    if not isinstance(base, dict):
        raise ValidationError("INVALID_INPUT", "Input de estresse inválido.")
    assumptions = base.get("assumptions")
    if not isinstance(assumptions, Mapping):
        return base, ()
    assumptions = dict(assumptions)
    excluded = []
    for field in ("custody_override_brl", "institution_net_brl", "institution_release_date"):
        if assumptions.get(field) is not None:
            assumptions.pop(field)
            excluded.append(field)
    base["assumptions"] = assumptions
    return base, tuple(excluded)


def apply_workspace_stress(payload: object, shock: Mapping[str, Any]) -> dict[str, Any]:
    """Build one independent hypothetical input by applying declared deltas."""
    if not isinstance(shock, Mapping) or not isinstance(shock.get("id"), str):
        raise ValidationError("INVALID_STRESS_SCENARIO", "Choque precisa ter ID nomeado.")
    result, _ = prepare_workspace_stress_base(payload)
    assumptions = dict(result.get("assumptions") or {})
    result["assumptions"] = assumptions
    rate_delta = _stress_decimal(shock.get("rate_shock_ratio", 0), "rate_shock_ratio")
    inflation_delta = _stress_decimal(shock.get("annual_inflation_ratio", 0), "annual_inflation_ratio")
    entry_delta = _stress_decimal(shock.get("entry_expense_delta_brl", 0), "entry_expense_delta_brl")
    exit_delta = _stress_decimal(shock.get("exit_expense_delta_brl", 0), "exit_expense_delta_brl")
    changed = any(value != 0 for value in (rate_delta, inflation_delta, entry_delta, exit_delta))
    if not changed:
        return result
    result["intent"] = "HYPOTHETICAL"

    if rate_delta != 0:
        exit_price = result.get("exit_price")
        if not isinstance(exit_price, Mapping):
            raise ValidationError("STRESS_RATE_NOT_APPLICABLE", "A taxa de saída não está resolvida na entrada-base.")
        mode = exit_price.get("mode")
        if mode == "MANUAL_RATE":
            rate_source = exit_price.get("annual_real_rate")
            stressed_exit = dict(exit_price)
        elif mode == "SAME_ENTRY_RATE":
            entry_price = result.get("entry_price")
            rate_source = entry_price.get("annual_real_rate") if isinstance(entry_price, Mapping) else None
            if rate_source is None and isinstance(entry_price, Mapping):
                rate_check = entry_price.get("rate_check")
                rate_source = rate_check.get("annual_real_rate") if isinstance(rate_check, Mapping) else None
            stressed_exit = {"mode": "MANUAL_RATE", "quoted_side": "SELL"}
        else:
            raise ValidationError(
                "STRESS_RATE_NOT_APPLICABLE",
                "Choque de taxa só pode alterar uma taxa de saída MANUAL_RATE ou SAME_ENTRY_RATE.",
            )
        if rate_source is None:
            raise ValidationError("STRESS_BASE_RATE_MISSING", "A taxa de saída-base não está disponível para aplicar o choque.")
        base_rate = _stress_decimal(rate_source, "exit_price.annual_real_rate")
        stressed_rate = base_rate + rate_delta
        if stressed_rate <= -1:
            raise ValidationError("INVALID_STRESS_ASSUMPTION", "O choque levaria a taxa de saída a −100% ou menos.")
        stressed_exit["annual_real_rate"] = str(stressed_rate)
        stressed_exit.pop("provenance", None)
        result["exit_price"] = stressed_exit

    if inflation_delta != 0:
        projection = assumptions.get("inflation_projection")
        if not isinstance(projection, Mapping):
            raise ValidationError("STRESS_BASE_INFLATION_MISSING", "Choque de inflação exige uma projeção-base explícita.")
        stressed_projection = dict(projection)
        base_rate = _stress_decimal(projection.get("annual_rate"), "inflation_projection.annual_rate")
        stressed_rate = base_rate + inflation_delta
        if stressed_rate <= -1:
            raise ValidationError("INVALID_STRESS_ASSUMPTION", "O choque levaria a inflação anual a −100% ou menos.")
        source_ref = projection.get("source_ref")
        if not isinstance(source_ref, str):
            raise ValidationError("STRESS_BASE_INFLATION_MISSING", "A projeção-base precisa identificar sua origem.")
        stressed_projection["annual_rate"] = str(stressed_rate)
        if projection.get("mode") == "INTERPOLATED_ANNUAL":
            end_rate = _stress_decimal(projection.get("end_annual_rate"), "inflation_projection.end_annual_rate") + inflation_delta
            if end_rate <= -1:
                raise ValidationError("INVALID_STRESS_ASSUMPTION", "O choque levaria a inflação anual final a −100% ou menos.")
            stressed_projection["end_annual_rate"] = str(end_rate)
        stressed_projection["source_ref"] = f"{source_ref}; estresse {shock['id']}"
        assumptions["inflation_projection"] = stressed_projection

    if entry_delta != 0:
        fee = assumptions.get("entry_fee")
        if not isinstance(fee, Mapping) or fee.get("fixed_brl") is None:
            raise ValidationError("STRESS_BASE_COST_MISSING", "Choque de despesa de entrada exige custo fixo-base explícito.")
        stressed_fee = dict(fee)
        fixed = _stress_decimal(fee["fixed_brl"], "entry_fee.fixed_brl") + entry_delta
        if fixed < 0:
            raise ValidationError("INVALID_STRESS_ASSUMPTION", "O choque não pode tornar negativa a despesa fixa de entrada.")
        stressed_fee["fixed_brl"] = str(fixed)
        assumptions["entry_fee"] = stressed_fee

    if exit_delta != 0:
        if assumptions.get("exit_fee_brl") is None:
            raise ValidationError("STRESS_BASE_COST_MISSING", "Choque de despesa de saída exige custo-base explícito.")
        exit_fee = _stress_decimal(assumptions["exit_fee_brl"], "exit_fee_brl") + exit_delta
        if exit_fee < 0:
            raise ValidationError("INVALID_STRESS_ASSUMPTION", "O choque não pode tornar negativa a despesa de saída.")
        assumptions["exit_fee_brl"] = str(exit_fee)
    return result


def _stress_decimal(value: object, name: str) -> Decimal:
    try:
        result = Decimal(str(value))
    except (InvalidOperation, TypeError, ValueError) as exc:
        raise ValidationError("INVALID_STRESS_ASSUMPTION", f"{name} precisa ser decimal finito.") from exc
    if not result.is_finite():
        raise ValidationError("INVALID_STRESS_ASSUMPTION", f"{name} precisa ser decimal finito.")
    return result


_WORKSPACE_BLOCKING_CAPABILITIES = frozenset({
    "input_resolution", "date_resolution", "price_resolution",
    "nominal_evaluation", "purchase_sizing",
})


def _workspace_pending_items(resolution: Mapping[str, Any]) -> list[dict[str, Any]]:
    """Describe unresolved workspace capabilities without inventing a fallback."""
    normalized = resolution.get("normalized_input", {})
    capabilities = resolution.get("capabilities", {})
    dates = resolution.get("dates") or {}
    index_rows = resolution.get("resolved_index_anchors", [])
    price_rows = resolution.get("resolved_prices", {})
    issues: dict[str, dict[str, Any]] = {}
    represented_capabilities: set[str] = set()

    def add(
        capability_id: str,
        field_path: str,
        reason_code: str | None,
        *,
        status: str = "needs_input",
        side: str | None = None,
        relevant_date: str | None = None,
        source_ref: str | None = None,
        order_date: str | None = None,
        settlement_date: str | None = None,
    ) -> None:
        code = reason_code or "MISSING_FIELD"
        key = field_path
        item = issues.get(key)
        if item is None:
            item = {
                "id": field_path,
                "capability_ids": [],
                "severity": "ADVISORY",
                "field_path": field_path,
                "reason_code": code,
                "reason_codes": [],
                "status": status,
                "side_names": [],
                "relevant_dates": [],
                "order_dates": [],
                "settlement_dates": [],
                "source_refs": [],
                "title": "Dados necessários",
                "message": "Complete a informação indicada para liberar esta saída.",
                "alternatives": [],
            }
            issues[key] = item
        if code not in item["reason_codes"]:
            item["reason_codes"].append(code)
        if status == "blocked_policy" and item["status"] != "blocked_policy":
            item["reason_code"] = code
        if capability_id not in item["capability_ids"]:
            item["capability_ids"].append(capability_id)
        if capability_id in _WORKSPACE_BLOCKING_CAPABILITIES:
            item["severity"] = "BLOCKING"
        if status == "blocked_policy":
            item["status"] = "blocked_policy"
        if side in ("purchase", "sale") and side not in item["side_names"]:
            item["side_names"].append(side)
        if relevant_date and relevant_date not in item["relevant_dates"]:
            item["relevant_dates"].append(relevant_date)
        if order_date and order_date not in item["order_dates"]:
            item["order_dates"].append(order_date)
        if settlement_date and settlement_date not in item["settlement_dates"]:
            item["settlement_dates"].append(settlement_date)
        if source_ref and source_ref not in item["source_refs"]:
            item["source_refs"].append(source_ref)
        if capability_id in _WORKSPACE_BLOCKING_CAPABILITIES:
            represented_capabilities.add(capability_id)

    # Keep index gaps tied to the exact financial settlement and side. A nearby
    # observation is never substituted for a missing date.
    for row in index_rows if isinstance(index_rows, list) else ():
        if not isinstance(row, Mapping) or row.get("status") == "available":
            continue
        side = "purchase" if row.get("for") == "entry_price" else "sale"
        selection = normalized.get(row.get("for"), {})
        capability_id = (
            "price_resolution"
            if selection.get("mode") in ("MANUAL_RATE", "SAME_ENTRY_RATE")
            else "rate_check"
        )
        kind = row.get("kind")
        reference_date = row.get("reference_date")
        if row.get("reason_code") == "MISSING_PROJECTION":
            field_path = "assumptions.inflation_projection"
        elif row.get('profile_id') == 'TD_CALENDAR_15_IPCA_RATIO_v1':
            field_path = 'data.ipca_monthly_indexes'
        elif kind and reference_date:
            field_path = f"data.index_anchors[{kind},{reference_date}]"
        else:
            field_path = "data.index_anchors[matching_kind_and_settlement]"
        add(
            capability_id, field_path, row.get("reason_code"),
            status=row.get("status", "needs_input"), side=side,
            relevant_date=reference_date,
            source_ref=row.get("source_ref"),
        )

    # Preserve the product horizon as a field-specific blocking item. A date
    # outside the supported title life is not a missing quote or a retryable
    # pricing input.
    for side_name, row in dates.items() if isinstance(dates, Mapping) else ():
        if not isinstance(row, Mapping):
            continue
        reason = row.get("reason") if isinstance(row.get("reason"), Mapping) else {}
        if reason.get("code") == "OUTSIDE_HORIZON":
            side = "purchase" if side_name == "purchase" else "sale"
            add(
                "date_resolution", f"{side}_date", "OUTSIDE_HORIZON",
                status="blocked_policy", side=side,
                relevant_date=row.get("proposed_order_date") or row.get("settlement_date"),
            )

    # A date-resolution failure can exist without a missing input field (for
    # example, a settlement outside the supported calendar or title horizon).
    for side in ("purchase", "sale"):
        row = dates.get(side) if isinstance(dates, Mapping) else None
        if not isinstance(row, Mapping) or row.get("status") == "available":
            continue
        reason = row.get("reason") if isinstance(row.get("reason"), Mapping) else {}
        event_coverage = row.get("event_coverage") if isinstance(row.get("event_coverage"), Mapping) else {}
        requested_order_date = row.get("proposed_order_date") or row.get("requested_date")
        settlement_date = row.get("settlement_date")
        if reason.get("code") or row.get("confirmation_required"):
            field_path = f"dates.{side}.confirmation" if row.get("confirmation_required") else f"{side}_date"
            add(
                "date_resolution", field_path, reason.get("code"),
                status=row.get("status", "needs_input"), side=side,
                relevant_date=settlement_date or requested_order_date,
                source_ref=row.get("source_ref"),
                order_date=requested_order_date,
                settlement_date=settlement_date,
            )
        if event_coverage.get("reason_code") == "EVENT_COVERAGE_UNCERTIFIED":
            event_order_date = event_coverage.get("order_date") or requested_order_date
            add(
                "date_resolution", f"dates.{side}.event_coverage",
                event_coverage.get("reason_code"), status="uncertified", side=side,
                relevant_date=event_order_date,
                source_ref=event_coverage.get("source_ref") or row.get("source_ref"),
                order_date=event_order_date,
                settlement_date=settlement_date,
            )

    # Local quote failures retain their side and observation date, including
    # policy blocks that intentionally have no editable missing_fields list.
    for side_key, row in price_rows.items() if isinstance(price_rows, Mapping) else ():
        if not isinstance(row, Mapping) or row.get("status") == "available":
            continue
        side = "purchase" if side_key == "entry_price" else "sale"
        row_fields = row.get("missing_fields") or []
        field_path = row_fields[0] if row_fields else f"{side_key}.mode"
        date_value = row.get("observation_date")
        if not date_value:
            date_value = (dates.get(side) or {}).get("settlement_date") if isinstance(dates, Mapping) else None
        add(
            "price_resolution", field_path, row.get("reason_code"),
            status=row.get("status", "needs_input"), side=side,
            relevant_date=date_value, source_ref=row.get("source_ref"),
        )

    for capability_id, capability in capabilities.items() if isinstance(capabilities, Mapping) else ():
        if not isinstance(capability, Mapping) or capability.get("status") == "available":
            continue
        reason = capability.get("reason") if isinstance(capability.get("reason"), Mapping) else {}
        fields = capability.get("missing_fields") or []
        if fields:
            for field_path in fields:
                # Exact anchor rows above carry side/date information and will
                # merge here by the same canonical field path and reason.
                if field_path.startswith("data.index_anchors["):
                    matching = next((row for row in index_rows if isinstance(row, Mapping)
                                     and (field_path.endswith(row.get("reference_date", ""))
                                          or field_path == "data.index_anchors[matching_kind_and_settlement]")), None)
                    if matching is not None:
                        continue
                side = "purchase" if ".purchase" in field_path or field_path.startswith("purchase") else (
                    "sale" if ".sale" in field_path or field_path.startswith("sale") else None
                )
                add(
                    capability_id, field_path, reason.get("code"),
                    status=capability.get("status", "needs_input"), side=side,
                )
        elif capability_id not in represented_capabilities:
            related = [item for item in issues.values()
                       if item["reason_code"] == (reason.get("code") or "MISSING_FIELD")]
            if len(related) == 1:
                add(
                    capability_id, related[0]["field_path"], reason.get("code"),
                    status=capability.get("status", "needs_input"),
                )
            else:
                add(
                    capability_id, f"capability.{capability_id}", reason.get("code"),
                    status=capability.get("status", "needs_input"),
                )

    def display(item: dict[str, Any]) -> None:
        field_path = item["field_path"]
        code = item["reason_code"]
        side = item["side_names"][0] if item["side_names"] else None
        date_value = item["relevant_dates"][0] if item["relevant_dates"] else None
        date_label = date.fromisoformat(date_value).strftime("%d/%m/%Y") if date_value else None
        side_label = "compra" if side == "purchase" else "venda" if side == "sale" else "operação"
        if code == "QUOTE_SETTLEMENT_MISMATCH":
            price_field = "entry_price" if side == "purchase" else "exit_price"
            quote = price_rows.get(price_field, {})
            item["title"] = "Cota\u00e7\u00e3o incompat\u00edvel com a liquida\u00e7\u00e3o selecionada"
            item["message"] = quote.get("message") or "Selecione uma cota\u00e7\u00e3o compat\u00edvel ou informe taxa/PU hipot\u00e9tico recalculado para a data pretendida."
            item["alternatives"] = [
                {"label": f"Selecionar cota\u00e7\u00e3o compat\u00edvel para {side_label}", "target_field": f"{price_field}.observation_date"},
                {"label": f"Reprecificar {side_label} como hip\u00f3tese", "target_field": f"{price_field}.mode"},
            ]
        elif field_path == 'data.ipca_monthly_indexes':
            item['title'] = 'IPCA mensal necessário ao cálculo automático'
            item['message'] = 'A série local não cobre um mês necessário, ou não estava disponível no corte escolhido. Atualize o cache IPCA ou confira o corte. VNA/VNI será calculado; nenhum índice foi inventado.'
            item['alternatives'] = [{'label': 'Abrir dados para atualizar o IPCA mensal', 'target_field': 'source_versions'}]
        elif field_path.startswith("data.index_anchors["):
            match = re.match(r"data\.index_anchors\[([^,\]]+),?([^\]]*)\]", field_path)
            kind = match.group(1) if match else "VNA/VNI"
            date_label = date_label or (date.fromisoformat(match.group(2)).strftime("%d/%m/%Y") if match and match.group(2) else None)
            item["title"] = f"{kind} exato da liquidação de {side_label} indisponível"
            if item["status"] == "blocked_policy":
                item["message"] = f"O {kind} de {date_label or 'data não resolvida'} não pode ser usado no corte de conhecimento escolhido. Verifique a publicação e a proveniência; o simulador não trocará por outra data."
            else:
                item["message"] = f"Falta o {kind} exato da liquidação de {side_label} ({date_label or 'data não resolvida'}). Um valor de outra data não será usado automaticamente."
            alternatives = [{"label": f"Informar {kind} de {side_label} e sua fonte", "target_field": "data.index_anchors"}]
            if side:
                price_side = "entry_price.pu" if side == "purchase" else "exit_price.pu"
                alternatives.append({"label": f"Informar o PU de {side_label}", "target_field": price_side})
            item["alternatives"] = alternatives
        elif field_path == "assumptions.inflation_projection":
            item["title"] = "Projeção necessária para precificar pela taxa"
            dates_text = ", ".join(date.fromisoformat(value).strftime("%d/%m/%Y") for value in item["relevant_dates"])
            item["message"] = "O motor calcula VNA/VNI pelo IPCA local. Meses ainda não divulgados exigem uma hipótese explícita de inflação. " + (f"Datas afetadas: {dates_text}." if dates_text else "")
            item["alternatives"] = [
                {"label": "Informar a hipótese de inflação para meses não divulgados", "target_field": "assumptions.inflation_projection"},
            ]
            for pending_side in item["side_names"] or ([side] if side else []):
                item["alternatives"].append({
                    "label": f"Informar PU de {'compra' if pending_side == 'purchase' else 'venda'}",
                    "target_field": "entry_price.pu" if pending_side == "purchase" else "exit_price.pu",
                })
        elif field_path.startswith("source_versions."):
            item["title"] = "Versão local da fonte não disponível"
            item["message"] = "A versão local selecionada não está disponível ou não cobre esta observação. Confira a fonte e o corte escolhidos; nenhuma versão ativa será substituída silenciosamente."
            item["alternatives"] = [
                {"label": "Abrir Dados e backups para escolher uma versão", "target_field": "source_versions"},
            ]
            for pending_side in item["side_names"] or ([side] if side else []):
                item["alternatives"].append({
                    "label": f"Informar PU de {'compra' if pending_side == 'purchase' else 'venda'}",
                    "target_field": "entry_price.pu" if pending_side == "purchase" else "exit_price.pu",
                })
        elif field_path.startswith("data.price_index_levels["):
            item["title"] = "Nível de índice de preços ausente"
            item["message"] = f"O retorno real depende de um nível do índice de preços em {date_label or 'cada data do fluxo'}. O resultado nominal pode continuar disponível."
            item["alternatives"] = [{"label": "Adicionar nível do índice nesta data e sua fonte", "target_field": "data.price_index_levels"}]
        elif code == "EVENT_COVERAGE_UNCERTIFIED":
            sale = dates.get("sale") if isinstance(dates, Mapping) else None
            sale = sale if isinstance(sale, Mapping) else {}
            coverage = sale.get("event_coverage") if isinstance(sale.get("event_coverage"), Mapping) else {}
            product_label = (
                "IPCA+ Principal" if coverage.get("family") == "IPCA_PRINCIPAL"
                else "RendA+" if coverage.get("family") == "RENDA_PLUS"
                else "este título"
            )
            event_date = coverage.get("event_date")
            event_label = (
                date.fromisoformat(event_date).strftime("%d/%m/%Y")
                if isinstance(event_date, str) else "data do evento não resolvida"
            )
            coverage_reason = coverage.get("reason") or (
                "O alcance da regra de suspensão por evento para esta família não está resolvido."
            )
            item["title"] = "Cobertura do evento sem certificação"
            item["message"] = (
                f"{coverage_reason} A venda de {product_label} em {date_label or 'data não resolvida'} "
                f"está dentro da janela T-1/T-2 do evento de {event_label}. "
                "Isso não confirma suspensão. Para usar um ponto com cobertura certificável, "
                "revise a venda para fora dessa janela ou consulte o localizador da seção 9 nos detalhes; "
                "a vigência e a aplicação por família ainda não foram comprovadas."
            )
            item["alternatives"] = [{
                "label": "Rever data da venda fora da janela do evento",
                "target_field": "sale_date",
            }]
        elif field_path == "sale_date" and code == "LOCKED":
            sale = dates.get("sale") if isinstance(dates, Mapping) else None
            sale = sale if isinstance(sale, Mapping) else {}
            requested = sale.get("proposed_order_date") or sale.get("requested_date")
            first_eligible = sale.get("minimum_eligible_order_date")
            requested_label = date.fromisoformat(requested).strftime("%d/%m/%Y") if isinstance(requested, str) else None
            first_eligible_label = date.fromisoformat(first_eligible).strftime("%d/%m/%Y") if isinstance(first_eligible, str) else None
            item["title"] = "Venda dentro da carência do produto"
            if requested_label and first_eligible_label:
                item["message"] = (
                    f"A venda pedida para {requested_label} ainda está dentro da carência. "
                    f"Primeira sessão de venda elegível: {first_eligible_label}."
                )
            else:
                item["message"] = "A data de venda selecionada ainda está dentro da carência do produto. Revise a primeira data elegível antes de avaliar."
            alternative_label = (
                f"Rever data da venda a partir de {first_eligible_label}"
                if first_eligible_label else "Rever data da venda"
            )
            item["alternatives"] = [{"label": alternative_label, "target_field": "sale_date"}]
        elif field_path in ("purchase_date", "sale_date"):
            side_label = "compra" if field_path == "purchase_date" else "venda"
            if code == "OUTSIDE_HORIZON":
                instrument = normalized.get("instrument") if isinstance(normalized, Mapping) else None
                is_renda_plus = isinstance(instrument, Mapping) and instrument.get("family") == "RENDA_PLUS"
                horizon_date = (
                    instrument.get("first_income_date") if is_renda_plus
                    else instrument.get("maturity_date")
                ) if isinstance(instrument, Mapping) else None
                horizon_label = (
                    date.fromisoformat(horizon_date).strftime("%d/%m/%Y")
                    if isinstance(horizon_date, str) else "a data limite do título"
                )
                item["title"] = (
                    "Data fora do período de acumulação" if is_renda_plus
                    else "Data no vencimento ou depois dele"
                )
                item["message"] = (
                    f"A {side_label} do RendA+ deve ocorrer antes da primeira parcela ({horizon_label})."
                    if is_renda_plus else
                    f"A {side_label} do IPCA+ Principal deve ocorrer antes do vencimento ({horizon_label})."
                )
                item["alternatives"] = [{"label": f"Rever data da {side_label}", "target_field": field_path}]
            else:
                item["title"] = f"Data de {side_label} necessária"
                item["message"] = f"Informe uma data de {side_label} dentro do período suportado para esta operação."
                item["alternatives"] = [{"label": f"Informar data da {side_label}", "target_field": field_path}]
        elif field_path.startswith("dates."):
            item["title"] = f"Confirme a liquidação da {side_label}"
            item["message"] = f"A liquidação proposta para {side_label} ({date_label or 'data não resolvida'}) precisa ser confirmada antes da avaliação."
            item["alternatives"] = [
                {"label": f"Revisar data da {side_label}", "target_field": f"{side}_date"},
                {"label": "Revisar perfil de liquidação", "target_field": "assumptions.settlement_profile"},
            ]
        elif field_path == "capital.value":
            item["title"] = "Informe o capital da operação"
            item["message"] = "Escolha orçamento ou quantidade e informe o valor correspondente."
            item["alternatives"] = [{"label": "Informar orçamento ou quantidade", "target_field": field_path}]
        elif field_path.startswith("instrument."):
            item["title"] = "Título ou ano não identificado"
            item["message"] = "Escolha um título e um ano compatíveis com as séries suportadas."
            item["alternatives"] = [{"label": "Revisar título e ano", "target_field": field_path}]
        elif field_path == "assumptions.settlement_profile" or field_path.startswith("assumptions.explicit_settlements."):
            item["title"] = "Liquidação da operação pendente"
            item["message"] = "Escolha o perfil de liquidação ou complete a data financeira explicitamente preservada."
            item["alternatives"] = [{"label": "Revisar perfil e datas financeiras", "target_field": "assumptions.settlement_profile"}]
        elif field_path == "knowledge":
            item["title"] = "Data de conhecimento necessária"
            item["message"] = "Defina a data que limita quais observações podem ser tratadas como conhecidas."
            item["alternatives"] = [{"label": "Informar data de conhecimento", "target_field": "knowledge"}]
        elif field_path in ("entry_price.mode", "entry_price.pu", "exit_price.mode", "exit_price.pu"):
            side = "purchase" if field_path.startswith("entry_") else "sale"
            side_label = "compra" if side == "purchase" else "venda"
            item["title"] = f"Preço de {side_label} necessário"
            item["message"] = f"Informe um PU ou uma taxa válida para o lado de {side_label}; uma cotação ausente não será estimada."
            item["alternatives"] = [
                {"label": f"Informar PU de {side_label}", "target_field": "entry_price.pu" if side == "purchase" else "exit_price.pu"},
                {"label": f"Informar taxa de {side_label}", "target_field": "entry_price.rate" if side == "purchase" else "exit_price.rate"},
            ]
        elif field_path.startswith("assumptions.entry_fee") or field_path == "assumptions.exit_fee_brl":
            item["title"] = "Declare os custos da operação"
            item["message"] = "Informe o custo conhecido ou zero quando a hipótese explícita for ausência de cobrança."
            item["alternatives"] = [{"label": "Revisar custos", "target_field": field_path}]
        else:
            item["title"] = "Informação necessária para esta saída"
            item["message"] = "A informação ainda não está disponível; preencha o campo indicado ou escolha uma alternativa compatível."
            item["alternatives"] = []

        item["relevant_dates"].sort()
        item["side_names"].sort()
        item["capability_ids"].sort()
        item["reason_codes"].sort()
        item["source_refs"].sort()

    for item in issues.values():
        display(item)
    return sorted(
        issues.values(),
        key=lambda item: (item["severity"] != "BLOCKING", item["title"], item["field_path"]),
    )


def resolve_workspace(
    payload: object,
    *,
    calendar: Any,
    price_observations: tuple[PriceObservation, ...] | None = None,
    index_observations: tuple[IndexObservation, ...] | None = None,
    price_source_error: str | None = None,
    index_source_error: str | None = None,
    require_automatic_nominal: bool = False,
) -> dict[str, Any]:
    """Resolve the normalized draft against one calendar and pinned local data.

    This remains deterministic and offline. Dataset readers belong to the
    service adapter; this function sees only immutable parsed observations.
    """
    defaults_applied = []
    if isinstance(payload, Mapping):
        supplied_assumptions = payload.get("assumptions")
        if supplied_assumptions is None or (
            isinstance(supplied_assumptions, Mapping)
            and "settlement_profile" not in supplied_assumptions
        ):
            defaults_applied.append("assumptions.settlement_profile")
    prepared = prepare_workspace_defaults(payload)
    normalized = normalize_workspace_input(prepared)
    raw_instrument = prepared.get("instrument") if isinstance(prepared, Mapping) else None
    if (price_observations is not None and isinstance(raw_instrument, Mapping)
            and "series_year" in raw_instrument and normalized.instrument is not None):
        normalized = _resolve_instrument_from_catalog(normalized, price_observations)
    result = normalized.to_dict()
    result["defaulted_fields"] = defaults_applied
    dates = None
    assumptions = _thaw_json(normalized.assumptions)
    analysis_context = normalized.analysis_context
    operation_window = bool(analysis_context and analysis_context.is_operation_window)
    window_without_sale = operation_window and assumptions.get("settlement_profile") != "EXPLICIT"
    explicit_missing = any(
        field.startswith("assumptions.explicit_settlements.")
        for field in normalized.missing_fields
    )
    if (normalized.instrument is not None and normalized.purchase_date is not None
            and assumptions.get("settlement_profile") and not explicit_missing):
        sale_date = normalized.sale_date
        if window_without_sale and sale_date is None:
            # Resolve the purchase side through the existing date engine. This
            # temporary later order is never returned or copied into the draft.
            try:
                purchase_settlement = calendar.next_session(normalized.purchase_date)
                sale_date = calendar.next_session(purchase_settlement)
            except Exception as exc:
                if getattr(exc, "code", None) != "E-CALENDAR":
                    raise
                sale_date = normalized.purchase_date + timedelta(days=1)
        if sale_date is not None:
            dates = resolve_workspace_dates(
                instrument=normalized.instrument,
                purchase_order_date=normalized.purchase_date,
                sale_order_date=sale_date,
                settlement_profile=assumptions["settlement_profile"],
                calendar=calendar,
                explicit_settlements=assumptions.get("explicit_settlements"),
            )
    if dates is None:
        result["dates"] = None
    else:
        resolved_dates = dates.to_dict()
        if window_without_sale:
            resolved_dates.update({
                "status": dates.purchase.status,
                "sale": None,
                "warnings": [dates.purchase.calendar_notice],
                "timeline": analysis_context.to_dict()["timeline"],
                "selection_required": True,
            })
        result["dates"] = resolved_dates
    result["calendar"] = {
        "calendar_id": calendar.calendar_id,
        "knowledge_date": normalized.knowledge.date.isoformat() if normalized.knowledge else None,
        "warning": calendar.warning,
    }

    capabilities = dict(result["capabilities"])
    missing_fields = list(result["missing_fields"])
    date_status = "needs_input" if dates is None else (
        dates.purchase.status if window_without_sale else dates.status
    )
    date_reason = None
    if dates is None:
        date_reason = "MISSING_EXPLICIT_SETTLEMENT" if explicit_missing else "MISSING_DATE_OR_PROFILE"
        missing_fields.extend(
            field for field, value in (
                ("instrument", normalized.instrument), ("purchase_date", normalized.purchase_date),
                ("sale_date", None if window_without_sale else normalized.sale_date),
                ("assumptions.settlement_profile", assumptions.get("settlement_profile")),
            ) if value is None
        )
    else:
        date_items = (dates.purchase,) if window_without_sale else (dates.purchase, dates.sale)
        for item in date_items:
            if item.reason_code:
                date_reason = item.reason_code
                if item.confirmation_required:
                    missing_fields.append(f"dates.{item.side}.confirmation")
                if item.status == "blocked_policy":
                    date_status = "blocked_policy"
                    break
    capabilities["date_resolution"] = {
        "status": date_status,
        "reason": None if date_reason is None else {"code": date_reason, "message": "Revise ou confirme as datas propostas."},
        "missing_fields": [field for field in missing_fields if (
            field.startswith("dates.") or field == "assumptions.settlement_profile"
            or field.startswith("assumptions.explicit_settlements.")
        )],
    }

    price_results: dict[str, dict[str, Any]] = {}
    source_versions = dict(normalized.source_versions)
    price_sides = [("entry_price", normalized.entry_price, None if dates is None else dates.purchase)]
    if not window_without_sale:
        price_sides.append(("exit_price", normalized.exit_price, None if dates is None else dates.sale))
    for side_name, selection, order in price_sides:
        if selection is None or selection.mode is not PriceMode.AUTO_LOCAL:
            continue
        if price_source_error is not None:
            price_results[side_name] = {
                "status": "needs_input", "reason_code": price_source_error,
                "missing_fields": ["source_versions.market_sim"],
            }
            continue
        if price_observations is None:
            price_results[side_name] = {
                "status": "needs_input", "reason_code": "SOURCE_VERSION_MISSING",
                "missing_fields": ["source_versions.market_sim"],
            }
            continue
        assert selection.observation_date is not None and selection.quoted_side is not None
        if normalized.instrument is None or order is None:
            price_results[side_name] = {
                "status": "needs_input", "reason_code": "MISSING_DATE_OR_INSTRUMENT",
                "missing_fields": ["instrument", "purchase_date", "sale_date"],
            }
            continue
        if normalized.knowledge is None:
            price_results[side_name] = {
                "status": "needs_input", "reason_code": "MISSING_KNOWLEDGE",
                "observation_date": selection.observation_date.isoformat(),
                "missing_fields": ["knowledge"],
            }
            continue
        if selection.observation_date != order.proposed_order_date:
            price_results[side_name] = {
                "status": "needs_input", "reason_code": "QUOTE_DATE_MISMATCH",
                "observation_date": selection.observation_date.isoformat(),
                "order_date": order.proposed_order_date.isoformat(),
                "missing_fields": [f"{side_name}.observation_date"],
            }
            continue
        mode = normalized.knowledge.mode if normalized.knowledge else EvidenceMode.CAUSAL
        as_of = normalized.knowledge.date if normalized.knowledge else None
        quote = lookup_price_exact(
            price_observations, instrument_id=normalized.instrument.instrument_id,
            observation_date=selection.observation_date, side=selection.quoted_side.value,
            as_of=as_of, mode=mode,
        )
        if quote["status"] != "available":
            price_results[side_name] = {**quote, "missing_fields": [] if quote["status"] == "blocked_policy" else [f"{side_name}.pu"]}
            continue
        if (quote.get("family") != normalized.instrument.family.value
                or quote.get("maturity_date") != normalized.instrument.maturity_date.isoformat()):
            price_results[side_name] = {
                **quote, "status": "blocked_policy", "reason_code": "INSTRUMENT_MISMATCH",
                "value": None, "missing_fields": [],
            }
            continue
        if quote.get("quote_settlement_date") != (
            order.settlement_date.isoformat() if order.settlement_date else None
        ):
            reason = "NO_NEXT_MARKET_DATE" if quote.get("quote_settlement_date") is None else "QUOTE_SETTLEMENT_MISMATCH"
            message = (
                "A cotação matinal não informa uma próxima Data Base para confirmar D+1; selecione outra cotação."
                if reason == "NO_NEXT_MARKET_DATE" else
                f"A cotação selecionada liquida em {quote['quote_settlement_date']}, mas o perfil exige {order.settlement_date.isoformat() if order.settlement_date else 'data desconhecida'}; selecione cotação compatível ou informe taxa/PU hipotético recalculado para essa data."
            )
            price_results[side_name] = {
                **quote, "status": "needs_input", "reason_code": reason, "message": message,
                "value": None, "calendar_settlement_date": order.settlement_date.isoformat() if order.settlement_date else None,
                "missing_fields": [f"{side_name}.observation_date"],
            }
            continue
        digest = selection.version_hash
        price_results[side_name] = {
            **quote,
            "provenance": {
                "source_id": "USER_SUPPLIED_TREASURY_CSV",
                "source_ref": f"Cotação local {selection.observation_date.isoformat()} — {selection.quoted_side.value}; fonte declarada, não autenticada",
                "quality": "INFORMED",
                "observed_on": selection.observation_date.isoformat(),
                "version": digest,
                "sha256": digest,
            },
            "financial_settlement_date": order.settlement_date.isoformat() if order.settlement_date else None,
            "role": "mark_only" if selection.quoted_side is Side.BASE else "price",
        }

    result["resolved_prices"] = price_results

    resolved_indices: list[dict[str, Any]] = []
    if dates is not None and normalized.instrument is not None and normalized.knowledge is not None:
        index_kind = "VNA" if normalized.instrument.family is ProductFamily.IPCA_PRINCIPAL else "VNI"
        direct_anchors = _thaw_json(normalized.data).get("index_anchors", [])
        index_sides = [("entry_price", normalized.entry_price, dates.purchase)]
        if not window_without_sale:
            index_sides.append(("exit_price", normalized.exit_price, dates.sale))
        for side_name, selection, order in index_sides:
            uses_rate = selection is not None and (
                selection.mode in (PriceMode.MANUAL_RATE, PriceMode.SAME_ENTRY_RATE)
                or selection.rate_check is not None
            )
            if not uses_rate or order.settlement_date is None:
                continue
            direct = next((anchor for anchor in direct_anchors
                           if anchor.get("kind") == index_kind
                           and anchor.get("reference_date") == order.settlement_date.isoformat()), None)
            if direct is not None:
                direct_status = "available"
                direct_reason = "EXPLICIT_EXACT_ANCHOR"
                direct_quality = direct["quality"]
                if normalized.knowledge is None:
                    direct_status = "needs_input"
                    direct_reason = "MISSING_KNOWLEDGE"
                elif (normalized.knowledge.mode is EvidenceMode.CAUSAL
                      and direct_quality != Quality.HYPOTHETICAL.value
                      and date.fromisoformat(direct["reference_date"]) > normalized.knowledge.date):
                    direct_status = "blocked_policy"
                    direct_reason = EvidenceStatus.OBSERVATION_AFTER_AS_OF.value
                elif (normalized.knowledge.mode is EvidenceMode.CAUSAL
                      and direct_quality in (Quality.OBSERVED.value, Quality.REVISED.value)
                      and direct.get("provenance") is None):
                    direct_status = "blocked_policy"
                    direct_reason = EvidenceStatus.PUBLICATION_DATE_UNKNOWN.value
                elif direct.get("provenance") is not None:
                    direct_provenance = _parse_provenance(
                        _thaw_json(direct["provenance"]), f"data.index_anchors.{index_kind}.provenance"
                    )
                    evidence = _check_provenance(direct_provenance, normalized.knowledge)
                    if evidence in (
                        EvidenceStatus.PUBLISHED_AFTER_AS_OF,
                        EvidenceStatus.PUBLICATION_DATE_UNKNOWN,
                        EvidenceStatus.OBSERVATION_AFTER_AS_OF,
                    ):
                        direct_status = "blocked_policy"
                        direct_reason = evidence.value
                resolved_indices.append({
                    "status": direct_status, "reason_code": direct_reason,
                    "for": side_name, "kind": index_kind,
                    "reference_date": order.settlement_date.isoformat(),
                    "value": direct["value"] if direct_status == "available" else None,
                    "quality": direct_quality,
                    "source_ref": direct["source_ref"],
                    "missing_fields": ["knowledge"] if direct_reason == "MISSING_KNOWLEDGE" else [],
                })
                continue
            if index_source_error is not None:
                resolved_indices.append({
                    "status": "needs_input", "reason_code": index_source_error,
                    "for": side_name, "kind": index_kind,
                    "reference_date": order.settlement_date.isoformat(), "value": None,
                    "missing_fields": ["source_versions.market_sim_indexes"],
                })
                continue
            if index_observations is None:
                resolved_indices.append({
                    "status": "needs_input", "reason_code": "NO_EXACT_INDEX",
                    "for": side_name, "kind": index_kind,
                    "reference_date": order.settlement_date.isoformat(), "value": None,
                    "missing_fields": ["data.index_anchors[matching_kind_and_settlement]"],
                })
                continue
            anchor = lookup_index_exact(
                index_observations, kind=index_kind, reference_date=order.settlement_date,
                as_of=normalized.knowledge.date, mode=normalized.knowledge.mode,
            )
            resolved_indices.append({"for": side_name, **anchor})
    result["resolved_index_anchors"] = resolved_indices

    projection = None
    projection_raw = assumptions.get("inflation_projection")
    if isinstance(projection_raw, Mapping):
        projection = InflationProjection(
            projection_raw["mode"], Decimal(projection_raw["annual_rate"]),
            date.fromisoformat(projection_raw["anchor_date"]),
            Decimal(projection_raw["anchor_level"]), projection_raw["source_ref"],
            Decimal(projection_raw["end_annual_rate"]) if projection_raw.get("end_annual_rate") is not None else None,
            date.fromisoformat(projection_raw["end_date"]) if projection_raw.get("end_date") is not None else None,
        )

    projection_context = None
    if normalized.instrument is not None:
        from .operation import IndexLevel
        from .service import (
            EvaluationContext, IndexAnchor, IndexKind, PriceIndexEvidence,
            prepare_projection_window,
        )

        family_index = IndexKind.VNA if normalized.instrument.family is ProductFamily.IPCA_PRINCIPAL else IndexKind.VNI
        context_anchors: list[IndexAnchor] = []
        direct_anchors = _thaw_json(normalized.data).get("index_anchors", [])
        direct_keys: set[tuple[IndexKind, date]] = set()
        for index, raw_anchor in enumerate(direct_anchors):
            kind = IndexKind(raw_anchor["kind"])
            reference_date = date.fromisoformat(raw_anchor["reference_date"])
            provenance = _parse_provenance(raw_anchor.get("provenance"), f"data.index_anchors[{index}].provenance")
            context_anchors.append(IndexAnchor(
                kind, Decimal(raw_anchor["value"]), reference_date,
                Quality(raw_anchor["quality"]), raw_anchor["source_ref"], provenance,
            ))
            direct_keys.add((kind, reference_date))
        if index_observations is not None:
            for observation in index_observations:
                if observation.kind != family_index.value:
                    continue
                key = (family_index, observation.reference_date)
                # A user-selected dated anchor has the same precedence as an
                # explicit PU: a local series never silently replaces it.
                if key in direct_keys:
                    continue
                context_anchors.append(IndexAnchor(
                    family_index, observation.value, observation.reference_date,
                    Quality.INFORMED, observation.source,
                ))

        context_levels: list[IndexLevel] = []
        context_level_evidence: list[PriceIndexEvidence] = []
        raw_levels = _thaw_json(normalized.data).get("price_index_levels", [])
        for index, raw_level in enumerate(raw_levels):
            provenance = _parse_provenance(raw_level.get("provenance"), f"data.price_index_levels[{index}].provenance")
            level_date = date.fromisoformat(raw_level["date"])
            level_quality = provenance.quality if provenance else Quality.INFORMED
            context_levels.append(IndexLevel(
                level_date, Decimal(raw_level["value"]), raw_level["source_ref"],
            ))
            context_level_evidence.append(PriceIndexEvidence(level_date, level_quality, provenance))

        index_targets: dict[IndexKind, tuple[date, ...]] = {}
        target_dates: list[date] = []
        projection_sides = [("entry_price", normalized.entry_price, None if dates is None else dates.purchase)]
        if not window_without_sale:
            projection_sides.append(("exit_price", normalized.exit_price, None if dates is None else dates.sale))
        for side_name, selection, order in projection_sides:
            uses_rate = selection is not None and (
                selection.mode in (PriceMode.MANUAL_RATE, PriceMode.SAME_ENTRY_RATE)
                or selection.rate_check is not None
            )
            if uses_rate and order is not None and order.settlement_date is not None:
                current = list(index_targets.get(family_index, ()))
                current.append(order.settlement_date)
                index_targets[family_index] = tuple(current)
            if order is not None and order.settlement_date is not None:
                target_dates.append(order.settlement_date)
        intermediate_costs = _thaw_json(normalized.data).get("intermediate_paid_costs", [])
        target_dates.extend(date.fromisoformat(item["date"]) for item in intermediate_costs)
        projection_context = prepare_projection_window(
            EvaluationContext(
                index_anchors=tuple(context_anchors), index_levels=tuple(context_levels),
                inflation_projection=projection,
                price_index_evidence=tuple(context_level_evidence),
                ipca_monthly_indexes=_monthly_ipca_inputs(normalized.data, index_observations),
                ipca_monthly_rates=_monthly_ipca_rates(normalized.assumptions),
                require_automatic_nominal=require_automatic_nominal,
            ),
            index_targets=index_targets,
            price_index_targets=tuple(target_dates),
            projection=projection,
            as_of=normalized.knowledge.date if normalized.knowledge else None,
            evidence_mode=normalized.knowledge.mode if normalized.knowledge else EvidenceMode.CAUSAL,
        )

        from .service import price_indexed_security

        def resolve_rate_price(side_name: str, selection: PriceSelection, rate: Decimal, order: Any) -> dict[str, Any]:
            if order is None or order.settlement_date is None:
                return {"status": "needs_input", "reason_code": "MISSING_DATE", "value": None}
            point = next((item for item in projection_context.index_points
                          if item.series_id == family_index.value
                          and item.reference_date == order.settlement_date), None)
            if point is None or point.status != "available":
                return {
                    "status": "blocked_policy" if point is not None and point.status == "blocked_policy" else "needs_input",
                    "reason_code": "NO_EXACT_INDEX" if point is None else point.reason_code,
                    "value": None,
                    "missing_fields": [] if point is not None and point.status == "blocked_policy" else [
                        _index_pending_field(point, f"data.index_anchors[{family_index.value},{order.settlement_date.isoformat()}]")
                    ],
                }
            anchor = next((item for item in projection_context.context.index_anchors
                           if item.kind is family_index and item.reference_date == order.settlement_date), None)
            if anchor is None:
                return {"status": "needs_input", "reason_code": "NO_EXACT_INDEX", "value": None}
            effective_rate = rate
            if side_name == "exit_price" and selection.quoted_side is Side.BUY:
                effective_rate += selection.spread or Decimal(0)
            try:
                pu = price_indexed_security(
                    normalized.instrument, calendar, anchor, order.settlement_date, effective_rate,
                )
            except ValidationError as exc:
                return {"status": "blocked_policy", "reason_code": exc.code, "value": None, "missing_fields": []}
            if pu is None:
                return {"status": "needs_input", "reason_code": "MISSING_INDEX", "value": None}
            if (
                normalized.intent is ScenarioIntent.HYPOTHETICAL
                or selection.quality is Quality.HYPOTHETICAL
                or anchor.quality is Quality.HYPOTHETICAL
            ):
                price_quality = Quality.HYPOTHETICAL
            elif selection.quality is Quality.ESTIMATED or anchor.quality is Quality.ESTIMATED:
                price_quality = Quality.ESTIMATED
            else:
                price_quality = Quality.RECONSTRUCTED
            return {
                "status": "available", "reason_code": point.reason_code,
                "value": str(pu), "unit": "BRL_PER_TITLE",
                "quality": price_quality.value, "anchor_quality": point.quality.value,
                "quoted_side": selection.quoted_side.value if selection.quoted_side else "SELL",
                "annual_real_rate": str(effective_rate),
                "reference_date": order.settlement_date.isoformat(),
                "source_ref": point.source_ref,
                "profile_id": point.profile_id,
                "anchor_date": point.anchor_date.isoformat() if point.anchor_date else None,
            }

        rate_sides = [("entry_price", normalized.entry_price, None if dates is None else dates.purchase)]
        if not window_without_sale:
            rate_sides.append(("exit_price", normalized.exit_price, None if dates is None else dates.sale))
        for side_name, selection, order in rate_sides:
            if selection is None:
                continue
            if selection.mode in (PriceMode.MANUAL_RATE, PriceMode.SAME_ENTRY_RATE):
                rate = (
                    selection.annual_real_rate
                    if selection.mode is PriceMode.MANUAL_RATE
                    else (normalized.entry_price.annual_real_rate if normalized.entry_price else None)
                )
                if rate is None:
                    price_results[side_name] = {"status": "needs_input", "reason_code": "MISSING_ENTRY_RATE", "value": None}
                else:
                    price_results[side_name] = resolve_rate_price(side_name, selection, rate, order)
            elif selection.rate_check is not None and selection.rate_check.annual_real_rate is not None:
                price_results.setdefault(side_name, {})["rate_check"] = resolve_rate_price(
                    side_name, selection.rate_check, selection.rate_check.annual_real_rate,
                    None if dates is None else (dates.purchase if side_name == "entry_price" else dates.sale),
                )

        points_by_target = {
            (point.series_id, point.reference_date): point
            for point in projection_context.index_points
        }
        for item in resolved_indices:
            if not (projection_context.context.require_automatic_nominal or projection_context.context.ipca_monthly_indexes) and (item["status"] != "needs_input" or item.get("reason_code") not in ("NO_EXACT_INDEX", "MISSING_INDEX")):
                continue
            point = points_by_target.get((item["kind"], date.fromisoformat(item["reference_date"])))
            if point is None:
                continue
            if point.status == "available":
                item.update({
                    "status": "available", "reason_code": point.reason_code,
                    "value": str(point.value), "quality": point.quality.value,
                    "source_ref": point.source_ref, "anchor_date": point.anchor_date.isoformat() if point.anchor_date else None,
                    "profile_id": point.profile_id,
                })
            else:
                item["reason_code"] = point.reason_code or item.get("reason_code")
                if projection_context.context.require_automatic_nominal or projection_context.context.ipca_monthly_indexes:
                    item.update(status=point.status, value=None, quality=Quality.MISSING.value,
                                source_ref=point.source_ref, anchor_date=None, provenance=None)
                if point.profile_id == 'TD_CALENDAR_15_IPCA_RATIO_v1':
                    item['profile_id'] = point.profile_id
                    item['missing_fields'] = [_index_pending_field(point, 'data.ipca_monthly_indexes')]
                if point.status == "blocked_policy":
                    item["status"] = "blocked_policy"
                    item["missing_fields"] = []
                elif point.reason_code == "MISSING_PROJECTION":
                    item["missing_fields"] = ["assumptions.inflation_projection"]
                elif point.reason_code in ("NO_PRIOR_ANCHOR", "EXPLICIT_GAP_NOT_INTERPOLATED"):
                    item["missing_fields"] = [f"data.index_anchors[{item['kind']},{item['reference_date']}]" ]

    projection_payload = {
        "profile_id": None if projection is None else projection.profile_id,
        "assumption": None if projection is None else projection.to_dict(),
        "quality": None if projection is None else Quality.HYPOTHETICAL.value,
        "index_anchors": [] if projection_context is None else [point.to_dict() for point in projection_context.index_points],
        "price_index_levels": [] if projection_context is None else [point.to_dict() for point in projection_context.price_index_points],
        "warnings": [] if projection_context is None else list(projection_context.warnings),
    }
    result["nominal_index_calculations"] = [] if projection_context is None else [
        {"kind": family_index.value, "calculation": item.to_dict()}
        for item in projection_context.nominal_calculations
    ]
    projection_payload['require_automatic_nominal'] = require_automatic_nominal
    projection_payload['ipca_monthly_indexes'] = [
        {'month': item.month.strftime('%Y-%m'), 'value': str(item.value),
         'known_on': item.known_on.isoformat(), 'source_ref': item.source_ref,
         'cache_sha256': item.cache_sha256}
        for item in (_monthly_ipca_inputs(normalized.data, index_observations) if projection_context else ())
    ]
    result["projection_window"] = projection_payload
    result["resolved_price_index_levels"] = projection_payload["price_index_levels"]

    if projection_context is not None:
        index_points = projection_context.index_points
        requested_rates = [
            (side_name, selection)
            for side_name, selection in (("entry_price", normalized.entry_price), ("exit_price", normalized.exit_price))
            if not (window_without_sale and side_name == "exit_price")
            if selection is not None and (
                selection.mode in (PriceMode.MANUAL_RATE, PriceMode.SAME_ENTRY_RATE)
                or selection.rate_check is not None
            )
        ]
        required_rates = [
            (side_name, selection)
            for side_name, selection in requested_rates
            if selection is not None and selection.mode in (PriceMode.MANUAL_RATE, PriceMode.SAME_ENTRY_RATE)
        ]
        selected_rate_points = [
            next((point for point in index_points if point.reference_date == order.settlement_date), None)
            for side_name, selection in required_rates if dates is not None
            for order in ((dates.purchase if side_name == "entry_price" else dates.sale),)
            if order is not None and order.settlement_date is not None
        ]
        if requested_rates and dates is None:
            capabilities["rate_pricing"] = {
                "status": "needs_input", "reason": {"code": "MISSING_DATE_OR_INSTRUMENT", "message": "Resolva datas financeiras antes de buscar âncoras."},
                "missing_fields": ["purchase_date", "sale_date"],
            }
        if required_rates:
            blocked_rate = next((point for point in selected_rate_points if point and point.status == "blocked_policy"), None)
            missing_rate = next((point for point in selected_rate_points if point is None or point.status != "available"), None)
            if blocked_rate is not None:
                capabilities["price_resolution"] = {
                    "status": "blocked_policy", "reason": {"code": blocked_rate.reason_code, "message": "A âncora está indisponível no corte de conhecimento."}, "missing_fields": [],
                }
                capabilities["nominal_evaluation"] = dict(capabilities["price_resolution"])
            elif missing_rate is None:
                price_reason = capabilities["price_resolution"].get("reason")
                nominal_reason = capabilities["nominal_evaluation"].get("reason")
                if isinstance(price_reason, Mapping) and price_reason.get("code") in ("MISSING_INDEX", "MISSING_PRICE"):
                    capabilities["price_resolution"] = {"status": "available", "reason": None, "missing_fields": []}
                if isinstance(nominal_reason, Mapping) and nominal_reason.get("code") in ("MISSING_INDEX", "MISSING_PRICE"):
                    capabilities["nominal_evaluation"] = {"status": "available", "reason": None, "missing_fields": []}
            else:
                code = missing_rate.reason_code or "NO_EXACT_INDEX"
                fields = [_index_pending_field(missing_rate, f"data.index_anchors[{family_index.value},{missing_rate.reference_date.isoformat()}]")]
                if code == "MISSING_PROJECTION":
                    fields = ["assumptions.inflation_projection"]
                capabilities["rate_pricing"] = {
                    "status": "needs_input", "reason": {"code": code, "message": "Taxa preservada; falta uma âncora exata ou hipótese selecionada."}, "missing_fields": fields,
                }
                if require_automatic_nominal:
                    capabilities["rate_pricing"]["reason"]["message"] = "Taxa preservada; importe ou atualize o IPCA mensal, ou declare a projeção de inflação quando necessária."
                    capabilities["price_resolution"] = dict(capabilities["rate_pricing"])
                    capabilities["nominal_evaluation"] = dict(capabilities["rate_pricing"])
        for side_name, selection in requested_rates:
            if selection.mode in (PriceMode.MANUAL_RATE, PriceMode.SAME_ENTRY_RATE) or dates is None:
                continue
            order = dates.purchase if side_name == "entry_price" else dates.sale
            point = next((
                candidate for candidate in index_points
                if order is not None and candidate.reference_date == order.settlement_date
            ), None)
            if point is None or point.status != "available":
                status = "blocked_policy" if point is not None and point.status == "blocked_policy" else "needs_input"
                code = "NO_EXACT_INDEX" if point is None else point.reason_code or "NO_EXACT_INDEX"
                field = _index_pending_field(point, f"data.index_anchors[{family_index.value},{order.settlement_date.isoformat()}]")
                capabilities["rate_check"] = {
                    "status": status, "reason": {"code": code, "message": "PU principal preservado; a conferência de taxa depende da âncora desta data."},
                    "missing_fields": [] if status == "blocked_policy" else [field],
                }
            else:
                capabilities["rate_check"] = {"status": "available", "reason": None, "missing_fields": []}
        price_points = projection_context.price_index_points
        unavailable_price = next((point for point in price_points if point.status != "available"), None)
        if unavailable_price is None and price_points:
            capabilities["real_return"] = {"status": "available", "reason": None, "missing_fields": []}
        elif unavailable_price is not None:
            status = "blocked_policy" if unavailable_price.status == "blocked_policy" else "needs_input"
            field = _index_pending_field(unavailable_price, f"data.price_index_levels[{unavailable_price.reference_date.isoformat()}]")
            capabilities["real_return"] = {
                "status": status, "reason": {"code": unavailable_price.reason_code, "message": "Retorno real depende de nível do índice geral de preços em cada data dos fluxos."}, "missing_fields": [] if status == "blocked_policy" else [field],
            }
        else:
            capabilities["real_return"] = {
                "status": "needs_input", "reason": {"code": "MISSING_INDEX", "message": "Retorno real depende de níveis do índice geral de preços nas datas dos fluxos."},
                "missing_fields": [f"data.price_index_levels[{value.isoformat()}]" for value in target_dates],
            }
        if "rate_pricing" not in capabilities:
            capabilities["rate_pricing"] = {"status": "available", "reason": None, "missing_fields": []}
    else:
        capabilities["rate_pricing"] = {"status": "needs_input", "reason": {"code": "MISSING_DATE_OR_INSTRUMENT", "message": "Resolva produto e datas financeiras antes de preparar âncoras."}, "missing_fields": []}
        capabilities["real_return"] = {"status": "needs_input", "reason": {"code": "MISSING_DATE_OR_INSTRUMENT", "message": "Resolva datas financeiras antes de preparar a janela real."}, "missing_fields": []}
    result["capabilities"] = capabilities

    blocked_anchor = next((item for item in resolved_indices if item["status"] == "blocked_policy"), None)
    if blocked_anchor is not None:
        side_selection = normalized.entry_price if blocked_anchor["for"] == "entry_price" else normalized.exit_price
        reason = {
            "code": blocked_anchor["reason_code"],
            "message": "A âncora foi excluída pelo corte de conhecimento; os preços informados permanecem preservados.",
        }
        if side_selection is not None and side_selection.rate_check is not None:
            capabilities["rate_check"] = {"status": "blocked_policy", "reason": reason, "missing_fields": []}
        if side_selection is not None and side_selection.mode in (PriceMode.MANUAL_RATE, PriceMode.SAME_ENTRY_RATE):
            capabilities["price_resolution"] = {"status": "blocked_policy", "reason": reason, "missing_fields": []}
            capabilities["nominal_evaluation"] = {"status": "blocked_policy", "reason": reason, "missing_fields": []}

    # Calendar and quote gates affect whether a financially complete draft can
    # proceed. Keep the normalized user fields unchanged for an explicit edit.
    auto_selections = [
        (side_name, selection)
        for side_name, selection in (("entry_price", normalized.entry_price), ("exit_price", normalized.exit_price))
        if not (window_without_sale and side_name == "exit_price")
        if selection is not None and selection.mode is PriceMode.AUTO_LOCAL
    ]
    auto_selected = bool(auto_selections)
    auto_failed = any(
        price_results.get(side_name, {}).get("status") != "available"
        for side_name, _selection in auto_selections
    )
    if dates is not None and date_status == "blocked_policy":
        capabilities["nominal_evaluation"] = {
            "status": "blocked_policy",
            "reason": {"code": date_reason or "OUTSIDE_HORIZON", "message": "As datas estão fora do horizonte permitido."},
            "missing_fields": [],
        }
    elif dates is not None and date_status == "needs_input":
        capabilities["nominal_evaluation"] = {
            "status": "needs_input",
            "reason": {"code": date_reason or "DATE_CONFIRMATION_REQUIRED", "message": "Confirme as datas propostas antes do cálculo."},
            "missing_fields": capabilities["date_resolution"]["missing_fields"],
        }
    elif auto_selected and not auto_failed and not normalized.missing_fields:
        capabilities["price_resolution"] = {"status": "available", "reason": None, "missing_fields": []}
        capabilities["nominal_evaluation"] = {"status": "available", "reason": None, "missing_fields": []}
    elif auto_failed:
        failed_side = next(
            side_name for side_name, _selection in auto_selections
            if price_results.get(side_name, {}).get("status") != "available"
        )
        failed = price_results[failed_side]
        capabilities["price_resolution"] = {
            "status": failed["status"],
            "reason": {"code": failed["reason_code"], "message": "A cotação exata não pode ser usada nesta data e corte."},
            "missing_fields": failed.get("missing_fields", []),
        }
        capabilities["nominal_evaluation"] = {
            "status": failed["status"],
            "reason": {"code": failed["reason_code"], "message": "A cotação selecionada ainda não foi resolvida."},
            "missing_fields": failed.get("missing_fields", []),
        }

    sizing, sizing_capability = _resolve_purchase_sizing(normalized, price_results)
    capabilities["purchase_sizing"] = sizing_capability
    result["purchase_sizing"] = sizing
    if sizing_capability["status"] == "needs_input":
        missing_fields.extend(sizing_capability["missing_fields"])

    result["capabilities"] = capabilities
    for field_result in price_results.values():
        if field_result.get("status") == "needs_input":
            missing_fields.extend(field_result.get("missing_fields", []))
    for anchor in resolved_indices:
        if anchor["status"] == "needs_input":
            selection = normalized.entry_price if anchor["for"] == "entry_price" else normalized.exit_price
            if selection is not None and selection.mode in (PriceMode.MANUAL_RATE, PriceMode.SAME_ENTRY_RATE):
                missing_fields.extend(anchor.get("missing_fields", []))
    result["missing_fields"] = list(dict.fromkeys(missing_fields))
    required_capabilities = (
        "input_resolution", "date_resolution", "price_resolution",
        "nominal_evaluation", "purchase_sizing",
    )
    result["status"] = "ready" if not result["missing_fields"] and all(
        capabilities.get(capability, {}).get("status") == "available"
        for capability in required_capabilities
    ) else "partial"
    result["source_resolution"] = {
        "market_sim": source_versions.get("market_sim"),
        "market_sim_indexes": source_versions.get("market_sim_indexes"),
        **_monthly_ipca_source_identity(_monthly_ipca_inputs(normalized.data, index_observations)),
    }
    result["instrument_series_options"] = _workspace_instrument_series_options()
    result["pending_items"] = _workspace_pending_items(result)
    return result


def _workspace_instrument_series_options() -> dict[str, list[int]]:
    """Return the canonical year choices from the server-owned title profile."""
    from .renda_plus import SUPPORTED_CONVERSION_YEARS

    return {"RENDA_PLUS": sorted(SUPPORTED_CONVERSION_YEARS)}


def _resolve_instrument_from_catalog(
    normalized: WorkspaceInput,
    observations: tuple[PriceObservation, ...],
) -> WorkspaceInput:
    """Attach an exact imported quote identity to a year-only selection.

    The selected year remains the user's only instrument input. If that pinned
    source contains one matching series, its exact identifier and maturity are
    carried internally so exact-date quote lookup does not depend on a title
    string or a date formula in the browser.
    """
    instrument = normalized.instrument
    if instrument is None:
        return normalized
    expected_year = (
        instrument.conversion_date.year
        if instrument.family is ProductFamily.RENDA_PLUS and instrument.conversion_date is not None
        else instrument.maturity_date.year
    )
    candidates = []
    for item in observations:
        if item.family != instrument.family.value:
            continue
        if instrument.family is ProductFamily.RENDA_PLUS:
            match = re.search(r"(\d{4})\s*$", item.title_type)
            title_year = int(match.group(1)) if match else None
            if title_year != expected_year:
                continue
        elif item.maturity_date.year != expected_year:
            continue
        candidates.append(item)
    identities = {(item.instrument_id, item.maturity_date) for item in candidates}
    if len(identities) != 1:
        return normalized
    instrument_id, maturity_date = next(iter(identities))
    if instrument.instrument_id == instrument_id and instrument.maturity_date == maturity_date:
        return normalized
    return replace(
        normalized,
        instrument=Instrument(
            instrument.family, instrument_id, maturity_date,
            instrument.conversion_date, instrument.first_income_date,
        ),
    )


def _workspace_settlement_quality(dates: Mapping[str, Any]) -> Quality | None:
    values = [
        Quality(item["quality"])
        for side in ("purchase", "sale")
        if isinstance((item := dates.get(side)), Mapping) and item.get("quality") in Quality._value2member_map_
    ]
    if not values:
        return None
    if Quality.HYPOTHETICAL in values:
        return Quality.HYPOTHETICAL
    if Quality.ESTIMATED in values:
        return Quality.ESTIMATED
    if all(item is values[0] for item in values):
        return values[0]
    return Quality.RECONSTRUCTED


def build_resolved_workspace_financial_inputs(
    payload: object, resolution: Mapping[str, Any], *, calendar: Any,
    surface_condition: Mapping[str, Any] | None = None,
) -> tuple[Scenario, Any]:
    """Build the scenario and context used by every direct workspace view."""
    from .operation import CashFlow, IndexLevel
    from .projections import InflationProjection
    from .service import EvaluationContext, IndexAnchor, IndexKind, PriceIndexEvidence

    normalized = normalize_workspace_input(prepare_workspace_defaults(payload))
    capabilities = resolution.get("capabilities", {})
    required = (
        ("date_resolution", "purchase_sizing") if surface_condition is not None
        else ("date_resolution", "price_resolution", "nominal_evaluation", "purchase_sizing")
    )
    if any(capabilities.get(name, {}).get("status") != "available" for name in required):
        raise ValidationError("WORKSPACE_NOT_READY", "A resolução ainda tem campos necessários para avaliar.")
    dates = resolution.get("dates")
    sizing = resolution.get("purchase_sizing", {})
    if not isinstance(dates, Mapping) or dates.get("status") != "available" or sizing.get("status") != "available":
        raise ValidationError("WORKSPACE_NOT_READY", "Confirme as datas e o dimensionamento antes de avaliar.")
    purchase_date, sale_date = dates.get("purchase"), dates.get("sale")
    if not isinstance(purchase_date, Mapping) or (
        surface_condition is None and not isinstance(sale_date, Mapping)
    ):
        raise ValidationError("WORKSPACE_NOT_READY", "Compra e, para avaliação pontual, venda precisam estar resolvidas.")
    resolved_prices = resolution.get("resolved_prices", {})
    entry_result, exit_result = resolved_prices.get("entry_price", {}), resolved_prices.get("exit_price", {})
    entry_selection, exit_selection = normalized.entry_price, normalized.exit_price
    if entry_selection is None or (exit_selection is None and surface_condition is None) or normalized.instrument is None or normalized.knowledge is None:
        raise ValidationError("WORKSPACE_NOT_READY", "Produto, corte de conhecimento e preços são obrigatórios.")

    entry_pu = entry_selection.pu if entry_selection.mode is PriceMode.MANUAL_PU else None
    if entry_selection.mode is PriceMode.AUTO_LOCAL and entry_result.get("status") == "available":
        entry_pu = Decimal(entry_result["value"])
    entry_rate = entry_selection.annual_real_rate
    if entry_selection.mode is PriceMode.MANUAL_PU and entry_selection.rate_check is not None:
        entry_rate = entry_selection.rate_check.annual_real_rate

    if surface_condition is not None:
        exit_pu = Decimal(surface_condition["value"]) if surface_condition["unit"] == "BRL_PER_TITLE" else None
        exit_rate = Decimal(surface_condition["value"]) if surface_condition["unit"] == "ratio" else None
    else:
        assert exit_selection is not None
        exit_pu = exit_selection.pu if exit_selection.mode is PriceMode.MANUAL_PU else None
        if exit_selection.mode is PriceMode.AUTO_LOCAL and exit_result.get("status") == "available":
            exit_pu = Decimal(exit_result["value"])
        exit_rate = exit_selection.annual_real_rate
        if exit_selection.mode is PriceMode.SAME_ENTRY_RATE:
            exit_rate = entry_selection.annual_real_rate
        if exit_selection.mode is PriceMode.MANUAL_PU and exit_selection.rate_check is not None:
            exit_rate = exit_selection.rate_check.annual_real_rate

    entry_provenance = entry_selection.provenance
    if entry_provenance is None and entry_result.get("provenance") is not None:
        entry_provenance = _parse_provenance(entry_result["provenance"], "resolved_prices.entry_price.provenance")
    if entry_provenance is None and entry_selection.quality is Quality.HYPOTHETICAL:
        entry_provenance = Provenance("USER_INPUT", "PU de entrada informado como hipótese", Quality.HYPOTHETICAL, None, None)
    exit_provenance = None
    if surface_condition is None:
        assert exit_selection is not None
        exit_provenance = exit_selection.provenance
        if exit_provenance is None and exit_result.get("provenance") is not None:
            exit_provenance = _parse_provenance(exit_result["provenance"], "resolved_prices.exit_price.provenance")
        if exit_provenance is None and exit_selection.quality is Quality.HYPOTHETICAL:
            exit_provenance = Provenance("USER_INPUT", "PU de saída informado como hipótese", Quality.HYPOTHETICAL, None, None)

    instrument = normalized.instrument
    sale_order_date = (
        surface_condition["order_date"] if surface_condition is not None
        else date.fromisoformat(sale_date["proposed_order_date"])
    )
    sale_settlement_date = (
        surface_condition["settlement_date"] if surface_condition is not None
        else date.fromisoformat(sale_date["settlement_date"])
    )
    scenario = Scenario(
        instrument,
        Entry(instrument.instrument_id, date.fromisoformat(purchase_date["proposed_order_date"]),
              date.fromisoformat(purchase_date["settlement_date"]), Decimal(sizing["quantity"]["value"]),
              entry_pu, entry_rate, Side.BUY, entry_provenance),
        Exit(instrument.instrument_id, sale_order_date,
             sale_settlement_date, Side.SELL, exit_pu, exit_rate,
             Side.SELL if surface_condition is not None else exit_selection.quoted_side or Side.SELL,
             None if surface_condition is not None else exit_selection.spread,
             None if surface_condition is not None else exit_selection.spread_source,
             exit_provenance),
        AsOf(normalized.knowledge.date, normalized.knowledge.mode), normalized.intent,
    )

    raw_data = _thaw_json(normalized.data)
    anchors: dict[tuple[IndexKind, date], IndexAnchor] = {}
    require_automatic_nominal = bool((resolution.get("projection_window") or {}).get("require_automatic_nominal"))
    legacy_anchors = [] if require_automatic_nominal else raw_data.get("index_anchors", [])
    for index, raw_anchor in enumerate(legacy_anchors):
        anchor = IndexAnchor(
            IndexKind(raw_anchor["kind"]), Decimal(raw_anchor["value"]),
            date.fromisoformat(raw_anchor["reference_date"]), Quality(raw_anchor["quality"]),
            raw_anchor["source_ref"],
            _parse_provenance(raw_anchor.get("provenance"), f"data.index_anchors[{index}].provenance"),
        )
        anchors[(anchor.kind, anchor.reference_date)] = anchor
    projection_window = resolution.get("projection_window", {})
    family_index = IndexKind.VNA if instrument.family is ProductFamily.IPCA_PRINCIPAL else IndexKind.VNI
    for point in projection_window.get("index_anchors", []):
        if point.get("status") != "available" or point.get("value") is None:
            continue
        kind = IndexKind(point["series_id"])
        if kind is not family_index:
            continue
        reference_date = date.fromisoformat(point["reference_date"])
        anchors.setdefault((kind, reference_date), IndexAnchor(
            kind, Decimal(point["value"]), reference_date, Quality(point["quality"]),
            point.get("source_ref") or "Projeção explicitamente selecionada",
        ))

    levels: dict[date, IndexLevel] = {}
    level_evidence: dict[date, PriceIndexEvidence] = {}
    for index, raw_level in enumerate(raw_data.get("price_index_levels", [])):
        reference_date = date.fromisoformat(raw_level["date"])
        provenance = _parse_provenance(raw_level.get("provenance"), f"data.price_index_levels[{index}].provenance")
        quality = provenance.quality if provenance is not None else Quality.INFORMED
        levels[reference_date] = IndexLevel(reference_date, Decimal(raw_level["value"]), raw_level["source_ref"])
        level_evidence[reference_date] = PriceIndexEvidence(reference_date, quality, provenance)
    for point in projection_window.get("price_index_levels", []):
        if point.get("status") != "available" or point.get("value") is None:
            continue
        reference_date = date.fromisoformat(point["reference_date"])
        if reference_date in levels:
            continue
        quality = Quality(point["quality"])
        levels[reference_date] = IndexLevel(
            reference_date, Decimal(point["value"]), point.get("source_ref") or "Índice de preços projetado",
        )
        level_evidence[reference_date] = PriceIndexEvidence(reference_date, quality)

    assumptions = _thaw_json(normalized.assumptions)
    projection_raw = assumptions.get("inflation_projection")
    projection = None if projection_raw is None else InflationProjection(
        projection_raw["mode"], Decimal(projection_raw["annual_rate"]),
        date.fromisoformat(projection_raw["anchor_date"]), Decimal(projection_raw["anchor_level"]),
        projection_raw["source_ref"],
        Decimal(projection_raw["end_annual_rate"]) if projection_raw.get("end_annual_rate") is not None else None,
        date.fromisoformat(projection_raw["end_date"]) if projection_raw.get("end_date") is not None else None,
    )
    costs = tuple(CashFlow(date.fromisoformat(item["date"]), Decimal(item["amount_brl"]), item["label"])
                  for item in raw_data.get("intermediate_paid_costs", []))
    tax_basis = assumptions.get("tax_cost_basis_brl")
    exit_fee = assumptions.get("exit_fee_brl")
    context = EvaluationContext(
        calendar=calendar, index_anchors=tuple(anchors.values()),
        tax_cost_basis=Decimal(tax_basis) if tax_basis is not None else Decimal(sizing["tax_cost_basis"]["value"]),
        entry_expense_paid=Decimal(sizing["entry_expense"]["value"]),
        exit_expense=Decimal(exit_fee) if exit_fee is not None else Decimal(0),
        custody_override=Decimal(assumptions["custody_override_brl"]) if assumptions.get("custody_override_brl") is not None else None,
        institution_net_override=Decimal(assumptions["institution_net_brl"]) if assumptions.get("institution_net_brl") is not None else None,
        intermediate_paid_costs=costs, index_levels=tuple(levels.values()),
        institution_release_date=date.fromisoformat(assumptions["institution_release_date"]) if assumptions.get("institution_release_date") else None,
        inflation_projection=projection, price_index_evidence=tuple(level_evidence.values()),
        capital_mode=normalized.capital.mode.value if normalized.capital is not None else None,
        tax_cost_basis_source=(sizing.get("tax_cost_basis") or {}).get("source"),
        settlement_quality=_workspace_settlement_quality(dates),
        ipca_monthly_indexes=_monthly_ipca_inputs(
            {'ipca_monthly_indexes': projection_window.get('ipca_monthly_indexes', [])}, None),
        ipca_monthly_rates=_monthly_ipca_rates(normalized.assumptions),
        require_automatic_nominal=require_automatic_nominal,
    )
    return scenario, context


def prepare_workspace_surface_domain(
    payload: object,
    resolution: Mapping[str, Any],
    surface: Mapping[str, Any],
    *,
    calendar: Any,
) -> dict[str, Any]:
    """Resolve caller coordinates into a bounded grid with explicit coverage."""
    from .surfaces import MAX_DATE_POINTS, generate_surface_domain

    selected_date = surface["selected_order_date"]
    selected_value = surface["selected_value"]
    normalized = normalize_workspace_input(prepare_workspace_defaults(payload))
    assumptions = _thaw_json(normalized.assumptions)
    profile = assumptions.get("settlement_profile")
    same_day = profile == "SIMULATED_BUY_D1_SELL_D0"
    explicit_profile = profile == "EXPLICIT"
    analysis_context = normalized.analysis_context
    operation_window = bool(analysis_context and analysis_context.is_operation_window)
    if operation_window and explicit_profile:
        # EXPLICIT only authorizes the declared sale settlement; it cannot be
        # expanded to dates for which the user supplied no settlement.
        sale_resolution = (resolution.get("dates") or {}).get("sale")
        if not isinstance(sale_resolution, Mapping) or selected_date.isoformat() != sale_resolution.get("proposed_order_date"):
            raise ValidationError(
                "SURFACE_SETTLEMENT_UNAVAILABLE",
                "O perfil EXPLICIT só autoriza a data e a liquidação declaradas; não há expansão temporal segura.",
            )
    if operation_window and not explicit_profile:
        if analysis_context.start is None or analysis_context.end is None:
            raise ValidationError("MISSING_FIELD", "OPERATION/WINDOW exige início e fim para gerar a superfície.")
        purchase = (resolution.get("dates") or {}).get("purchase")
        if not isinstance(purchase, Mapping) or not purchase.get("settlement_date"):
            raise ValidationError("WORKSPACE_NOT_READY", "Resolva a liquidação da compra antes de explorar o período.")
        if normalized.instrument is None:
            raise ValidationError("MISSING_INSTRUMENT", "OPERATION/WINDOW exige título e horizonte conhecidos.")
        if (normalized.knowledge is not None
                and normalized.intent is not ScenarioIntent.HYPOTHETICAL
                and selected_date > normalized.knowledge.date):
            raise ValidationError(
                "HYPOTHETICAL_INTENT_REQUIRED",
                "Uma data de venda depois do corte exige intent HYPOTHETICAL explícito.",
            )

        from .dates import minimum_renda_plus_sale_date

        calendar_start, calendar_end = date(2000, 1, 1), date(2085, 12, 31)
        requested_start, requested_end = analysis_context.start, analysis_context.end
        domain_start, domain_end = max(requested_start, calendar_start), min(requested_end, calendar_end)
        timeline_exclusions: list[dict[str, str]] = []
        if requested_start < calendar_start:
            timeline_exclusions.append({
                "start": requested_start.isoformat(),
                "end": min(requested_end, calendar_start - timedelta(days=1)).isoformat(),
                "reason": "Fora da cobertura do calendário financeiro projetado (2000–2085).",
            })
        if requested_end > calendar_end:
            timeline_exclusions.append({
                "start": max(requested_start, calendar_end + timedelta(days=1)).isoformat(),
                "end": requested_end.isoformat(),
                "reason": "Fora da cobertura do calendário financeiro projetado (2000–2085).",
            })
        if (normalized.knowledge is not None
                and normalized.intent is not ScenarioIntent.HYPOTHETICAL
                and requested_end > normalized.knowledge.date):
            future_start = max(requested_start, normalized.knowledge.date + timedelta(days=1))
            if future_start <= requested_end:
                timeline_exclusions.append({
                    "start": future_start.isoformat(), "end": requested_end.isoformat(),
                    "reason": "Depois do corte de conhecimento; intent HYPOTHETICAL é necessário para explorar datas futuras.",
                })
        horizon = (
            normalized.instrument.first_income_date
            if normalized.instrument.family is ProductFamily.RENDA_PLUS
            else normalized.instrument.maturity_date
        )
        if horizon is None:
            raise ValidationError("INVALID_INSTRUMENT", "RendA+ exige primeira data de renda para limitar o período.")
        entry_settlement = date.fromisoformat(purchase["settlement_date"])
        first_order = max(domain_start, entry_settlement + timedelta(days=1))
        product_last_order = min(domain_end, horizon - timedelta(days=1))
        if normalized.instrument.family is ProductFamily.RENDA_PLUS:
            try:
                lock_end = minimum_renda_plus_sale_date(entry_settlement)
                first_order = max(first_order, calendar.next_session(lock_end, include=True))
            except Exception as exc:
                if getattr(exc, "code", None) != "CALENDAR_OUTSIDE_DOMAIN":
                    raise
                first_order = product_last_order + timedelta(days=1)

        def candidate_is_eligible(order_date: date) -> bool:
            if (normalized.knowledge is not None
                    and normalized.intent is not ScenarioIntent.HYPOTHETICAL
                    and order_date > normalized.knowledge.date):
                return False
            if not calendar.is_session(order_date):
                return False
            try:
                candidate_dates = resolve_workspace_dates(
                    instrument=normalized.instrument,
                    purchase_order_date=normalized.purchase_date,
                    sale_order_date=order_date,
                    settlement_profile=profile,
                    calendar=calendar,
                )
            except ValidationError:
                return False
            return candidate_dates.purchase.status == "available" and candidate_dates.sale.status == "available"

        supplied_dates = surface.get("order_dates")
        if supplied_dates is None and surface["mode"] == "RATE_CURVE":
            candidate_dates = (selected_date,)
        elif supplied_dates is not None:
            candidate_dates = tuple(supplied_dates)
            if (normalized.knowledge is not None
                    and normalized.intent is not ScenarioIntent.HYPOTHETICAL
                    and any(item > normalized.knowledge.date for item in candidate_dates)):
                raise ValidationError(
                    "HYPOTHETICAL_INTENT_REQUIRED",
                    "Uma data de venda depois do corte exige intent HYPOTHETICAL explícito.",
                )
        else:
            found: list[date] = []
            cursor = first_order
            while cursor <= product_last_order:
                if calendar.is_session(cursor) and candidate_is_eligible(cursor):
                    found.append(cursor)
                    if len(found) > MAX_DATE_POINTS:
                        raise ValidationError(
                            "SURFACE_LIMIT",
                            f"A janela excede o limite de {MAX_DATE_POINTS} datas elegíveis; reduza o período.",
                        )
                cursor += timedelta(days=1)
            candidate_dates = tuple(found)

        if not candidate_dates:
            return {
                "mode": surface["mode"], "metric_id": surface["metric_id"],
                "metric_unit": surface["metric_unit"], "value_unit": surface["value_unit"],
                "order_dates": (), "values": surface.get("values") or (),
                "candidate_order_dates": (), "candidate_values": surface.get("values") or (),
                "omitted_dates": (), "omitted_values": (), "policy_dates": (),
                "date_range": (requested_start, requested_end), "complete": False,
                "coverage_status": "OUTSIDE_DOMAIN",
                "timeline_coverage_complete": False,
                "timeline_exclusions": timeline_exclusions,
                "selected_order_date": selected_date, "selected_value": selected_value,
                "selected_value_source": surface.get("selected_value_source", "USER_SELECTED"),
                "requested_order_dates": supplied_dates,
                "requested_values": surface.get("values"),
                "selected_settlement_date": None,
                "g4_frontier": bool(surface.get("g4_frontier")),
                "_empty_domain_reason": {
                    "code": "NO_ELIGIBLE_SESSIONS",
                    "message": "Não há sessões de venda elegíveis dentro do período, calendário e horizonte do título.",
                },
            }
        if any(item < domain_start or item > domain_end or not candidate_is_eligible(item) for item in candidate_dates):
            raise ValidationError(
                "INVALID_DOMAIN",
                "Todas as datas solicitadas precisam ser sessões elegíveis dentro do calendário e perfil declarados.",
            )
        if selected_date < domain_start or selected_date > domain_end or not candidate_is_eligible(selected_date):
            raise ValidationError(
                "INVALID_SELECTION",
                "A data selecionada precisa ser uma sessão elegível dentro do período e perfil declarados.",
            )
        candidate_dates = tuple(sorted(set((*candidate_dates, selected_date))))
        if len(candidate_dates) > MAX_DATE_POINTS:
            raise ValidationError("SURFACE_LIMIT", f"A janela aceita no máximo {MAX_DATE_POINTS} datas elegíveis.")
        requested_dates = candidate_dates
        selected_resolution = resolve_workspace_dates(
            instrument=normalized.instrument,
            purchase_order_date=normalized.purchase_date,
            sale_order_date=selected_date,
            settlement_profile=profile,
            calendar=calendar,
        )
        selected_settlement = selected_resolution.sale.settlement_date
        condition = {
            "order_date": selected_date, "settlement_date": selected_settlement,
            "value": selected_value, "unit": surface["value_unit"],
        }
        scenario, context = build_resolved_workspace_financial_inputs(
            payload, resolution, calendar=calendar, surface_condition=condition,
        )
        domain = generate_surface_domain(
            scenario, context, surface["mode"], surface["value_unit"], selected_date, selected_value,
            requested_order_dates=requested_dates,
            requested_values=surface.get("values"),
            max_value_points=21 if surface.get("g4_frontier") else 15,
        )
        eligible_candidates = tuple(
            item for item in domain.candidate_order_dates if candidate_is_eligible(item)
        )
        eligible_sampled = tuple(item for item in domain.order_dates if candidate_is_eligible(item))
        eligible_omitted = tuple(item for item in domain.omitted_dates if candidate_is_eligible(item))
        eligible_policy_dates = tuple(item for item in domain.policy_dates if candidate_is_eligible(item))
        domain = replace(
            domain, order_dates=eligible_sampled,
            candidate_order_dates=eligible_candidates, omitted_dates=eligible_omitted,
            policy_dates=eligible_policy_dates,
        )
        timeline_coverage_complete = not timeline_exclusions
        return {
            "mode": surface["mode"], "metric_id": surface["metric_id"],
            "metric_unit": surface["metric_unit"], "value_unit": surface["value_unit"],
            "order_dates": domain.order_dates, "values": domain.values,
            "candidate_order_dates": domain.candidate_order_dates,
            "candidate_values": domain.candidate_values,
            "omitted_dates": domain.omitted_dates, "omitted_values": domain.omitted_values,
            "policy_dates": domain.policy_dates, "date_range": domain.date_range,
            "complete": domain.complete and timeline_coverage_complete,
            "coverage_status": (
                "PARTIAL_DOMAIN" if not timeline_coverage_complete else domain.coverage_status
            ),
            "timeline_coverage_complete": timeline_coverage_complete,
            "timeline_exclusions": timeline_exclusions,
            "selected_order_date": selected_date, "selected_value": selected_value,
            "selected_value_source": surface.get("selected_value_source", "USER_SELECTED"),
            "requested_order_dates": supplied_dates,
            "requested_values": surface.get("values"),
            "selected_settlement_date": selected_settlement,
            "g4_frontier": bool(surface.get("g4_frontier")),
            "_scenario": scenario,
            "_context": context,
        }
    if explicit_profile:
        sale_resolution = resolution.get("dates", {}).get("sale")
        if not isinstance(sale_resolution, Mapping) or selected_date.isoformat() != sale_resolution.get("proposed_order_date"):
            raise ValidationError(
                "SURFACE_SETTLEMENT_UNAVAILABLE",
                "Liquidação explícita só autoriza a data declarada; nenhuma data será presumida.",
            )
        supplied_dates = surface.get("order_dates")
        if supplied_dates is not None and any(item != selected_date for item in supplied_dates):
            raise ValidationError(
                "SURFACE_SETTLEMENT_UNAVAILABLE",
                "Liquidação explícita só autoriza projetar a data declarada.",
            )
        selected_settlement = date.fromisoformat(sale_resolution["settlement_date"])
    elif same_day:
        selected_settlement = selected_date
    else:
        selected_settlement = calendar.next_session(selected_date)
    condition = {
        "order_date": selected_date, "settlement_date": selected_settlement,
        "value": selected_value, "unit": surface["value_unit"],
    }
    scenario, context = build_resolved_workspace_financial_inputs(
        payload, resolution, calendar=calendar, surface_condition=condition,
    )
    domain = generate_surface_domain(
        scenario, context, surface["mode"], surface["value_unit"], selected_date, selected_value,
        requested_order_dates=(
            (selected_date,) if explicit_profile and surface.get("order_dates") is None
            else surface.get("order_dates")
        ),
        requested_values=surface.get("values"),
        max_value_points=21 if surface.get("g4_frontier") else 15,
    )
    return {
        "mode": surface["mode"], "metric_id": surface["metric_id"],
        "metric_unit": surface["metric_unit"], "value_unit": surface["value_unit"],
        "order_dates": domain.order_dates, "values": domain.values,
        "candidate_order_dates": domain.candidate_order_dates,
        "candidate_values": domain.candidate_values,
        "omitted_dates": domain.omitted_dates, "omitted_values": domain.omitted_values,
        "policy_dates": domain.policy_dates, "date_range": domain.date_range,
        "complete": domain.complete, "coverage_status": domain.coverage_status,
        "timeline_coverage_complete": True, "timeline_exclusions": [],
        "selected_order_date": selected_date, "selected_value": selected_value,
        "requested_order_dates": surface.get("order_dates"),
        "requested_values": surface.get("values"),
        "selected_settlement_date": selected_settlement,
        "g4_frontier": bool(surface.get("g4_frontier")),
        "_scenario": scenario,
        "_context": context,
    }


@dataclass(frozen=True, slots=True)
class WorkspaceEvaluation(ScenarioEvaluation):
    constraint_evaluation: Any = None
    goal_gap: tuple[dict[str, Any], ...] = ()
    presentation_summary: dict[str, Any] | None = None
    cash_bridge: dict[str, Any] | None = None
    assumptions_summary: tuple[dict[str, Any], ...] = ()


def _workspace_goal_gap(constraint_evaluation: Any) -> tuple[dict[str, Any], ...]:
    """Return non-negative, operator-aware distances for human presentation."""
    result: list[dict[str, Any]] = []
    for criterion in constraint_evaluation.criteria:
        status = getattr(criterion.status, "value", criterion.status)
        operator = getattr(criterion.operator, "value", criterion.operator)
        margin = criterion.margin
        amount = None
        kind = "UNAVAILABLE"
        if status in {"MET", "NOT_MET"} and margin is not None and criterion.achieved_value is not None:
            satisfied = margin >= 0
            if satisfied == (status == "MET"):
                amount = abs(margin)
                if not amount:
                    kind = "AT_LIMIT"
                elif operator == "AT_LEAST":
                    kind = "SURPLUS" if status == "MET" else "SHORTFALL"
                elif operator == "AT_MOST":
                    kind = "BELOW_LIMIT" if status == "MET" else "EXCESS"
                else:
                    amount = None
        result.append({
            "criterion_id": criterion.constraint_id,
            "operator": operator,
            "unit": criterion.unit,
            "amount_unit": criterion.margin_unit,
            "status": status,
            "kind": kind,
            "amount": amount,
        })
    return tuple(result)


def _money_cents(value: Decimal | None) -> str | None:
    if value is None:
        return None
    return format(value.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP), "f")


def _dto_decimal(value: object) -> Decimal | None:
    if not isinstance(value, Mapping) or value.get("value") is None:
        return None
    return Decimal(value["value"])


def _money_magnitude(value: Decimal | None) -> str | None:
    if value is None:
        return None
    return _money_cents(abs(value))


def _workspace_reason(capability: Mapping[str, Any] | None, fallback_code: str) -> dict[str, Any]:
    capability = capability if isinstance(capability, Mapping) else {}
    reason = capability.get("reason")
    reason = reason if isinstance(reason, Mapping) else {}
    return {
        "code": reason.get("code") or capability.get("reason_code") or fallback_code,
        "message": reason.get("message") or capability.get("message"),
        "missing_fields": list(capability.get("missing_fields", ())),
    }


def _presentation_metric(
    metric_id: str,
    value: Decimal | int | str | None,
    unit: str,
    *,
    quality: Quality | None,
    dependencies: tuple[str, ...],
    horizon_days: int | None = None,
    reason: Mapping[str, Any] | None = None,
    forced_status: str | None = None,
) -> dict[str, Any]:
    if forced_status is not None:
        status = forced_status
        value = None if status in {"MISSING", "BLOCKED_POLICY", "UNAVAILABLE"} else value
    elif value is None:
        status = "MISSING"
    elif quality is Quality.ESTIMATED:
        status = "ESTIMATED"
    else:
        status = "AVAILABLE"
    raw_quality = None if value is None or quality in (None, Quality.MISSING) else quality.value
    return {
        "metric_id": metric_id,
        "value": None if value is None else str(value),
        "unit": unit,
        "status": status,
        "quality": raw_quality,
        "horizon_days": horizon_days,
        "dependencies": list(dependencies),
        "reason": None if reason is None else dict(reason),
    }


def _step_quality(evaluation: ScenarioEvaluation, name: str) -> Quality | None:
    return next((step.quality for step in evaluation.steps if step.name == name), None)


def _price_step_quality(evaluation: ScenarioEvaluation, side: str) -> Quality | None:
    token = "entrada" if side == "entry" else "saída"
    return next((
        step.quality for step in evaluation.steps
        if step.name.lower().startswith("pu ") and token in step.name.lower()
    ), None)


def _workspace_assumptions_summary(
    payload: object,
    resolution: Mapping[str, Any],
    evaluation: ScenarioEvaluation,
    scenario: Scenario,
    context: Any,
) -> tuple[dict[str, Any], ...]:
    normalized = normalize_workspace_input(prepare_workspace_defaults(payload))
    assumptions = _thaw_json(normalized.assumptions)
    data = _thaw_json(normalized.data)
    dates = resolution.get("dates", {})
    sizing = resolution.get("purchase_sizing", {})
    rows: list[dict[str, Any]] = []

    def add(
        assumption_id: str, value: Any, unit: str, status: str, *,
        quality: Quality | str | None = None, source: Mapping[str, Any] | None = None,
        control_id: str | None = None,
    ) -> None:
        quality_value = quality.value if isinstance(quality, Quality) else quality
        rows.append({
            "assumption_id": assumption_id,
            "label_key": "assumption." + assumption_id,
            "value": None if value is None else str(value),
            "unit": unit,
            "status": status,
            "quality": quality_value,
            "source": None if source is None else dict(source),
            "control_id": control_id,
        })

    for side, selection, quote, financial_value in (
        ("entry", normalized.entry_price, scenario.entry, evaluation.entry_pu),
        ("exit", normalized.exit_price, scenario.exit, evaluation.exit_pu),
    ):
        if selection is None:
            continue
        step_quality = _price_step_quality(evaluation, side) or selection.quality
        provenance = selection.provenance
        source = {
            "kind": selection.mode.value,
            "source_ref": provenance.source_ref if provenance is not None else "Entrada manual",
            "provenance": _provenance_dict(provenance) if provenance is not None else None,
        }
        add(
            f"{side}_price", financial_value, "BRL_PER_TITLE",
            "AVAILABLE" if financial_value is not None else "MISSING",
            quality=step_quality if financial_value is not None else Quality.MISSING,
            source=source, control_id=f"{side}_price",
        )
        rate = None if selection.mode is PriceMode.MANUAL_PU else selection.annual_real_rate
        if selection.mode is PriceMode.SAME_ENTRY_RATE:
            rate = quote.real_yield
        add(
            f"{side}_rate", rate, "ratio",
            "AVAILABLE" if rate is not None else "NOT_APPLIED",
            quality=(Quality.RECONSTRUCTED if selection.mode is PriceMode.SAME_ENTRY_RATE else selection.quality) if rate is not None else None,
            source=source if rate is not None else None, control_id=f"{side}_price",
        )
        rate_check = selection.rate_check
        add(
            f"{side}_rate_check", rate_check.annual_real_rate if rate_check is not None else None,
            "ratio", "NOT_EVALUATED" if rate_check is not None else "NOT_APPLIED",
            quality=rate_check.quality if rate_check is not None else None,
            source={"kind": "USER_INPUT", "evaluation": "NOT_EVALUATED"} if rate_check is not None else None,
            control_id=f"{side}_price",
        )
        add(
            f"{side}_price_mode", selection.mode.value, "enum", "AVAILABLE",
            quality=selection.quality, source=source, control_id=f"{side}_price",
        )

    for input_name, output_name, side in (
        ("purchase_date", "purchase_date", "purchase"),
        ("sale_date", "sale_date", "sale"),
    ):
        row = dates.get(side) if isinstance(dates, Mapping) else None
        requested = row.get("requested_date") if isinstance(row, Mapping) else getattr(normalized, input_name, None)
        requested = requested.isoformat() if hasattr(requested, "isoformat") else requested
        quality = row.get("quality") if isinstance(row, Mapping) else None
        source = {key: row[key] for key in ("source_ref", "profile_id", "calendar_id") if row.get(key)} if isinstance(row, Mapping) else None
        add(output_name, requested, "date", "AVAILABLE" if requested is not None else "MISSING",
            quality=quality, source=source, control_id=input_name)
        financial_date = row.get("settlement_date") if isinstance(row, Mapping) else None
        add(f"{side}_financial_date", financial_date, "date",
            "AVAILABLE" if financial_date is not None else "MISSING",
            quality=quality, source=source, control_id=input_name)

    add("settlement_profile", assumptions.get("settlement_profile"), "enum",
        "AVAILABLE" if assumptions.get("settlement_profile") else "MISSING",
        quality=_workspace_settlement_quality(dates) if isinstance(dates, Mapping) else None,
        source={"profile_id": assumptions.get("settlement_profile")} if assumptions.get("settlement_profile") else None,
        control_id="assumptions.settlement_profile")
    add("knowledge_date", normalized.knowledge.date.isoformat() if normalized.knowledge else None,
        "date", "AVAILABLE" if normalized.knowledge else "MISSING",
        quality=Quality.INFORMED if normalized.knowledge else Quality.MISSING,
        source={"mode": normalized.knowledge.mode.value} if normalized.knowledge else None,
        control_id="knowledge.date")
    add("intent", normalized.intent.value, "enum", "AVAILABLE",
        quality=Quality.HYPOTHETICAL if normalized.intent is ScenarioIntent.HYPOTHETICAL else Quality.INFORMED,
        source={"kind": "USER_DECLARED"}, control_id="intent")

    projection = assumptions.get("inflation_projection")
    if isinstance(projection, Mapping):
        add("inflation_projection", projection.get("mode"), "enum", "AVAILABLE",
            quality=Quality.HYPOTHETICAL, source={
                key: projection.get(key) for key in (
                    "annual_rate", "end_annual_rate", "anchor_date", "anchor_level", "end_date", "source_ref",
                ) if projection.get(key) is not None
            }, control_id="assumptions.inflation_projection")
        add("inflation_projection_rate", projection.get("annual_rate"), "ratio", "AVAILABLE",
            quality=Quality.HYPOTHETICAL, source={"source_ref": projection.get("source_ref")},
            control_id="assumptions.inflation_projection")
    else:
        add("inflation_projection", None, "enum", "NOT_APPLIED", control_id="assumptions.inflation_projection")

    purchase_sizing = sizing if isinstance(sizing, Mapping) else {}
    entry_fee = assumptions.get("entry_fee") if isinstance(assumptions.get("entry_fee"), Mapping) else {}
    add("entry_fee", (purchase_sizing.get("entry_expense") or {}).get("value"), "BRL",
        "AVAILABLE" if (purchase_sizing.get("entry_expense") or {}).get("value") is not None else "MISSING",
        quality=Quality.INFORMED if purchase_sizing.get("entry_expense") else Quality.MISSING,
        source={"fixed_brl": entry_fee.get("fixed_brl"), "proportional_rate": entry_fee.get("proportional_rate")},
        control_id="assumptions.entry_fee")
    add("entry_fee_fixed", entry_fee.get("fixed_brl"), "BRL",
        "AVAILABLE" if entry_fee.get("fixed_brl") is not None else "MISSING",
        quality=Quality.INFORMED if entry_fee.get("fixed_brl") is not None else Quality.MISSING,
        source={"kind": "USER_INPUT"}, control_id="assumptions.entry_fee")
    add("entry_fee_rate", entry_fee.get("proportional_rate"), "ratio",
        "AVAILABLE" if entry_fee.get("proportional_rate") is not None else "MISSING",
        quality=Quality.INFORMED if entry_fee.get("proportional_rate") is not None else Quality.MISSING,
        source={"kind": "USER_INPUT"}, control_id="assumptions.entry_fee")
    for assumption_id, raw, unit, control_id in (
        ("exit_fee", assumptions.get("exit_fee_brl"), "BRL", "assumptions.exit_fee_brl"),
        ("tax_cost_basis", (purchase_sizing.get("tax_cost_basis") or {}).get("value"), "BRL", "assumptions.tax_cost_basis_brl"),
        ("custody_override", assumptions.get("custody_override_brl"), "BRL", "assumptions.custody_override_brl"),
        ("institution_net_override", assumptions.get("institution_net_brl"), "BRL", "assumptions.institution_net_brl"),
    ):
        source = None
        if assumption_id == "tax_cost_basis":
            source = {"kind": (purchase_sizing.get("tax_cost_basis") or {}).get("source")}
        elif raw is not None:
            source = {"kind": "USER_INPUT"}
        add(assumption_id, raw, unit,
            "AVAILABLE" if raw is not None else ("AVAILABLE" if assumption_id == "exit_fee" else "NOT_APPLIED"),
            quality=Quality.INFORMED if raw is not None or assumption_id in {"exit_fee", "tax_cost_basis"} else None,
            source=source, control_id=control_id)

    for index, cost in enumerate(context.intermediate_paid_costs, 1):
        add(f"intermediate_cost_{index}", cost.amount, "BRL", "AVAILABLE",
            quality=Quality.INFORMED,
            source={"date": cost.date.isoformat(), "label": cost.label},
            control_id=f"data.intermediate_paid_costs[{index - 1}]")
    for index, item in enumerate(data.get("index_anchors", []), 1):
        kind = item["kind"]
        reference_date = item["reference_date"]
        value = Decimal(item["value"])
        quality = item["quality"]
        source_ref = item["source_ref"]
        add(f"index_anchor_{kind}_{reference_date}_{index}", value, kind.upper(), "AVAILABLE",
            quality=quality, source={"source_ref": source_ref, "reference_date": reference_date},
            control_id="data.index_anchors")
    for item in data.get("price_index_levels", []):
        add(f"price_index_{item['date']}", item["value"], "INDEX_LEVEL", "AVAILABLE",
            quality=Quality.INFORMED, source={"source_ref": item["source_ref"], "date": item["date"]},
            control_id="data.price_index_levels")
    for key, version in normalized.source_versions:
        add(f"source_version_{key}", version, "sha256", "AVAILABLE" if version else "NOT_USED",
            quality=Quality.INFORMED if version else None,
            source={"key": key} if version else None, control_id=f"source_versions.{key}")
    return tuple(rows)


def _cash_bridge_line(
    line_id: str, label_key: str, value: Decimal | None, *,
    sign: str, status: str, source_component: str,
) -> dict[str, Any]:
    return {
        "line_id": line_id, "label_key": label_key,
        "amount_brl": _money_magnitude(value), "sign": sign,
        "status": status, "source_component": source_component,
    }


def _workspace_cash_bridge(
    payload: object,
    resolution: Mapping[str, Any],
    scenario: Scenario,
    context: Any,
    evaluation: ScenarioEvaluation,
) -> dict[str, Any] | None:
    if scenario.exit.side is not Side.SELL:
        return None
    normalized = normalize_workspace_input(prepare_workspace_defaults(payload))
    operation = evaluation.operation
    sizing = resolution.get("purchase_sizing", {})
    sizing = sizing if isinstance(sizing, Mapping) else {}
    capital_is_budget = normalized.capital is not None and normalized.capital.mode is CapitalMode.BUDGET
    capital_available = normalized.capital.value if capital_is_budget and normalized.capital else None
    initial_raw = operation.initial_outflow if operation is not None else _dto_decimal(sizing.get("initial_outflow"))
    gross_purchase = operation.entry_gross if operation is not None else _dto_decimal(sizing.get("purchase_gross"))
    entry_expense = None if initial_raw is None or gross_purchase is None else initial_raw - gross_purchase
    remainder_raw = _dto_decimal(sizing.get("cash_remainder")) if capital_is_budget else None
    lines: list[dict[str, Any]] = []
    if capital_is_budget:
        lines.append(_cash_bridge_line(
            "capital_available", "cash_bridge.capital_available", capital_available,
            sign="NEUTRAL", status="AVAILABLE" if capital_available is not None else "MISSING",
            source_component="input.capital.value",
        ))
    lines.append(_cash_bridge_line(
        "purchase_gross", "cash_bridge.purchase_gross", gross_purchase,
        sign="OUTFLOW" if gross_purchase else "NEUTRAL",
        status="AVAILABLE" if gross_purchase is not None else "MISSING",
        source_component="operation.entry_gross" if operation is not None else "purchase_sizing.purchase_gross",
    ))
    lines.append(_cash_bridge_line(
        "entry_expense", "cash_bridge.entry_expense", entry_expense,
        sign="OUTFLOW" if entry_expense else "NEUTRAL",
        status="AVAILABLE" if entry_expense is not None else "MISSING",
        source_component="operation.initial_outflow_minus_entry_gross",
    ))
    if capital_is_budget:
        lines.append(_cash_bridge_line(
            "cash_remainder_after_purchase", "cash_bridge.cash_remainder_after_purchase", remainder_raw,
            sign="NEUTRAL", status="AVAILABLE" if remainder_raw is not None else "MISSING",
            source_component="purchase_sizing.cash_remainder",
        ))

    intermediate_rounded: list[Decimal] = []
    for index, cost in enumerate(context.intermediate_paid_costs, 1):
        rounded = cost.amount.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
        intermediate_rounded.append(rounded)
        sign = "OUTFLOW" if rounded < 0 else "INFLOW" if rounded > 0 else "NEUTRAL"
        lines.append(_cash_bridge_line(
            f"intermediate_paid_cost_{index}", "cash_bridge.intermediate_paid_cost",
            rounded, sign=sign, status="AVAILABLE",
            source_component=f"operation.intermediate_paid_costs[{index - 1}]",
        ))
    intermediate_net = sum(intermediate_rounded, Decimal("0.00"))

    breakdown_available = bool(
        operation is not None and operation.status != "READY_INFORMED_NET"
        and all(getattr(operation, field) is not None for field in ("iof", "income_tax", "custody", "exit_expense"))
    )
    blocked = operation is not None and operation.status == "BLOCKED_POLICY"
    if operation is None or blocked:
        sale_status = "BLOCKED_POLICY" if blocked else "MISSING"
        lines.extend((
            _cash_bridge_line("gross_redemption", "cash_bridge.gross_redemption", None,
                              sign="INFLOW", status=sale_status, source_component="operation.gross_redemption"),
            _cash_bridge_line("net_redemption", "cash_bridge.net_redemption", None,
                              sign="NEUTRAL", status=sale_status, source_component="operation.net_redemption"),
        ))
        for line_id in ("iof", "income_tax", "custody", "exit_expense"):
            lines.append(_cash_bridge_line(
                line_id, "cash_bridge." + line_id, None, sign="OUTFLOW",
                status=sale_status, source_component="operation." + line_id,
            ))
        final_net_raw = profit_raw = None
    elif breakdown_available:
        lines.append(_cash_bridge_line(
            "gross_redemption", "cash_bridge.gross_redemption", operation.gross_redemption,
            sign="INFLOW", status="AVAILABLE", source_component="operation.gross_redemption",
        ))
        for line_id, value, status in (
            ("iof", operation.iof, "AVAILABLE"),
            ("income_tax", operation.income_tax, "AVAILABLE"),
            ("custody", operation.custody, "ESTIMATED" if operation.quality is Quality.ESTIMATED else "AVAILABLE"),
            ("exit_expense", operation.exit_expense, "AVAILABLE"),
        ):
            lines.append(_cash_bridge_line(
                line_id, "cash_bridge." + line_id, value, sign="OUTFLOW" if value else "NEUTRAL",
                status=status, source_component="operation." + line_id,
            ))
        lines.append(_cash_bridge_line(
            "net_redemption", "cash_bridge.net_redemption", operation.net_redemption,
            sign="NEUTRAL", status="AVAILABLE", source_component="operation.net_redemption",
        ))
        final_net_raw, profit_raw = operation.net_redemption, operation.nominal_profit
    else:
        lines.append(_cash_bridge_line(
            "gross_redemption", "cash_bridge.gross_redemption_reference", operation.gross_redemption,
            sign="NEUTRAL", status="AVAILABLE", source_component="operation.gross_redemption",
        ))
        for line_id in ("iof", "income_tax", "custody", "exit_expense"):
            lines.append(_cash_bridge_line(
                line_id, "cash_bridge." + line_id, None, sign="OUTFLOW",
                status="UNAVAILABLE", source_component="operation." + line_id,
            ))
        lines.append(_cash_bridge_line(
            "net_redemption", "cash_bridge.net_redemption", operation.net_redemption,
            sign="INFLOW", status="AVAILABLE", source_component="operation.net_redemption",
        ))
        final_net_raw, profit_raw = operation.net_redemption, operation.nominal_profit

    initial = _money_cents(initial_raw)
    intermediate = _money_cents(intermediate_net)
    final_net = _money_cents(final_net_raw)
    profit = _money_cents(profit_raw)
    remainder = _money_cents(remainder_raw)
    capital = _money_cents(capital_available)
    final_cash = None
    final_wealth = None
    if capital_is_budget and remainder_raw is not None:
        final_cash = _money_cents(Decimal(remainder or "0") + Decimal(intermediate or "0"))
        if final_net is not None:
            final_wealth = _money_cents(Decimal(final_cash or "0") + Decimal(final_net))

    rounding_residual = None
    if profit is not None and final_net is not None and initial is not None:
        bridge_profit = Decimal(final_net) - Decimal(initial) + Decimal(intermediate or "0")
        rounding_residual = _money_cents(Decimal(profit) - bridge_profit)
        residual_value = Decimal(rounding_residual or "0")
        if residual_value:
            lines.append(_cash_bridge_line(
                "rounding_residual", "cash_bridge.rounding_residual", residual_value,
                sign="INFLOW" if residual_value > 0 else "OUTFLOW", status="AVAILABLE",
                source_component="cash_bridge.rounding_reconciliation",
            ))

    reconciliation_status = (
        "NOT_EVALUATED" if profit is None else "RECONCILED" if rounding_residual == "0.00" else "RESIDUAL_EXPOSED"
    )
    is_partial = operation is None or blocked or not breakdown_available
    return {
        "currency": "BRL",
        "status": "partial" if is_partial else "ready",
        "lines": lines,
        "totals": {
            "capital_available_brl": capital,
            "initial_outflow_brl": initial,
            "cash_remainder_after_purchase_brl": remainder,
            "intermediate_net_brl": intermediate,
            "final_cash_balance_brl": final_cash,
            "final_net_inflow_brl": final_net,
            "final_wealth_brl": final_wealth,
            "nominal_profit_brl": profit,
            "rounding_residual_brl": rounding_residual,
            "reconciliation_status": reconciliation_status,
        },
    }


def _workspace_presentation_summary(
    resolution: Mapping[str, Any],
    evaluation: ScenarioEvaluation,
    scenario: Scenario,
    context: Any,
) -> dict[str, Any]:
    operation = evaluation.operation
    capabilities = resolution.get("capabilities", {})
    nominal_reason = _workspace_reason(capabilities.get("nominal_evaluation"), evaluation.status)
    real_reason = _workspace_reason(capabilities.get("real_return"), "REAL_METRIC_UNAVAILABLE")
    blocked = operation is not None and operation.status == "BLOCKED_POLICY"
    blocked_reason = {
        "code": operation.warnings[0] if operation and operation.warnings else "BLOCKED_POLICY",
        "message": "A política do produto bloqueia esta operação na data selecionada.",
        "missing_fields": [],
    }
    annualized_reason = (
        {
            "code": "INTERMEDIATE_CASH_FLOWS",
            "message": "Retorno anualizado indisponível com fluxos de caixa intermediários.",
            "missing_fields": ["data.intermediate_paid_costs"],
        }
        if context.intermediate_paid_costs else nominal_reason
    )
    days = operation.holding_days if operation is not None else None
    if days is None:
        dates = resolution.get("dates", {})
        purchase = dates.get("purchase") if isinstance(dates, Mapping) else None
        sale = dates.get("sale") if isinstance(dates, Mapping) else None
        if isinstance(purchase, Mapping) and isinstance(sale, Mapping) and purchase.get("settlement_date") and sale.get("settlement_date"):
            days = (date.fromisoformat(sale["settlement_date"]) - date.fromisoformat(purchase["settlement_date"])).days
    settlement_quality = _workspace_settlement_quality(resolution.get("dates", {}))
    sizing = resolution.get("purchase_sizing", {})
    sizing = sizing if isinstance(sizing, Mapping) else {}
    entry_quality = _price_step_quality(evaluation, "entry")
    exit_quality = _price_step_quality(evaluation, "exit")
    operation_quality = _step_quality(evaluation, "Caixa líquido da venda")
    profit_quality = _step_quality(evaluation, "Resultado econômico nominal")
    real_quality = _step_quality(evaluation, "Retorno real")

    sale_metrics = {"gross_redemption", "iof", "income_tax", "custody", "net_redemption",
                    "nominal_profit", "nominal_return", "annualized_nominal_return",
                    "real_profit_in_exit_date_currency", "real_return"}

    def status_for(metric_id: str, value: Any, reason: Mapping[str, Any] | None = None) -> str | None:
        if blocked and metric_id in sale_metrics:
            return "BLOCKED_POLICY"
        if metric_id == "annualized_nominal_return" and value is None and context.intermediate_paid_costs:
            return "UNAVAILABLE"
        if value is None and reason and reason.get("code") == "BLOCKED_POLICY":
            return "BLOCKED_POLICY"
        return None

    specs = [
        ("nominal_profit", None if operation is None else operation.nominal_profit, "BRL",
         profit_quality, ("operation.net_redemption", "operation.initial_outflow", "operation.intermediate_paid_costs"), nominal_reason),
        ("nominal_return", None if operation is None else operation.nominal_return, "ratio",
         _step_quality(evaluation, "Retorno nominal simples"), ("operation.net_redemption", "operation.initial_outflow"), nominal_reason),
        ("annualized_nominal_return", None if operation is None else operation.annualized_nominal_return, "ratio_per_year",
         _step_quality(evaluation, "Retorno nominal anualizado"), ("operation.net_redemption", "operation.initial_outflow", "dates.purchase.settlement_date", "dates.sale.settlement_date"), annualized_reason),
        ("net_redemption", None if operation is None else operation.net_redemption, "BRL",
         operation_quality, ("operation.gross_redemption", "operation.iof", "operation.income_tax", "operation.custody", "operation.exit_expense"), nominal_reason),
        ("real_profit_in_exit_date_currency", None if operation is None else operation.real_profit_in_exit_date_currency, "BRL_EXIT_DATE",
         real_quality, ("operation.nominal_profit", "projection_window.price_index_levels"), real_reason),
        ("real_return", None if operation is None else operation.real_return, "ratio",
         real_quality, ("operation.net_redemption", "operation.initial_outflow", "projection_window.price_index_levels"), real_reason),
        ("gross_redemption", None if operation is None else operation.gross_redemption, "BRL",
         _step_quality(evaluation, "Valor bruto de venda"), ("operation.quantity", "operation.exit_pu"), nominal_reason),
        ("iof", None if operation is None else operation.iof, "BRL",
         _step_quality(evaluation, "IOF"), ("operation.gross_redemption", "dates.purchase.settlement_date", "dates.sale.settlement_date"), nominal_reason),
        ("income_tax", None if operation is None else operation.income_tax, "BRL",
         _step_quality(evaluation, "IR"), ("operation.gross_redemption", "operation.tax_cost_basis", "operation.iof"), nominal_reason),
        ("custody", None if operation is None else operation.custody, "BRL",
         _step_quality(evaluation, "Custódia"), ("operation.gross_redemption", "operation.custody_policy"), nominal_reason),
        ("initial_outflow", None if operation is None else operation.initial_outflow,
         "BRL", _step_quality(evaluation, "Desembolso inicial"),
         ("operation.entry_gross", "assumptions.entry_fee"), nominal_reason),
        ("quantity", None if operation is None else operation.quantity, "TITLE",
         entry_quality, ("purchase_sizing.quantity",), _workspace_reason(capabilities.get("purchase_sizing"), "MISSING_QUANTITY")),
        ("entry_pu", evaluation.entry_pu, "BRL_PER_TITLE", entry_quality,
         ("resolved_prices.entry_price", "dates.purchase.settlement_date"), _workspace_reason(capabilities.get("price_resolution"), "MISSING_ENTRY_PRICE")),
        ("exit_pu", evaluation.exit_pu, "BRL_PER_TITLE", exit_quality,
         ("resolved_prices.exit_price", "dates.sale.settlement_date"), _workspace_reason(capabilities.get("price_resolution"), "MISSING_EXIT_PRICE")),
        ("holding_days", days, "calendar_days", settlement_quality,
         ("dates.purchase.settlement_date", "dates.sale.settlement_date"), _workspace_reason(capabilities.get("date_resolution"), "MISSING_DATES")),
    ]
    metrics = [
        _presentation_metric(
            metric_id, value, unit, quality=quality, dependencies=dependencies,
            horizon_days=days if metric_id in {
                "nominal_profit", "nominal_return", "annualized_nominal_return", "net_redemption",
                "real_profit_in_exit_date_currency", "real_return", "gross_redemption", "iof",
                "income_tax", "custody",
            } else None,
            reason=blocked_reason if blocked and metric_id in sale_metrics else reason,
            forced_status=status_for(metric_id, value, reason),
        )
        for metric_id, value, unit, quality, dependencies, reason in specs
    ]
    summary_status = "partial" if any(
        metric["status"] not in {"AVAILABLE", "ESTIMATED"} for metric in metrics
    ) else "ready"
    headline = "nominal_profit" if any(
        item["metric_id"] == "nominal_profit" and item["value"] is not None for item in metrics
    ) else None
    return {"status": summary_status, "metrics": metrics, "headline_metric_id": headline}


def evaluate_resolved_workspace(
    payload: object,
    resolution: Mapping[str, Any],
    *,
    calendar: Any,
    evaluation_cache: Any | None = None,
    evaluation_budget: Any | None = None,
) -> Any:
    """Build the direct domain evaluation from one successfully resolved workspace."""
    from .constraints import evaluate_constraint_set, parse_constraint_set
    from .service import evaluate_scenario

    scenario, context = build_resolved_workspace_financial_inputs(payload, resolution, calendar=calendar)
    if evaluation_cache is None and evaluation_budget is None:
        evaluation = evaluate_scenario(scenario, context)
    else:
        from .surfaces import _RequestEvaluator

        evaluation = _RequestEvaluator(context, evaluation_cache, evaluation_budget).evaluate(scenario)
    constraint_evaluation = None
    goal_gap: tuple[dict[str, Any], ...] = ()
    if isinstance(payload, Mapping) and "constraints" in payload:
        constraint_set = parse_constraint_set(payload["constraints"])
        constraint_evaluation = evaluate_constraint_set(scenario, evaluation, constraint_set)
        goal_gap = _workspace_goal_gap(constraint_evaluation)
    return WorkspaceEvaluation(
        scenario_id=evaluation.scenario_id,
        status=evaluation.status,
        entry_pu=evaluation.entry_pu,
        exit_pu=evaluation.exit_pu,
        operation=evaluation.operation,
        steps=evaluation.steps,
        warnings=evaluation.warnings,
        evidence_statuses=evaluation.evidence_statuses,
        marked_value=evaluation.marked_value,
        constraint_evaluation=constraint_evaluation,
        goal_gap=goal_gap,
        presentation_summary=_workspace_presentation_summary(resolution, evaluation, scenario, context),
        cash_bridge=_workspace_cash_bridge(payload, resolution, scenario, context, evaluation),
        assumptions_summary=_workspace_assumptions_summary(payload, resolution, evaluation, scenario, context),
    )


def resolve_workspace_exit_constraints(
    payload: object,
    resolution: Mapping[str, Any],
    *,
    calendar: Any,
    tick: Decimal | str = "0.01",
    maximum_pu: Decimal | str = "1000000000",
    rate_bounds: tuple[Decimal | str, Decimal | str] | None = None,
    rate_tolerance: Decimal | str = "0.000000001",
    rate_step: Decimal | str | None = None,
) -> Any:
    """Resolve a workspace's combined exit limit with its resolved context."""
    from .constraints import parse_constraint_set, solve_combined_exit_constraints

    if not isinstance(payload, Mapping) or "constraints" not in payload:
        raise ValidationError("MISSING_CONSTRAINTS", "Resolução combinada exige constraints validadas na entrada.")
    scenario, context = build_resolved_workspace_financial_inputs(payload, resolution, calendar=calendar)
    return solve_combined_exit_constraints(
        scenario, parse_constraint_set(payload["constraints"]), context,
        tick=tick, maximum_pu=maximum_pu, rate_bounds=rate_bounds,
        rate_tolerance=rate_tolerance, rate_step=rate_step,
    )


def find_workspace_first_date(
    payload: object,
    resolution: Mapping[str, Any],
    query: Mapping[str, Any],
    *,
    calendar: Any,
    resolve_candidate: Any,
) -> dict[str, Any]:
    """Search eligible sessions by re-resolving each date and its direct MTM."""
    from datetime import timedelta

    from .constraints import evaluate_constraint_set, parse_constraint_set, search_first_date
    from .service import evaluate_scenario

    point_assumptions = payload.get('assumptions') if isinstance(payload, Mapping) else None
    if isinstance(point_assumptions, Mapping) and any(point_assumptions.get(key) is not None
            for key in ('custody_override_brl','institution_net_brl','institution_release_date')):
        raise ValidationError('POINT_OVERRIDE_NOT_TRANSFERABLE',
            'A busca de primeira data não pode reutilizar cobranças ou líquido de uma operação pontual.')
    if not isinstance(payload, Mapping) or "constraints" not in payload:
        raise ValidationError("MISSING_CONSTRAINTS", "A busca de data exige critérios na entrada.")
    normalized = normalize_workspace_input(prepare_workspace_defaults(payload))
    if normalized.instrument is None:
        raise ValidationError("MISSING_INSTRUMENT", "A busca de data exige título e horizonte conhecidos.")
    start, end = query["date_domain"]["start"], query["date_domain"]["end"]
    condition = query["fixed_exit_condition"]
    constraints = parse_constraint_set(payload["constraints"])
    if not constraints.criteria:
        raise ValidationError("MISSING_CONSTRAINTS", "A busca de data não aceita conjunto de metas vazio.")

    calendar_start, calendar_end = date(2000, 1, 1), date(2085, 12, 31)
    clipped_start, clipped_end = max(start, calendar_start), min(end, calendar_end)
    horizon = (normalized.instrument.maturity_date
               if normalized.instrument.family is ProductFamily.IPCA_PRINCIPAL
               else normalized.instrument.first_income_date)
    if horizon is None:
        raise ValidationError("INVALID_INSTRUMENT", "RendA+ exige a data da primeira parcela.")
    clipped_end = min(clipped_end, horizon - timedelta(days=1))
    exclusions: list[dict[str, str]] = []
    if start < calendar_start:
        exclusions.append({"start": start.isoformat(), "end": min(end, calendar_start - timedelta(days=1)).isoformat(),
                           "reason": "Fora da cobertura do calendário financeiro projetado (2000–2085)."})
    if end > calendar_end:
        exclusions.append({"start": max(start, calendar_end + timedelta(days=1)).isoformat(), "end": end.isoformat(),
                           "reason": "Fora da cobertura do calendário financeiro projetado (2000–2085)."})
    if end >= horizon:
        exclusions.append({"start": max(start, horizon).isoformat(), "end": end.isoformat(),
                           "reason": "Data fora do horizonte de negociação do produto; vencimento/primeira parcela é exclusivo."})

    effective_start = clipped_start
    purchase = (resolution.get("dates") or {}).get("purchase")
    if isinstance(purchase, Mapping) and purchase.get("proposed_order_date"):
        effective_start = max(effective_start, date.fromisoformat(purchase["proposed_order_date"]) + timedelta(days=1))
    sale_template = (resolution.get("dates") or {}).get("sale")
    minimum_eligible = sale_template.get("minimum_eligible_order_date") if isinstance(sale_template, Mapping) else None
    if minimum_eligible:
        effective_start = max(effective_start, date.fromisoformat(minimum_eligible))
    if effective_start > clipped_start and clipped_start <= clipped_end:
        exclusions.append({"start": clipped_start.isoformat(), "end": min(clipped_end, effective_start - timedelta(days=1)).isoformat(),
                           "reason": "Antes da primeira data de venda elegível após compra e carência do produto."})

    def sessions():
        cursor = effective_start
        while cursor <= clipped_end:
            if calendar.is_session(cursor):
                yield cursor
            cursor += timedelta(days=1)

    assumptions = _thaw_json(normalized.assumptions)
    settlement_profile = assumptions.get("settlement_profile")
    explicit_sale_date = normalized.sale_date

    def evaluate_candidate(order_date: date) -> dict[str, Any]:
        if settlement_profile == "EXPLICIT" and order_date != explicit_sale_date:
            return {"status": "UNKNOWN", "reason": "Perfil EXPLICIT declara liquidação somente para a data de venda original; não é seguro reutilizá-la em outra data."}
        candidate_input = dict(payload)
        candidate_input["sale_date"] = order_date.isoformat()
        if normalized.knowledge is not None and order_date > normalized.knowledge.date:
            # FIRST_DATE explicitly supplies a fixed exit hypothesis and date
            # window; future candidates are therefore modeled as hypothetical,
            # never as observed orders or causal market facts.
            candidate_input["intent"] = "HYPOTHETICAL"
        candidate_input["exit_price"] = (
            {"mode": "MANUAL_PU", "pu": str(condition["value"])}
            if condition["unit"] == "BRL_PER_TITLE"
            else {"mode": "MANUAL_RATE", "annual_real_rate": str(condition["value"]), "quoted_side": "SELL"}
        )
        try:
            candidate_resolution = resolve_candidate(candidate_input)
        except ValidationError as exc:
            return {"status": "UNKNOWN", "reason": str(exc).partition(":")[2].strip() or exc.code}
        dates = candidate_resolution.get("dates") or {}
        sale = dates.get("sale") if isinstance(dates, Mapping) else None
        sale_capability = candidate_resolution.get("capabilities", {}).get("date_resolution", {})
        sale_reason = sale.get("reason") if isinstance(sale, Mapping) else None
        sale_reason_code = sale_reason.get("code") if isinstance(sale_reason, Mapping) else None
        sale_reason_message = sale_reason.get("message") if isinstance(sale_reason, Mapping) else None
        if not isinstance(sale, Mapping) or not sale.get("settlement_date"):
            code = ((sale_capability.get("reason") or {}).get("code")
                    if isinstance(sale_capability, Mapping) else None)
            if code in {"OUTSIDE_HORIZON", "LOCKED", "INVALID_DATES"}:
                return {"status": "EXCLUDED", "reason": sale_reason_message or sale_reason_code or code}
            return {"status": "UNKNOWN", "reason": (sale_capability.get("reason") or {}).get("message")
                    or "Data de liquidação não pôde ser resolvida para este candidato."}
        settlement_date = date.fromisoformat(sale["settlement_date"])
        if sale.get("status") == "blocked_policy" or sale_reason_code in {"OUTSIDE_HORIZON", "LOCKED"}:
            return {"status": "EXCLUDED", "settlement_date": settlement_date.isoformat(),
                    "reason": sale_reason_message or sale_reason_code or "Venda fora da elegibilidade financeira do produto."}
        try:
            scenario, context = build_resolved_workspace_financial_inputs(
                candidate_input, candidate_resolution, calendar=calendar,
                surface_condition={
                    "order_date": order_date, "settlement_date": settlement_date,
                    "value": condition["value"], "unit": condition["unit"],
                },
            )
            financial = evaluate_scenario(scenario, context)
            criteria_evaluation = evaluate_constraint_set(scenario, financial, constraints)
        except ValidationError as exc:
            return {"status": "UNKNOWN", "settlement_date": settlement_date.isoformat(),
                    "reason": str(exc).partition(":")[2].strip() or exc.code}
        return {
            "status": "EVALUATED", "settlement_date": settlement_date.isoformat(),
            "financial_result": financial,
            "constraint_evaluation": criteria_evaluation,
        }

    budget = EvaluationBudget(
        max_evaluations=query["max_evaluations"],
        deadline_seconds=query["deadline_ms"] / 1000,
    )
    result = search_first_date(
        sessions(), constraints, evaluate_candidate, budget=budget,
        fixed_exit_condition={"value": condition["value"], "unit": condition["unit"]},
        date_domain={"start": start, "end": end},
    )
    result["calendar_id"] = calendar.calendar_id
    result["calendar_warning"] = calendar.warning
    result["eligibility_exclusions"] = exclusions
    calendar_gap_before = start < calendar_start
    calendar_gap_after = end > calendar_end
    if calendar_gap_before:
        entry = {
            "start": start.isoformat(),
            "end": min(end, calendar_start - timedelta(days=1)).isoformat(),
            "reason": "Sessões anteriores estão fora da cobertura do calendário financeiro projetado; a primeira data não pode ser verificada.",
        }
        result["previous_coverage"]["unknown_ranges"] = [entry]
        result["previous_coverage"]["complete_before_found_date"] = False
        result["coverage"]["exhaustive_in_declared_domain"] = False
        if result.get("found_date"):
            result["status"] = "INCOMPLETE"
            result["first_verified"] = False
            result["reason"] = entry["reason"]
        elif result["status"] in ("NO_SOLUTION", "OUTSIDE_DOMAIN"):
            result["status"] = "UNKNOWN"
            result["reason"] = "Parte inicial do domínio está fora da cobertura do calendário; não é possível provar que nenhuma data atende."
    if calendar_gap_after and not result.get("found_date"):
        result["status"] = "INCOMPLETE"
        result["coverage"]["exhaustive_in_declared_domain"] = False
        result["incomplete_reason"] = "CALENDAR_OUTSIDE_DOMAIN"
        result["reason"] = "Parte final do domínio está fora da cobertura do calendário financeiro projetado."
    return result


def find_workspace_entry_boundary(
    payload: object,
    resolution: Mapping[str, Any],
    query: Mapping[str, Any],
    *,
    calendar: Any,
    resolve_candidate: Any,
) -> dict[str, Any]:
    """Re-resolve a frozen sale scenario for each hypothetical entry PU."""
    if isinstance(query, Mapping) and "rate_domain" in query:
        return find_workspace_rate_boundary(
            payload, resolution, query, calendar=calendar, resolve_candidate=resolve_candidate,
        )

    from .constraints import EntrySearchPoint, parse_constraint_set, search_maximum_entry_pu
    from .operation import size_purchase_from_budget
    from .service import evaluate_scenario

    normalized = normalize_workspace_input(prepare_workspace_defaults(payload))
    if normalized.capital is None or normalized.entry_price is None:
        raise ValidationError("WORKSPACE_NOT_READY", "Capital e modo de compra são necessários para buscar PU de entrada.")
    if not isinstance(query, Mapping):
        raise ValidationError("INVALID_QUERY", "ENTRY_BOUNDARY exige um objeto de consulta.")
    mode = query.get("entry_mode")
    if mode != normalized.capital.mode.value:
        raise ValidationError("ENTRY_MODE_MISMATCH", "A busca precisa respeitar o modo de capital da operação.")
    if "constraints" not in payload:
        raise ValidationError("MISSING_CONSTRAINTS", "ENTRY_BOUNDARY exige critérios explícitos.")
    constraints = parse_constraint_set(payload["constraints"])
    if not constraints.criteria:
        raise ValidationError("MISSING_CONSTRAINTS", "ENTRY_BOUNDARY exige ao menos um critério.")

    assumptions = normalized.assumptions
    domain = query.get("pu_domain")
    if not isinstance(domain, Mapping) or set(domain) != {"minimum", "maximum", "tick"}:
        raise ValidationError("INVALID_TARGET_DOMAIN", "pu_domain exige minimum, maximum e tick.")
    max_evaluations = query.get("max_evaluations", WORKSPACE_SEARCH_BUDGET["max_evaluations"])
    deadline_ms = query.get("deadline_ms", 10_000)
    if type(max_evaluations) is not int or not 1 <= max_evaluations <= WORKSPACE_SEARCH_BUDGET["max_evaluations"]:
        raise ValidationError("INVALID_SEARCH_BUDGET", "max_evaluations precisa ficar entre 1 e 4096.")
    if type(deadline_ms) is not int or not 1 <= deadline_ms <= 10_000:
        raise ValidationError("INVALID_SEARCH_DEADLINE", "deadline_ms precisa ficar entre 1 e 10000.")
    unsupported_reason = None
    if assumptions.get("tax_cost_basis_brl") is not None:
        unsupported_reason = (
            "A base fiscal manual pertence à compra original e não pode ser reaproveitada numa nova hipótese de entrada."
        )
        reason_code = "MANUAL_TAX_BASIS_NOT_TRANSFERABLE"
    elif mode == "BUDGET" and (
        assumptions.get("custody_override_brl") is not None
        or assumptions.get("institution_net_brl") is not None
    ):
        unsupported_reason = (
            "Custódia ou resgate institucional informado para a quantidade original não pode ser escalado para outra quantidade."
        )
        reason_code = "POSITION_OVERRIDE_NOT_TRANSFERABLE"
    else:
        reason_code = None
    if unsupported_reason is not None:
        return {
            "status": "UNSUPPORTED", "entry_mode": mode,
            "maximum_entry_pu": None, "candidate": None, "verification": None,
            "domain": {"minimum_pu": str(domain["minimum"]), "maximum_pu": str(domain["maximum"]),
                       "tick": str(domain["tick"])},
            "coverage": {"method": "not_started", "evaluated_candidates": 0,
                         "complete_for_maximum": False, "proof_scope": "A hipótese não é transferível dos dados fornecidos."},
            "reason_code": reason_code, "reason": unsupported_reason,
        }

    if not callable(resolve_candidate):
        raise ValidationError("INVALID_ENTRY_RESOLVER", "ENTRY_BOUNDARY exige um resolvedor local por candidato.")
    minimum_pu = Decimal(str(domain["minimum"]))
    maximum_pu = Decimal(str(domain["maximum"]))
    tick = Decimal(str(domain["tick"]))
    minimum_ticks, maximum_ticks = minimum_pu / tick, maximum_pu / tick
    if (minimum_ticks != minimum_ticks.to_integral_value()
            or maximum_ticks != maximum_ticks.to_integral_value()):
        raise ValidationError("INVALID_TARGET_DOMAIN", "Limites do domínio precisam coincidir com o tick de PU.")

    maximum_affordable: Decimal | None = None
    if mode == "BUDGET":
        fee = assumptions.get("entry_fee", {})
        fixed_fee, proportional_fee = fee.get("fixed_brl"), fee.get("proportional_rate")
        if fixed_fee is None or proportional_fee is None:
            raise ValidationError("WORKSPACE_NOT_READY", "Custos de entrada fixo e proporcional precisam estar resolvidos.")

        def affordable(ticks: int) -> bool:
            try:
                size_purchase_from_budget(
                    normalized.capital.value, tick * ticks, "0.01", fixed_fee, proportional_fee,
                )
                return True
            except ValidationError as exc:
                if exc.code == "INSUFFICIENT_BUDGET":
                    return False
                raise

        low, high = int(minimum_ticks), int(maximum_ticks)
        if affordable(high):
            maximum_affordable = maximum_pu
        elif not affordable(low):
            maximum_affordable = tick * (low - 1)
        else:
            while low < high:
                middle = (low + high + 1) // 2
                if affordable(middle):
                    low = middle
                else:
                    high = middle - 1
            maximum_affordable = tick * low
        if maximum_affordable < minimum_pu:
            return {
                "status": "OUTSIDE_DOMAIN", "entry_mode": mode,
                "maximum_entry_pu": None, "candidate": None, "verification": None,
                "domain": {"minimum_pu": str(minimum_pu), "maximum_pu": str(maximum_pu),
                           "effective_maximum_pu": str(maximum_affordable), "tick": str(tick)},
                "coverage": {"method": "purchase_sizing_boundary", "evaluated_candidates": 0,
                             "complete_for_maximum": True, "excluded_above_effective_maximum": "INSUFFICIENT_BUDGET"},
                "reason": "O orçamento não compra a menor quantidade em nenhuma PU dentro do domínio declarado.",
            }

    # The original entry quote may be unaffordable or missing an anchor. Seed
    # the fixed exit context from the lowest declared, affordable PU instead.
    seed_payload = _thaw_json(payload)
    seed_payload["entry_price"] = {"mode": "MANUAL_PU", "pu": str(minimum_pu)}
    seed_payload["intent"] = "HYPOTHETICAL"
    seed_resolution = resolve_candidate(seed_payload)
    base_scenario, _ = build_resolved_workspace_financial_inputs(
        seed_payload, seed_resolution, calendar=calendar,
    )
    fixed_exit = {
        "sale_order_date": base_scenario.exit.order_date.isoformat(),
        "sale_settlement_date": base_scenario.exit.settlement_date.isoformat(),
        "exit_pu": None if base_scenario.exit.unit_price is None else str(base_scenario.exit.unit_price),
        "exit_rate": None if base_scenario.exit.real_yield is None else str(base_scenario.exit.real_yield),
        "exit_side": base_scenario.exit.quoted_side.value,
    }
    budget = EvaluationBudget(
        max_evaluations=max_evaluations,
        deadline_seconds=deadline_ms / 1000,
    )

    def evaluate_entry_pu(entry_pu: Decimal) -> EntrySearchPoint:
        candidate_payload = _thaw_json(payload)
        candidate_payload["entry_price"] = {"mode": "MANUAL_PU", "pu": str(entry_pu)}
        candidate_payload["intent"] = "HYPOTHETICAL"
        try:
            candidate_resolution = resolve_candidate(candidate_payload)
            scenario, context = build_resolved_workspace_financial_inputs(
                candidate_payload, candidate_resolution, calendar=calendar,
            )
            financial = evaluate_scenario(scenario, context)
            sizing = candidate_resolution.get("purchase_sizing", {})
            remainder_raw = sizing.get("cash_remainder")
            remainder = Decimal(remainder_raw["value"]) if isinstance(remainder_raw, Mapping) and remainder_raw.get("value") is not None else None
            return EntrySearchPoint(
                "EVALUATED", scenario, financial, scenario.entry.quantity, remainder,
            )
        except ValidationError as exc:
            return EntrySearchPoint("UNKNOWN", reason=f"{exc.code}: {exc}")

    result = search_maximum_entry_pu(
        base_scenario, constraints, evaluate_entry_pu,
        entry_mode=mode, budget=budget, pu_domain=domain,
        maximum_affordable_pu=maximum_affordable,
        fixed_entry_fee=assumptions["entry_fee"]["fixed_brl"],
    )
    result["fixed_exit_condition"] = fixed_exit
    result["hypothesis_quality"] = "HYPOTHETICAL"
    return result


def find_workspace_rate_boundary(
    payload: object,
    resolution: Mapping[str, Any],
    query: Mapping[str, Any],
    *,
    calendar: Any,
    resolve_candidate: Any,
) -> dict[str, Any]:
    """Resolve a goal boundary by purchase or sale rate inside a declared domain.

    Entry boundaries enumerate the declared rate grid and fully re-resolve the
    workspace at every point. Exit boundaries reuse the combined PU constraint
    solver and the established monotonicity-checking rate inversion.
    """
    from decimal import ROUND_CEILING, ROUND_FLOOR, localcontext

    from .constraints import evaluate_constraint_set, parse_constraint_set, _rate_solution_dict
    from .service import evaluate_scenario
    from .targets import TargetStatus, solve_rate_for_pu_limit

    if not isinstance(payload, Mapping) or "constraints" not in payload:
        raise ValidationError("MISSING_CONSTRAINTS", "A fronteira de taxa exige metas explícitas.")
    if not callable(resolve_candidate):
        raise ValidationError("INVALID_ENTRY_RESOLVER", "A fronteira de taxa exige resolução local por candidato.")
    side = query.get("boundary_side")
    if side not in {"ENTRY", "EXIT"}:
        raise ValidationError("INVALID_RATE_SIDE", "boundary_side precisa ser ENTRY ou EXIT.")
    raw_domain = query.get("rate_domain")
    if not isinstance(raw_domain, Mapping) or set(raw_domain) != {"minimum", "maximum", "step"}:
        raise ValidationError("INVALID_RATE_DOMAIN", "rate_domain exige minimum, maximum e step.")
    minimum, maximum, step = (Decimal(str(raw_domain[key])) for key in ("minimum", "maximum", "step"))
    intervals = (maximum - minimum) / step if step > 0 else Decimal(0)
    if minimum <= -1 or maximum <= minimum or step <= 0 or intervals != intervals.to_integral_value():
        raise ValidationError("INVALID_RATE_DOMAIN", "O domínio de taxa precisa ser crescente, maior que −100% e alinhado ao passo.")
    rate_points = int(intervals) + 1
    if rate_points > 101:
        raise ValidationError("INVALID_RATE_DOMAIN", "O domínio de taxa pode conter no máximo 101 pontos de verificação.")
    max_evaluations = query.get("max_evaluations", WORKSPACE_SEARCH_BUDGET["max_evaluations"])
    deadline_ms = query.get("deadline_ms", int(WORKSPACE_SEARCH_BUDGET["deadline_seconds"] * 1000))
    if type(max_evaluations) is not int or not 1 <= max_evaluations <= WORKSPACE_SEARCH_BUDGET["max_evaluations"]:
        raise ValidationError("INVALID_SEARCH_BUDGET", "max_evaluations precisa ficar entre 1 e 4096.")
    if type(deadline_ms) is not int or not 1 <= deadline_ms <= int(WORKSPACE_SEARCH_BUDGET["deadline_seconds"] * 1000):
        raise ValidationError("INVALID_SEARCH_DEADLINE", "deadline_ms precisa ficar entre 1 e 10000.")
    if not parse_constraint_set(payload["constraints"]).criteria:
        raise ValidationError("MISSING_CONSTRAINTS", "A fronteira de taxa exige ao menos uma meta.")

    def serialized_rate_solution(solution: Any) -> dict[str, Any]:
        return _rate_solution_dict(solution)

    def rate_candidate(rate: Decimal) -> dict[str, Any]:
        candidate_input = _thaw_json(payload)
        candidate_input["intent"] = "HYPOTHETICAL"
        if side == "ENTRY":
            candidate_input["entry_price"] = {"mode": "MANUAL_RATE", "annual_real_rate": str(rate)}
        else:
            candidate_input["exit_price"] = {
                "mode": "MANUAL_RATE", "annual_real_rate": str(rate), "quoted_side": "SELL",
            }
        try:
            candidate_resolution = resolve_candidate(candidate_input)
            scenario, context = build_resolved_workspace_financial_inputs(
                candidate_input, candidate_resolution, calendar=calendar,
            )
            financial = evaluate_scenario(scenario, context)
            evaluation = evaluate_constraint_set(
                scenario, financial, parse_constraint_set(candidate_input["constraints"]),
            )
        except ValidationError as exc:
            return {
                "rate": str(rate), "rate_unit": "ratio", "status": "UNKNOWN",
                "constraint_evaluation": None,
                "reason": str(exc).partition(":")[2].strip() or exc.code,
            }
        unit_price = financial.entry_pu if side == "ENTRY" else financial.exit_pu
        return {
            "rate": str(rate), "rate_unit": "ratio",
            "unit_price": None if unit_price is None else str(unit_price),
            "unit_price_unit": "BRL_PER_TITLE",
            "status": evaluation.status.value, "met": evaluation.met,
            "constraint_evaluation": evaluation.to_dict(),
        }

    started_at = monotonic()
    pu_boundary: dict[str, Any] | None = None
    combined_limit: dict[str, Any] | None = None
    if side == "ENTRY":
        normalized = normalize_workspace_input(prepare_workspace_defaults(payload))
        if normalized.capital is None or normalized.entry_price is None:
            raise ValidationError("WORKSPACE_NOT_READY", "Capital e modo de compra são necessários para buscar taxa de entrada.")
        if query.get("entry_mode") != normalized.capital.mode.value:
            raise ValidationError("ENTRY_MODE_MISMATCH", "A busca por taxa precisa respeitar o modo de capital da operação.")
        entry_mode = normalized.capital.mode.value
        previous: dict[str, Any] | None = None
        unknown_before = False
        evaluated_points = 0
        for index in range(rate_points):
            if evaluated_points >= max_evaluations:
                break
            rate = minimum + step * index
            current = rate_candidate(rate)
            evaluated_points += 1
            if current.get("status") == "UNKNOWN":
                unknown_before = True
            if current.get("status") == "MET":
                verified_neighbor = previous is not None and previous.get("status") == "NOT_MET"
                domain_minimum = index == 0
                complete = (domain_minimum or verified_neighbor) and not unknown_before
                verification_status = (
                    "DOMAIN_MINIMUM" if domain_minimum and complete
                    else "PROVEN_GRID_STEP" if verified_neighbor and complete
                    else "CANDIDATE_ONLY"
                )
                result_status = "SOLVED" if complete else "INCOMPLETE"
                reason = (
                    "A menor taxa do domínio foi reavaliada diretamente e atende às metas."
                    if verification_status == "DOMAIN_MINIMUM" else
                    "A menor taxa atendida no passo declarado e a taxa imediatamente anterior foram reavaliadas diretamente."
                    if verification_status == "PROVEN_GRID_STEP" else
                    "A taxa candidata atende diretamente, mas falta cobertura suficiente para confirmar a menor taxa do domínio."
                )
                return {
                    "status": result_status, "boundary_status": verification_status,
                    "boundary_side": side, "boundary_rate": str(rate), "boundary_rate_unit": "ratio",
                    "minimum_entry_rate": str(rate), "maximum_exit_rate": None,
                    "entry_mode": entry_mode,
                    "rate_domain": {"minimum": str(minimum), "maximum": str(maximum), "step": str(step), "unit": "ratio"},
                    "unit_price_at_rate": current.get("unit_price"),
                    "rate_solution": {
                        "status": verification_status, "side": side, "rate": str(rate),
                        "pu_at_rate": current.get("unit_price"),
                        "adjacent_rate": None if previous is None else previous.get("rate"),
                        "adjacent_pu": None if previous is None else previous.get("unit_price"),
                        "precision": {"kind": "DECLARED_RATE_STEP", "step": str(step)},
                        "evaluations": evaluated_points,
                    },
                    "candidate": current,
                    "violation_neighbor": previous,
                    "verification_status": verification_status,
                    "reason": reason,
                    "coverage": {
                        "method": "direct_rate_grid_with_fresh_workspace_dimensioning",
                        "rate_points_checked": evaluated_points,
                        "evaluated_candidates": evaluated_points,
                        "checked_prefix_end": str(rate),
                        "complete_for_minimum_in_declared_domain": complete,
                        "complete_in_declared_domain": index == rate_points - 1,
                        "elapsed_ms": int((monotonic() - started_at) * 1000),
                        "proof_scope": "Menor ponto atendido na grade discreta: todos os pontos anteriores foram reavaliados sem lacunas; quantidade, custos, impostos e metas foram recalculados. Pontos posteriores não são necessários para provar o mínimo.",
                    },
                }
            previous = current
            elapsed_ms = int((monotonic() - started_at) * 1000)
            if elapsed_ms >= deadline_ms:
                break

        elapsed_ms = int((monotonic() - started_at) * 1000)
        complete_domain = evaluated_points == rate_points and not unknown_before
        if not complete_domain:
            status, reason = "INCOMPLETE", (
                "O limite de tempo terminou antes de cobrir o domínio de taxas declarado."
                if elapsed_ms >= deadline_ms else
                "O orçamento de avaliações terminou antes de cobrir o domínio de taxas declarado."
            )
        elif unknown_before:
            status, reason = "UNKNOWN", "Pelo menos uma taxa do domínio não pôde ser avaliada diretamente."
        else:
            status, reason = "NO_SOLUTION", "Nenhuma taxa do domínio discreto declarado atende a todas as metas."
        return {
            "status": status, "boundary_status": status, "boundary_side": side,
            "minimum_entry_rate": None, "maximum_exit_rate": None,
            "rate_domain": {"minimum": str(minimum), "maximum": str(maximum), "step": str(step), "unit": "ratio"},
            "rate_solution": {"status": status, "side": side, "rate": None,
                              "precision": {"kind": "DECLARED_RATE_STEP", "step": str(step)},
                              "evaluations": evaluated_points},
            "candidate": None, "violation_neighbor": None,
            "verification_status": status, "reason": reason,
            "coverage": {"method": "direct_rate_grid_with_fresh_workspace_dimensioning",
                         "rate_points_checked": evaluated_points, "evaluated_candidates": evaluated_points,
                         "complete_for_minimum_in_declared_domain": complete_domain,
                         "complete_in_declared_domain": complete_domain, "elapsed_ms": elapsed_ms,
                         "proof_scope": "Todos os pontos da grade declarada foram avaliados diretamente; nenhuma conclusão se estende a taxas entre os pontos."},
        }
    else:
        combined = resolve_workspace_exit_constraints(
            payload, resolution, calendar=calendar, rate_bounds=(minimum, maximum), rate_step=step,
        )
        combined_limit = combined.to_dict()
        solution = combined.rate_solution
        pu_boundary = combined_limit
        if combined.status.value != "SOLVED":
            status = "NO_SOLUTION" if combined.status.value in {"INFEASIBLE", "NO_FINANCIAL_BOUND"} else "INCOMPLETE"
            return {
                "status": status, "boundary_side": side,
                "rate_domain": {"minimum": str(minimum), "maximum": str(maximum), "step": str(step), "unit": "ratio"},
                "pu_boundary": combined_limit, "reason": combined.reason,
                "coverage": {"method": "combined_exit_pu_boundary_then_rate_inversion",
                             "evaluated_candidates": combined.evaluations,
                             "complete_in_declared_domain": False},
            }
        if solution is None:
            return {
                "status": "NO_SOLUTION", "boundary_side": side,
                "rate_domain": {"minimum": str(minimum), "maximum": str(maximum), "step": str(step), "unit": "ratio"},
                "pu_boundary": combined_limit, "reason": combined.reason or "As metas não definem limite máximo de taxa de venda.",
                "coverage": {"method": "combined_exit_pu_boundary_then_rate_inversion",
                             "evaluated_candidates": combined.evaluations,
                             "complete_in_declared_domain": False},
            }

    rate_status = solution.status.value
    if solution.rate is None:
        status = "NO_SOLUTION" if solution.status is TargetStatus.NO_ROOT else (
            "INCOMPLETE" if solution.status in {TargetStatus.AMBIGUOUS_ROOT, TargetStatus.VERIFICATION_FAILED} else "UNKNOWN"
        )
        return {
            "status": status, "boundary_status": rate_status, "boundary_side": side,
            "rate_domain": {"minimum": str(minimum), "maximum": str(maximum), "step": str(step), "unit": "ratio"},
            "rate_solution": serialized_rate_solution(solution), "pu_boundary": pu_boundary,
            "reason": solution.reason or "A conversão de PU para taxa não encontrou fronteira verificável.",
            "coverage": {"method": "pu_boundary_then_rate_inversion", "rate_points_checked": rate_points,
                         "evaluated_candidates": solution.evaluations,
                         "complete_in_declared_domain": False},
        }

    quantum = Decimal("0.0000000001")
    if solution.status is TargetStatus.ALL_DOMAIN:
        candidate_rate = minimum if side == "ENTRY" else maximum
    else:
        with localcontext() as context_decimal:
            context_decimal.prec = max(context_decimal.prec, len(solution.rate.as_tuple().digits) + 14)
            candidate_rate = solution.rate.quantize(
                quantum, rounding=ROUND_CEILING if side == "ENTRY" else ROUND_FLOOR,
            )
    candidate = rate_candidate(candidate_rate)
    neighbor_rate = solution.adjacent_rate
    neighbor = rate_candidate(neighbor_rate) if neighbor_rate is not None else None
    candidate_met = candidate.get("status") == "MET"
    neighbor_violates = neighbor is not None and neighbor.get("status") == "NOT_MET"
    all_domain = solution.status is TargetStatus.ALL_DOMAIN
    if not candidate_met:
        status, verification_status = "VERIFICATION_FAILED", "CANDIDATE_NOT_MET"
        reason = "A avaliação direta no rate exibido não confirmou todas as metas."
    elif all_domain:
        status, verification_status = "SOLVED", "ALL_DOMAIN"
        reason = "Todas as metas foram reavaliadas diretamente na taxa da extremidade e toda a faixa declarada atende à fronteira financeira."
    elif neighbor_violates:
        status, verification_status = "SOLVED", "PROVEN"
        reason = "Taxa exibida e metas confirmadas diretamente; o vizinho verificado no lado de violação falha no conjunto."
    else:
        status, verification_status = "INCOMPLETE", "CANDIDATE_ONLY"
        reason = "A taxa candidata atende diretamente, mas o vizinho do lado de violação não confirmou a fronteira dentro da precisão declarada."

    elapsed_ms = int((monotonic() - started_at) * 1000)
    if elapsed_ms > deadline_ms:
        status, verification_status = "INCOMPLETE", "DEADLINE_EXCEEDED"
        reason = "A fronteira candidata foi avaliada, mas o limite de tempo terminou antes da confirmação do domínio completo."
    rate_text = str(candidate_rate)
    return {
        "status": status,
        "boundary_status": rate_status,
        "boundary_side": side,
        "rate_domain": {"minimum": str(minimum), "maximum": str(maximum), "step": str(step), "unit": "ratio"},
        "boundary_rate": rate_text,
        "boundary_rate_unit": "ratio",
        "minimum_entry_rate": rate_text if side == "ENTRY" else None,
        "maximum_exit_rate": rate_text if side == "EXIT" else None,
        "unit_price_at_rate": candidate.get("unit_price"),
        "rate_solution": serialized_rate_solution(solution),
        "candidate": candidate,
        "violation_neighbor": neighbor,
        "verification_status": verification_status,
        "pu_boundary": pu_boundary,
        "reason": reason,
        "coverage": {
            "method": "quantity_aware_pu_boundary_then_direct_rate_verification",
            "rate_points_checked": rate_points,
            "evaluated_candidates": (
                4 + solution.evaluations
                + int((pu_boundary.get("coverage") or {}).get("evaluated_candidates", 0))
                if side == "ENTRY" else combined.evaluations + 2
            ),
            "elapsed_ms": elapsed_ms,
            "complete_in_declared_domain": status == "SOLVED",
            "proof_scope": "PU e metas foram reavaliados na taxa exibida e no vizinho do lado de violação; monotonicidade do PU foi verificada na grade de taxas declarada e o bracket foi refinado. Não certifica oscilações entre pontos da grade.",
        },
    }


def build_workspace_surface(
    payload: object,
    resolution: Mapping[str, Any],
    surface: Mapping[str, Any],
    *,
    calendar: Any,
    input_fingerprint: str,
    evaluation_cache: Any | None = None,
    evaluation_budget: Any | None = None,
    fixed_position_frontier: Mapping[str, Any] | None = None,
) -> dict[str, Any]:
    """Project one explicit v2 domain through the existing direct surface engines."""
    from hashlib import sha256

    from .surfaces import (
        ExitObservation, SurfaceEvaluationBudgetExceeded, SurfaceMetric, SurfaceMetricValue, SurfacePoint,
        SurfaceResult, SurfaceSession, SurfaceStatus, build_date_curve,
        build_decision_map, build_rate_curve, build_rate_date_map,
    )

    empty_reason = surface.get("_empty_domain_reason")
    if isinstance(empty_reason, Mapping):
        selected_date = surface["selected_order_date"]
        selected_value = surface["selected_value"]
        unit = surface["value_unit"]
        metric_id = surface["metric_id"]
        empty_analysis = normalize_workspace_input(prepare_workspace_defaults(payload)).analysis_context
        empty_domain = {
            "date_range": {
                "start": surface["date_range"][0].isoformat(),
                "end": surface["date_range"][1].isoformat(),
            },
            "requested_date_range": (
                {"start": empty_analysis.start.isoformat(), "end": empty_analysis.end.isoformat()}
                if empty_analysis is not None and empty_analysis.start is not None and empty_analysis.end is not None
                else None
            ),
            "timeline_exclusions": surface.get("timeline_exclusions", []),
            "candidate_order_dates": [], "sampled_order_dates": [],
            "candidate_values": [], "sampled_values": [], "unit": unit,
            "purpose": "visual", "proof_domain": None, "policy_dates": [],
        }
        empty_result = {
            "mode": surface["mode"], "metric_id": metric_id,
            "unit": surface["metric_unit"], "status": "partial",
            "selected": {"order_date": selected_date.isoformat(), "value": str(selected_value), "unit": unit},
            "selection_assumption": {
                "kind": "EXIT_RATE" if unit == "ratio" else "EXIT_PRICE",
                "quality": "HYPOTHETICAL",
                "source": surface.get("selected_value_source", "USER_SELECTED"),
            },
            "requested_points": 0, "evaluated_points": 0, "new_evaluations": 0,
            "reused_points": 0, "resolution": {"dates": 0, "values": 0},
            "cache_id": None, "points": [],
            "coverage": {
                "status": "OUTSIDE_DOMAIN", "domain": empty_domain,
                "resolution": {"dates": 0, "values": 0}, "complete": False,
                "evaluated_points": 0, "new_evaluations": 0, "reused_points": 0,
                "requested_points": 0, "resolved_points": 0,
                "method": "no_eligible_sessions", "max_evaluations": 512 if surface.get("g4_frontier") else 256,
                "deadline_ms": None, "omitted_ranges": [], "omitted_dates": [],
                "omitted_values": [], "reason": empty_reason,
            },
        }
        if surface.get("g4_frontier"):
            from .frontiers import analyze_g4_frontiers

            empty_analysis_result = analyze_g4_frontiers([], order_dates=[], values=[])
            empty_result["frontiers"] = empty_analysis_result["frontiers"]
            empty_result["frontier_reference"] = {
                "status": "unavailable", "reason": empty_reason,
                "common_horizon": None,
            }
            if evaluation_budget is not None:
                empty_result["computation_budget"] = evaluation_budget.to_dict()
        return empty_result

    selected_date = surface["selected_order_date"]
    selected_value = surface["selected_value"]
    dates = surface["order_dates"]
    values = surface["values"]
    metric = SurfaceMetric(surface["metric_id"])
    unit = surface["value_unit"]
    normalized = normalize_workspace_input(prepare_workspace_defaults(payload))
    assumptions = _thaw_json(normalized.assumptions)
    profile = assumptions.get("settlement_profile")
    explicit_profile = profile == "EXPLICIT"
    same_day = profile == "SIMULATED_BUY_D1_SELL_D0"
    selected_settlement = surface["selected_settlement_date"]

    scenario = surface["_scenario"]
    context = surface["_context"]
    if context.custody_override is not None or context.institution_net_override is not None:
        raise ValidationError(
            "SURFACE_OVERRIDE_UNSUPPORTED",
            "Custódia e líquido informados para um ponto não podem ser replicados no domínio da superfície.",
        )

    def settlement_for(order_date: date) -> date:
        if order_date == selected_date:
            return selected_settlement
        if not calendar.is_session(order_date):
            return order_date
        if explicit_profile:
            raise ValidationError(
                "SURFACE_SETTLEMENT_UNAVAILABLE",
                "Datas de liquidação explícitas só autorizam projetar a data declarada; não há liquidação para outra data.",
            )
        return order_date if same_day else calendar.next_session(order_date)

    # Reference curves have their own dated support: they need purchase cost
    # and price indexes, not a successfully priced sale at each exit rate.
    overlay_dates = []
    if (surface["mode"] == "RATE_DATE_MAP" and fixed_position_frontier is None
            and normalized.analysis_context is not None
            and normalized.analysis_context.is_operation_window and dates
            and not context.intermediate_paid_costs and not explicit_profile):
        from .surfaces import _date_status
        # Sample the shared input window first so A/B keep the same support
        # dates even when their eligible sale horizons differ.
        cursor = normalized.analysis_context.start or min(dates)
        last = normalized.analysis_context.end or max(dates)
        candidates = []
        while cursor <= last:
            if calendar.is_session(cursor):
                candidates.append(cursor)
            cursor += timedelta(days=1)
        sampled = candidates if len(candidates) <= 119 else [candidates[i * (len(candidates) - 1) // 118] for i in range(119)]
        # Preserve every calculated date, including gaps in sale pricing. The
        # remaining reference samples only fill the unused bounded support.
        selected = set(dates)
        extra = sorted(set(sampled) - selected)
        room = 121 - len(selected)
        if len(extra) > room:
            extra = [extra[i * (len(extra) - 1) // max(1, room - 1)] for i in range(room)]
        sampled = sorted(selected | set(extra))
        for day in sampled:
            if min(dates) <= day <= max(dates) and _date_status(scenario, day, settlement_for(day), context) is None:
                if scenario.instrument.family is not ProductFamily.RENDA_PLUS or day >= scenario.entry.settlement_date + timedelta(days=60):
                    overlay_dates.append(day)

    # The point resolution only projects the selected sale date. Rebuild the
    # projection over this surface's dated domain from the original anchors;
    # otherwise its projected selected point would become the last "input"
    # and suppress projections on all preceding dates in the map.
    if (context.require_automatic_nominal or context.inflation_projection is not None or context.ipca_monthly_indexes) and dates:
        from .service import IndexKind, prepare_projection_window

        window = resolution.get("projection_window") or {}
        projected_index_keys = {
            (item["series_id"], item["reference_date"])
            for item in window.get("index_anchors", [])
            if item.get("reason_code") in ("HYPOTHETICAL_PROJECTION", "CALCULATED_FROM_IPCA")
        }
        projected_price_dates = {
            item["reference_date"] for item in window.get("price_index_levels", [])
            if item.get("reason_code") in ("HYPOTHETICAL_PROJECTION", "HYPOTHETICAL_PROJECTION_ANCHOR", "CALCULATED_FROM_IPCA")
        }
        base_context = replace(
            context,
            index_anchors=tuple(anchor for anchor in context.index_anchors
                                if (anchor.kind.value, anchor.reference_date.isoformat()) not in projected_index_keys),
            index_levels=tuple(level for level in context.index_levels
                               if level.date.isoformat() not in projected_price_dates),
            price_index_evidence=tuple(item for item in context.price_index_evidence
                                       if item.reference_date.isoformat() not in projected_price_dates),
        )
        dated_settlements = tuple(dict.fromkeys((
            scenario.entry.settlement_date,
            *(settlement_for(day) for day in dates if calendar.is_session(day)),
        )))
        index_kind = IndexKind.VNA if scenario.instrument.family is ProductFamily.IPCA_PRINCIPAL else IndexKind.VNI
        context = prepare_projection_window(
            base_context,
            index_targets={index_kind: dated_settlements},
            price_index_targets=tuple(sorted(set((*dated_settlements, *(settlement_for(day) for day in overlay_dates))))),
            as_of=normalized.knowledge.date if normalized.knowledge else None,
            evidence_mode=normalized.knowledge.mode if normalized.knowledge else EvidenceMode.CAUSAL,
        ).context

    selected_scenario = scenario
    from .api import workspace_fingerprint
    financial_namespace = workspace_fingerprint("EVALUATE", payload)
    if evaluation_cache is None:
        bucket = _surface_evaluation_cache_for(financial_namespace)
        point_cache, point_cache_lock = bucket
    else:
        point_cache = evaluation_cache
        point_cache_lock = RLock()

    if surface["mode"] == "PRICE_DATE_MAP":
        with point_cache_lock:
            result = build_decision_map(
                selected_scenario, dates, values, context, metric, (),
                selected_order_date=selected_date, selected_pu=selected_value,
                evaluation_cache=point_cache,
            )
            _trim_surface_evaluation_cache(point_cache)
    elif surface["mode"] == "RATE_DATE_MAP":
        invalid_dates = tuple(order for order in dates if not calendar.is_session(order))
        sessions = tuple(
            SurfaceSession(order, settlement_for(order))
            for order in dates if order not in invalid_dates
        )
        dummy_date = selected_date if selected_date not in invalid_dates else next(iter(sessions), None)
        if dummy_date is None:
            result = SurfaceResult(
                "RATE_DATE_MAP", metric, (), SurfaceStatus.NON_SESSION, selected_date,
                selected_value, len(dates) * len(values), 0, (len(dates), len(values)),
                "masked-empty-domain",
            )
        else:
            with point_cache_lock:
                result = build_rate_date_map(
                    selected_scenario, sessions, values, context, metric,
                    selected_order_date=dummy_date.order_date if isinstance(dummy_date, SurfaceSession) else dummy_date,
                    selected_rate=selected_value, evaluation_cache=point_cache,
                    evaluation_budget=evaluation_budget,
                )
                _trim_surface_evaluation_cache(point_cache)
            if dummy_date != selected_date:
                result = replace(result, points=tuple(replace(point, selected=False) for point in result.points),
                                 selected_date=selected_date)
        masked = tuple(
            _workspace_masked_surface_point(
                order, order, rate, unit, metric,
                SurfaceStatus.NON_SESSION, "Data sem sessão no calendário identificado.",
                order == selected_date and rate == selected_value,
            )
            for order in invalid_dates for rate in values
        )
        if masked:
            result = _extend_workspace_surface_result(result, masked, len(dates) * len(values), (len(dates), len(values)))
    elif surface["mode"] == "RATE_CURVE":
        if not calendar.is_session(selected_date):
            masked = tuple(
                _workspace_masked_surface_point(
                    selected_date, selected_date, rate, unit, metric,
                    SurfaceStatus.NON_SESSION, "Data sem sessão no calendário identificado.",
                    rate == selected_value,
                ) for rate in values
            )
            result = SurfaceResult(
                "RATE_CURVE", metric, masked, SurfaceStatus.NON_SESSION, selected_date,
                selected_value, len(values), 0, (1, len(values)), "masked-non-session",
            )
        else:
            with point_cache_lock:
                result = build_rate_curve(
                    selected_scenario, values, context, metric, selected_rate=selected_value,
                    evaluation_cache=point_cache,
                )
                _trim_surface_evaluation_cache(point_cache)
    else:
        invalid_dates = tuple(order for order in dates if not calendar.is_session(order))
        observations = tuple(
            ExitObservation(
                order, settlement_for(order),
                unit_price=selected_value if unit == "BRL_PER_TITLE" else None,
                real_yield=selected_value if unit == "ratio" else None,
            )
            for order in dates if order not in invalid_dates
        )
        with point_cache_lock:
            result = build_date_curve(
                selected_scenario, observations, context, metric,
                selected_order_date=selected_date if selected_date not in invalid_dates else None,
                evaluation_cache=point_cache,
            )
            _trim_surface_evaluation_cache(point_cache)
        if selected_date in invalid_dates:
            result = replace(result, selected_date=selected_date)
        masked = tuple(
            _workspace_masked_surface_point(
                order, order, selected_value, unit, metric,
                SurfaceStatus.NON_SESSION, "Data sem sessão no calendário identificado.",
                order == selected_date,
            )
            for order in invalid_dates
        )
        if masked:
            result = _extend_workspace_surface_result(result, masked, len(dates), (len(dates), 1), selected_date)

    frontier_reference_evaluation = None
    frontier_reference_reason = (
        None if fixed_position_frontier is None
        else fixed_position_frontier.get("reference_resolution_error")
    )
    if fixed_position_frontier is not None:
        reference = fixed_position_frontier.get("reference") or {}
        reference_input = reference.get("input")
        reference_resolution = fixed_position_frontier.get("reference_resolution")
        try:
            if not isinstance(reference_input, Mapping) or not isinstance(reference_resolution, Mapping):
                raise ValidationError("REFERENCE_UNAVAILABLE", "A resolu\u00e7\u00e3o da venda de refer\u00eancia n\u00e3o est\u00e1 dispon\u00edvel.")
            frontier_reference_evaluation = evaluate_resolved_workspace(
                reference_input, reference_resolution,
                calendar=fixed_position_frontier.get("reference_calendar") or calendar,
                evaluation_cache=point_cache, evaluation_budget=evaluation_budget,
            )
        except (ValidationError, SurfaceEvaluationBudgetExceeded) as exc:
            frontier_reference_reason = frontier_reference_reason or str(exc).partition(":")[2].strip() or str(exc)

    points = []
    frontier_reference_summary = None
    constraint_set = None
    if "constraints" in payload:
        from .constraints import parse_constraint_set

        constraint_set = parse_constraint_set(payload["constraints"])
    for point in result.points:
        coordinate = (
            getattr(point, "rate", None) if unit == "ratio"
            else getattr(point, "unit_price", None)
        )
        point_value = point.value
        point_unit = surface["metric_unit"]
        point_metrics = {
            item.metric.value: {
                "metric_id": item.metric.value,
                "value": None if item.value is None else str(item.value),
                "unit": item.unit,
                "status": item.status.value.lower(),
                "quality": item.quality.value,
                "reason": item.reason,
                "source_ref": point.source_ref,
            }
            for item in getattr(point, "metrics", ())
        }
        if not point_metrics:
            point_metrics = {
                item.value: {
                    "metric_id": item.value, "value": None,
                    "unit": _workspace_surface_metric_unit(item),
                    "status": point.status.value.lower(), "quality": "MISSING",
                    "reason": point.reason, "source_ref": getattr(point, "source_ref", None),
                }
                for item in SurfaceMetric
            }
        identity_material = "|".join((
            input_fingerprint, point.order_date.isoformat(), point.settlement_date.isoformat(),
            str(coordinate),
        ))
        projected_point = {
            "order_date": point.order_date.isoformat(),
            "settlement_date": point.settlement_date.isoformat(),
            "coordinate": {"value": None if coordinate is None else str(coordinate), "unit": unit},
            "value": None if point_value is None else str(point_value),
            "unit": point_unit,
            "status": point.status.value.lower(),
            "quality": point.quality.value,
            "reason": point.reason,
                "source_ref": getattr(point, "source_ref", None),
            "identity": sha256(identity_material.encode("utf-8")).hexdigest(),
            "selected": point.selected,
            "metrics": point_metrics,
        }
        # Preserve the original two-flow conversion basis, including degenerate
        # net redemptions. Never reconstruct inflation from rounded returns.
        operation = getattr(getattr(point, "evaluation", None), "operation", None)
        basis = None
        if (operation is not None and operation.status != "BLOCKED_POLICY"
                and not context.intermediate_paid_costs and operation.initial_outflow > 0):
            levels = {level.date: level.value for level in context.index_levels}
            initial_index = levels.get(scenario.entry.settlement_date)
            final_index = levels.get(point.settlement_date)
            factor = final_index / initial_index if initial_index and final_index else None
            basis = {
                "initial_outflow": str(operation.initial_outflow),
                "inflation_factor": None if factor is None else str(factor),
                "purchase_settlement_date": scenario.entry.settlement_date.isoformat(),
                "quality": operation.quality.value,
                "inflation_quality": point_metrics.get("real_return", {}).get("quality", "MISSING"),
            }
        projected_point["conversion_basis"] = basis
        if constraint_set is not None:
            from .constraints import evaluate_constraint_metrics

            constraint_evaluation = evaluate_constraint_metrics(
                constraint_set,
                requested_order_date=point.order_date,
                settlement_date=point.settlement_date,
                metrics=point_metrics,
                quality=point.quality.value,
                base_status=point.status.value.lower(),
                base_reason=point.reason,
            )
            projected_point["constraint_evaluation"] = constraint_evaluation.to_dict()
        if fixed_position_frontier is not None:
            comparison_point, reference_summary = _g4_fixed_position_comparison(
                payload, resolution, point, fixed_position_frontier,
                frontier_reference_evaluation, calendar=calendar,
            )
            if comparison_point is not None:
                projected_point.update(comparison_point)
            if frontier_reference_summary is None and reference_summary is not None:
                frontier_reference_summary = reference_summary
        points.append(projected_point)
    requested_points = getattr(result, "requested_cells", len(result.points))
    resolution_detail = {"dates": len(dates), "values": len(values)}
    reused_points = getattr(result, "reused_scenarios", 0)
    new_evaluations = result.evaluated_scenarios
    evaluated_points = new_evaluations + reused_points
    domain_payload = {
        "date_range": {"start": surface["date_range"][0].isoformat(), "end": surface["date_range"][1].isoformat()},
        "requested_date_range": (
            {"start": normalized.analysis_context.start.isoformat(), "end": normalized.analysis_context.end.isoformat()}
            if normalized.analysis_context is not None and normalized.analysis_context.is_operation_window
            and normalized.analysis_context.start is not None and normalized.analysis_context.end is not None
            else None
        ),
        "timeline_exclusions": surface.get("timeline_exclusions", []),
        "candidate_order_dates": [item.isoformat() for item in surface["candidate_order_dates"]],
        "sampled_order_dates": [item.isoformat() for item in dates],
        "candidate_values": [str(item) for item in surface["candidate_values"]],
        "sampled_values": [str(item) for item in values],
        "unit": unit,
        "purpose": "visual",
        "proof_domain": None,
        "policy_dates": [item.isoformat() for item in surface["policy_dates"]],
    }
    surface_status = result.status.value.lower()
    if not surface.get("complete", True) and surface_status == "ready":
        surface_status = "partial"
    response = {
        "mode": surface["mode"],
        "metric_id": metric.value,
        "unit": surface["metric_unit"],
        "status": surface_status,
        "selected": {"order_date": selected_date.isoformat(), "value": str(selected_value), "unit": unit},
        "selection_assumption": {
            "kind": "EXIT_RATE" if unit == "ratio" else "EXIT_PRICE",
            "quality": "HYPOTHETICAL",
            "source": surface.get("selected_value_source", "USER_SELECTED"),
            "domain_is_forecast": False,
        },
        "requested_points": requested_points,
        "evaluated_points": evaluated_points,
        "new_evaluations": new_evaluations,
        "reused_points": reused_points,
        "resolution": resolution_detail,
        "cache_id": result.cache_id,
        "points": points,
        "coverage": {
            "status": surface["coverage_status"],
            "domain": domain_payload,
            "resolution": resolution_detail,
            "complete": surface["complete"],
            "evaluated_points": evaluated_points,
            "new_evaluations": new_evaluations,
            "reused_points": reused_points,
            "requested_points": requested_points,
            "resolved_points": len(result.points),
            "method": "direct_grid" if surface["complete"] else "deterministic_even_sample",
            "max_evaluations": 512 if fixed_position_frontier is not None else 256,
            "deadline_ms": int(evaluation_budget.deadline_seconds * 1000) if evaluation_budget is not None else None,
            "omitted_ranges": _date_ranges(surface["omitted_dates"]),
            "omitted_dates": [item.isoformat() for item in surface["omitted_dates"]],
            "omitted_values": [str(item) for item in surface["omitted_values"]],
        },
    }
    if overlay_dates:
        from .service import _real_metric_quality
        sizing = resolution.get("purchase_sizing") or {}
        capital = _dto_decimal(sizing.get("initial_outflow")) if sizing.get("status") == "available" else None
        known = next((point["conversion_basis"] for point in points if point.get("conversion_basis")), None)
        if capital is None and known:
            capital = Decimal(known["initial_outflow"])
        levels = {level.date: level.value for level in context.index_levels}
        initial_index = levels.get(scenario.entry.settlement_date)
        support = []
        for day in overlay_dates:
            settlement = settlement_for(day)
            final_index = levels.get(settlement)
            basis = None
            if capital is not None and capital > 0:
                basis = {"initial_outflow": str(capital),
                         "inflation_factor": str(final_index / initial_index) if initial_index and final_index else None,
                         "purchase_settlement_date": scenario.entry.settlement_date.isoformat(),
                         "quality": known["quality"] if known else Quality.HYPOTHETICAL.value,
                         "inflation_quality": _real_metric_quality(context, (scenario.entry.settlement_date, settlement)).value if initial_index and final_index else Quality.MISSING.value}
            support.append({"order_date": day.isoformat(), "settlement_date": settlement.isoformat(), "conversion_basis": basis})
        response["overlay_support"] = support
    if fixed_position_frontier is not None:
        from .frontiers import analyze_g4_frontiers

        analyzed = analyze_g4_frontiers(
            points,
            order_dates=[item.isoformat() for item in dates],
            values=[str(item) for item in values],
        )
        response["points"] = analyzed["points"]
        response["frontiers"] = analyzed["frontiers"]
        reference = fixed_position_frontier.get("reference") or {}
        comparison_context = fixed_position_frontier.get("comparison_context") or {}
        response["frontier_reference"] = {
            "id": reference.get("id", "reference"),
            "label": reference.get("label", "Refer\u00eancia"),
            "status": "ready" if frontier_reference_evaluation is not None else "unavailable",
            "sale_order": ((reference.get("input") or {}).get("sale_date")),
            "common_horizon": (
                comparison_context.get("horizon").isoformat()
                if hasattr(comparison_context.get("horizon"), "isoformat")
                else comparison_context.get("horizon")
            ),
            "nominal_profit": (
                None if frontier_reference_evaluation is None or frontier_reference_evaluation.operation is None
                else {"value": str(frontier_reference_evaluation.operation.nominal_profit), "unit": "BRL"}
            ),
            "total_resources_at_horizon": None if frontier_reference_summary is None else frontier_reference_summary.get("total_resources_at_horizon"),
            "quality": (
                None if frontier_reference_evaluation is None or frontier_reference_evaluation.operation is None
                else frontier_reference_evaluation.operation.quality.value
            ),
            "reason": frontier_reference_reason,
            "cash_growth": comparison_context.get("cash_growth"),
        }
        response["frontier_definitions"] = [
            {"id": "nominal_equilibrium", "condition": "Lucro l\u00edquido nominal desde a compra >= R$ 0,00", "reference": "base original da posi\u00e7\u00e3o"},
            {"id": "personal_goals", "condition": "Todas as metas pessoais declaradas s\u00e3o atendidas", "reference": "input.constraints"},
            {"id": "sell_wait_indifference", "condition": "Patrim\u00f4nio no horizonte comum >= venda de refer\u00eancia", "reference": "FIXED_POSITION + premissas de caixa declaradas"},
        ]
        if evaluation_budget is not None:
            response["computation_budget"] = evaluation_budget.to_dict()
    if fixed_position_frontier is not None and evaluation_budget is not None and evaluation_budget.check_deadline():
        response["status"] = "partial"
        response["incomplete_reason"] = "DEADLINE_EXCEEDED"
        response["computation_budget"] = evaluation_budget.to_dict()
        coverage = response.get("coverage")
        if isinstance(coverage, dict):
            coverage["status"] = "partial"
            coverage["complete"] = False
            coverage["reason"] = "DEADLINE_EXCEEDED"
        for frontier in response.get("frontiers", {}).values():
            frontier_coverage = frontier.get("coverage") if isinstance(frontier, dict) else None
            if isinstance(frontier_coverage, dict):
                frontier_coverage["status"] = "partial"
                frontier_coverage["reason"] = "DEADLINE_EXCEEDED"
    return response


def _g4_fixed_position_comparison(
    payload: object,
    resolution: Mapping[str, Any],
    point: Any,
    fixed_position_frontier: Mapping[str, Any],
    reference_evaluation: Any,
    *,
    calendar: Any,
) -> tuple[dict[str, Any] | None, dict[str, Any] | None]:
    """Compare one evaluated map cell with the frozen G3 reference via G3."""
    from copy import deepcopy

    from .api import workspace_fingerprint
    from .comparisons import compare_workspace_evaluations
    from .contracts import ValidationError

    reference = fixed_position_frontier.get("reference") or {}
    reference_input = reference.get("input")
    reference_resolution = fixed_position_frontier.get("reference_resolution")
    comparison_context = fixed_position_frontier.get("comparison_context") or {}
    if (
        reference_evaluation is None or not isinstance(reference_input, Mapping)
        or not isinstance(reference_resolution, Mapping) or point.evaluation is None
        or point.rate is None or point.evaluation.operation is None
    ):
        return None, None

    candidate_input = deepcopy(dict(payload))
    candidate_input["sale_date"] = point.order_date.isoformat()
    candidate_input["exit_price"] = {
        "mode": "MANUAL_RATE", "annual_real_rate": str(point.rate), "quoted_side": "SELL",
    }
    candidate_input = prepare_workspace_defaults(candidate_input)
    candidate_resolution = deepcopy(dict(resolution))
    candidate_dates = candidate_resolution.setdefault("dates", {})
    candidate_dates["sale"] = {
        "status": "available",
        "proposed_order_date": point.order_date.isoformat(),
        "settlement_date": point.settlement_date.isoformat(),
    }
    resolved_prices = candidate_resolution.setdefault("resolved_prices", {})
    resolved_prices["exit_price"] = {
        "status": "available", "mode": "MANUAL_RATE",
        "value": str(point.evaluation.exit_pu), "provenance": None,
    }
    comparison_items = [
        {
            "id": "reference", "label": reference.get("label") or "Refer\u00eancia",
            "input_fingerprint": workspace_fingerprint("EVALUATE", reference_input),
            "normalized_input": reference_input,
            "resolution": reference_resolution,
            "evaluation": reference_evaluation,
            "comparison_context": comparison_context,
        },
        {
            "id": "map", "label": "Ponto da grade G4",
            "input_fingerprint": workspace_fingerprint("EVALUATE", candidate_input),
            "normalized_input": candidate_input,
            "resolution": candidate_resolution,
            "evaluation": point.evaluation,
            "comparison_context": comparison_context,
        },
    ]
    try:
        comparison = compare_workspace_evaluations(comparison_items, comparison_mode="FIXED_POSITION")
    except ValidationError as exc:
        return {
            "wealth_advantage_vs_reference": None,
            "wealth_comparison_status": "unavailable",
            "wealth_comparison_reason": str(exc).partition(":")[2].strip() or exc.code,
        }, None
    reference_row, candidate_row = comparison["alternatives"]
    reference_summary = {
        "status": reference_row.get("status"),
        "nominal_profit": reference_row.get("profit_since_purchase"),
        "total_resources_at_horizon": reference_row.get("total_resources_at_horizon"),
        "quality": reference_row.get("quality"),
    }
    return {
        "wealth_advantage_vs_reference": candidate_row.get("wealth_advantage_vs_reference"),
        "total_resources_at_horizon": candidate_row.get("total_resources_at_horizon"),
        "wealth_comparison_status": "ready" if comparison["ranking"].get("rankable") else "unavailable",
        "wealth_comparison_reason": None if comparison["ranking"].get("rankable") else comparison["ranking"].get("reasons"),
    }, reference_summary


def _date_ranges(values: tuple[date, ...]) -> list[dict[str, str]]:
    if not values:
        return []
    ranges: list[tuple[date, date]] = []
    start = previous = values[0]
    for value in values[1:]:
        if value.toordinal() == previous.toordinal() + 1:
            previous = value
            continue
        ranges.append((start, previous))
        start = previous = value
    ranges.append((start, previous))
    return [{"start": start.isoformat(), "end": end.isoformat()} for start, end in ranges]


def _workspace_surface_metric_unit(metric: Any) -> str:
    if metric in {"gross_redemption", "net_redemption", "nominal_profit", "real_profit_in_exit_date_currency"}:
        return "BRL"
    return "ratio_per_year" if metric == "annualized_nominal_return" else "ratio"


def _workspace_masked_surface_point(
    order_date: date,
    settlement_date: date,
    coordinate: Decimal,
    coordinate_unit: str,
    metric: Any,
    status: Any,
    reason: str,
    selected: bool,
) -> Any:
    from .surfaces import SurfaceMetricValue, SurfacePoint

    from_rate = coordinate_unit == "ratio"
    metrics = tuple(
        SurfaceMetricValue(
            item, None, _workspace_surface_metric_unit(item.value), status,
            Quality.MISSING, reason,
        )
        for item in type(metric)
    )
    return SurfacePoint(
        order_date, settlement_date, coordinate if from_rate else None,
        None if from_rate else coordinate, None, metric,
        _workspace_surface_metric_unit(metric.value), status, Quality.MISSING,
        None, reason, selected, metrics,
    )


def _extend_workspace_surface_result(
    result: Any,
    additional_points: tuple[Any, ...],
    requested_points: int,
    resolution: tuple[int, int],
    selected_date: date | None = None,
) -> Any:
    points = tuple(sorted(
        (*result.points, *additional_points),
        key=_workspace_surface_point_order,
    ))
    status = result.status
    if additional_points and any(item.status.value == "READY" for item in result.points):
        status = type(status).METRIC_UNAVAILABLE
    return replace(
        result,
        points=points,
        status=status,
        requested_cells=requested_points,
        resolution=resolution,
        selected_date=selected_date if selected_date is not None else result.selected_date,
    )


def _workspace_surface_point_order(item: Any) -> tuple[date, Decimal | None]:
    coordinate = getattr(item, "rate", None)
    if coordinate is None:
        coordinate = getattr(item, "unit_price", None)
    return item.order_date, coordinate


def _resolve_purchase_sizing(
    normalized: WorkspaceInput,
    resolved_prices: Mapping[str, Mapping[str, Any]],
) -> tuple[dict[str, Any], dict[str, Any]]:
    missing: list[str] = []
    if normalized.capital is None:
        missing.extend(("capital.mode", "capital.value"))
    assumptions = normalized.assumptions
    fee = assumptions.get("entry_fee")
    if not isinstance(fee, Mapping):
        missing.extend(("assumptions.entry_fee.fixed_brl", "assumptions.entry_fee.proportional_rate"))
        fixed_fee = proportional_fee = None
    else:
        fixed_fee = fee.get("fixed_brl")
        proportional_fee = fee.get("proportional_rate")
        if fixed_fee is None:
            missing.append("assumptions.entry_fee.fixed_brl")
        if proportional_fee is None:
            missing.append("assumptions.entry_fee.proportional_rate")

    selection = normalized.entry_price
    entry_pu: Decimal | None = None
    if selection is None:
        missing.append("entry_price.mode")
    elif selection.mode is PriceMode.MANUAL_PU:
        if selection.evidence_status in (
            EvidenceStatus.PUBLISHED_AFTER_AS_OF,
            EvidenceStatus.PUBLICATION_DATE_UNKNOWN,
            EvidenceStatus.OBSERVATION_AFTER_AS_OF,
        ):
            capability = {
                "status": "blocked_policy",
                "reason": {"code": selection.evidence_status.value, "message": "PU de entrada fora do corte de conhecimento."},
                "missing_fields": [],
            }
            return ({"status": "blocked_policy", "reason_code": selection.evidence_status.value}, capability)
        entry_pu = selection.pu
    elif selection.mode is PriceMode.AUTO_LOCAL:
        quote = resolved_prices.get("entry_price", {})
        if quote.get("status") == "available":
            entry_pu = Decimal(quote["value"])
        else:
            reason = quote.get("reason_code", "MISSING_PRICE")
            capability = {
                "status": quote.get("status", "needs_input"),
                "reason": {"code": reason, "message": "O dimensionamento aguarda o PU de entrada selecionado."},
                "missing_fields": quote.get("missing_fields", ["entry_price.pu"]),
            }
            return ({"status": capability["status"], "reason_code": reason}, capability)
    elif selection.mode is PriceMode.MANUAL_RATE:
        quote = resolved_prices.get("entry_price", {})
        if quote.get("status") == "available":
            entry_pu = Decimal(quote["value"])
        else:
            reason = quote.get("reason_code", "MISSING_INDEX")
            capability = {
                "status": quote.get("status", "needs_input"),
                "reason": {"code": reason, "message": "O dimensionamento aguarda a âncora e o PU teórico da taxa escolhida."},
                "missing_fields": quote.get("missing_fields", ["data.index_anchors[matching_kind_and_settlement]"]),
            }
            return ({"status": capability["status"], "reason_code": reason}, capability)
    else:
        missing.append("entry_price.pu")

    if missing:
        unique = list(dict.fromkeys(missing))
        capability = {
            "status": "needs_input", "reason": {"code": "MISSING_FIELD", "message": "Informe o capital, PU e custos de entrada para dimensionar."},
            "missing_fields": unique,
        }
        return ({"status": "needs_input", "missing_fields": unique}, capability)
    assert normalized.capital is not None and entry_pu is not None
    assert fixed_fee is not None and proportional_fee is not None

    from .operation import size_purchase_from_budget, size_purchase_from_quantity

    try:
        if normalized.capital.mode is CapitalMode.BUDGET:
            sized = size_purchase_from_budget(
                normalized.capital.value, entry_pu, "0.01", fixed_fee, proportional_fee,
            )
            quantity = sized.quantity
            purchase_gross = sized.purchase_gross
            entry_expense = sized.entry_expense
            total_outflow = sized.total_outflow
            unspent = sized.unspent_cash
        else:
            sized = size_purchase_from_quantity(
                normalized.capital.value, entry_pu, "0.01", fixed_fee, proportional_fee,
            )
            quantity = sized.quantity
            purchase_gross = sized.purchase_gross
            entry_expense = sized.entry_expense
            total_outflow = sized.total_outflow
            unspent = None
    except ValidationError as exc:
        if exc.code == "INSUFFICIENT_BUDGET":
            missing = ["capital.value"]
            message = "Aumente o orçamento ou altere explicitamente título, PU ou custos."
            status = "needs_input"
        else:
            raise
        capability = {"status": status, "reason": {"code": exc.code, "message": message}, "missing_fields": missing}
        return ({"status": status, "reason_code": exc.code}, capability)

    tax_basis_raw = assumptions.get("tax_cost_basis_brl")
    tax_basis = Decimal(tax_basis_raw) if tax_basis_raw is not None else purchase_gross
    basis_source = "INFORMED" if tax_basis_raw is not None else "PURCHASE_GROSS_DEFAULT"
    response = {
        "status": "available",
        "capital_mode": normalized.capital.mode.value,
        "capital_value": str(normalized.capital.value),
        "capital_unit": normalized.capital.unit,
        "unit_price": {"value": str(entry_pu), "unit": "BRL_PER_TITLE"},
        "quantity": {"value": str(quantity), "unit": "TITLE"},
        "quantity_step": {"value": "0.01", "unit": "TITLE"},
        "purchase_gross": {"value": str(purchase_gross), "unit": "BRL"},
        "entry_expense": {"value": str(entry_expense), "unit": "BRL"},
        "initial_outflow": {"value": str(total_outflow), "unit": "BRL"},
        "cash_remainder": None if unspent is None else {"value": str(unspent), "unit": "BRL"},
        "tax_cost_basis": {"value": str(tax_basis), "unit": "BRL", "source": basis_source},
        "entry_fee": {
            "fixed_brl": str(fixed_fee), "proportional_rate": str(proportional_fee),
        },
    }
    return response, {"status": "available", "reason": None, "missing_fields": []}


def _parse_instrument(raw: object, missing: list[str]) -> Instrument | None:
    if raw is None:
        missing.extend(("instrument.family", "instrument.series_year"))
        return None
    value = _object(raw, "instrument", _INSTRUMENT_FIELDS)
    if "family" not in value:
        missing.append("instrument.family")
    family = _enum(ProductFamily, value["family"], "instrument.family") if "family" in value else None
    if "series_year" in value:
        year = value["series_year"]
        if type(year) is not int or not 1900 <= year <= 9979:
            raise ValidationError("INVALID_SERIES", "Ano do título precisa ser um ano inteiro válido.")
        if family is None:
            return None
        if family is ProductFamily.IPCA_PRINCIPAL:
            maturity = date(year, 5 if year % 2 else 8, 15)
            generated = Instrument(family, f"IPCA+ {year}", maturity)
        else:
            from .renda_plus import RendaPlusSeries
            try:
                series = RendaPlusSeries.for_conversion_year(year)
            except ValidationError as exc:
                if exc.code != "UNSUPPORTED_SERIES":
                    raise
                missing.append("instrument.series_year")
                return None
            generated = Instrument(
                family, series.series_id, series.last_income_date,
                series.conversion_date, series.first_income_date,
            )
        for field, actual in (
            ("instrument_id", generated.instrument_id),
            ("maturity_date", generated.maturity_date),
            ("conversion_date", generated.conversion_date),
            ("first_income_date", generated.first_income_date),
        ):
            if field in value:
                supplied = _optional_date(value[field], f"instrument.{field}") if field.endswith("date") else _text(value[field], f"instrument.{field}", 128)
                if supplied != actual:
                    raise ValidationError("INVALID_SERIES", f"instrument.{field} diverge do ano do título.")
        return generated
    if family is None or not any(
        field in value for field in ("instrument_id", "maturity_date", "conversion_date", "first_income_date")
    ):
        missing.append("instrument.series_year")
        return None
    for field in ("instrument_id", "maturity_date"):
        if field not in value:
            missing.append("instrument." + field)
    instrument_id = _text(value["instrument_id"], "instrument.instrument_id", 128) if "instrument_id" in value else None
    maturity = _date(value["maturity_date"], "instrument.maturity_date") if "maturity_date" in value else None
    conversion = _optional_date(value.get("conversion_date"), "instrument.conversion_date")
    first_income = _optional_date(value.get("first_income_date"), "instrument.first_income_date")
    if family is ProductFamily.RENDA_PLUS:
        if conversion is None:
            missing.append("instrument.conversion_date")
        if first_income is None:
            missing.append("instrument.first_income_date")
    if family is None or instrument_id is None or maturity is None:
        return None
    if family is ProductFamily.RENDA_PLUS and (conversion is None or first_income is None):
        return None
    return Instrument(family, instrument_id, maturity, conversion, first_income)


def _parse_capital(raw: object, missing: list[str]) -> CapitalInput | None:
    if raw is None:
        missing.extend(("capital.mode", "capital.value"))
        return None
    value = _object(raw, "capital", {"mode", "value"})
    if "mode" not in value:
        missing.append("capital.mode")
    if "value" not in value:
        missing.append("capital.value")
    mode = _enum(CapitalMode, value["mode"], "capital.mode") if "mode" in value else None
    amount = _decimal(value["value"], "capital.value") if "value" in value else None
    if amount is not None and amount <= 0:
        raise ValidationError("INVALID_CAPITAL", "Capital deve ser positivo.")
    if mode is None or amount is None:
        return None
    if mode is CapitalMode.QUANTITY and amount % Decimal("0.01") != 0:
        raise ValidationError("INVALID_QUANTITY", "Quantidade deve respeitar múltiplos de 0,01 título.")
    return CapitalInput(mode, amount)


def _parse_knowledge(raw: object, missing: list[str]) -> AsOf | None:
    if raw is None:
        missing.append("knowledge.date")
        return None
    value = _object(raw, "knowledge", {"date", "mode"})
    if "date" not in value:
        missing.append("knowledge.date")
    if "mode" not in value:
        missing.append("knowledge.mode")
    mode = _enum(EvidenceMode, value.get("mode", "CAUSAL"), "knowledge.mode")
    if "date" not in value:
        return None
    return AsOf(
        _date(value["date"], "knowledge.date"),
        mode,
    )


def _parse_price(
    raw: object,
    path: str,
    missing: list[str],
    *,
    is_exit: bool,
    knowledge: AsOf | None,
    intent: ScenarioIntent,
    family: ProductFamily | None,
) -> PriceSelection | None:
    if raw is None:
        missing.append(path + ".mode")
        return None
    value = _object(raw, path, {
        "mode", "pu", "annual_real_rate", "quoted_side", "provenance", "rate_check",
        "dataset_kind", "version_hash", "observation_date", "spread", "spread_source",
    })
    if "mode" not in value:
        missing.append(path + ".mode")
        return None
    mode = _enum(PriceMode, value["mode"], path + ".mode")
    provenance = _parse_provenance(value.get("provenance"), path + ".provenance")
    rate_check = None
    if "rate_check" in value:
        rate_check = _parse_price(
            value["rate_check"], path + ".rate_check", missing, is_exit=is_exit,
            knowledge=knowledge, intent=intent, family=family,
        )
        if rate_check is not None and rate_check.mode is not PriceMode.MANUAL_RATE:
            raise ValidationError("INVALID_PRICE_MODE", "rate_check precisa usar MANUAL_RATE.")

    if mode is PriceMode.MANUAL_PU:
        _only_fields(value, path, _PRICE_COMMON | {"pu", "rate_check"})
        if "pu" not in value:
            missing.append(path + ".pu")
            return None
        pu = _decimal(value["pu"], path + ".pu")
        if pu <= 0:
            raise ValidationError("INVALID_PRICE", f"{path}.pu precisa ser positivo.")
        if provenance is not None and provenance.quality is Quality.MISSING:
            raise ValidationError("INVALID_PROVENANCE", f"{path} não pode declarar proveniência MISSING para um PU preenchido.")
        evidence_status = _check_provenance(provenance, knowledge)
        return PriceSelection(
            mode=mode, pu=pu, provenance=provenance, rate_check=rate_check,
            evidence_status=evidence_status,
            quality=(provenance.quality if provenance else (
                Quality.HYPOTHETICAL if intent is ScenarioIntent.HYPOTHETICAL else Quality.INFORMED
            )),
        )

    if mode is PriceMode.MANUAL_RATE:
        _only_fields(value, path, _PRICE_COMMON | {
            "annual_real_rate", "quoted_side", "spread", "spread_source",
        })
        if "annual_real_rate" not in value:
            missing.append(path + ".annual_real_rate")
            return None
        rate = _decimal(value["annual_real_rate"], path + ".annual_real_rate")
        side = _enum(Side, value.get("quoted_side", "SELL" if is_exit else "BUY"), path + ".quoted_side")
        if not is_exit and side is not Side.BUY:
            raise ValidationError("WRONG_MARKET_SIDE", "Taxa de entrada precisa ser do lado BUY.")
        if is_exit and side is Side.BASE:
            raise ValidationError("BASE_NOT_CASH", "Taxa BASE não representa uma venda.")
        spread = _optional_decimal(value.get("spread"), path + ".spread")
        spread_source = _optional_text(value.get("spread_source"), path + ".spread_source", 256)
        if is_exit and side is Side.BUY and (spread is None or spread_source is None):
            raise ValidationError("BUY_NOT_REDEMPTION", "Taxa BUY para venda exige spread e fonte explícitos.")
        if provenance is not None and provenance.quality is Quality.MISSING:
            raise ValidationError("INVALID_PROVENANCE", f"{path} não pode declarar proveniência MISSING para uma taxa preenchida.")
        _validate_rate(rate, path, family)
        evidence_status = _check_provenance(provenance, knowledge)
        return PriceSelection(
            mode=mode, annual_real_rate=rate, quoted_side=side, provenance=provenance,
            spread=spread, spread_source=spread_source, evidence_status=evidence_status,
            quality=provenance.quality if provenance else (
                Quality.HYPOTHETICAL if intent is ScenarioIntent.HYPOTHETICAL else Quality.INFORMED
            ),
        )

    if mode is PriceMode.AUTO_LOCAL:
        _only_fields(value, path, {
            "mode", "dataset_kind", "version_hash", "observation_date", "quoted_side",
        })
        for field in ("dataset_kind", "version_hash", "observation_date", "quoted_side"):
            if field not in value:
                missing.append(path + "." + field)
        if any(field not in value for field in ("dataset_kind", "version_hash", "observation_date", "quoted_side")):
            return None
        dataset_kind = _text(value["dataset_kind"], path + ".dataset_kind", 32)
        if dataset_kind != "market_sim":
            raise ValidationError("INVALID_PRICE_MODE", "dataset_kind deve ser market_sim.")
        version_hash = _hash(value["version_hash"], path + ".version_hash")
        observation_date = _date(value["observation_date"], path + ".observation_date")
        side = _enum(Side, value["quoted_side"], path + ".quoted_side")
        if not is_exit and side is not Side.BUY:
            raise ValidationError("WRONG_MARKET_SIDE", "Cotação local de entrada precisa ser do lado BUY.")
        if is_exit and side is Side.BUY:
            raise ValidationError("BUY_NOT_REDEMPTION", "Cotação BUY local não é preço de resgate; use venda ou taxa com spread explícito.")
        return PriceSelection(mode, quoted_side=side, dataset_kind=dataset_kind,
                              version_hash=version_hash, observation_date=observation_date,
                              quality=Quality.MISSING)

    _only_fields(value, path, {"mode"})
    if not is_exit:
        raise ValidationError("INVALID_PRICE_MODE", "SAME_ENTRY_RATE só pode ser usado na saída.")
    return PriceSelection(mode=mode, quality=Quality.HYPOTHETICAL)


def _parse_provenance(raw: object, path: str) -> Provenance | None:
    if raw is None:
        return None
    value = _object(raw, path, _PROVENANCE_FIELDS)
    required = {"source_id", "source_ref", "quality"}
    if not required <= set(value):
        raise ValidationError("INVALID_PROVENANCE", f"{path} exige source_id, source_ref e quality.")
    quality = _enum(Quality, value["quality"], path + ".quality")
    if quality is Quality.RECONSTRUCTED:
        raise ValidationError("INVALID_PROVENANCE", "RECONSTRUCTED é qualidade produzida pelo servidor.")
    source_id = _text(value["source_id"], path + ".source_id", 128)
    source_ref = _text(value["source_ref"], path + ".source_ref", 512)
    observed_on = _optional_date(value.get("observed_on"), path + ".observed_on")
    published_at = _optional_datetime(value.get("published_at"), path + ".published_at")
    if quality in (Quality.OBSERVED, Quality.REVISED) and published_at is None:
        raise ValidationError(
            "INVALID_PROVENANCE", f"{path} em qualidade {quality.value} exige published_at com fuso.",
        )
    return Provenance(
        source_id=source_id,
        source_ref=source_ref,
        quality=quality,
        observed_on=observed_on,
        published_at=published_at,
        version=_optional_text(value.get("version"), path + ".version", 128),
        sha256=_optional_hash(value.get("sha256"), path + ".sha256"),
        revision_id=_optional_text(value.get("revision_id"), path + ".revision_id", 128),
        supersedes_revision=_optional_text(value.get("supersedes_revision"), path + ".supersedes_revision", 128),
        settlement_date=_optional_date(value.get("settlement_date"), path + ".settlement_date"),
    )


def _check_provenance(
    provenance: Provenance | None,
    knowledge: AsOf | None,
) -> EvidenceStatus | None:
    if provenance is None:
        return None
    if knowledge is None:
        return EvidenceStatus.PUBLICATION_DATE_UNKNOWN if provenance.quality in (
            Quality.OBSERVED, Quality.REVISED,
        ) else None
    has_late_timestamp = (
        (provenance.observed_on is not None and provenance.observed_on > knowledge.date)
        or (provenance.published_at is not None and provenance.published_at.date() > knowledge.date)
    )
    if provenance.quality is Quality.HYPOTHETICAL and not has_late_timestamp:
        return None
    if provenance.quality not in (Quality.OBSERVED, Quality.REVISED) and not has_late_timestamp:
        return None
    decision = assess_evidence(provenance, knowledge.date, knowledge.mode)
    return None if decision.usable else decision.status


def _parse_assumptions(raw: object) -> tuple[Mapping[str, Any], tuple[str, ...]]:
    missing: list[str] = []
    if raw is None:
        return MappingProxyType({}), (
            "assumptions.settlement_profile", "assumptions.entry_fee", "assumptions.exit_fee_brl",
        )
    value = _object(raw, "assumptions", _ASSUMPTION_FIELDS)
    normalized = dict(value)
    if "settlement_profile" not in value:
        missing.append("assumptions.settlement_profile")
    if "settlement_profile" in value and value["settlement_profile"] not in {
        "SIMULATED_BUY_D1_SELL_D1", "SIMULATED_BUY_D1_SELL_D0", "EXPLICIT",
    }:
        raise ValidationError("INVALID_SETTLEMENT_PROFILE", "Perfil de liquidação não suportado.")
    if "entry_fee" in value:
        fee = _object(value["entry_fee"], "assumptions.entry_fee", {"fixed_brl", "proportional_rate"})
        fixed = None
        proportional = None
        if "fixed_brl" not in fee:
            missing.append("assumptions.entry_fee.fixed_brl")
        else:
            fixed = _decimal(fee["fixed_brl"], "assumptions.entry_fee.fixed_brl")
            if fixed < 0:
                raise ValidationError("INVALID_ASSUMPTION", "Custo fixo de entrada não pode ser negativo.")
        if "proportional_rate" not in fee:
            missing.append("assumptions.entry_fee.proportional_rate")
        else:
            proportional = _decimal(fee["proportional_rate"], "assumptions.entry_fee.proportional_rate")
        if proportional is not None and (proportional < 0 or proportional >= 1):
            raise ValidationError("INVALID_ASSUMPTION", "Taxa proporcional deve ser não negativa e menor que 1.")
        if fixed is not None and proportional is not None:
            if fixed < 0 or proportional < 0 or proportional >= 1:
                raise ValidationError("INVALID_ASSUMPTION", "Custos de entrada precisam ser não negativos e a taxa menor que 1.")
    else:
        missing.append("assumptions.entry_fee")
    if "exit_fee_brl" not in value:
        missing.append("assumptions.exit_fee_brl")
    else:
        if _decimal(value["exit_fee_brl"], "assumptions.exit_fee_brl") < 0:
            raise ValidationError("INVALID_ASSUMPTION", "Custo de saída não pode ser negativo.")
    for field in ("exit_fee_brl", "tax_cost_basis_brl", "custody_override_brl", "institution_net_brl"):
        if field in value and value[field] is not None:
            amount = _decimal(value[field], "assumptions." + field)
            if field in ("tax_cost_basis_brl", "custody_override_brl", "institution_net_brl") and amount < 0:
                raise ValidationError("INVALID_ASSUMPTION", f"assumptions.{field} não pode ser negativo.")
    if value.get("institution_release_date") is not None:
        _date(value["institution_release_date"], "assumptions.institution_release_date")
    if value.get('ipca_monthly_rates') is not None:
        rates = value['ipca_monthly_rates']
        if not isinstance(rates, Mapping) or len(rates) > 1020:
            raise ValidationError('INVALID_IPCA', 'Projeções mensais devem mapear mês YYYY-MM a taxa decimal.')
        for month, rate in rates.items():
            if not isinstance(month, str) or not re.fullmatch(r'\d{4}-\d{2}', month):
                raise ValidationError('INVALID_IPCA_MONTH', 'Projeção mensal exige mês YYYY-MM.')
            _date(month+'-01', 'assumptions.ipca_monthly_rates')
            if _decimal(rate, 'assumptions.ipca_monthly_rates') <= -1:
                raise ValidationError('INVALID_IPCA', 'Inflação mensal deve superar −100%.')
    if "inflation_projection" in value and value["inflation_projection"] is not None:
        projection = _object(value["inflation_projection"], "assumptions.inflation_projection", {
            "mode", "annual_rate", "anchor_date", "anchor_level", "source_ref", "end_annual_rate", "end_date",
        }, {"mode", "annual_rate", "anchor_date", "anchor_level", "source_ref"})
        if projection["mode"] not in ("CONSTANT_ANNUAL", "INTERPOLATED_ANNUAL"):
            raise ValidationError("INVALID_PROJECTION", "Modo de projeção de inflação inválido.")
        rate = _decimal(projection["annual_rate"], "assumptions.inflation_projection.annual_rate")
        if rate <= -1:
            raise ValidationError("INVALID_PROJECTION", "Inflação anual precisa ser maior que −100%.")
        anchor_date = _date(projection["anchor_date"], "assumptions.inflation_projection.anchor_date")
        if projection["mode"] == "INTERPOLATED_ANNUAL":
            if "end_annual_rate" not in projection or "end_date" not in projection:
                missing.extend([f"assumptions.inflation_projection.{field}" for field in ("end_annual_rate", "end_date") if field not in projection])
            else:
                end_rate = _decimal(projection["end_annual_rate"], "assumptions.inflation_projection.end_annual_rate")
                end_date = _date(projection["end_date"], "assumptions.inflation_projection.end_date")
                if end_rate <= -1 or end_date <= anchor_date:
                    raise ValidationError("INVALID_PROJECTION", "Ponto final da inflação inválido.")
        elif "end_annual_rate" in projection or "end_date" in projection:
            raise ValidationError("INVALID_PROJECTION", "Projeção constante não aceita ponto final.")
        if _decimal(projection["anchor_level"], "assumptions.inflation_projection.anchor_level") <= 0:
            raise ValidationError("INVALID_PROJECTION", "Nível-âncora do índice precisa ser positivo.")
        _text(projection["source_ref"], "assumptions.inflation_projection.source_ref", 512)
    if "explicit_settlements" in value and value["explicit_settlements"] is not None:
        if value.get("settlement_profile") != "EXPLICIT":
            raise ValidationError("INVALID_SETTLEMENT_PROFILE", "Datas explícitas exigem settlement_profile EXPLICIT.")
        settlements = _object(value["explicit_settlements"], "assumptions.explicit_settlements", {"purchase", "sale"})
        settlement_dates: dict[str, date] = {}
        for side in ("purchase", "sale"):
            if side not in settlements:
                missing.append("assumptions.explicit_settlements." + side)
                continue
            item = _object(settlements[side], "assumptions.explicit_settlements." + side,
                           {"date", "quality", "source_ref"})
            for field in ("date", "quality", "source_ref"):
                if field not in item:
                    missing.append(f"assumptions.explicit_settlements.{side}.{field}")
            if any(field not in item for field in ("date", "quality", "source_ref")):
                continue
            settlement_dates[side] = _date(item["date"], "assumptions.explicit_settlements." + side + ".date")
            quality = _enum(Quality, item["quality"], "assumptions.explicit_settlements." + side + ".quality")
            if quality in (Quality.MISSING, Quality.RECONSTRUCTED):
                raise ValidationError("INVALID_PROVENANCE", "Liquidação explícita não pode ser MISSING ou RECONSTRUCTED.")
            _text(item["source_ref"], "assumptions.explicit_settlements." + side + ".source_ref", 512)
        if len(settlement_dates) == 2 and settlement_dates["sale"] <= settlement_dates["purchase"]:
            raise ValidationError("INVALID_DATES", "Liquidação da venda precisa ocorrer depois da compra.")
    elif value.get("settlement_profile") == "EXPLICIT":
        missing.extend((
            "assumptions.explicit_settlements.purchase",
            "assumptions.explicit_settlements.sale",
        ))
    return _freeze_json(normalized), tuple(missing)


def _parse_data(raw: object) -> Mapping[str, Any]:
    if raw is None:
        return MappingProxyType({})
    value = _object(raw, "data", _DATA_FIELDS)
    normalized = dict(value)
    monthly = _array(value.get('ipca_monthly_indexes', ()), 'data.ipca_monthly_indexes', 1020)
    monthly_keys = set()
    for index, raw_month in enumerate(monthly):
        path=f'data.ipca_monthly_indexes[{index}]'
        point=_object(raw_month,path,{'month','value','known_on','source_ref','cache_sha256'}, {'month','value','known_on','source_ref'})
        if not isinstance(point['month'], str) or not re.fullmatch(r'\d{4}-\d{2}',point['month']):
            raise ValidationError('INVALID_IPCA_MONTH','Número índice exige mês YYYY-MM.')
        if point['month'] in monthly_keys:
            raise ValidationError('CONFLICTING_IPCA','Número índice mensal duplicado.')
        monthly_keys.add(point['month'])
        from .nominal_index import MonthlyIPCA
        MonthlyIPCA(_date(point['month']+'-01',path+'.month'), _decimal(point['value'],path+'.value'),
                    _date(point['known_on'],path+'.known_on'), _text(point['source_ref'],path+'.source_ref',512))
        if point.get('cache_sha256') is not None:_hash(point['cache_sha256'],path+'.cache_sha256')
    anchors = _array(value.get("index_anchors", ()), "data.index_anchors", 1261)
    seen_anchors: set[tuple[str, str]] = set()
    for index, raw_anchor in enumerate(anchors):
        path = f"data.index_anchors[{index}]"
        anchor = _object(raw_anchor, path, {"kind", "value", "reference_date", "quality", "source_ref", "provenance"},
                         {"kind", "value", "reference_date", "quality", "source_ref"})
        if anchor["kind"] not in ("VNA", "VNI"):
            raise ValidationError("INVALID_INDEX", f"{path}.kind precisa ser VNA ou VNI.")
        number = _decimal(anchor["value"], path + ".value")
        if number <= 0:
            raise ValidationError("INVALID_INDEX", f"{path}.value precisa ser positivo.")
        reference_date = _date(anchor["reference_date"], path + ".reference_date")
        anchor_quality = _enum(Quality, anchor["quality"], path + ".quality")
        if anchor_quality in (Quality.MISSING, Quality.RECONSTRUCTED):
            raise ValidationError("INVALID_INDEX", f"{path} não pode ser MISSING ou RECONSTRUCTED.")
        _text(anchor["source_ref"], path + ".source_ref", 512)
        key = (anchor["kind"], reference_date.isoformat())
        if key in seen_anchors:
            raise ValidationError("CONFLICTING_INDEX", "Há mais de uma âncora do mesmo tipo e data.")
        seen_anchors.add(key)
        if anchor.get("provenance") is not None:
            provenance = _parse_provenance(anchor["provenance"], path + ".provenance")
            if provenance.quality is Quality.MISSING or provenance.quality is not anchor_quality:
                raise ValidationError("INVALID_PROVENANCE", f"{path} e sua proveniência precisam ter a mesma qualidade disponível.")
    levels = _array(value.get("price_index_levels", ()), "data.price_index_levels", 1261)
    seen_levels: set[str] = set()
    for index, raw_level in enumerate(levels):
        path = f"data.price_index_levels[{index}]"
        level = _object(raw_level, path, {"date", "value", "source_ref", "provenance"}, {"date", "value", "source_ref"})
        level_date = _date(level["date"], path + ".date").isoformat()
        if level_date in seen_levels:
            raise ValidationError("INVALID_INDEX", "Há nível de índice repetido na mesma data.")
        seen_levels.add(level_date)
        if _decimal(level["value"], path + ".value") <= 0:
            raise ValidationError("INVALID_INDEX", f"{path}.value precisa ser positivo.")
        _text(level["source_ref"], path + ".source_ref", 512)
        if level.get("provenance") is not None:
            provenance = _parse_provenance(level["provenance"], path + ".provenance")
            if provenance.quality is Quality.MISSING:
                raise ValidationError("INVALID_PROVENANCE", f"{path} não pode ter nível preenchido com proveniência MISSING.")
    costs = _array(value.get("intermediate_paid_costs", ()), "data.intermediate_paid_costs", 240)
    for index, raw_cost in enumerate(costs):
        path = f"data.intermediate_paid_costs[{index}]"
        cost = _object(raw_cost, path, {"date", "amount_brl", "label"}, {"date", "amount_brl", "label"})
        _date(cost["date"], path + ".date")
        if _decimal(cost["amount_brl"], path + ".amount_brl") > 0:
            raise ValidationError("INVALID_CASH_FLOW", "Custo intermediário precisa ser zero ou negativo.")
        _text(cost["label"], path + ".label", 128)
    return _freeze_json(normalized)


def _index_pending_field(point: Any, fallback: str) -> str:
    if point is not None and point.reason_code == 'MISSING_PROJECTION':
        return 'assumptions.inflation_projection'
    if point is not None and point.profile_id == 'TD_CALENDAR_15_IPCA_RATIO_v1':
        return 'data.ipca_monthly_indexes'
    return fallback


def _monthly_ipca_inputs(data: Mapping[str, Any], observations: tuple[IndexObservation, ...] | None):
    from .nominal_index import MonthlyIPCA
    rows = []
    direct = _thaw_json(data).get('ipca_monthly_indexes', [])
    direct_keys = set()
    for raw in direct:
        month = date.fromisoformat(raw['month']+'-01')
        rows.append(MonthlyIPCA(month, raw['value'], date.fromisoformat(raw['known_on']), raw['source_ref'], raw.get('cache_sha256')))
        direct_keys.add(month)
    # An explicit monthly series selects that complete series; bundled history
    # cannot silently fill its gaps or override its declared cutoff.
    if direct:
        return tuple(rows)
    for item in observations or ():
        if item.kind != 'IPCA_MONTHLY_INDEX':continue
        digest = re.search(r'cache SHA256 ([0-9a-f]{64})', item.source)
        rows.append(MonthlyIPCA(item.reference_date, item.value, item.known_on, item.source,
                               digest.group(1) if digest else None))
    return tuple(rows)


def _monthly_ipca_source_identity(rows):
    """Identify the selected monthly input, including offline cache revisions."""
    if not rows:
        return {}
    from hashlib import sha256
    import json
    hashes = {item.cache_sha256 for item in rows if item.cache_sha256}
    if len(hashes) == 1 and all(item.cache_sha256 for item in rows):
        digest = next(iter(hashes))
    else:
        records = [(item.month.isoformat(), str(item.value), item.known_on.isoformat(), item.source_ref) for item in rows]
        digest = sha256(json.dumps(sorted(records), ensure_ascii=False, separators=(',', ':')).encode('utf8')).hexdigest()
    return {'ipca_monthly_cache_sha256': digest}


def _monthly_ipca_rates(assumptions: Mapping[str, Any]):
    return tuple((date.fromisoformat(month+'-01'),Decimal(rate))
                 for month,rate in (assumptions.get('ipca_monthly_rates') or {}).items())


def _parse_source_versions(raw: object) -> tuple[tuple[str, str | None], ...]:
    if raw is None:
        return (("market_sim", None), ("market_sim_indexes", None))
    value = _object(raw, "source_versions", {"market_sim", "market_sim_indexes"}, {"market_sim", "market_sim_indexes"})
    normalized: list[tuple[str, str | None]] = []
    for field in ("market_sim", "market_sim_indexes"):
        version = value.get(field)
        normalized.append((field, _optional_hash(version, "source_versions." + field)))
    return tuple(normalized)


def _reject_non_json_numbers(value: object, path: str, depth: int = 0) -> None:
    if depth > 32:
        raise ValidationError("INPUT_TOO_DEEP", f"{path} ultrapassa a profundidade máxima do contrato.")
    if isinstance(value, float):
        if not math.isfinite(value):
            raise ValidationError("NON_FINITE", f"{path} contém número não finito.")
        raise ValidationError("INVALID_NUMBER_FORMAT", f"{path} deve usar strings decimais para valores financeiros.")
    if isinstance(value, Mapping):
        if any(not isinstance(key, str) for key in value):
            raise ValidationError("INVALID_OBJECT", f"{path} contém chave que não é texto.")
        for key, item in value.items():
            _reject_non_json_numbers(item, f"{path}.{key}", depth + 1)
    elif isinstance(value, (list, tuple)):
        for index, item in enumerate(value):
            _reject_non_json_numbers(item, f"{path}[{index}]", depth + 1)
    elif value is not None and not isinstance(value, (str, int, bool)):
        raise ValidationError("INVALID_JSON_VALUE", f"{path} contém valor não permitido em JSON.")


def _object(raw: object, name: str, allowed: set[str], required: set[str] | None = None) -> dict[str, Any]:
    if not isinstance(raw, Mapping) or any(not isinstance(key, str) for key in raw):
        raise ValidationError("INVALID_OBJECT", f"{name} precisa ser um objeto JSON.")
    extra = set(raw) - allowed
    missing = (required or set()) - set(raw)
    if extra:
        raise ValidationError("UNKNOWN_FIELD", f"Campo inesperado em {name}: " + ", ".join(sorted(extra)))
    if missing:
        raise ValidationError("MISSING_FIELD", f"Campo obrigatório ausente em {name}: " + ", ".join(sorted(missing)))
    return dict(raw)


def _only_fields(value: Mapping[str, Any], path: str, allowed: set[str]) -> None:
    extra = set(value) - allowed
    if extra:
        raise ValidationError("UNKNOWN_FIELD", f"Campo inesperado em {path}: " + ", ".join(sorted(extra)))


def _array(raw: object, name: str, maximum: int) -> tuple[Any, ...]:
    if not isinstance(raw, (list, tuple)) or isinstance(raw, (str, bytes)):
        raise ValidationError("INVALID_ARRAY", f"{name} precisa ser uma lista.")
    if len(raw) > maximum:
        raise ValidationError("ARRAY_LIMIT", f"{name} excede o limite de {maximum} itens.")
    return tuple(raw)


def _enum(enum_type: type[StrEnum], raw: object, name: str) -> Any:
    if not isinstance(raw, str):
        raise ValidationError("INVALID_ENUM", f"{name} precisa ser um identificador textual conhecido.")
    try:
        return enum_type(raw)
    except ValueError as exc:
        raise ValidationError("INVALID_ENUM", f"{name} não é suportado.") from exc


def _date(raw: object, name: str) -> date:
    if not isinstance(raw, str) or not re.fullmatch(r"\d{4}-\d{2}-\d{2}", raw):
        raise ValidationError("INVALID_DATE", f"{name} precisa estar no formato AAAA-MM-DD.")
    try:
        parsed = date.fromisoformat(raw)
    except ValueError as exc:
        raise ValidationError("INVALID_DATE", f"{name} não é uma data válida.") from exc
    if parsed.isoformat() != raw:
        raise ValidationError("INVALID_DATE", f"{name} precisa estar normalizada em AAAA-MM-DD.")
    return parsed


def _optional_date(raw: object, name: str) -> date | None:
    return None if raw is None else _date(raw, name)


def _decimal(raw: object, name: str) -> Decimal:
    if not isinstance(raw, str) or not raw or raw.strip() != raw:
        raise ValidationError("INVALID_NUMBER_FORMAT", f"{name} deve ser texto decimal canônico.")
    try:
        result = Decimal(raw)
    except InvalidOperation as exc:
        raise ValidationError("INVALID_NUMBER_FORMAT", f"{name} deve ser um decimal válido.") from exc
    if not result.is_finite():
        raise ValidationError("NON_FINITE", f"{name} deve ser finito.")
    if not re.fullmatch(r"[+-]?(?:0|[1-9]\d*)(?:\.\d+)?", raw):
        raise ValidationError("INVALID_NUMBER_FORMAT", f"{name} deve usar decimal canônico sem expoente ou agrupamento.")
    return result


def _text(raw: object, name: str, maximum: int) -> str:
    if not isinstance(raw, str) or not raw.strip() or len(raw) > maximum:
        raise ValidationError("INVALID_TEXT", f"{name} precisa ser texto não vazio de até {maximum} caracteres.")
    if raw != raw.strip():
        raise ValidationError("INVALID_TEXT", f"{name} não pode ter espaços externos.")
    return raw


def _optional_text(raw: object, name: str, maximum: int) -> str | None:
    return None if raw is None else _text(raw, name, maximum)


def _optional_decimal(raw: object, name: str) -> Decimal | None:
    return None if raw is None else _decimal(raw, name)


def _optional_datetime(raw: object, name: str) -> datetime | None:
    if raw is None:
        return None
    if not isinstance(raw, str):
        raise ValidationError("INVALID_DATE", f"{name} precisa ser data ISO com fuso.")
    try:
        parsed = datetime.fromisoformat(raw)
    except ValueError as exc:
        raise ValidationError("INVALID_DATE", f"{name} não é uma data ISO válida.") from exc
    if parsed.tzinfo is None:
        raise ValidationError("INVALID_DATE", f"{name} precisa incluir fuso horário.")
    return parsed


def _hash(raw: object, name: str) -> str:
    if not isinstance(raw, str) or not re.fullmatch(r"[0-9a-fA-F]{64}", raw):
        raise ValidationError("INVALID_HASH", f"{name} precisa ser SHA-256 hexadecimal de 64 dígitos.")
    return raw.lower()


def _optional_hash(raw: object, name: str) -> str | None:
    return None if raw is None else _hash(raw, name)


def _validate_rate(rate: Decimal, path: str, family: ProductFamily | None) -> None:
    if family is ProductFamily.RENDA_PLUS and not Decimal("-0.95") <= rate <= Decimal("10"):
        raise ValidationError("INVALID_YIELD", f"{path} está fora do intervalo suportado para RendA+.")
    if rate <= -1:
        raise ValidationError("INVALID_YIELD", f"{path} precisa ser maior que −100%.")


def _freeze_json(value: Any) -> Any:
    if isinstance(value, Mapping):
        return MappingProxyType({key: _freeze_json(item) for key, item in value.items()})
    if isinstance(value, (list, tuple)):
        return tuple(_freeze_json(item) for item in value)
    return value


def _thaw_json(value: Any) -> Any:
    if isinstance(value, Mapping):
        return {key: _thaw_json(item) for key, item in value.items()}
    if isinstance(value, tuple):
        return [_thaw_json(item) for item in value]
    return value


def _provenance_dict(value: Provenance) -> dict[str, Any]:
    return {
        "source_id": value.source_id,
        "source_ref": value.source_ref,
        "quality": value.quality.value,
        "observed_on": value.observed_on.isoformat() if value.observed_on else None,
        "published_at": value.published_at.isoformat() if value.published_at else None,
        "version": value.version,
        "sha256": value.sha256,
        "revision_id": value.revision_id,
        "supersedes_revision": value.supersedes_revision,
        "settlement_date": value.settlement_date.isoformat() if value.settlement_date else None,
    }
