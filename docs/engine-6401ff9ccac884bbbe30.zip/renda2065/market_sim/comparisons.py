"""Fair comparison of independently resolved v2 workspace alternatives."""
from __future__ import annotations

from datetime import date
from decimal import Decimal, InvalidOperation, localcontext
from typing import Any, Mapping, Sequence

from .contracts import ValidationError
from .policies import calculate_income_tax, income_tax_rate, round_money

_CASH_GROWTH_PROFILE = "ACT_365_COMPOUND_v1"


def g5_threshold_margin(
    *, metric: str, condition_id: str, actual_value: object, threshold: object, unit: str,
) -> dict[str, str]:
    """Return a named margin without conflating unlike decision conditions."""
    for name, value in (("metric", metric), ("condition_id", condition_id), ("unit", unit)):
        if not isinstance(value, str) or not value.strip():
            raise ValidationError("INVALID_G5_MARGIN", f"{name} precisa ser texto não vazio.")
    actual = _g5_decimal(actual_value, "actual_value")
    limit = _g5_decimal(threshold, "threshold")
    margin = actual - limit
    if unit == "BRL":
        actual, limit, margin = map(round_money, (actual, limit, margin))
    return {
        "metric": metric,
        "condition_id": condition_id,
        "unit": unit,
        "actual_value": str(actual),
        "threshold": str(limit),
        "margin": str(margin),
        "status": "MET" if margin >= 0 else "NOT_MET",
    }


def g5_decompose_metric(y0: object, ya: object, yb: object, yab: object) -> dict[str, Any]:
    """Decompose a 2x2 deterministic result and retain the displayed residual."""
    with localcontext() as context:
        context.prec = 50
        base, value_a, value_b, value_ab = (
            _g5_decimal(value, name)
            for value, name in ((y0, "Y0"), (ya, "YA"), (yb, "YB"), (yab, "YAB"))
        )
        isolated_a = value_a - base
        isolated_b = value_b - base
        interaction = value_ab - value_a - value_b + base
        total_delta = value_ab - base
        exact_residual = total_delta - isolated_a - isolated_b - interaction
        displayed_components = {
            "isolated_a": round_money(isolated_a),
            "isolated_b": round_money(isolated_b),
            "interaction": round_money(interaction),
        }
        displayed_total = round_money(total_delta)
        observed_rounding_residual = round_money(
            displayed_total - sum(displayed_components.values(), Decimal(0))
        )
    return {
        "base": str(base),
        "rate_a": str(value_a),
        "inflation_b": str(value_b),
        "rate_a_and_inflation_b": str(value_ab),
        "isolated_a": str(isolated_a),
        "isolated_b": str(isolated_b),
        "interaction": str(interaction),
        "total_delta": str(total_delta),
        "exact_residual": str(exact_residual),
        "displayed": {
            "components": {key: str(value) for key, value in displayed_components.items()},
            "total_delta": str(displayed_total),
            "observed_rounding_residual": str(observed_rounding_residual),
        },
    }


def g5_tax_bracket_control(gain_brl: object) -> dict[str, Any]:
    """Show the existing statutory tax rates on one fixed nominal gain."""
    gain = round_money(_g5_decimal(gain_brl, "gain_brl"))
    result: dict[str, Any] = {"gain_brl": str(gain)}
    for key, holding_days in (("day_180", 180), ("day_181", 181)):
        rate = income_tax_rate(holding_days)
        tax = calculate_income_tax(gain, Decimal(0), holding_days).amount
        result[key] = {
            "holding_days": holding_days,
            "income_tax_rate": str(rate),
            "income_tax_brl": str(tax),
        }
    return result


def g5_fiscal_transition_bridge(
    day180: Mapping[str, Any], day181: Mapping[str, Any], *,
    day180_total_at_horizon: object, day181_total_at_horizon: object,
    day180_availability: object, day181_availability: object,
    common_horizon: object, cash_growth_rate: object,
) -> dict[str, Any]:
    """Attribute a 180/181-day change while keeping cash timing explicit."""
    if not isinstance(day180, Mapping) or not isinstance(day181, Mapping):
        raise ValidationError("INVALID_G5_FISCAL_BRIDGE", "O par fiscal exige duas operações estruturadas.")
    day180_date = _as_date(day180_availability, "day180_availability")
    day181_date = _as_date(day181_availability, "day181_availability")
    horizon = _as_date(common_horizon, "common_horizon")
    if (day181_date - day180_date).days != 1 or day181_date != horizon:
        raise ValidationError(
            "INVALID_G5_FISCAL_BRIDGE",
            "O par fiscal G5 exige disponibilidades consecutivas e horizonte na data posterior.",
        )
    if day180.get("holding_days") != 180 or day181.get("holding_days") != 181:
        raise ValidationError("INVALID_G5_FISCAL_BRIDGE", "O par fiscal G5 precisa preservar 180 e 181 dias de permanência.")
    cash_rate = _g5_decimal(cash_growth_rate, "cash_growth_rate")
    if cash_rate <= -1:
        raise ValidationError("INVALID_G5_FISCAL_BRIDGE", "A taxa líquida de caixa precisa ser maior que −100%.")

    def operation_amount(row: Mapping[str, Any], key: str, name: str) -> Decimal:
        if key not in row:
            raise ValidationError("INVALID_G5_FISCAL_BRIDGE", f"{name}.{key} está ausente.")
        return round_money(_g5_decimal(row[key], f"{name}.{key}"))

    def taxable_base(row: Mapping[str, Any], name: str, gross: Decimal, iof: Decimal) -> Decimal:
        basis_field = "tax_basis" if "tax_basis" in row else "tax_cost_basis"
        basis = operation_amount(row, basis_field, name)
        derived = max(gross - basis - iof, Decimal(0))
        if "taxable_base" in row:
            stated = operation_amount(row, "taxable_base", name)
            if stated != derived:
                raise ValidationError("INVALID_G5_FISCAL_BRIDGE", f"{name}.taxable_base não reconcilia com bruto, IOF e base fiscal.")
        return derived

    gross180 = operation_amount(day180, "gross_redemption", "day180")
    gross181 = operation_amount(day181, "gross_redemption", "day181")
    iof180 = operation_amount(day180, "iof", "day180")
    iof181 = operation_amount(day181, "iof", "day181")
    tax180 = operation_amount(day180, "income_tax", "day180")
    tax181 = operation_amount(day181, "income_tax", "day181")
    custody180 = operation_amount(day180, "custody", "day180")
    custody181 = operation_amount(day181, "custody", "day181")
    exit_expense180 = operation_amount(day180, "exit_expense", "day180")
    exit_expense181 = operation_amount(day181, "exit_expense", "day181")
    net180 = operation_amount(day180, "net_redemption", "day180")
    net181 = operation_amount(day181, "net_redemption", "day181")
    base180 = taxable_base(day180, "day180", gross180, iof180)
    base181 = taxable_base(day181, "day181", gross181, iof181)
    rate180 = income_tax_rate(180)
    rate181 = income_tax_rate(181)
    if any(
        _g5_decimal(row["income_tax_rate"], f"{name}.income_tax_rate") != rate
        for row, name, rate in ((day180, "day180", rate180), (day181, "day181", rate181))
        if row.get("income_tax_rate") is not None
    ):
        raise ValidationError("INVALID_G5_FISCAL_BRIDGE", "As alíquotas declaradas precisam coincidir com a política fiscal vigente.")
    if round_money(base180 * rate180) != tax180 or round_money(base181 * rate181) != tax181:
        raise ValidationError("INVALID_G5_FISCAL_BRIDGE", "IR observado não reconcilia com base tributável e política fiscal vigente.")
    for name, gross, iof, tax, custody, expense, net in (
        ("day180", gross180, iof180, tax180, custody180, exit_expense180, net180),
        ("day181", gross181, iof181, tax181, custody181, exit_expense181, net181),
    ):
        if round_money(gross - iof - tax - custody - expense) != net:
            raise ValidationError("INVALID_G5_FISCAL_BRIDGE", f"{name}.net_redemption não reconcilia com seus componentes.")

    total180 = operation_amount(
        {"value": day180_total_at_horizon}, "value", "day180_total_at_horizon",
    )
    total181 = operation_amount(
        {"value": day181_total_at_horizon}, "value", "day181_total_at_horizon",
    )
    expected180 = _grow_cash(net180, cash_rate, day180_date, horizon)
    expected181 = _grow_cash(net181, cash_rate, day181_date, horizon)
    if total180 != expected180 or total181 != expected181:
        raise ValidationError("INVALID_G5_FISCAL_BRIDGE", "Totais no horizonte não reconciliam com líquidos, datas e caixa declarados.")

    counterfactual181_tax_at_old_rate = round_money(base181 * rate180)
    tax_base_effect = counterfactual181_tax_at_old_rate - tax180
    rate_change_benefit = counterfactual181_tax_at_old_rate - tax181
    net_tax_reduction = tax180 - tax181
    gross_change = gross181 - gross180
    iof_change = iof181 - iof180
    custody_change = custody181 - custody180
    exit_expense_change = exit_expense181 - exit_expense180
    cash_timing_effect = total180 - net180
    wealth_change = total181 - total180
    reconciled_change = (
        gross_change - iof_change + net_tax_reduction
        - custody_change - exit_expense_change - cash_timing_effect
    )
    residual = wealth_change - reconciled_change
    return {
        "income_tax_rate_day_180": str(rate180),
        "income_tax_rate_day_181": str(rate181),
        "taxable_base_day_180_brl": str(base180),
        "taxable_base_day_181_brl": str(base181),
        "tax_at_day_181_base_and_day_180_rate_brl": str(counterfactual181_tax_at_old_rate),
        "tax_base_effect_brl": str(tax_base_effect),
        "rate_change_benefit_brl": str(rate_change_benefit),
        "net_tax_reduction_brl": str(net_tax_reduction),
        "gross_change_brl": str(gross_change),
        "iof_change_brl": str(iof_change),
        "custody_change_brl": str(custody_change),
        "exit_expense_change_brl": str(exit_expense_change),
        "cash_timing_effect_brl": str(cash_timing_effect),
        "wealth_advantage_change_brl": str(wealth_change),
        "reconciled_delta_brl": str(reconciled_change),
        "observed_residual_brl": str(residual),
    }


def _g5_decimal(value: object, name: str) -> Decimal:
    if isinstance(value, bool) or value is None:
        raise ValidationError("INVALID_G5_DECIMAL", f"{name} precisa ser um número decimal finito.")
    try:
        result = value if isinstance(value, Decimal) else Decimal(str(value))
    except (InvalidOperation, TypeError, ValueError) as exc:
        raise ValidationError("INVALID_G5_DECIMAL", f"{name} precisa ser um número decimal finito.") from exc
    if not result.is_finite():
        raise ValidationError("INVALID_G5_DECIMAL", f"{name} precisa ser um número decimal finito.")
    return result


def compare_workspace_evaluations(
    items: Sequence[Mapping[str, Any]], *, comparison_mode: str = "BUDGET",
) -> dict[str, Any]:
    """Compare direct evaluations and reconcile cash to one declared horizon.

    Every item supplies its own normalized input, resolution, and evaluation.
    Comparison-level horizon and cash growth are shared metadata; financial
    inputs, evidence, and index anchors are never copied between alternatives.
    """
    if comparison_mode == "FIXED_POSITION":
        return _compare_fixed_position_evaluations(items)
    if comparison_mode != "BUDGET":
        raise ValidationError("INVALID_COMPARISON_MODE", "Modo de comparação não suportado.")
    if not 2 <= len(items) <= 3:
        raise ValidationError("INVALID_COMPARISON", "A comparação exige uma referência e uma ou duas alternativas.")

    normalized = [item["normalized_input"] for item in items]
    if any(
        (entry.get("analysis_context") or {}).get("kind") == "UNIT_PRICE"
        for entry in normalized
    ):
        raise ValidationError(
            "UNIT_PRICE_NOT_COMPARABLE",
            "Preço unitário é expresso por título e não representa uma operação patrimonial; compare-o fora do ranking de operações.",
        )
    capitals = [entry.get("capital") for entry in normalized]
    if any(not isinstance(value, Mapping) or value.get("mode") != "BUDGET" for value in capitals):
        raise ValidationError("COMMON_BUDGET_REQUIRED", "Cada cenário precisa usar orçamento comum.")
    try:
        capital_values = {Decimal(value["value"]) for value in capitals}
    except (InvalidOperation, KeyError, TypeError) as exc:
        raise ValidationError("COMMON_BUDGET_REQUIRED", "Cada cenário precisa declarar o mesmo orçamento.") from exc
    if len(capital_values) != 1:
        raise ValidationError("COMMON_BUDGET_MISMATCH", "Todos os cenários precisam usar o mesmo orçamento.")
    common_budget = next(iter(capital_values))

    comparison_context = items[0].get("comparison_context") or {}
    if any((item.get("comparison_context") or {}) != comparison_context for item in items[1:]):
        raise ValidationError("COMPARISON_CONTEXT_MISMATCH", "Horizonte e crescimento de caixa precisam ser comuns a todas as alternativas.")
    horizon = comparison_context.get("horizon")
    if horizon is not None:
        horizon = _as_date(horizon, "horizon")
    cash_growth = comparison_context.get("cash_growth")
    growth_rate: Decimal | None = None
    growth_origin: date | None = None
    if cash_growth is not None:
        if not isinstance(cash_growth, Mapping) or cash_growth.get("profile") != _CASH_GROWTH_PROFILE:
            raise ValidationError("UNSUPPORTED_CASH_GROWTH_PROFILE", f"O perfil precisa ser {_CASH_GROWTH_PROFILE}.")
        growth_rate = Decimal(cash_growth["annual_net_rate"])
        growth_origin = _as_date(cash_growth["origin_date"], "cash_growth.origin_date")
        if growth_rate <= -1:
            raise ValidationError("INVALID_CASH_GROWTH_RATE", "A taxa líquida anual precisa ser maior que −100%.")
        if horizon is None:
            raise ValidationError("HORIZON_REQUIRED", "Crescimento de caixa exige um horizonte comum explícito.")

    rows: list[dict[str, Any]] = []
    flow_values: list[dict[str, Any]] = []
    purchase_orders: set[str] = set()
    purchase_settlements: set[str] = set()
    sale_orders: set[str] = set()
    sale_settlements: set[str] = set()
    intermediate_costs_present = False
    point_override_present = False

    for item, source in zip(items, normalized):
        resolution = item["resolution"]
        evaluation = item.get("evaluation")
        operation = getattr(evaluation, "operation", None)
        constraint_evaluation = getattr(evaluation, "constraint_evaluation", None)
        dates = resolution.get("dates") or {}
        purchase = dates.get("purchase") or {}
        sale = dates.get("sale") or {}
        purchase_settlement = purchase.get("settlement_date")
        sale_settlement = sale.get("settlement_date")
        purchase_order = purchase.get("proposed_order_date") or source.get("purchase_date")
        sale_order = sale.get("proposed_order_date") or source.get("sale_date")
        purchase_order_day = _date_or_none(purchase_order)
        sale_order_day = _date_or_none(sale_order)
        purchase_settlement_day = _date_or_none(purchase_settlement)
        sale_settlement_day = _date_or_none(sale_settlement)
        if (purchase_order_day is not None and purchase_settlement_day is not None
                and purchase_settlement_day < purchase_order_day):
            raise ValidationError("INVALID_CASH_FLOW_DATES", "A liquidação da compra não pode preceder sua ordem.")
        if (sale_order_day is not None and sale_settlement_day is not None
                and sale_settlement_day < sale_order_day):
            raise ValidationError("INVALID_CASH_FLOW_DATES", "A liquidação da venda não pode preceder sua ordem.")
        if (purchase_order_day is not None and sale_order_day is not None
                and sale_order_day < purchase_order_day):
            raise ValidationError("INVALID_CASH_FLOW_DATES", "A venda não pode ser ordenada antes da compra.")
        if (purchase_settlement_day is not None and sale_settlement_day is not None
                and sale_settlement_day < purchase_settlement_day):
            raise ValidationError("INVALID_CASH_FLOW_DATES", "A liquidação da venda não pode preceder a liquidação da compra.")
        if purchase_order:
            purchase_orders.add(purchase_order)
        if purchase.get("status") == "available" and purchase_settlement:
            purchase_settlements.add(purchase_settlement)
        if sale_order:
            sale_orders.add(sale_order)
        if sale.get("status") == "available" and sale_settlement:
            sale_settlements.add(sale_settlement)

        data = source.get("data") or {}
        assumptions = source.get("assumptions") or {}
        intermediate_costs_present |= any(
            Decimal(str(flow.get("amount_brl", "0"))) != 0
            for flow in data.get("intermediate_paid_costs", ())
        )
        point_override_present |= any(
            assumptions.get(name) is not None
            for name in ("custody_override_brl", "institution_net_brl")
        )

        sizing = resolution.get("purchase_sizing")
        remainder = _sizing_value(sizing, "cash_remainder")
        initial_outflow = _sizing_value(sizing, "initial_outflow")
        net_redemption = None if operation is None else operation.net_redemption
        operation_result = None
        if operation is not None:
            operation_result = {
                "status": operation.status,
                "quality": _enum_value(operation.quality),
                "quantity": _decimal(operation.quantity),
                "entry_pu": _decimal(operation.entry_pu),
                "exit_pu": _decimal(operation.exit_pu),
                "initial_outflow": _decimal(operation.initial_outflow),
                "gross_redemption": _decimal(operation.gross_redemption),
                "iof": _decimal(operation.iof),
                "income_tax": _decimal(operation.income_tax),
                "custody": _decimal(operation.custody),
                "exit_expense": _decimal(operation.exit_expense),
                "net_redemption": _decimal(operation.net_redemption),
                "nominal_profit": _decimal(operation.nominal_profit),
                "nominal_return": _decimal(operation.nominal_return),
                "annualized_nominal_return": _decimal(operation.annualized_nominal_return),
                "real_profit_in_exit_date_currency": _decimal(operation.real_profit_in_exit_date_currency),
                "real_return": _decimal(operation.real_return),
                "holding_days": operation.holding_days,
            }

        row_status = "ready" if operation_result is not None and net_redemption is not None and remainder is not None else "partial"
        instrument = source.get("instrument") or {}
        entry_price = source.get("entry_price") or {}
        exit_price = source.get("exit_price") or {}
        row = {
            "id": item["id"],
            "label": item["label"],
            "input_fingerprint": item["input_fingerprint"],
            "status": row_status,
            "instrument": {
                "family": instrument.get("family"),
                "instrument_id": instrument.get("instrument_id"),
                "maturity_date": instrument.get("maturity_date"),
            },
            "capital": {"mode": "BUDGET", "value": str(common_budget), "unit": "BRL"},
            "dates": {
                "purchase_order": purchase_order,
                "purchase_settlement": purchase_settlement,
                "sale_order": sale_order,
                "sale_settlement": sale_settlement,
            },
            "purchase_sizing": sizing,
            "operation": operation_result,
            "cash_remainder": None if remainder is None else {"value": str(remainder), "unit": "BRL"},
            "cash_conservation": None,
            "total_resources_at_horizon": None,
            "source_versions": source.get("source_versions", {}),
            "price_provenance": {
                "entry": {"mode": entry_price.get("mode"), "provenance": entry_price.get("provenance")},
                "exit": {"mode": exit_price.get("mode"), "provenance": exit_price.get("provenance")},
            },
            "quality": None if operation is None else _enum_value(operation.quality),
            "goals": None if constraint_evaluation is None else constraint_evaluation.to_dict(),
            "warnings": list(getattr(evaluation, "warnings", ())) if evaluation is not None else [],
            "differences_from_reference": [],
        }
        rows.append(row)
        flow_values.append({
            "remainder": remainder,
            "initial_outflow": initial_outflow,
            "net_redemption": net_redemption,
            "purchase_settlement": _date_or_none(purchase_settlement),
            "sale_settlement": _date_or_none(sale_settlement),
        })

    reference_input = normalized[0]
    reference_quality = rows[0]["quality"]
    for row, source in zip(rows[1:], normalized[1:]):
        row["differences_from_reference"] = _input_differences(reference_input, source)
        if row["quality"] != reference_quality:
            row["differences_from_reference"].append("evidence_quality")

    reference_row = rows[0]
    for row in rows:
        row["metric_deltas_from_reference"] = _metric_deltas_from_reference(
            reference_row.get("operation"), row.get("operation"),
        )
        reference_quality_value = reference_row.get("quality")
        alternative_quality_value = row.get("quality")
        row["quality_comparison"] = {
            "reference": reference_quality_value,
            "alternative": alternative_quality_value,
            "same": None if reference_quality_value is None or alternative_quality_value is None
            else reference_quality_value == alternative_quality_value,
        }
        row["goal_deltas_from_reference"] = _goal_deltas_from_reference(
            reference_row.get("goals"), row.get("goals"),
        )

    reasons: list[dict[str, str]] = []
    if any(row["status"] == "partial" for row in rows):
        reasons.append({"code": "ALTERNATIVE_INCOMPLETE", "message": "Uma ou mais alternativas não têm avaliação financeira completa."})
    dates_diverge = any(len(values) != 1 for values in (purchase_orders, purchase_settlements, sale_orders, sale_settlements))
    available_sales = [item["sale_settlement"] for item in flow_values if item["sale_settlement"] is not None]
    available_purchases = [item["purchase_settlement"] for item in flow_values if item["purchase_settlement"] is not None]
    common_horizon = horizon or (
        _as_date(next(iter(sale_settlements)), "sale_settlement")
        if len(sale_settlements) == 1 else None
    )

    if horizon is not None and available_sales and max(available_sales) > horizon:
        raise ValidationError("INVALID_COMPARISON_HORIZON", "horizon não pode preceder nenhuma liquidação de venda.")
    available_purchase_orders = [
        _as_date(item, "purchase_order") for item in purchase_orders
    ]
    if growth_origin is not None and available_purchase_orders and growth_origin > min(available_purchase_orders):
        raise ValidationError("INVALID_CASH_GROWTH_ORIGIN", "cash_growth.origin_date precisa ser anterior ou igual a todas as compras.")

    if intermediate_costs_present:
        reasons.append({"code": "INTERMEDIATE_CASH_FLOWS_REQUIRE_FUNDING_MODEL", "message": "Custos intermediários impedem ordenar o valor patrimonial sem hipótese de financiamento."})
    if point_override_present:
        reasons.append({"code": "POINT_OVERRIDE_NOT_COMPARABLE", "message": "Custódia ou líquido institucional informado para um ponto impede ordenar alternativas como estimativas equivalentes."})

    cash_flow_model_available = not intermediate_costs_present and not point_override_present
    if growth_rate is None:
        if dates_diverge:
            reasons.append({"code": "DATES_NOT_COMMON", "message": "Datas diferentes exigem uma taxa líquida de caixa e horizonte comuns para ordenar patrimônio."})
        elif common_horizon is not None and available_sales and common_horizon > max(available_sales):
            reasons.append({"code": "CASH_GROWTH_REQUIRED", "message": "Um horizonte posterior à venda exige uma hipótese explícita de crescimento líquido do caixa."})
        elif not available_sales or common_horizon is None:
            reasons.append({"code": "COMMON_HORIZON_UNAVAILABLE", "message": "Não foi possível resolver uma liquidação comum para valorar o patrimônio."})
        elif cash_flow_model_available:
            _set_no_growth_values(rows, flow_values, common_budget, common_horizon)
    elif cash_flow_model_available and common_horizon is not None and growth_origin is not None:
        for row, flows in zip(rows, flow_values):
            if row["status"] != "ready":
                continue
            purchase_day = flows["purchase_settlement"]
            sale_day = flows["sale_settlement"]
            remainder = flows["remainder"]
            initial_outflow = flows["initial_outflow"]
            net_redemption = flows["net_redemption"]
            if None in (purchase_day, sale_day, remainder, initial_outflow, net_redemption):
                row["status"] = "partial"
                continue
            assert isinstance(purchase_day, date) and isinstance(sale_day, date)
            assert isinstance(remainder, Decimal) and isinstance(initial_outflow, Decimal)
            assert isinstance(net_redemption, Decimal)
            available_at_purchase = _grow_cash(common_budget, growth_rate, growth_origin, purchase_day)
            if available_at_purchase < initial_outflow:
                row["status"] = "infeasible"
                row["cash_conservation"] = {
                    "status": "infeasible",
                    "reason_code": "INSUFFICIENT_PREPURCHASE_CASH",
                    "available_at_purchase": {"value": str(available_at_purchase), "unit": "BRL"},
                    "required_initial_outflow": {"value": str(initial_outflow), "unit": "BRL"},
                    "implicit_contribution": False,
                }
                reasons.append({"code": "INSUFFICIENT_PREPURCHASE_CASH", "message": f"O caixa disponível não cobre o desembolso de {row['label']}; nenhum aporte foi presumido."})
                continue

            cash_after_purchase = round_money(available_at_purchase - initial_outflow)
            cash_at_horizon = _grow_cash(cash_after_purchase, growth_rate, purchase_day, common_horizon)
            sale_proceeds_at_horizon = _grow_cash(net_redemption, growth_rate, sale_day, common_horizon)
            total = round_money(cash_at_horizon + sale_proceeds_at_horizon)
            pre_purchase_delta = available_at_purchase - common_budget
            remainder_growth = cash_at_horizon - cash_after_purchase
            sale_growth = sale_proceeds_at_horizon - net_redemption
            row["cash_conservation"] = {
                "status": "balanced",
                "cash_available_at_origin": {"value": str(common_budget), "unit": "BRL"},
                "cash_available_at_purchase": {"value": str(available_at_purchase), "unit": "BRL"},
                "prepurchase_cash_growth_delta": {"value": str(pre_purchase_delta), "unit": "BRL"},
                "fixed_budget_for_purchase": {"value": str(common_budget), "unit": "BRL"},
                "initial_outflow": {"value": str(initial_outflow), "unit": "BRL"},
                "cash_remainder_at_purchase": {"value": str(cash_after_purchase), "unit": "BRL"},
                "cash_remainder_at_horizon": {"value": str(cash_at_horizon), "unit": "BRL"},
                "sale_proceeds_at_horizon": {"value": str(sale_proceeds_at_horizon), "unit": "BRL"},
                "profile": _CASH_GROWTH_PROFILE,
                "annual_net_rate": str(growth_rate),
                "origin_date": growth_origin.isoformat(),
                "horizon": common_horizon.isoformat(),
                "implicit_contribution": False,
            }
            row["total_resources_at_horizon"] = {"value": str(total), "unit": "BRL"}
            row["_flow_components"] = {
                "operation_net_redemption": net_redemption,
                "fixed_budget_remainder": common_budget - initial_outflow,
                "prepurchase_cash_growth": pre_purchase_delta,
                "remainder_growth_after_purchase": remainder_growth,
                "sale_proceeds_growth": sale_growth,
            }
    elif cash_flow_model_available:
        reasons.append({"code": "CASH_FLOW_MODEL_UNAVAILABLE", "message": "Os fluxos de caixa não podem ser conciliados com as premissas atuais."})

    budget_checks: list[bool] = []
    for row in rows:
        sizing = row["purchase_sizing"]
        cash_remainder = row["cash_remainder"]
        sizing_outflow = _sizing_value(sizing, "initial_outflow")
        if sizing_outflow is None or cash_remainder is None:
            budget_checks = []
            break
        reconciles = sizing_outflow + Decimal(cash_remainder["value"]) == common_budget
        operation_outflow = (row["operation"] or {}).get("initial_outflow")
        if operation_outflow is not None:
            reconciles &= Decimal(operation_outflow) == sizing_outflow
        budget_checks.append(reconciles)
    reconciles_common_budget: bool | None = (
        None if len(budget_checks) != len(rows) else all(budget_checks)
    )
    if reconciles_common_budget is False:
        reasons.append({"code": "COMMON_BUDGET_RECONCILIATION_FAILED", "message": "Desembolso e sobra não reconciliam com o orçamento comum em uma ou mais alternativas."})

    rankable = reconciles_common_budget is True and not reasons and all(row["status"] == "ready" for row in rows) and all(
        row["total_resources_at_horizon"] is not None for row in rows
    )
    order: list[str] = []
    if rankable:
        order = [item["id"] for item in sorted(
            rows,
            key=lambda row: Decimal(row["total_resources_at_horizon"]["value"]),
            reverse=True,
        )]
        reference_total = Decimal(rows[0]["total_resources_at_horizon"]["value"])
        reference_components = rows[0]["_flow_components"]
        for row in rows:
            components = row["_flow_components"]
            deltas = {key: components[key] - reference_components[key] for key in components}
            total_delta = Decimal(row["total_resources_at_horizon"]["value"]) - reference_total
            if sum(deltas.values(), Decimal(0)) != total_delta:
                reasons.append({"code": "COMPARISON_RECONCILIATION_FAILED", "message": "A decomposição dos fluxos não reconcilia com a diferença patrimonial."})
                rankable = False
                order = []
                break
            row["comparison_to_reference"] = {
                "total_resources_delta": {"value": str(total_delta), "unit": "BRL"},
                "decomposition": {
                    key: {"value": str(value), "unit": "BRL"}
                    for key, value in deltas.items()
                },
            }
    if not rankable:
        for row in rows:
            row.pop("comparison_to_reference", None)
    for row in rows:
        row.pop("_flow_components", None)

    if growth_rate is None:
        assumption = "Caixa remanescente mantido em valor nominal constante; sem taxa líquida declarada, datas diferentes não são ordenáveis."
    else:
        assumption = (
            f"Caixa cresce à taxa nominal líquida declarada {growth_rate}, perfil {_CASH_GROWTH_PROFILE}, "
            f"desde {growth_origin.isoformat()} até {common_horizon.isoformat()}; orçamento da compra permanece fixo."
        )
    return {
        "status": "ready" if all(row["status"] == "ready" for row in rows) else "partial",
        "common_budget": {"value": str(common_budget), "unit": "BRL"},
        "alternatives": rows,
        "ranking": {
            "rankable": rankable,
            "metric": "TOTAL_RESOURCES_AT_COMMON_HORIZON",
            "common_horizon": None if common_horizon is None else common_horizon.isoformat(),
            "assumption": assumption,
            "cash_growth": None if cash_growth is None else {
                "annual_net_rate": str(growth_rate),
                "profile": _CASH_GROWTH_PROFILE,
                "origin_date": growth_origin.isoformat() if growth_origin else None,
            },
            "order": order,
            "reasons": reasons,
        },
        "reconciles_common_budget": reconciles_common_budget,
    }


def fixed_position_input_identity(source: Mapping[str, Any]) -> dict[str, Any]:
    """Return acquisition facts that every fixed-position exit must preserve."""
    capital = source.get("capital") or {}
    if not isinstance(capital, Mapping) or capital.get("mode") != "QUANTITY":
        raise ValidationError(
            "FIXED_POSITION_QUANTITY_REQUIRED",
            "FIXED_POSITION exige quantidade explícita, não orçamento de compra.",
        )
    try:
        quantity = Decimal(str(capital["value"]))
    except (InvalidOperation, KeyError, TypeError) as exc:
        raise ValidationError("FIXED_POSITION_QUANTITY_REQUIRED", "Informe a quantidade da posição.") from exc
    if quantity <= 0:
        raise ValidationError("FIXED_POSITION_QUANTITY_REQUIRED", "A quantidade da posição precisa ser positiva.")
    assumptions = source.get("assumptions") or {}
    data = source.get("data") or {}
    paid_costs = data.get("intermediate_paid_costs") or ()
    return {
        "instrument": source.get("instrument"),
        "quantity": quantity,
        "purchase_date": source.get("purchase_date"),
        "entry_price": source.get("entry_price"),
        "knowledge": source.get("knowledge"),
        "intent": source.get("intent"),
        "settlement_profile": assumptions.get("settlement_profile"),
        "entry_fee": assumptions.get("entry_fee"),
        "tax_cost_basis_brl": assumptions.get("tax_cost_basis_brl"),
        "intermediate_paid_costs": tuple(paid_costs),
    }


def _compare_fixed_position_evaluations(items: Sequence[Mapping[str, Any]]) -> dict[str, Any]:
    if len(items) != 2:
        raise ValidationError(
            "FIXED_POSITION_REQUIRES_TWO_EXITS",
            "A primeira comparação de posição fixa exige uma referência e uma alternativa.",
        )
    if items[0].get("id") != "reference":
        raise ValidationError("INVALID_COMPARISON_ID", "A primeira saída da posição fixa precisa ser a referência.")

    normalized = [item.get("normalized_input") or {} for item in items]
    identities = [fixed_position_input_identity(source) for source in normalized]
    if any(identity != identities[0] for identity in identities[1:]):
        raise ValidationError(
            "FIXED_POSITION_MISMATCH",
            "Título, quantidade, aquisição, compra e base fiscal precisam permanecer iguais entre as saídas.",
        )

    for source in normalized[1:]:
        assumptions = source.get("assumptions") or {}
        if assumptions.get("institution_net_brl") is not None:
            raise ValidationError(
                "INSTITUTION_NET_TRANSFERRED",
                "O líquido institucional pontual só pode pertencer à saída de referência; não o copie para outra saída.",
            )

    comparison_context = items[0].get("comparison_context") or {}
    if any((item.get("comparison_context") or {}) != comparison_context for item in items[1:]):
        raise ValidationError(
            "COMPARISON_CONTEXT_MISMATCH",
            "Horizonte e hipótese de caixa precisam ser comuns às saídas.",
        )
    horizon = comparison_context.get("horizon")
    if horizon is None:
        raise ValidationError("HORIZON_REQUIRED", "FIXED_POSITION exige horizonte comum explícito.")
    horizon_day = _as_date(horizon, "horizon")
    cash_growth = comparison_context.get("cash_growth")
    growth_rate: Decimal | None = None
    if cash_growth is not None:
        if not isinstance(cash_growth, Mapping) or cash_growth.get("profile") != _CASH_GROWTH_PROFILE:
            raise ValidationError("UNSUPPORTED_CASH_GROWTH_PROFILE", f"O perfil precisa ser {_CASH_GROWTH_PROFILE}.")
        if cash_growth.get("origin_date") is not None:
            raise ValidationError(
                "CASH_GROWTH_ORIGIN_NOT_ALLOWED",
                "Em FIXED_POSITION, cada saldo começa na própria data de disponibilidade.",
            )
        try:
            growth_rate = Decimal(str(cash_growth["annual_net_rate"]))
        except (InvalidOperation, KeyError, TypeError) as exc:
            raise ValidationError("INVALID_CASH_GROWTH_RATE", "Informe uma taxa líquida anual explícita.") from exc
        if growth_rate <= -1:
            raise ValidationError("INVALID_CASH_GROWTH_RATE", "A taxa líquida anual precisa ser maior que −100%.")

    purchase_dates = []
    sale_dates = []
    for source, item in zip(normalized, items):
        dates = item.get("resolution", {}).get("dates") or {}
        purchase = dates.get("purchase") or {}
        sale = dates.get("sale") or {}
        purchase_settlement = _date_or_none(purchase.get("settlement_date"))
        if purchase.get("status") != "available" or purchase_settlement is None:
            raise ValidationError("FIXED_POSITION_PURCHASE_UNRESOLVED", "A liquidação original da posição precisa estar disponível.")
        purchase_order = _date_or_none(purchase.get("proposed_order_date") or source.get("purchase_date"))
        sale_order = _date_or_none(sale.get("proposed_order_date") or source.get("sale_date"))
        sale_settlement = _date_or_none(sale.get("settlement_date"))
        if sale.get("status") != "available" or sale_settlement is None or sale_order is None:
            sale_dates.append((purchase_order, sale_order, sale_settlement, sale.get("status")))
            purchase_dates.append((purchase_order, purchase_settlement))
            continue
        if purchase_order is not None and purchase_settlement < purchase_order:
            raise ValidationError("INVALID_CASH_FLOW_DATES", "A liquidação original não pode preceder sua ordem.")
        if sale_settlement < purchase_settlement or sale_order < purchase_settlement:
            raise ValidationError("INVALID_CASH_FLOW_DATES", "A saída não pode preceder a aquisição original.")
        if sale_settlement < sale_order:
            raise ValidationError("INVALID_CASH_FLOW_DATES", "A liquidação da saída não pode preceder sua ordem.")
        if sale_settlement > horizon_day:
            raise ValidationError("HORIZON_BEFORE_AVAILABILITY", "O horizonte comum não pode anteceder a disponibilidade de uma saída.")
        sale_dates.append((purchase_order, sale_order, sale_settlement, sale.get("status")))
        purchase_dates.append((purchase_order, purchase_settlement))
    if any(value != purchase_dates[0] for value in purchase_dates[1:]):
        raise ValidationError("FIXED_POSITION_MISMATCH", "A liquidação de compra precisa ser a mesma em todas as saídas.")

    # Resolved operations must also confirm the same acquired quantity, price,
    # outflow, and tax base; matching request identifiers alone is insufficient.
    resolved_operations = [
        getattr(item.get("evaluation"), "operation", None) for item in items
    ]
    for attribute in ("quantity", "entry_pu", "initial_outflow", "tax_cost_basis"):
        values = [getattr(operation, attribute, None) for operation in resolved_operations]
        populated = [value for value in values if value is not None]
        if populated and any(value != populated[0] for value in populated[1:]):
            raise ValidationError(
                "FIXED_POSITION_MISMATCH",
                "As operações resolvidas não conservam quantidade, preço, desembolso e base fiscal originais.",
            )

    rows: list[dict[str, Any]] = []
    reasons: list[dict[str, str]] = []
    intermediate_costs_present = False
    distinct_sale_dates = {value[2] for value in sale_dates if value[2] is not None}
    for index, (item, source, position, dates_tuple, operation) in enumerate(
        zip(items, normalized, identities, sale_dates, resolved_operations)
    ):
        resolution = item.get("resolution") or {}
        sale = (resolution.get("dates") or {}).get("sale") or {}
        purchase = (resolution.get("dates") or {}).get("purchase") or {}
        purchase_sizing = resolution.get("purchase_sizing") or {}
        purchase_order, sale_order, sale_settlement, _sale_status = dates_tuple
        evaluation = item.get("evaluation")
        constraint_evaluation = getattr(evaluation, "constraint_evaluation", None)
        net = None if operation is None else getattr(operation, "net_redemption", None)
        initial_outflow = None if operation is None else getattr(operation, "initial_outflow", None)
        entry_gross = None if operation is None else getattr(operation, "entry_gross", None)
        tax_basis = None if operation is None else getattr(operation, "tax_cost_basis", None)
        entry_expense = None if initial_outflow is None or entry_gross is None else initial_outflow - entry_gross
        quantity = position["quantity"]
        operation_result = None
        if operation is not None:
            taxable_base = None
            tax_rate = None
            if (
                operation.gross_redemption is not None
                and tax_basis is not None
                and operation.iof is not None
            ):
                taxable_base = max(operation.gross_redemption - tax_basis - operation.iof, Decimal(0))
            if operation.holding_days is not None:
                tax_rate = income_tax_rate(operation.holding_days)
            operation_result = {
                "status": operation.status,
                "quality": _enum_value(operation.quality),
                "quantity": _decimal(operation.quantity),
                "entry_pu": _decimal(operation.entry_pu),
                "exit_pu": _decimal(operation.exit_pu),
                "entry_gross": _decimal(entry_gross),
                "initial_outflow": _decimal(initial_outflow),
                "tax_cost_basis": _decimal(tax_basis),
                "gross_redemption": _decimal(operation.gross_redemption),
                "iof": _decimal(operation.iof),
                "taxable_base": _decimal(taxable_base),
                "income_tax_rate": _decimal(tax_rate),
                "income_tax": _decimal(operation.income_tax),
                "custody": _decimal(operation.custody),
                "exit_expense": _decimal(operation.exit_expense),
                "net_redemption": _decimal(net),
                "nominal_profit": _decimal(operation.nominal_profit),
                "nominal_return": _decimal(operation.nominal_return),
                "annualized_nominal_return": _decimal(operation.annualized_nominal_return),
                "real_profit_in_exit_date_currency": _decimal(operation.real_profit_in_exit_date_currency),
                "real_return": _decimal(operation.real_return),
                "holding_days": operation.holding_days,
            }
        status = "ready" if operation_result is not None and net is not None and sale_settlement is not None else "partial"
        profit = None if operation is None else getattr(operation, "nominal_profit", None)
        if profit is None and net is not None and initial_outflow is not None:
            prior_total = sum(
                (Decimal(str(flow.get("amount_brl", "0"))) for flow in (source.get("data") or {}).get("intermediate_paid_costs", ())),
                Decimal(0),
            )
            profit = net - initial_outflow + prior_total
        total = None
        growth_days = None if sale_settlement is None else (horizon_day - sale_settlement).days
        if net is not None and sale_settlement is not None:
            if growth_rate is not None:
                total = _grow_cash(net, growth_rate, sale_settlement, horizon_day)
            elif sale_settlement == horizon_day:
                total = round_money(net)
        if total is None and status != "ready":
            reasons.append({"code": "ALTERNATIVE_INCOMPLETE", "message": "Uma saída não foi resolvida com líquido e disponibilidade completos."})

        data = source.get("data") or {}
        intermediate_costs = data.get("intermediate_paid_costs") or ()
        resolved_prices = resolution.get("resolved_prices") or {}
        entry_price = source.get("entry_price") or {}
        exit_price = source.get("exit_price") or {}
        resolved_entry_price = resolved_prices.get("entry_price") or {}
        resolved_exit_price = resolved_prices.get("exit_price") or {}
        tax_basis_metadata = (purchase_sizing.get("tax_cost_basis") or {}) if isinstance(purchase_sizing, Mapping) else {}
        tax_basis_assumption = next((
            assumption for assumption in getattr(evaluation, "assumptions_summary", ())
            if assumption.get("assumption_id") == "tax_cost_basis"
        ), {})
        intermediate_costs_present |= any(
            Decimal(str(flow.get("amount_brl", "0"))) != 0 for flow in intermediate_costs
        )
        instrument = source.get("instrument") or {}
        row = {
            "id": item["id"], "label": item["label"], "input_fingerprint": item["input_fingerprint"],
            "status": status,
            "instrument": {
                "family": instrument.get("family"), "instrument_id": instrument.get("instrument_id"),
                "maturity_date": instrument.get("maturity_date"),
            },
            "capital": {"mode": "FIXED_POSITION", "value": str(quantity), "unit": "TITLE"},
            "position": {
                "quantity": str(quantity),
                "purchase_order": None if purchase_order is None else purchase_order.isoformat(),
                "purchase_settlement": purchase.get("settlement_date"),
                "entry_pu": _decimal(None if operation is None else operation.entry_pu),
                "initial_outflow": _decimal(initial_outflow),
                "tax_cost_basis": _decimal(tax_basis),
                "tax_cost_basis_source": tax_basis_metadata.get("source"),
                "tax_cost_basis_quality": tax_basis_assumption.get("quality"),
                "entry_expense_paid": _decimal(entry_expense),
            },
            "dates": {
                "purchase_order": None if purchase_order is None else purchase_order.isoformat(),
                "purchase_settlement": purchase.get("settlement_date"),
                "sale_order": None if sale_order is None else sale_order.isoformat(),
                "sale_settlement": sale.get("settlement_date"),
                "cash_available_at": sale.get("settlement_date"),
                "common_horizon": horizon_day.isoformat(),
            },
            "purchase_sizing": {"quantity": {"value": str(quantity), "unit": "TITLE"}},
            "operation": operation_result,
            "cash_remainder": None,
            "cash_growth_period_days": growth_days,
            "cash_conservation": None,
            "profit_since_purchase": None if profit is None else {
                "value": str(profit), "unit": "BRL", "quality": _enum_value(operation.quality),
            },
            "net_proceeds_at_availability": None if net is None else {
                "value": str(net), "unit": "BRL", "quality": _enum_value(operation.quality),
            },
            "total_resources_at_horizon": None if total is None else {"value": str(total), "unit": "BRL"},
            "wealth_advantage_vs_reference": None,
            "price_provenance": {
                "entry": {
                    "mode": resolved_entry_price.get("mode") or entry_price.get("mode"),
                    "provenance": resolved_entry_price.get("provenance") or entry_price.get("provenance"),
                },
                "exit": {
                    "mode": resolved_exit_price.get("mode") or exit_price.get("mode"),
                    "provenance": resolved_exit_price.get("provenance") or exit_price.get("provenance"),
                },
            },
            "source_versions": source.get("source_versions", {}),
            "quality": None if operation is None else _enum_value(operation.quality),
            "cash_growth_quality": None if growth_rate is None else "HYPOTHETICAL",
            "goals": None if constraint_evaluation is None else constraint_evaluation.to_dict(),
            "warnings": list(getattr(evaluation, "warnings", ())) if evaluation is not None else [],
            "differences_from_reference": [] if index == 0 else _input_differences(normalized[0], source),
        }
        rows.append(row)

    if intermediate_costs_present:
        reasons.append({
            "code": "INTERMEDIATE_CASH_FLOWS_REQUIRE_FUNDING_MODEL",
            "message": "Custos intermediários permanecem no resultado individual; a comparação patrimonial exige modelo de financiamento.",
        })
    if growth_rate is None and len(distinct_sale_dates) > 1:
        reasons.append({
            "code": "CASH_GROWTH_REQUIRED_FOR_DIFFERENT_SETTLEMENT_DATES",
            "message": "Declare uma hipótese líquida de caixa para comparar disponibilidades em datas diferentes.",
        })
    elif growth_rate is None and any(
        value[2] is not None and value[2] != horizon_day for value in sale_dates
    ):
        reasons.append({
            "code": "CASH_GROWTH_REQUIRED",
            "message": "Declare uma hipótese líquida de caixa para levar o saldo disponível até o horizonte comum.",
        })
    rankable = (
        not reasons and all(row["status"] == "ready" for row in rows)
        and all(row["total_resources_at_horizon"] is not None for row in rows)
    )
    order: list[str] = []
    if rankable:
        order = [row["id"] for row in sorted(
            rows, key=lambda row: Decimal(row["total_resources_at_horizon"]["value"]), reverse=True,
        )]
        reference_total = Decimal(rows[0]["total_resources_at_horizon"]["value"])
        for row in rows:
            delta = Decimal(row["total_resources_at_horizon"]["value"]) - reference_total
            row["wealth_advantage_vs_reference"] = {"value": str(delta), "unit": "BRL"}
            row["comparison_to_reference"] = {
                "total_resources_delta": {"value": str(delta), "unit": "BRL"},
            }
            row["metric_deltas_from_reference"] = _metric_deltas_from_reference(
                rows[0].get("operation"), row.get("operation"),
            )
            row["goal_deltas_from_reference"] = _goal_deltas_from_reference(
                rows[0].get("goals"), row.get("goals"),
            )
            row["quality_comparison"] = {
                "reference": rows[0]["quality"], "alternative": row["quality"],
                "same": rows[0]["quality"] == row["quality"],
            }

    if growth_rate is None:
        assumption = "Sem hipótese líquida de caixa; os resultados das saídas permanecem visíveis, sem ranking entre disponibilidades distintas."
    else:
        rate_percent = format(growth_rate * Decimal("100"), "f")
        if "." in rate_percent:
            rate_percent = rate_percent.rstrip("0").rstrip(".")
        assumption = (
            f"Líquidos crescem à taxa nominal líquida declarada {rate_percent}% a.a., perfil {_CASH_GROWTH_PROFILE}, "
            f"desde a disponibilidade de cada saída até {horizon_day.isoformat()}; sem crescimento antes da disponibilidade."
        )
    return {
        "status": "ready" if all(row["status"] == "ready" for row in rows) else "partial",
        "comparison_mode": "FIXED_POSITION",
        "position": rows[0]["position"],
        "alternatives": rows,
        "ranking": {
            "rankable": rankable, "metric": "NET_WEALTH_AT_COMMON_HORIZON",
            "common_horizon": horizon_day.isoformat(), "assumption": assumption,
            "cash_growth": None if growth_rate is None else {
                "annual_net_rate": str(growth_rate), "profile": _CASH_GROWTH_PROFILE,
                "origin": "EACH_EXIT_AVAILABILITY",
            },
            "order": order, "reasons": reasons,
        },
        "reconciles_common_budget": None,
    }


def _metric_deltas_from_reference(
    reference: Mapping[str, Any] | None,
    alternative: Mapping[str, Any] | None,
) -> dict[str, dict[str, str] | None]:
    """Return exact display deltas only when both operation metrics exist."""
    def delta(field: str, unit: str, scale: Decimal = Decimal("1")) -> dict[str, str] | None:
        if reference is None or alternative is None:
            return None
        left, right = reference.get(field), alternative.get(field)
        if left is None or right is None:
            return None
        value = (Decimal(str(right)) - Decimal(str(left))) * scale
        return {"value": format(value, "f"), "unit": unit}

    return {
        "nominal_profit": delta("nominal_profit", "BRL"),
        "nominal_return": delta("nominal_return", "PERCENTAGE_POINTS", Decimal("100")),
        "holding_days": delta("holding_days", "DAYS"),
    }


def _goal_deltas_from_reference(
    reference: Mapping[str, Any] | None,
    alternative: Mapping[str, Any] | None,
) -> dict[str, Any]:
    """Compare goal margins only where the declared criterion basis is identical."""
    if reference is None and alternative is None:
        return {"status": "NO_GOALS", "criteria": []}

    reference_criteria = {
        item["id"]: item for item in (reference or {}).get("criteria", ())
    }
    alternative_criteria = {
        item["id"]: item for item in (alternative or {}).get("criteria", ())
    }
    criteria: list[dict[str, Any]] = []
    all_comparable = reference is not None and alternative is not None
    for criterion_id in sorted(set(reference_criteria) | set(alternative_criteria)):
        left = reference_criteria.get(criterion_id)
        right = alternative_criteria.get(criterion_id)
        same_basis = bool(left and right) and all(
            left.get(field) == right.get(field)
            for field in ("metric", "operator", "target_value", "unit", "margin_unit")
        )
        margin_delta = None
        if same_basis and left.get("margin") is not None and right.get("margin") is not None:
            margin_difference = Decimal(right["margin"]) - Decimal(left["margin"])
            margin_delta = {
                "value": format(margin_difference, "f"),
                "unit": right["margin_unit"],
            }
        else:
            all_comparable = False
        criteria.append({
            "id": criterion_id,
            "comparable_basis": same_basis,
            "reference_status": None if left is None else left.get("status"),
            "alternative_status": None if right is None else right.get("status"),
            "reference_margin": None if left is None else left.get("margin"),
            "alternative_margin": None if right is None else right.get("margin"),
            "margin_delta": margin_delta,
        })
    if not criteria:
        both_without_goals = (
            reference is None and alternative is None
        ) or (
            reference is not None and alternative is not None
            and not reference_criteria and not alternative_criteria
        )
        status = "NO_GOALS" if both_without_goals else "DIFFERENT_BASIS"
    else:
        status = "COMPARABLE" if all_comparable else "DIFFERENT_BASIS"
    return {
        "status": status,
        "reference_status": None if reference is None else reference.get("status"),
        "alternative_status": None if alternative is None else alternative.get("status"),
        "criteria": criteria,
    }


def _set_no_growth_values(
    rows: list[dict[str, Any]], flow_values: list[dict[str, Any]],
    common_budget: Decimal, common_horizon: date,
) -> None:
    for row, flows in zip(rows, flow_values):
        if row["status"] != "ready":
            continue
        remainder = flows["remainder"]
        net = flows["net_redemption"]
        initial_outflow = flows["initial_outflow"]
        if not isinstance(remainder, Decimal) or not isinstance(net, Decimal) or not isinstance(initial_outflow, Decimal):
            row["status"] = "partial"
            continue
        row["cash_conservation"] = {
            "status": "balanced",
            "cash_available_at_origin": {"value": str(common_budget), "unit": "BRL"},
            "initial_outflow": {"value": str(initial_outflow), "unit": "BRL"},
            "cash_remainder_at_purchase": {"value": str(remainder), "unit": "BRL"},
            "cash_remainder_at_horizon": {"value": str(remainder), "unit": "BRL"},
            "sale_proceeds_at_horizon": {"value": str(net), "unit": "BRL"},
            "profile": None,
            "implicit_contribution": False,
            "horizon": common_horizon.isoformat(),
        }
        total = net + remainder
        row["total_resources_at_horizon"] = {"value": str(total), "unit": "BRL"}
        row["_flow_components"] = {
            "operation_net_redemption": net,
            "fixed_budget_remainder": remainder,
            "prepurchase_cash_growth": Decimal(0),
            "remainder_growth_after_purchase": Decimal(0),
            "sale_proceeds_growth": Decimal(0),
        }


def _grow_cash(amount: Decimal, annual_net_rate: Decimal, start: date, end: date) -> Decimal:
    if end < start:
        raise ValidationError("INVALID_CASH_FLOW_DATES", "Um fluxo de caixa não pode crescer antes de sua data de disponibilidade.")
    days = (end - start).days
    with localcontext() as context:
        context.prec = 36
        try:
            factor = (Decimal(1) + annual_net_rate) ** (Decimal(days) / Decimal(365))
            value = round_money(amount * factor)
        except (ArithmeticError, InvalidOperation, OverflowError) as exc:
            raise ValidationError("CASH_GROWTH_OVERFLOW", "O crescimento declarado excede o domínio numérico suportado.") from exc
    if not value.is_finite() or value < 0:
        raise ValidationError("CASH_GROWTH_OVERFLOW", "O crescimento declarado excede o domínio numérico suportado.")
    return value


def _sizing_value(sizing: object, key: str) -> Decimal | None:
    if not isinstance(sizing, Mapping):
        return None
    raw = sizing.get(key)
    if not isinstance(raw, Mapping) or raw.get("value") is None:
        return None
    return Decimal(raw["value"])


def _date_or_none(value: object) -> date | None:
    return None if value is None else _as_date(value, "settlement_date")


def _as_date(value: object, name: str) -> date:
    if isinstance(value, date):
        return value
    if isinstance(value, str):
        try:
            parsed = date.fromisoformat(value)
        except ValueError as exc:
            raise ValidationError("INVALID_DATE", f"{name} precisa ser uma data ISO válida.") from exc
        if parsed.isoformat() == value:
            return parsed
    raise ValidationError("INVALID_DATE", f"{name} precisa ser uma data ISO válida.")


def _input_differences(reference: Mapping[str, Any], alternative: Mapping[str, Any]) -> list[str]:
    fields = (
        ("instrument", "instrument"), ("purchase_date", "purchase_date"),
        ("sale_date", "sale_date"), ("entry_price", "entry_price"),
        ("exit_price", "exit_price"), ("knowledge", "knowledge"),
        ("intent", "intent"), ("source_versions", "source_versions"),
        ("analysis_context", "analysis_context"), ("constraints", "constraints"),
    )
    differences = [label for key, label in fields if reference.get(key) != alternative.get(key)]
    for name, label in (
        ("settlement_profile", "settlement_profile"), ("entry_fee", "entry_fee"),
        ("exit_fee_brl", "exit_fee_brl"), ("tax_cost_basis_brl", "tax_cost_basis_brl"),
        ("inflation_projection", "inflation_projection"), ("explicit_settlements", "explicit_settlements"),
    ):
        if (reference.get("assumptions") or {}).get(name) != (alternative.get("assumptions") or {}).get(name):
            differences.append(label)
    for name, label in (
        ("index_anchors", "index_anchors"), ("price_index_levels", "price_index_levels"),
        ("intermediate_paid_costs", "intermediate_paid_costs"),
    ):
        if (reference.get("data") or {}).get(name) != (alternative.get("data") or {}).get(name):
            differences.append("data." + label)
    return differences


def _decimal(value: Decimal | None) -> str | None:
    return None if value is None else str(value)


def _enum_value(value: Any) -> Any:
    return getattr(value, "value", value)


def summarize_workspace_stresses(
    reference: Mapping[str, Any],
    scenarios: Sequence[Mapping[str, Any]],
    *,
    margins: Sequence[Mapping[str, Any]] = (),
    excluded_point_overrides: Sequence[str] = (),
    computation_budget: Mapping[str, Any] | None = None,
    constraints_present: bool = False,
) -> dict[str, Any]:
    """Summarize independently evaluated, named deterministic stress scenarios."""
    rows = [_stress_case_row(reference), *(_stress_case_row(item) for item in scenarios)]
    valid_tested_scenarios = [
        row for row in rows[1:]
        if row["operation"] is not None and row["operation"]["nominal_profit"] is not None
    ]
    worst = None
    best = None
    if valid_tested_scenarios:
        best_row = max(valid_tested_scenarios, key=lambda row: Decimal(row["operation"]["nominal_profit"]))
        best_profit = Decimal(best_row["operation"]["nominal_profit"])
        best = {
            "scenario_id": best_row["id"],
            "metric": "nominal_profit",
            "value": str(best_profit),
            "unit": "BRL",
            "quality": best_row["quality"],
            "scope": "named_scenarios_with_valid_operation_result",
        }
        worst_row = min(valid_tested_scenarios, key=lambda row: Decimal(row["operation"]["nominal_profit"]))
        worst_profit = Decimal(worst_row["operation"]["nominal_profit"])
        worst = {
            "scenario_id": worst_row["id"],
            "metric": "nominal_profit",
            "value": str(worst_profit),
            "unit": "BRL",
            "maximum_loss_brl": str(max(Decimal(0), -worst_profit)),
            "quality": worst_row["quality"],
            "scope": "named_scenarios_with_valid_operation_result",
        }
    reference_operation = rows[0]["operation"]
    for row in rows[1:]:
        operation = row["operation"]
        deltas = {}
        for metric in ("net_redemption", "nominal_profit", "nominal_return"):
            base_value = None if reference_operation is None else reference_operation.get(metric)
            value = None if operation is None else operation.get(metric)
            deltas[metric] = None if base_value is None or value is None else str(Decimal(value) - Decimal(base_value))
        base_days = None if reference_operation is None else reference_operation.get("holding_days")
        days = None if operation is None else operation.get("holding_days")
        deltas["holding_days"] = None if base_days is None or days is None else days - base_days
        row["metric_deltas_from_reference"] = deltas

    has_constraints = constraints_present or any(row["constraints"] is not None for row in rows)
    failed_scenarios = [
        row["id"] for row in rows
        if row["failed_constraint_ids"]
    ]
    unknown_scenarios = [
        row["id"] for row in rows
        if row["unavailable_constraint_ids"] or row["status"] != "ready"
    ]
    if not has_constraints:
        risk_limit = {
            "status": "NO_CONSTRAINTS", "met": None,
            "failed_scenarios": [], "unknown_scenarios": [],
        }
    else:
        if failed_scenarios:
            risk_status, risk_met = "NOT_MET", False
        elif unknown_scenarios:
            risk_status, risk_met = "UNKNOWN", None
        else:
            risk_status, risk_met = "MET", True
        risk_limit = {
            "status": risk_status, "met": risk_met,
            "failed_scenarios": failed_scenarios,
            "unknown_scenarios": unknown_scenarios,
        }

    margin_results = [dict(item) for item in margins]
    incomplete_margins = any(
        item.get("status") in {"UNKNOWN", "INCOMPLETE"}
        for item in margin_results
    )
    complete = all(row["status"] == "ready" for row in rows) and not incomplete_margins
    return {
        "status": "ready" if complete else "partial",
        "reference": rows[0],
        "scenarios": rows[1:],
        "best_tested_result": best,
        "worst_tested_result": worst,
        "best_scope": "Among named scenarios with a valid operation result only.",
        "worst_scope": "Among named scenarios with a valid operation result only.",
        "risk_limit": risk_limit,
        "margins": margin_results,
        "excluded_point_overrides": list(excluded_point_overrides),
        "probabilities_inferred": False,
        "coverage": {
            "requested_scenarios": len(scenarios),
            "evaluated_scenarios": sum(row["status"] == "ready" for row in rows),
            "complete": complete,
            "domain": "reference plus only the named deterministic scenarios and one-dimensional margins",
        },
        "computation_budget": None if computation_budget is None else dict(computation_budget),
    }


def _stress_case_row(case: Mapping[str, Any]) -> dict[str, Any]:
    evaluation = case.get("evaluation")
    operation = getattr(evaluation, "operation", None)
    operation_value = None
    if operation is not None:
        operation_value = {
            "status": operation.status,
            "quality": _enum_value(operation.quality),
            "entry_pu": _decimal(getattr(evaluation, "entry_pu", None)),
            "exit_pu": _decimal(getattr(evaluation, "exit_pu", None)),
            "initial_outflow": _decimal(operation.initial_outflow),
            "gross_redemption": _decimal(operation.gross_redemption),
            "iof": _decimal(operation.iof),
            "income_tax": _decimal(operation.income_tax),
            "custody": _decimal(operation.custody),
            "exit_expense": _decimal(operation.exit_expense),
            "net_redemption": _decimal(operation.net_redemption),
            "nominal_profit": _decimal(operation.nominal_profit),
            "nominal_return": _decimal(operation.nominal_return),
            "annualized_nominal_return": _decimal(operation.annualized_nominal_return),
            "real_profit_in_exit_date_currency": _decimal(operation.real_profit_in_exit_date_currency),
            "real_return": _decimal(operation.real_return),
            "holding_days": operation.holding_days,
        }
    status = case.get("status", "partial")
    if evaluation is None and status == "ready":
        status = "partial"
    if evaluation is not None and operation_value is None and status == "ready":
        status = "partial"
    constraint_evaluation = getattr(evaluation, "constraint_evaluation", None)
    constraints = None if constraint_evaluation is None else constraint_evaluation.to_dict()
    criteria = () if constraints is None else constraints["criteria"]
    return {
        "id": case["id"],
        "label": case.get("label", case["id"]),
        "status": status,
        "reason": case.get("reason"),
        "shock": case.get("shock"),
        "operation": operation_value,
        "constraints": constraints,
        "failed_constraint_ids": [
            item["id"] for item in criteria if item["status"] == "NOT_MET"
        ],
        "unavailable_constraint_ids": [
            item["id"] for item in criteria if item["status"] == "UNKNOWN"
        ],
        "quality": None if operation is None else _enum_value(operation.quality),
        "warnings": list(getattr(evaluation, "warnings", ())) if evaluation is not None else [],
        "resolved": case.get("resolved"),
        "source_versions": case.get("source_versions"),
    }
