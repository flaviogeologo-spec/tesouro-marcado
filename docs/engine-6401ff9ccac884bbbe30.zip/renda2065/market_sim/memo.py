"""Bounded, request-local reuse of immutable calculations; never persists data."""
from collections import OrderedDict
from contextlib import contextmanager
from contextvars import ContextVar
from decimal import getcontext
from functools import wraps


MAX_MEMO_ENTRIES = 1024
_active = ContextVar('market_sim_calculation_memo', default=None)


def decimal_identity():
    ctx = getcontext()
    return (ctx.prec, ctx.rounding, ctx.Emin, ctx.Emax, ctx.capitals, ctx.clamp,
            tuple(ctx.traps.items()))


@contextmanager
def calculation_scope():
    """Nested calls share one cache; independent requests/threads never do."""
    if _active.get() is not None:
        yield
        return
    token = _active.set(OrderedDict())
    try:
        yield
    finally:
        _active.reset(token)


def scoped_calculation(function):
    @wraps(function)
    def run(*args, **kwargs):
        with calculation_scope():
            return function(*args, **kwargs)
    return run


def scoped_memo(function=None, *, guard=None):
    """Only hashable immutable arguments qualify; exceptions are never cached."""
    if function is None:
        return lambda target: scoped_memo(target, guard=guard)
    @wraps(function)
    def run(*args, **kwargs):
        cache = _active.get()
        if cache is None or (guard is not None and not guard(args, kwargs)):
            return function(*args, **kwargs)
        key = (function, args, tuple(sorted(kwargs.items())), decimal_identity())
        try:
            hash(key)
        except TypeError:
            # Custom calendars and generator inputs retain the original path.
            return function(*args, **kwargs)
        if key in cache:
            cache.move_to_end(key)
            return cache[key]
        result = function(*args, **kwargs)
        cache[key] = result
        while len(cache) > MAX_MEMO_ENTRIES:
            cache.popitem(last=False)
        return result
    return run
