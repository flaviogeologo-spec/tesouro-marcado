"""Strict, local-only adapter for SIDRA XLSX number-index tables.

The workbook is an original source artifact. This module converts only the
identified IPCA number-index series to the existing canonical index CSV format;
it does not authenticate the source or interpret percentage series.
"""
from __future__ import annotations

import csv
from datetime import date, datetime
from decimal import Decimal, InvalidOperation
from io import BytesIO, StringIO
import re
import unicodedata
from zipfile import BadZipFile

from .contracts import ValidationError

MAX_XLSX_BYTES = 60 * 1024 * 1024
MAX_XLSX_COLUMNS = 16_384
SIDRA_NUMBER_INDEX_SOURCE = (
    "IBGE SIDRA tabela 1737 — IPCA número-índice, base dezembro de 1993 = 100 "
    "(arquivo fornecido pelo usuário)"
)
_MONTHS = {
    "jan": 1, "january": 1, "janeiro": 1, "feb": 2, "february": 2, "fev": 2, "fevereiro": 2,
    "mar": 3, "march": 3, "marco": 3, "apr": 4, "april": 4, "abr": 4, "abril": 4,
    "may": 5, "mai": 5, "maio": 5, "jun": 6, "june": 6, "junho": 6,
    "jul": 7, "july": 7, "julho": 7, "aug": 8, "august": 8, "ago": 8, "agosto": 8,
    "sep": 9, "sept": 9, "september": 9, "set": 9, "setembro": 9,
    "oct": 10, "october": 10, "out": 10, "outubro": 10,
    "nov": 11, "november": 11, "novembro": 11, "dec": 12, "december": 12,
    "dez": 12, "dezembro": 12,
}


def _plain_text(value: object) -> str:
    if not isinstance(value, str):
        return ""
    text = unicodedata.normalize("NFKD", value)
    text = "".join(char for char in text if not unicodedata.combining(char))
    return re.sub(r"[^a-z0-9]+", " ", text.casefold()).strip()


def _is_number_index_title(value: object) -> bool:
    if not isinstance(value, str) or "%" in value:
        return False
    text = _plain_text(value)
    words = text.split()
    allowed = {"variavel", "ipca", "numero", "indice", "base", "dezembro", "de", "1993", "100"}
    if not words or any(word not in allowed for word in words):
        return False
    if words.count("ipca") != 1 or words.count("base") != 1:
        return False
    if not re.search(r"\bbase dezembro de 1993 100\b", text):
        return False
    return any(words[index:index + 2] == ["numero", "indice"] for index in range(len(words) - 1))


def _parse_month(value: object, column: int) -> date:
    if isinstance(value, datetime):
        result = value.date()
    elif isinstance(value, date):
        result = value
    elif isinstance(value, str):
        text = _plain_text(value)
        match = re.fullmatch(r"(\d{4}) (\d{1,2})", text)
        if match:
            result = date(int(match.group(1)), int(match.group(2)), 1)
        else:
            match = re.fullmatch(r"(\d{1,2}) (\d{4})", text)
            if match:
                result = date(int(match.group(2)), int(match.group(1)), 1)
            else:
                words = text.split()
                month_token = next((word for word in words if word in _MONTHS), None)
                year_token = next((word for word in words if re.fullmatch(r"\d{4}", word)), None)
                if month_token is not None and year_token is not None:
                    result = date(int(year_token), _MONTHS[month_token], 1)
                else:
                    iso_month = re.fullmatch(r"(\d{4})[ /-](\d{1,2})(?:[ /-](\d{1,2}))?", value.strip())
                    numeric_day = re.fullmatch(r"(\d{1,2})/(\d{1,2})/(\d{4})", value.strip())
                    if iso_month:
                        result = date(int(iso_month.group(1)), int(iso_month.group(2)), int(iso_month.group(3) or 1))
                    elif numeric_day:
                        result = date(int(numeric_day.group(3)), int(numeric_day.group(2)), int(numeric_day.group(1)))
                    else:
                        raise ValidationError(
                            "SIDRA_XLSX_INVALID_MONTH",
                            f"Cabeçalho da coluna {column}: mês de referência inválido.",
                        )
    else:
        raise ValidationError(
            "SIDRA_XLSX_INVALID_MONTH",
            f"Cabeçalho da coluna {column}: mês de referência inválido.",
        )
    if result.day != 1:
        raise ValidationError(
            "SIDRA_XLSX_INVALID_MONTH",
            f"Cabeçalho da coluna {column}: informe o primeiro dia do mês.",
        )
    return result


def _decimal_text(value: object, column: int) -> str:
    if isinstance(value, bool) or value is None:
        raise ValidationError("SIDRA_XLSX_INVALID_VALUE", f"Coluna {column}: índice mensal ausente ou inválido.")
    raw = str(value).strip()
    if isinstance(value, str):
        if not re.fullmatch(r"[+]?\d+(?:[.,]\d+)?", raw):
            raise ValidationError("SIDRA_XLSX_INVALID_VALUE", f"Coluna {column}: índice mensal não é um decimal inequívoco.")
        raw = raw.replace(",", ".")
    try:
        number = Decimal(raw)
    except (InvalidOperation, ValueError) as exc:
        raise ValidationError("SIDRA_XLSX_INVALID_VALUE", f"Coluna {column}: índice mensal inválido.") from exc
    if not number.is_finite() or number <= 0:
        raise ValidationError("SIDRA_XLSX_INVALID_VALUE", f"Coluna {column}: índice mensal deve ser finito e positivo.")
    canonical = format(number, "f")
    if "." in canonical:
        canonical = canonical.rstrip("0").rstrip(".")
    return canonical


def _cell_has_content(cell) -> bool:
    return cell.value is not None and not (isinstance(cell.value, str) and not cell.value.strip())


def _month_ordinal(value: date) -> int:
    return value.year * 12 + value.month


def convert_sidra_xlsx(raw: bytes, *, known_on: date) -> tuple[bytes, dict[str, object]]:
    """Convert one identified IPCA number-index worksheet to canonical CSV.

    ``known_on`` is supplied by the importing service from its local clock. It
    is deliberately independent of any date declared by the workbook.
    """
    if not isinstance(raw, bytes) or not raw:
        raise ValidationError("SIDRA_XLSX_EMPTY", "Escolha uma planilha XLSX não vazia.")
    if len(raw) > MAX_XLSX_BYTES:
        raise ValidationError("SIDRA_XLSX_TOO_LARGE", "A planilha XLSX ultrapassa 60 MB.")
    if not isinstance(known_on, date) or isinstance(known_on, datetime):
        raise ValidationError("SIDRA_XLSX_IMPORT_DATE", "A data local de importação é inválida.")
    try:
        from openpyxl import load_workbook
        from openpyxl.utils.exceptions import InvalidFileException
    except ImportError as exc:
        raise ValidationError(
            "SIDRA_XLSX_DEPENDENCY",
            "Importar XLSX requer openpyxl 3.1.5; prepare as dependências declaradas e confira o diagnóstico do aplicativo.",
        ) from exc

    try:
        workbook = load_workbook(BytesIO(raw), read_only=True, data_only=False, keep_links=False)
    except (BadZipFile, InvalidFileException, OSError, EOFError, ValueError, KeyError, TypeError) as exc:
        raise ValidationError("SIDRA_XLSX_CORRUPT", "A planilha XLSX está corrompida ou não é compatível.") from exc

    try:
        candidates = []
        for worksheet in workbook.worksheets:
            columns = max(1, min(int(worksheet.max_column or 1), MAX_XLSX_COLUMNS))
            sample = list(worksheet.iter_rows(min_row=2, max_row=5, min_col=1, max_col=columns))
            if len(sample) < 4 or not sample[0]:
                continue
            title_cell = sample[0][0]
            if title_cell.data_type == "f":
                continue
            if _is_number_index_title(title_cell.value):
                candidates.append((worksheet, title_cell.value, sample))
        if not candidates:
            raise ValidationError(
                "SIDRA_XLSX_SERIES_NOT_FOUND",
                "Não encontrei uma série identificável de IPCA número-índice, base dezembro de 1993 = 100.",
            )
        if len(candidates) != 1:
            raise ValidationError("SIDRA_XLSX_AMBIGUOUS_SERIES", "A planilha contém mais de uma série IPCA número-índice compatível.")

        worksheet, title, sample = candidates[0]
        geography_cell = sample[3][0]
        if geography_cell.data_type == "f":
            raise ValidationError("SIDRA_XLSX_FORMULA", "A identificação geográfica contém fórmula; a série não foi importada.")
        if _plain_text(geography_cell.value) != "brasil":
            raise ValidationError("SIDRA_XLSX_GEOGRAPHY", "A série identificada não está marcada como Brasil.")

        month_cells = sample[2][1:]
        value_cells = sample[3][1:]
        entries = []
        stopped = False
        for offset, (month_cell, value_cell) in enumerate(zip(month_cells, value_cells), start=2):
            month_present = _cell_has_content(month_cell)
            value_present = _cell_has_content(value_cell)
            if not month_present and not value_present:
                stopped = True
                continue
            if stopped:
                raise ValidationError("SIDRA_XLSX_GAP", "Há dados depois de uma coluna mensal vazia.")
            if month_present != value_present:
                raise ValidationError("SIDRA_XLSX_ROW_MISMATCH", f"Coluna {offset}: mês e índice mensal devem aparecer juntos.")
            if month_cell.data_type == "f" or value_cell.data_type == "f":
                raise ValidationError("SIDRA_XLSX_FORMULA", f"Coluna {offset}: fórmulas não são aceitas na série de origem.")
            if month_cell.data_type == "e" or value_cell.data_type == "e":
                raise ValidationError("SIDRA_XLSX_CELL_ERROR", f"Coluna {offset}: a planilha contém erro de célula.")
            month = _parse_month(month_cell.value, offset)
            if month < date(2000, 6, 1):
                raise ValidationError("SIDRA_XLSX_MONTH_RANGE", f"Coluna {offset}: o mês antecede a base mensal suportada.")
            if month > date(known_on.year, known_on.month, 1):
                raise ValidationError("SIDRA_XLSX_FUTURE_MONTH", f"Coluna {offset}: o mês observado é posterior à importação.")
            value = _decimal_text(value_cell.value, offset)
            entries.append((month, value))
        if not entries:
            raise ValidationError("SIDRA_XLSX_EMPTY_SERIES", "A série identificada não contém meses e índices válidos.")

        entries.sort(key=lambda item: item[0])
        months = [item[0] for item in entries]
        if len(set(months)) != len(months):
            raise ValidationError("SIDRA_XLSX_DUPLICATE_MONTH", "A série contém meses de referência duplicados.")
        if any(_month_ordinal(right) - _month_ordinal(left) != 1 for left, right in zip(months, months[1:])):
            raise ValidationError("SIDRA_XLSX_GAP", "A série mensal tem uma lacuna; nenhum valor foi preenchido.")

        output = StringIO(newline="")
        writer = csv.writer(output, delimiter=";", lineterminator="\n")
        writer.writerow(("Data", "Conhecido em", "Tipo", "Valor", "Fonte"))
        for month, value in entries:
            writer.writerow((month.isoformat(), known_on.isoformat(), "IPCA_MONTHLY_INDEX", value, SIDRA_NUMBER_INDEX_SOURCE))
        canonical = output.getvalue().encode("utf-8")
        metadata = {
            "adapter_profile": "SIDRA_XLSX_NUMBER_INDEX_V1",
            "sheet": str(worksheet.title),
            "series_title": str(title),
            "geography": "Brasil",
            "rows": len(entries),
            "first_reference": months[0].isoformat(),
            "last_reference": months[-1].isoformat(),
            "known_on": known_on.isoformat(),
            "source_authenticated": False,
        }
        return canonical, metadata
    except ValidationError:
        raise
    except Exception as exc:
        raise ValidationError("SIDRA_XLSX_CORRUPT", "A planilha XLSX não pôde ser lida com segurança.") from exc
    finally:
        workbook.close()
