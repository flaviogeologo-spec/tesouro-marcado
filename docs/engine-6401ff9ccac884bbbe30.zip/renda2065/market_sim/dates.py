"""Tipos e validações de datas do cenário, sem inferir calendário de pregão."""
from __future__ import annotations

from dataclasses import dataclass, replace
from datetime import date, datetime, timedelta
from typing import Any, Mapping

from .contracts import Instrument, ProductFamily, ValidationError
from .provenance import EvidenceMode, EvidenceStatus, Provenance, Quality, assess_evidence

EVENT_COVERAGE_SOURCE_REF = "https://www.tesourodireto.com.br/sobre-o-tesouro/regras-e-regulamento"
EVENT_COVERAGE_SOURCE_SECTION = "9"
EVENT_COVERAGE_REASON = (
    "O alcance da regra de suspensão por evento para esta família não está resolvido; "
    "a cobertura não pode ser certificada neste ponto."
)


@dataclass(frozen=True, slots=True)
class EventDates:
    observation_date: date
    order_date: date
    settlement_date: date
    valuation_date: date
    publication_at: datetime | None = None

    def __post_init__(self) -> None:
        if self.publication_at is not None and self.publication_at.tzinfo is None:
            raise ValueError("Data de publicação precisa incluir fuso horário.")
        if self.settlement_date < self.order_date:
            raise ValueError("Liquidação não pode preceder a ordem.")


def minimum_renda_plus_sale_date(settlement_date: date) -> date:
    """Piso regulatório de 60 dias corridos; não certifica sessão executável."""
    return settlement_date + timedelta(days=60)


@dataclass(frozen=True, slots=True)
class EventCoverage:
    family: ProductFamily
    event_type: str
    event_date: date
    order_date: date
    quality: Quality
    source_ref: str
    source_section: str
    reason_code: str
    reason: str
    status: str = "UNCERTIFIED"

    def to_dict(self) -> dict[str, Any]:
        return {
            "status": self.status,
            "family": self.family.value,
            "event_type": self.event_type,
            "event_date": self.event_date.isoformat(),
            "order_date": self.order_date.isoformat(),
            "quality": self.quality.value,
            "source_ref": self.source_ref,
            "source_section": self.source_section,
            "source_applicability": "UNRESOLVED",
            "reason_code": self.reason_code,
            "reason": self.reason,
        }


def event_uncertification_order_dates(instrument: Instrument, calendar: Any) -> tuple[date, ...]:
    """Return the two sessions before this family's event, without asserting suspension."""
    event_date = (
        instrument.maturity_date
        if instrument.family is ProductFamily.IPCA_PRINCIPAL
        else instrument.first_income_date
    )
    if event_date is None:
        return ()

    sessions: list[date] = []
    candidate = event_date - timedelta(days=1)
    while len(sessions) < 2 and candidate >= date(2000, 1, 1):
        try:
            if calendar.is_session(candidate):
                sessions.append(candidate)
        except Exception as exc:
            if not _is_calendar_domain_error(exc):
                raise
            break
        candidate -= timedelta(days=1)
    return tuple(sessions)


def event_coverage_for_order_date(
    instrument: Instrument,
    order_date: date,
    calendar: Any,
) -> EventCoverage | None:
    """Mark only the two preceding sessions as uncertified while family scope is unresolved."""
    if instrument.family is ProductFamily.IPCA_PRINCIPAL:
        event_date = instrument.maturity_date
        event_type = "MATURITY"
    else:
        event_date = instrument.first_income_date
        event_type = "FIRST_INCOME"
    if event_date is None or order_date not in event_uncertification_order_dates(instrument, calendar):
        return None
    return EventCoverage(
        family=instrument.family,
        event_type=event_type,
        event_date=event_date,
        order_date=order_date,
        quality=Quality.MISSING,
        source_ref=EVENT_COVERAGE_SOURCE_REF,
        source_section=EVENT_COVERAGE_SOURCE_SECTION,
        reason_code="EVENT_COVERAGE_UNCERTIFIED",
        reason=EVENT_COVERAGE_REASON,
    )


@dataclass(frozen=True, slots=True)
class ResolvedOrderDate:
    side: str
    requested_date: date
    proposed_order_date: date
    settlement_date: date | None
    profile_id: str
    quality: Quality
    reason_code: str | None
    message: str | None
    confirmation_required: bool
    minimum_eligible_order_date: date | None
    source_ref: str
    calendar_id: str
    calendar_notice: str
    event_coverage: EventCoverage | None = None

    @property
    def status(self) -> str:
        if self.reason_code == "EVENT_COVERAGE_UNCERTIFIED" and not self.confirmation_required:
            return "uncertified"
        if self.reason_code is not None and not self.confirmation_required:
            return "blocked_policy"
        if self.confirmation_required:
            return "needs_input"
        return "available"

    def to_dict(self) -> dict[str, Any]:
        return {
            "requested_date": self.requested_date.isoformat(),
            "proposed_order_date": self.proposed_order_date.isoformat(),
            "settlement_date": self.settlement_date.isoformat() if self.settlement_date else None,
            "profile_id": self.profile_id,
            "quality": self.quality.value,
            "reason": None if self.reason_code is None else {
                "code": self.reason_code,
                "message": self.message,
            },
            "confirmation_required": self.confirmation_required,
            "minimum_eligible_order_date": (
                self.minimum_eligible_order_date.isoformat()
                if self.minimum_eligible_order_date else None
            ),
            "source_ref": self.source_ref,
            "calendar_id": self.calendar_id,
            "calendar_notice": self.calendar_notice,
            "event_coverage": self.event_coverage.to_dict() if self.event_coverage else None,
            "status": self.status,
        }


@dataclass(frozen=True, slots=True)
class WorkspaceDateResolution:
    purchase: ResolvedOrderDate
    sale: ResolvedOrderDate
    calendar_id: str
    warnings: tuple[str, ...]

    @property
    def status(self) -> str:
        if self.purchase.status == "blocked_policy" or self.sale.status == "blocked_policy":
            return "blocked_policy"
        if self.purchase.status == "needs_input" or self.sale.status == "needs_input":
            return "needs_input"
        if self.purchase.status == "uncertified" or self.sale.status == "uncertified":
            return "uncertified"
        return "available"

    def to_dict(self) -> dict[str, Any]:
        return {
            "status": self.status,
            "calendar_id": self.calendar_id,
            "purchase": self.purchase.to_dict(),
            "sale": self.sale.to_dict(),
            "warnings": list(self.warnings),
        }


def resolve_workspace_dates(
    *,
    instrument: Instrument,
    purchase_order_date: date,
    sale_order_date: date,
    settlement_profile: str,
    calendar: Any,
    explicit_settlements: Mapping[str, Any] | None = None,
) -> WorkspaceDateResolution:
    """Resolve requested dates against one identified calendar and profile.

    A non-session request receives an editable proposal and is never relabeled
    silently. The quote CSV is intentionally not used as a trading calendar.
    """
    profiles = {
        "SIMULATED_BUY_D1_SELL_D1",
        "SIMULATED_BUY_D1_SELL_D0",
        "EXPLICIT",
    }
    if settlement_profile not in profiles:
        raise ValidationError("INVALID_SETTLEMENT_PROFILE", "Perfil de liquidação não suportado.")
    if sale_order_date <= purchase_order_date:
        raise ValidationError("INVALID_DATES", "Venda precisa ocorrer depois da compra.")
    if settlement_profile == "EXPLICIT" and not isinstance(explicit_settlements, Mapping):
        raise ValidationError("MISSING_FIELD", "EXPLICIT exige liquidações de compra e venda declaradas.")
    if settlement_profile != "EXPLICIT" and explicit_settlements is not None:
        raise ValidationError("INVALID_SETTLEMENT_PROFILE", "Liquidações declaradas exigem perfil EXPLICIT.")

    profile_id = settlement_profile
    purchase = _resolve_order_date(
        side="purchase", requested=purchase_order_date, profile_id=profile_id,
        calendar=calendar, explicit=_explicit_settlement(explicit_settlements, "purchase"),
        d0=False,
    )
    sale_d0 = settlement_profile == "SIMULATED_BUY_D1_SELL_D0"
    sale = _resolve_order_date(
        side="sale", requested=sale_order_date, profile_id=profile_id,
        calendar=calendar, explicit=_explicit_settlement(explicit_settlements, "sale"),
        d0=sale_d0,
    )

    purchase_reason = purchase.reason_code
    sale_reason = sale.reason_code
    purchase_message = purchase.message
    sale_message = sale.message
    purchase_confirm = purchase.confirmation_required
    sale_confirm = sale.confirmation_required

    if purchase.settlement_date is not None and sale.settlement_date is not None:
        if sale.settlement_date <= purchase.settlement_date:
            raise ValidationError("INVALID_DATES", "Liquidação da venda precisa ocorrer depois da compra.")

    if instrument.family is ProductFamily.IPCA_PRINCIPAL:
        horizon = instrument.maturity_date
        if purchase.proposed_order_date >= instrument.maturity_date:
            purchase_reason = "OUTSIDE_HORIZON"
            purchase_message = "A compra solicitada está no vencimento ou depois dele."
            purchase_confirm = False
        if sale.proposed_order_date >= instrument.maturity_date:
            sale_reason = "OUTSIDE_HORIZON"
            sale_message = "A venda solicitada está no vencimento ou depois dele."
            sale_confirm = False
    else:
        first_income = instrument.first_income_date
        if first_income is None:
            raise ValidationError("INVALID_INSTRUMENT", "RendA+ exige a data da primeira parcela.")
        if purchase.proposed_order_date >= first_income:
            purchase_reason = "OUTSIDE_HORIZON"
            purchase_message = "Compra RendA+ precisa ocorrer antes da primeira parcela."
            purchase_confirm = False
        if sale.proposed_order_date >= first_income:
            sale_reason = "OUTSIDE_HORIZON"
            sale_message = "Venda RendA+ na primeira parcela ou depois não é resgate antecipado."
            sale_confirm = False
        elif purchase.settlement_date is not None:
            lock_end = minimum_renda_plus_sale_date(purchase.settlement_date)
            try:
                earliest = calendar.next_session(lock_end, include=True)
            except Exception as exc:
                if not _is_calendar_domain_error(exc):
                    raise
                earliest = None
                sale_reason = "CALENDAR_OUTSIDE_DOMAIN"
                sale_message = "A primeira data elegível ultrapassa a cobertura do calendário projetado."
                sale_confirm = False
            sale = ResolvedOrderDate(
                side=sale.side,
                requested_date=sale.requested_date,
                proposed_order_date=sale.proposed_order_date,
                settlement_date=sale.settlement_date,
                profile_id=sale.profile_id,
                quality=sale.quality,
                reason_code=sale.reason_code,
                message=sale.message,
                confirmation_required=sale.confirmation_required,
                minimum_eligible_order_date=earliest,
                source_ref=sale.source_ref,
                calendar_id=sale.calendar_id,
                calendar_notice=sale.calendar_notice,
            )
            if earliest is not None and sale.proposed_order_date < earliest:
                sale_reason = "LOCKED"
                sale_message = f"Carência de 60 dias; primeira data de sessão elegível: {earliest.isoformat()}."
                sale_confirm = False
        horizon = first_income

    # A data financeira precisa continuar dentro da vida útil do produto, ainda
    # que a ordem tenha sido enviada antes do limite.
    if purchase.settlement_date is not None and purchase.settlement_date >= horizon:
        purchase_reason = "OUTSIDE_HORIZON"
        purchase_message = "A liquidação da compra fica no vencimento ou depois do horizonte do produto."
        purchase_confirm = False
    if sale.settlement_date is not None and sale.settlement_date >= horizon:
        sale_reason = "OUTSIDE_HORIZON"
        sale_message = "A liquidação da venda fica no vencimento ou depois do horizonte do produto."
        sale_confirm = False

    if purchase_reason != purchase.reason_code or purchase_message != purchase.message or purchase_confirm != purchase.confirmation_required:
        purchase = _replace_order_status(purchase, purchase_reason, purchase_message, purchase_confirm)
    if sale_reason != sale.reason_code or sale_message != sale.message or sale_confirm != sale.confirmation_required:
        sale = _replace_order_status(sale, sale_reason, sale_message, sale_confirm)

    event_coverage = event_coverage_for_order_date(instrument, sale.proposed_order_date, calendar)
    if event_coverage is not None:
        if sale.reason_code is None:
            sale = _replace_order_status(
                sale, event_coverage.reason_code, event_coverage.reason, False,
            )
        sale = replace(sale, event_coverage=event_coverage)

    warnings = tuple(dict.fromkeys((purchase.calendar_notice, sale.calendar_notice)))
    return WorkspaceDateResolution(purchase, sale, calendar.calendar_id, warnings)


def resolve_workspace_reference_date(
    *,
    requested_date: date,
    settlement_profile: str,
    calendar: Any,
    explicit_settlements: Mapping[str, Any] | None = None,
) -> ResolvedOrderDate:
    """Resolve one requested valuation date without inventing a sale side."""
    profiles = {
        "SIMULATED_BUY_D1_SELL_D1",
        "SIMULATED_BUY_D1_SELL_D0",
        "EXPLICIT",
    }
    if settlement_profile not in profiles:
        raise ValidationError("INVALID_SETTLEMENT_PROFILE", "Perfil de liquidação não suportado.")
    if settlement_profile == "EXPLICIT" and not isinstance(explicit_settlements, Mapping):
        raise ValidationError("MISSING_FIELD", "EXPLICIT exige a liquidação da data de referência.")
    if settlement_profile != "EXPLICIT" and explicit_settlements is not None:
        raise ValidationError("INVALID_SETTLEMENT_PROFILE", "Liquidação declarada exige perfil EXPLICIT.")
    return _resolve_order_date(
        side="reference", requested=requested_date, profile_id=settlement_profile,
        calendar=calendar,
        explicit=_explicit_settlement(explicit_settlements, "reference"),
        d0=False,
    )


def _resolve_order_date(
    *,
    side: str,
    requested: date,
    profile_id: str,
    calendar: Any,
    explicit: Mapping[str, Any] | None,
    d0: bool,
) -> ResolvedOrderDate:
    if requested.year < 2000 or requested.year > 2085:
        raise ValidationError("CALENDAR_OUTSIDE_DOMAIN", "Calendário financeiro projetado cobre 2000–2085.")
    try:
        requested_is_session = calendar.is_session(requested)
        proposed = requested if requested_is_session else calendar.next_session(requested, include=True)
    except Exception as exc:
        if not _is_calendar_domain_error(exc):
            raise
        raise ValidationError(
            "CALENDAR_OUTSIDE_DOMAIN",
            "A data solicitada ou sua próxima sessão está fora do domínio do calendário projetado.",
        ) from exc
    confirmation_required = not requested_is_session
    reason_code = None if requested_is_session else "NON_SESSION"
    message = None if requested_is_session else (
        f"Data pedida não é sessão; confirme ou edite a sugestão {proposed.isoformat()}."
    )
    quality = Quality.ESTIMATED
    source_ref = f"Calendário {calendar.calendar_id}; perfil {profile_id}"
    settlement: date

    if explicit is not None:
        settlement = _as_date(explicit.get("date"), f"explicit_settlements.{side}.date")
        quality = _as_quality(explicit.get("quality"), f"explicit_settlements.{side}.quality")
        source_ref = str(explicit.get("source_ref", "")).strip()
        if not source_ref:
            raise ValidationError("INVALID_PROVENANCE", f"Liquidação explícita de {side} precisa de source_ref.")
        if settlement < proposed:
            raise ValidationError("INVALID_DATES", f"Liquidação explícita de {side} não pode preceder a ordem proposta.")
        try:
            settlement_is_session = calendar.is_session(settlement)
        except Exception as exc:
            if not _is_calendar_domain_error(exc):
                raise
            settlement_is_session = None
        if settlement_is_session is None:
            reason_code = "CALENDAR_OUTSIDE_DOMAIN"
            message = f"Liquidação explícita de {side} excede a cobertura do calendário projetado."
            confirmation_required = False
        elif not settlement_is_session:
            reason_code = "NON_SESSION"
            message = f"Liquidação explícita de {side} não é sessão no calendário selecionado."
            confirmation_required = False
    elif d0:
        settlement = proposed
    else:
        try:
            settlement = calendar.next_session(proposed, include=False)
        except Exception as exc:
            if not _is_calendar_domain_error(exc):
                raise
            raise ValidationError(
                "CALENDAR_OUTSIDE_DOMAIN",
                "A liquidação calculada está fora do domínio do calendário projetado.",
            ) from exc

    try:
        calendar_notice = calendar.coverage(settlement)
    except Exception as exc:
        if not _is_calendar_domain_error(exc):
            raise
        calendar_notice = "Liquidação fora do domínio do calendário projetado; confirmação indisponível."

    return ResolvedOrderDate(
        side=side,
        requested_date=requested,
        proposed_order_date=proposed,
        settlement_date=settlement,
        profile_id=profile_id,
        quality=quality,
        reason_code=reason_code,
        message=message,
        confirmation_required=confirmation_required,
        minimum_eligible_order_date=None,
        source_ref=source_ref,
        calendar_id=calendar.calendar_id,
        calendar_notice=calendar_notice,
    )


def _explicit_settlement(
    settlements: Mapping[str, Any] | None,
    side: str,
) -> Mapping[str, Any] | None:
    if settlements is None:
        return None
    value = settlements.get(side)
    if not isinstance(value, Mapping):
        raise ValidationError("MISSING_FIELD", f"explicit_settlements.{side} precisa ser declarado.")
    return value


def _as_date(value: object, name: str) -> date:
    if isinstance(value, date) and not isinstance(value, datetime):
        return value
    if not isinstance(value, str):
        raise ValidationError("INVALID_DATE", f"{name} precisa ser data ISO.")
    try:
        parsed = date.fromisoformat(value)
    except ValueError as exc:
        raise ValidationError("INVALID_DATE", f"{name} não é uma data válida.") from exc
    if parsed.isoformat() != value:
        raise ValidationError("INVALID_DATE", f"{name} precisa estar normalizada em AAAA-MM-DD.")
    return parsed


def _as_quality(value: object, name: str) -> Quality:
    try:
        quality = Quality(value)
    except (TypeError, ValueError) as exc:
        raise ValidationError("INVALID_PROVENANCE", f"{name} não tem qualidade suportada.") from exc
    if quality in (Quality.MISSING, Quality.RECONSTRUCTED):
        raise ValidationError("INVALID_PROVENANCE", f"{name} não pode declarar {quality.value}.")
    return quality


def _replace_order_status(
    value: ResolvedOrderDate,
    reason_code: str | None,
    message: str | None,
    confirmation_required: bool,
) -> ResolvedOrderDate:
    return ResolvedOrderDate(
        side=value.side,
        requested_date=value.requested_date,
        proposed_order_date=value.proposed_order_date,
        settlement_date=value.settlement_date,
        profile_id=value.profile_id,
        quality=value.quality,
        reason_code=reason_code,
        message=message,
        confirmation_required=confirmation_required,
        minimum_eligible_order_date=value.minimum_eligible_order_date,
        source_ref=value.source_ref,
        calendar_id=value.calendar_id,
        calendar_notice=value.calendar_notice,
        event_coverage=value.event_coverage,
    )


def _is_calendar_domain_error(error: BaseException) -> bool:
    """Recognize the calendar adapter's domain error without importing its app layer."""
    return getattr(error, "code", None) == "E-CALENDAR"


def evidence_status(
    provenance: Provenance,
    as_of: date,
    mode: EvidenceMode = EvidenceMode.CAUSAL,
) -> EvidenceStatus:
    return assess_evidence(provenance, as_of, mode).status
