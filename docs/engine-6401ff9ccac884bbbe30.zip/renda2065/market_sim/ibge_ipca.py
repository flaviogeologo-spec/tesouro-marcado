"""Bounded official IBGE IPCA acquisition and deterministic CSV conversion.

No storage, activation, publication-date inference or import-time network I/O.
The complete original response is returned for the caller's evidence archive.
"""
from __future__ import annotations

import base64
import csv
from datetime import date, datetime
from decimal import Decimal
import gzip
import hashlib
from http.client import HTTPException
from io import BytesIO, StringIO
import json
import re
import zlib
from urllib.error import URLError
from urllib.parse import urlsplit
from urllib.request import HTTPRedirectHandler, Request, build_opener

from .contracts import ValidationError

SOURCE_LABEL = "IBGE API agregados 1737/2266 — IPCA número-índice, base dezembro de 1993 = 100, Brasil"
METADATA_URL = "https://servicodados.ibge.gov.br/api/v3/agregados/1737/metadados"
SOURCE_PROFILE = "IBGE_IPCA_1737_2266_BRASIL_V1"
MAX_WIRE_BYTES = 2 * 1024 * 1024
MAX_JSON_BYTES = 4 * 1024 * 1024
MAX_MONTHS = 1200
MAX_URL_LENGTH = 10_000
TIMEOUT_SECONDS = 20
SUPPORTED_START = date(2000, 6, 1)
_HOST = "servicodados.ibge.gov.br"
_VARIABLE = "IPCA - Número-índice (base: dezembro de 1993 = 100)"
_UNIT = "Número-índice"


def _error(code: str, message: str) -> ValidationError:
    return ValidationError("IBGE_IPCA_" + code, message)


def _official_url(url: str) -> None:
    try:
        parts = urlsplit(url)
        valid = (parts.scheme == "https" and parts.hostname == _HOST
                 and parts.port in (None, 443) and parts.username is None
                 and parts.password is None and not parts.fragment)
    except (TypeError, ValueError) as exc:
        raise _error("URL", "Endereço oficial do IBGE inválido.") from exc
    if not valid or len(url) > MAX_URL_LENGTH:
        raise _error("URL", "A aquisição aceita somente HTTPS no host oficial do IBGE.")


class _OfficialRedirect(HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        _official_url(newurl)
        return super().redirect_request(req, fp, code, msg, headers, newurl)


def _decode(raw: bytes, content_encoding: str | None) -> bytes:
    if not isinstance(raw, bytes) or not raw:
        raise _error("EMPTY", "A resposta do IBGE está vazia.")
    if len(raw) > MAX_WIRE_BYTES:
        raise _error("SIZE", "A resposta do IBGE excede o limite de aquisição.")
    encoding = (content_encoding or "").strip().lower()
    if encoding not in ("", "identity", "gzip"):
        raise _error("ENCODING", "A codificação da resposta do IBGE não é suportada.")
    if encoding == "gzip":
        try:
            with gzip.GzipFile(fileobj=BytesIO(raw)) as stream:
                decoded = stream.read(MAX_JSON_BYTES + 1)
        except (OSError, EOFError, ValueError, zlib.error) as exc:
            raise _error("GZIP", "A resposta gzip do IBGE está corrompida.") from exc
    else:
        decoded = raw
    if len(decoded) > MAX_JSON_BYTES:
        raise _error("SIZE", "O JSON descompactado do IBGE excede o limite.")
    return decoded


def _object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise _error("DUPLICATE_KEY", "O JSON do IBGE contém uma chave duplicada.")
        result[key] = value
    return result


def _constant(value):
    raise _error("JSON", "O JSON do IBGE contém um número não finito.")


def _json(raw: bytes, content_encoding: str | None):
    try:
        return json.loads(_decode(raw, content_encoding).decode("utf-8"),
                          object_pairs_hook=_object, parse_constant=_constant)
    except (UnicodeError, ValueError, RecursionError) as exc:
        if isinstance(exc, ValidationError):
            raise
        raise _error("JSON", "A resposta do IBGE não contém JSON UTF-8 válido.") from exc


def _month(value: object) -> date:
    text = str(value)
    if not re.fullmatch(r"[0-9]{6}", text):
        raise _error("MONTH", "O período mensal do IBGE é inválido.")
    try:
        result = date(int(text[:4]), int(text[4:]), 1)
    except ValueError as exc:
        raise _error("MONTH", "O período mensal do IBGE é inválido.") from exc
    if result < date(1979, 12, 1):
        raise _error("MONTH", "O período antecede a série oficial identificada.")
    return result


def _months(first: date, last: date) -> list[str]:
    count = (last.year - first.year) * 12 + last.month - first.month + 1
    if not 1 <= count <= MAX_MONTHS:
        raise _error("PERIOD_RANGE", "A cobertura mensal do IBGE é inválida ou excede o limite.")
    start = first.year * 12 + first.month - 1
    return [f"{ordinal // 12:04d}{ordinal % 12 + 1:02d}"
            for ordinal in range(start, start + count)]


def _metadata(payload) -> list[str]:
    if not isinstance(payload, dict) or str(payload.get("id")) != "1737":
        raise _error("METADATA", "O agregado oficial esperado é 1737.")
    period = payload.get("periodicidade")
    variables = payload.get("variaveis")
    levels = payload.get("nivelTerritorial")
    if (not isinstance(period, dict) or period.get("frequencia") != "mensal"
            or not isinstance(variables, list) or not isinstance(levels, dict)
            or not isinstance(levels.get("Administrativo"), list)
            or "N1" not in levels["Administrativo"] or payload.get("classificacoes") != []):
        raise _error("METADATA", "Os metadados não identificam uma série mensal nacional sem classificação.")
    matches = [item for item in variables if isinstance(item, dict) and str(item.get("id")) == "2266"]
    if len(matches) != 1 or matches[0].get("nome") != _VARIABLE or matches[0].get("unidade") != _UNIT:
        raise _error("METADATA", "Variável, unidade ou base do IPCA divergem do perfil oficial.")
    return _months(_month(period.get("inicio")), _month(period.get("fim")))


def _entries(payload) -> list[tuple[date, str]]:
    if not isinstance(payload, list) or len(payload) != 1 or not isinstance(payload[0], dict):
        raise _error("SERIES", "A resposta deve conter exatamente uma variável IPCA.")
    variable = payload[0]
    if (str(variable.get("id")) != "2266" or variable.get("variavel") != _VARIABLE
            or variable.get("unidade") != _UNIT):
        raise _error("SERIES", "Variável, unidade ou base do IPCA não correspondem ao perfil oficial.")
    results = variable.get("resultados")
    if (not isinstance(results, list) or len(results) != 1 or not isinstance(results[0], dict)
            or results[0].get("classificacoes") != []):
        raise _error("SERIES", "O IPCA deve conter um único resultado sem classificações.")
    series = results[0].get("series")
    if not isinstance(series, list) or len(series) != 1 or not isinstance(series[0], dict):
        raise _error("SERIES", "O IPCA deve conter exatamente uma série nacional.")
    locality = series[0].get("localidade")
    if (not isinstance(locality, dict) or locality.get("id") != "1"
            or locality.get("nome") != "Brasil"
            or locality.get("nivel") != {"id": "N1", "nome": "Brasil"}):
        raise _error("GEOGRAPHY", "O IPCA deve identificar Brasil, localidade 1, nível N1.")
    observations = series[0].get("serie")
    if not isinstance(observations, dict) or not observations or len(observations) > MAX_MONTHS:
        raise _error("SERIES", "A série mensal está vazia ou excede o limite.")
    entries = []
    for key, value in observations.items():
        month = _month(key)
        if (not isinstance(value, str) or len(value) > 64
                or not re.fullmatch(r"[0-9]+(?:\.[0-9]+)?", value)):
            raise _error("VALUE", "O índice mensal deve ser um decimal positivo sem marcadores de ausência.")
        number = Decimal(value)
        if not number.is_finite() or number <= 0:
            raise _error("VALUE", "O índice mensal deve ser finito e positivo.")
        canonical = format(number, "f")
        if "." in canonical:
            canonical = canonical.rstrip("0").rstrip(".")
        entries.append((month, canonical))
    entries.sort()
    expected = _months(entries[0][0], entries[-1][0])
    if [month.strftime("%Y%m") for month, _ in entries] != expected:
        raise _error("GAP", "A série mensal contém uma lacuna; nenhum mês foi preenchido.")
    return entries


def _get(url: str, opener) -> tuple[bytes, str | None]:
    _official_url(url)
    request = Request(url, headers={"Accept": "application/json", "Accept-Encoding": "gzip"})
    try:
        open_request = opener.open if hasattr(opener, "open") else opener
        with open_request(request, timeout=TIMEOUT_SECONDS) as response:
            _official_url(response.geturl())
            if response.status != 200:
                raise _error("HTTP", "O IBGE não retornou uma resposta HTTP 200.")
            content_length = response.headers.get("Content-Length")
            if content_length is not None:
                if not re.fullmatch(r"[0-9]+", content_length) or int(content_length) > MAX_WIRE_BYTES:
                    raise _error("SIZE", "O tamanho declarado da resposta do IBGE é inválido ou excede o limite.")
            encoding = response.headers.get("Content-Encoding")
            raw = response.read(MAX_WIRE_BYTES + 1)
            if content_length is not None and len(raw) != int(content_length):
                raise _error("INCOMPLETE", "A resposta do IBGE está incompleta. Tente novamente; a base anterior foi preservada.")
            _decode(raw, encoding)
            return raw, encoding
    except ValidationError:
        raise
    except (URLError, OSError, HTTPException, ValueError) as exc:
        raise _error("NETWORK", "Não foi possível obter a série oficial do IBGE por HTTPS.") from exc


def fetch_ipca(*, opener=None) -> tuple[bytes, dict[str, object]]:
    """Fetch metadata then every explicitly enumerated month, preserving wire bytes.

    The optional opener is a urllib-style object (``open``) or callable accepting
    ``Request, timeout=``; it exists for isolated tests. Normal acquisition uses
    the platform HTTPS/proxy defaults and rejects redirects outside the host.
    """
    if opener is None:
        opener = build_opener(_OfficialRedirect())
    metadata_raw, metadata_encoding = _get(METADATA_URL, opener)
    snapshot = _json(metadata_raw, metadata_encoding)
    months = _metadata(snapshot)
    data_url = ("https://servicodados.ibge.gov.br/api/v3/agregados/1737/periodos/"
                + "|".join(months) + "/variaveis/2266?localidades=N1[1]")
    raw, encoding = _get(data_url, opener)
    entries = _entries(_json(raw, encoding))
    if [month.strftime("%Y%m") for month, _ in entries] != months:
        raise _error("COVERAGE", "A cobertura recebida diverge dos meses solicitados nos metadados.")
    return raw, {
        "source_profile": SOURCE_PROFILE,
        "content_encoding": encoding,
        "data_url": data_url,
        "metadata_url": METADATA_URL,
        "metadata_content_encoding": metadata_encoding,
        "metadata_raw_base64": base64.b64encode(metadata_raw).decode("ascii"),
        "metadata_sha256": hashlib.sha256(metadata_raw).hexdigest(),
        "metadata_snapshot": snapshot,
        "requested_first_month": months[0],
        "requested_last_month": months[-1],
        "requested_months": len(months),
    }


def convert_ipca(raw: bytes, *, known_on: date,
                 content_encoding: str | None = None) -> tuple[bytes, dict[str, object]]:
    """Validate the complete source; emit the simulator's supported 2000-06+ span.

    ``known_on`` is caller-supplied local confirmation day, never an inferred
    historical release date. Earlier source months remain in the raw archive.
    """
    if not isinstance(known_on, date) or isinstance(known_on, datetime):
        raise _error("KNOWN_ON", "A data local de confirmação é inválida.")
    entries = _entries(_json(raw, content_encoding))
    if entries[-1][0] > known_on:
        raise _error("FUTURE_MONTH", "O mês observado é posterior à confirmação local.")
    supported = [(month, value) for month, value in entries if month >= SUPPORTED_START]
    if not supported:
        raise _error("EMPTY_SUPPORTED", "A série não contém meses na cobertura suportada desde junho de 2000.")
    output = StringIO(newline="")
    writer = csv.writer(output, delimiter=";", lineterminator="\n")
    writer.writerow(("Data", "Conhecido em", "Tipo", "Valor", "Fonte"))
    for month, value in supported:
        writer.writerow((month.isoformat(), known_on.isoformat(), "IPCA_MONTHLY_INDEX", value, SOURCE_LABEL))
    return output.getvalue().encode("utf-8"), {
        "adapter_profile": SOURCE_PROFILE,
        "source_profile": SOURCE_PROFILE,
        "series_title": _VARIABLE,
        "geography": "Brasil",
        "unit": _UNIT + " (base: dezembro de 1993 = 100)",
        "source_rows": len(entries),
        "source_first_reference": entries[0][0].isoformat(),
        "source_last_reference": entries[-1][0].isoformat(),
        "supported_start": SUPPORTED_START.isoformat(),
        "omitted_before_supported_start": len(entries) - len(supported),
        "rows": len(supported),
        "first_reference": supported[0][0].isoformat(),
        "last_reference": supported[-1][0].isoformat(),
        "known_on": known_on.isoformat(),
    }
