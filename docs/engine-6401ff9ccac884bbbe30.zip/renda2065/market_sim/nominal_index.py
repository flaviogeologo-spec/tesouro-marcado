"""VNA/VNI calculated from monthly IPCA number indices, never market prices.

Tesouro educational convention: calendar days between consecutive 15ths.
This is distinct from ANBIMA business-day interpolation. During accumulation
the two nominal indices coincide; amortization is outside this simulator.
"""
from __future__ import annotations

from dataclasses import dataclass
from datetime import date
from decimal import Decimal, DecimalException, ROUND_DOWN, localcontext
from typing import Iterable

from .contracts import ValidationError, decimal_value
from .projections import InflationProjection
from .provenance import EvidenceMode, Quality

from .memo import scoped_memo

D = Decimal
BASE_DATE = date(2000, 7, 15)
BASE_MONTH = date(2000, 6, 1)
BASE_VALUE = D('1000')
BASE_IPCA_INDEX = D('1614.62')
PROFILE_ID = 'TD_CALENDAR_15_IPCA_RATIO_v1'
ANNUAL_MONTHLY_PROFILE = 'ANNUAL_COMPOUND_TO_MONTHLY_LOG_INTERPOLATED_v1'


def shift_month(month: date, count: int) -> date:
    ordinal = month.year * 12 + month.month - 1 + count
    year, zero_month = divmod(ordinal, 12)
    return date(year, zero_month + 1, 1)


@dataclass(frozen=True, slots=True)
class MonthlyIPCA:
    month: date
    value: Decimal
    known_on: date
    source_ref: str
    cache_sha256: str | None = None

    def __post_init__(self) -> None:
        value = decimal_value(self.value, 'Número índice IPCA')
        if not isinstance(self.month, date) or self.month.day != 1 or self.month < BASE_MONTH:
            raise ValidationError('INVALID_IPCA_MONTH', 'O IPCA mensal exige mês a partir de junho/2000 (dia 1).')
        if not isinstance(self.known_on, date) or self.known_on < self.month:
            raise ValidationError('INVALID_IPCA_PUBLICATION', 'Conhecimento do IPCA mensal não pode anteceder seu mês.')
        if value <= 0 or not isinstance(self.source_ref, str) or not self.source_ref.strip():
            raise ValidationError('INVALID_IPCA_INDEX', 'Número índice IPCA deve ser positivo e identificar a fonte.')
        if self.month == BASE_MONTH and value != BASE_IPCA_INDEX:
            raise ValidationError('CONFLICTING_IPCA_BASE', 'A série deve usar junho/2000 = 1614,62, base dezembro/1993 = 100.')
        object.__setattr__(self, 'value', value)


@dataclass(frozen=True, slots=True)
class NominalIndexResult:
    settlement_date: date
    status: str
    reason_code: str | None
    value: Decimal | None
    quality: Quality
    previous_reference_date: date
    previous_value: Decimal | None
    numerator_days: int
    denominator_days: int
    source_ref: str
    projected_months: int = 0
    profile_id: str = PROFILE_ID
    cache_sha256: str | None = None
    missing_month: date | None = None
    annual_projection_used: bool = False
    knowledge_cutoff: date | None = None
    evidence_mode: EvidenceMode = EvidenceMode.CAUSAL
    last_observed_month: date | None = None
    projection_start_month: date | None = None

    def to_dict(self) -> dict[str, object]:
        return {
            'settlement_date': self.settlement_date.isoformat(), 'status': self.status,
            'reason_code': self.reason_code, 'value': None if self.value is None else str(self.value),
            'quality': self.quality.value, 'profile_id': self.profile_id,
            'base_date': BASE_DATE.isoformat(), 'base_value': str(BASE_VALUE),
            'base_ipca_month': '2000-06', 'base_ipca_index': str(BASE_IPCA_INDEX),
            'previous_reference_date': self.previous_reference_date.isoformat(),
            'previous_value': None if self.previous_value is None else str(self.previous_value),
            'numerator_days': self.numerator_days, 'denominator_days': self.denominator_days,
            'projected_months': self.projected_months, 'source_ref': self.source_ref,
            'cache_sha256': self.cache_sha256,
            'missing_month': None if self.missing_month is None else self.missing_month.strftime('%Y-%m'),
            'knowledge_cutoff': None if self.knowledge_cutoff is None else self.knowledge_cutoff.isoformat(),
            'evidence_mode': self.evidence_mode.value,
            'last_observed_month': None if self.last_observed_month is None else self.last_observed_month.strftime('%Y-%m'),
            'projection_start_month': None if self.projection_start_month is None else self.projection_start_month.strftime('%Y-%m'),
            'annual_projection_profile': ANNUAL_MONTHLY_PROFILE if self.annual_projection_used else None,
            'formula': 'TRUNC6(TRUNC6(1000 * IPCA_anterior / 1614.62) * (IPCA_mes / IPCA_anterior)^TRUNC14(dias_corridos/periodo_15))',
        }


def _annual_month_factor(projection: InflationProjection, month: date) -> Decimal:
    """An explicitly hypothetical annual trajectory converted to monthly growth."""
    rate = projection.annual_rate
    if projection.mode == 'INTERPOLATED_ANNUAL':
        point = date(month.year, month.month, 15)
        duration = D((projection.end_date - projection.anchor_date).days)
        weight = min(max(D((point - projection.anchor_date).days) / duration, D(0)), D(1))
        annual_log = (D(1) + rate).ln() * (D(1) - weight) + (D(1) + projection.end_annual_rate).ln() * weight
        return (annual_log / D(12)).exp()
    return (D(1) + rate) ** (D(1) / D(12))


def _observed_months(monthly_indexes, as_of, mode):
    safe: dict[date, MonthlyIPCA] = {}
    seen: set[date] = set()
    for row in monthly_indexes:
        if row.month in seen:
            raise ValidationError('CONFLICTING_IPCA', 'Há números índices IPCA duplicados no mesmo mês.')
        seen.add(row.month)
        if mode is EvidenceMode.EX_POST or row.known_on <= as_of:
            safe[row.month] = row
    return safe, max(safe, default=None)


def _calculate_nominal_index(
    settlement_date: date, monthly_indexes: Iterable[MonthlyIPCA] = (), *,
    as_of: date, evidence_mode: EvidenceMode = EvidenceMode.CAUSAL,
    projection: InflationProjection | None = None,
    monthly_rates: Iterable[tuple[date, Decimal]] = (),
    observed: tuple[dict[date, MonthlyIPCA], date | None] | None = None,
) -> NominalIndexResult:
    if not isinstance(settlement_date, date) or not isinstance(as_of, date):
        raise ValidationError('INVALID_DATE', 'VNA/VNI exige datas válidas.')
    if settlement_date < BASE_DATE:
        raise ValidationError('BEFORE_NOMINAL_BASE', 'Data anterior à base nominal de 15/07/2000.')
    if settlement_date.year > 2085:
        raise ValidationError('OUTSIDE_NOMINAL_HORIZON', 'Estimativa nominal suporta datas até 2085.')
    mode = evidence_mode if isinstance(evidence_mode, EvidenceMode) else EvidenceMode(evidence_mode)
    ref = date(settlement_date.year, settlement_date.month, 15)
    if settlement_date < ref:
        prior_month = shift_month(date(settlement_date.year, settlement_date.month, 1), -1)
        ref = date(prior_month.year, prior_month.month, 15)
    ref_month = date(ref.year, ref.month, 1)
    next_month = shift_month(ref_month, 1)
    next_ref = date(next_month.year, next_month.month, 15)
    numerator = (settlement_date - ref).days
    denominator = (next_ref - ref).days
    anchor_month = shift_month(ref_month, -1)
    safe, latest = _observed_months(monthly_indexes, as_of, mode) if observed is None else observed
    rates: dict[date, Decimal] = {}
    for month, raw_rate in monthly_rates:
        if not isinstance(month, date) or month.day != 1 or month < BASE_MONTH:
            raise ValidationError('INVALID_IPCA_MONTH', 'Projeção mensal exige mês válido.')
        if month in rates:
            raise ValidationError('CONFLICTING_IPCA', 'Projeções mensais duplicadas.')
        rate = decimal_value(raw_rate, 'IPCA mensal hipotético')
        if rate <= -1:
            raise ValidationError('INVALID_IPCA', 'IPCA mensal deve superar −100%.')
        rates[month] = rate
    used: dict[date, MonthlyIPCA] = {}
    projected: set[date] = set()
    future_values: dict[date, Decimal] = {}
    missing_month = None
    reason = None
    annual_projection_used = False
    constant_month_factor = None

    def level(month: date) -> Decimal | None:
        nonlocal missing_month, reason, annual_projection_used, constant_month_factor
        if month == BASE_MONTH:
            return BASE_IPCA_INDEX
        if month in safe:
            used[month] = safe[month]
            return safe[month].value
        if month in future_values:
            return future_values[month]
        missing_month = month
        if latest is None:
            reason = 'MISSING_IPCA_HISTORY'
            return None
        if month <= latest:
            reason = 'MISSING_IPCA_MONTH'
            return None
        value = safe[latest].value
        used[latest] = safe[latest]
        current = shift_month(latest, 1)
        while current <= month:
            if current in future_values:
                value = future_values[current]
            elif current in rates or projection is not None:
                annual_projection_used = annual_projection_used or current not in rates
                if current in rates:
                    factor = D(1) + rates[current]
                elif projection.mode == 'CONSTANT_ANNUAL':
                    if constant_month_factor is None:
                        constant_month_factor = _annual_month_factor(projection, current)
                    factor = constant_month_factor
                else:
                    factor = _annual_month_factor(projection, current)
                value *= factor
                future_values[current] = value
                projected.add(current)
            else:
                missing_month = current
                reason = 'MISSING_PROJECTION'
                return None
            current = shift_month(current, 1)
        return value

    source_prefix = PROFILE_ID + '; IPCA mensal; ' + ('ex-post' if mode is EvidenceMode.EX_POST else 'corte causal')
    with localcontext() as ctx:
        ctx.prec = 50
        anchor_index = level(anchor_month)
        previous = None if anchor_index is None else (BASE_VALUE * anchor_index / BASE_IPCA_INDEX).quantize(D('.000001'), rounding=ROUND_DOWN)
        next_index = None if previous is None or numerator == 0 else level(ref_month)
        if previous is None or (numerator and next_index is None):
            projection_start = min(projected) if projected else (
                missing_month if reason == 'MISSING_PROJECTION' else None
            )
            hashes = sorted({row.cache_sha256 for row in used.values() if row.cache_sha256})
            cache_hash = hashes[0] if len(hashes) == 1 else None
            sources = sorted({row.source_ref for row in used.values()})
            source = source_prefix + ('; ' + ' / '.join(sources) if sources else '; base definida')
            if projected:
                source += '; inflação projetada explícita'
            if cache_hash:
                source += '; cache SHA256 ' + cache_hash
            return NominalIndexResult(
                settlement_date, 'needs_input', reason, None, Quality.MISSING, ref, previous,
                numerator, denominator, source, len(projected), cache_sha256=cache_hash,
                missing_month=missing_month,
                annual_projection_used=annual_projection_used, knowledge_cutoff=as_of,
                evidence_mode=mode, last_observed_month=latest,
                projection_start_month=projection_start,
            )
        exponent = (D(numerator) / D(denominator)).quantize(D('.00000000000001'), rounding=ROUND_DOWN)
        value = previous if numerator == 0 else (previous * (next_index / anchor_index) ** exponent).quantize(D('.000001'), rounding=ROUND_DOWN)
        if not value.is_finite() or value <= 0:
            raise ValidationError('NOMINAL_OVERFLOW', 'A projeção nominal excedeu o domínio numérico.')
    quality = Quality.HYPOTHETICAL if projected else Quality.RECONSTRUCTED
    hashes = sorted({row.cache_sha256 for row in used.values() if row.cache_sha256})
    cache_hash = hashes[0] if len(hashes) == 1 else None
    sources = sorted({row.source_ref for row in used.values()})
    source = source_prefix + ('; ' + ' / '.join(sources) if sources else '; base definida')
    if projected:
        source += '; inflação projetada explícita'
    if cache_hash:
        source += '; cache SHA256 ' + cache_hash
    return NominalIndexResult(
        settlement_date, 'available', 'HYPOTHETICAL_PROJECTION' if projected else 'CALCULATED_FROM_IPCA',
        value, quality, ref, previous, numerator, denominator, source, len(projected),
        cache_sha256=cache_hash, annual_projection_used=annual_projection_used,
        knowledge_cutoff=as_of, evidence_mode=mode,
        last_observed_month=latest,
        projection_start_month=min(projected, default=None),
    )


def _immutable_nominal_inputs(args, kwargs):
    indexes = args[1] if len(args) > 1 else kwargs.get('monthly_indexes', ())
    rates = kwargs.get('monthly_rates', ())
    projection = kwargs.get('projection')
    return (type(indexes) is tuple and all(type(row) is MonthlyIPCA for row in indexes)
            and type(rates) is tuple and all(type(row) is tuple for row in rates)
            and (projection is None or type(projection) is InflationProjection))


def _checked_nominal_index(*args, **kwargs):
    try:
        return _calculate_nominal_index(*args, **kwargs)
    except (DecimalException, OverflowError) as exc:
        raise ValidationError('NOMINAL_OVERFLOW', 'A projeção nominal excedeu o domínio numérico; revise a inflação informada.') from exc


def prepare_nominal_index(monthly_indexes, *, as_of: date, evidence_mode: EvidenceMode = EvidenceMode.CAUSAL):
    """Prepare one read-only monthly lookup for a series at the same cutoff."""
    if not isinstance(as_of, date):
        raise ValidationError('INVALID_DATE', 'VNA/VNI exige datas válidas.')
    mode = EvidenceMode(evidence_mode)
    observed = _observed_months(monthly_indexes, as_of, mode)

    def nominal(settlement_date, *, projection=None):
        return _checked_nominal_index(settlement_date, as_of=as_of, evidence_mode=mode,
                                      projection=projection, observed=observed)

    return nominal


@scoped_memo(guard=_immutable_nominal_inputs)
def calculate_nominal_index(
    settlement_date: date, monthly_indexes: Iterable[MonthlyIPCA] = (), *,
    as_of: date, evidence_mode: EvidenceMode = EvidenceMode.CAUSAL,
    projection: InflationProjection | None = None,
    monthly_rates: Iterable[tuple[date, Decimal]] = (),
) -> NominalIndexResult:
    return _checked_nominal_index(settlement_date, monthly_indexes,
        as_of=as_of, evidence_mode=evidence_mode, projection=projection,
        monthly_rates=monthly_rates)
