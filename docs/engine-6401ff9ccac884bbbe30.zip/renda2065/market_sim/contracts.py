"""Contratos imutáveis, finitos e serializáveis do simulador MTM."""
from __future__ import annotations

from dataclasses import dataclass
from datetime import date, datetime
from decimal import Decimal, InvalidOperation
from enum import StrEnum
import json
from math import isfinite
from typing import Any

from .provenance import EvidenceMode, Provenance, Quality


class ValidationError(ValueError):
    """Erro de domínio identificado e seguro para apresentação na interface."""

    def __init__(self, code: str, message: str):
        self.code = code
        super().__init__(f"{code}: {message}")


class ProductFamily(StrEnum):
    IPCA_PRINCIPAL = "IPCA_PRINCIPAL"
    RENDA_PLUS = "RENDA_PLUS"


class Side(StrEnum):
    BUY = "BUY"
    SELL = "SELL"
    BASE = "BASE"


class MetricStatus(StrEnum):
    AVAILABLE = "AVAILABLE"
    MISSING = "MISSING"
    BLOCKED_POLICY = "BLOCKED_POLICY"
    ESTIMATED = "ESTIMATED"
    UNAVAILABLE = "UNAVAILABLE"


class ScenarioIntent(StrEnum):
    """Intenção explícita do usuário para a operação analisada."""

    HISTORICAL_REVIEW = "HISTORICAL_REVIEW"
    HYPOTHETICAL = "HYPOTHETICAL"


def decimal_value(value: object, name: str) -> Decimal:
    try:
        result = Decimal(str(value))
    except (InvalidOperation, ValueError, TypeError) as exc:
        raise ValidationError("INVALID_NUMBER", f"{name} precisa ser um decimal válido.") from exc
    if not result.is_finite():
        raise ValidationError("NON_FINITE", f"{name} precisa ser finito.")
    return result


def _optional_decimal(value: object | None, name: str) -> Decimal | None:
    return None if value is None else decimal_value(value, name)


@dataclass(frozen=True, slots=True)
class Instrument:
    family: ProductFamily
    instrument_id: str
    maturity_date: date
    conversion_date: date | None = None
    first_income_date: date | None = None
    pays_coupon: bool = False
    coupon_rate: Decimal = Decimal("0")

    def __post_init__(self) -> None:
        coupon_rate = decimal_value(self.coupon_rate, "coupon_rate")
        object.__setattr__(self, "coupon_rate", coupon_rate)
        if not self.instrument_id.strip():
            raise ValidationError("INVALID_INSTRUMENT", "Informe o identificador oficial do título.")
        if self.pays_coupon or coupon_rate != 0:
            raise ValidationError("COUPON_OUT_OF_SCOPE", "Títulos com juros semestrais não pertencem ao simulador.")
        if self.family is ProductFamily.IPCA_PRINCIPAL:
            if self.conversion_date is not None or self.first_income_date is not None:
                raise ValidationError("INVALID_INSTRUMENT", "IPCA+ Principal não possui data de conversão ou renda.")
        elif self.family is ProductFamily.RENDA_PLUS:
            if self.conversion_date is None or self.first_income_date is None:
                raise ValidationError("INVALID_INSTRUMENT", "RendA+ exige datas de conversão e primeira parcela.")
            if self.conversion_date > self.first_income_date:
                raise ValidationError("INVALID_INSTRUMENT", "Conversão deve ocorrer até a primeira parcela.")
        else:
            raise ValidationError("INVALID_INSTRUMENT", "Família de título não suportada.")


@dataclass(frozen=True, slots=True)
class AsOf:
    date: date
    mode: EvidenceMode = EvidenceMode.CAUSAL


@dataclass(frozen=True, slots=True)
class Entry:
    instrument_id: str
    order_date: date
    settlement_date: date
    quantity: Decimal
    unit_price: Decimal | None
    real_yield: Decimal | None = None
    side: Side = Side.BUY
    provenance: Provenance | None = None

    def __post_init__(self) -> None:
        if not self.instrument_id.strip():
            raise ValidationError("INVALID_INSTRUMENT", "Entrada exige o identificador do título.")
        if self.side is not Side.BUY:
            raise ValidationError("WRONG_MARKET_SIDE", "O preço de entrada precisa ser do lado de compra.")
        quantity = decimal_value(self.quantity, "quantity")
        unit_price = _optional_decimal(self.unit_price, "unit_price")
        real_yield = _optional_decimal(self.real_yield, "real_yield")
        if quantity <= 0 or quantity % Decimal("0.01") != 0:
            raise ValidationError("INVALID_QUANTITY", "Quantidade deve ser positiva em múltiplos de 0,01 título.")
        if unit_price is not None and unit_price <= 0:
            raise ValidationError("INVALID_PRICE", "PU de entrada precisa ser positivo.")
        if real_yield is not None and real_yield <= -1:
            raise ValidationError("INVALID_YIELD", "Taxa real precisa ser maior que −100%.")
        if unit_price is None and real_yield is None:
            raise ValidationError("MISSING_ENTRY_PRICE", "Informe PU de compra ou taxa para reconstruir o preço.")
        if self.settlement_date < self.order_date:
            raise ValidationError("INVALID_DATES", "Liquidação não pode preceder a ordem de compra.")
        object.__setattr__(self, "quantity", quantity)
        object.__setattr__(self, "unit_price", unit_price)
        object.__setattr__(self, "real_yield", real_yield)


@dataclass(frozen=True, slots=True)
class Exit:
    instrument_id: str
    order_date: date
    settlement_date: date
    side: Side
    unit_price: Decimal | None
    real_yield: Decimal | None = None
    quoted_side: Side = Side.SELL
    spread: Decimal | None = None
    spread_source: str | None = None
    provenance: Provenance | None = None

    def __post_init__(self) -> None:
        if not self.instrument_id.strip():
            raise ValidationError("INVALID_INSTRUMENT", "Saída exige o identificador do título.")
        if self.side not in (Side.SELL, Side.BASE):
            raise ValidationError("WRONG_MARKET_SIDE", "Saída aceita lado SELL ou referência BASE.")
        price = _optional_decimal(self.unit_price, "unit_price")
        real_yield = _optional_decimal(self.real_yield, "real_yield")
        spread = _optional_decimal(self.spread, "spread")
        if price is not None and price <= 0:
            raise ValidationError("INVALID_PRICE", "PU de saída precisa ser positivo.")
        if real_yield is not None and real_yield <= -1:
            raise ValidationError("INVALID_YIELD", "Taxa real precisa ser maior que −100%.")
        if price is None and real_yield is None:
            raise ValidationError("MISSING_EXIT_PRICE", "Informe PU de saída ou taxa para reconstruir o preço.")
        if self.settlement_date < self.order_date:
            raise ValidationError("INVALID_DATES", "Liquidação não pode preceder a ordem de venda.")
        if self.quoted_side is Side.BUY and (
            spread is None or not self.spread_source or not self.spread_source.strip()
        ):
            raise ValidationError(
                "BUY_NOT_REDEMPTION",
                "Cotação de compra só pode estimar recompra com spread explícito e fonte declarada.",
            )
        if self.quoted_side is Side.BUY and (price is not None or real_yield is None):
            raise ValidationError(
                "BUY_PRICE_NOT_REDEMPTION",
                "PU de compra não pode ser tratado como PU de recompra; informe a taxa de compra e o spread.",
            )
        if (self.side is Side.BASE) != (self.quoted_side is Side.BASE):
            raise ValidationError("BASE_NOT_CASH", "PU Base serve apenas para marcação e nunca para caixa de venda.")
        if self.side is Side.BASE and self.settlement_date != self.order_date:
            raise ValidationError("BASE_NOT_CASH", "PU Base é marcação, não caixa com liquidação.")
        object.__setattr__(self, "unit_price", price)
        object.__setattr__(self, "real_yield", real_yield)
        object.__setattr__(self, "spread", spread)


@dataclass(frozen=True, slots=True)
class Scenario:
    instrument: Instrument
    entry: Entry
    exit: Exit
    as_of: AsOf
    intent: ScenarioIntent = ScenarioIntent.HISTORICAL_REVIEW

    def __post_init__(self) -> None:
        if not isinstance(self.intent, ScenarioIntent):
            raise ValidationError("INVALID_INTENT", "Intenção da operação não suportada.")
        instrument_id = self.instrument.instrument_id
        if self.entry.instrument_id != instrument_id or self.exit.instrument_id != instrument_id:
            raise ValidationError("INSTRUMENT_MISMATCH", "Compra, saída e instrumento devem ser o mesmo título.")
        if self.exit.order_date <= self.entry.order_date:
            raise ValidationError("INVALID_DATES", "Venda precisa ocorrer depois da compra.")
        if self.exit.settlement_date <= self.entry.settlement_date:
            raise ValidationError("INVALID_DATES", "Venda precisa liquidar depois da compra.")
        if self.instrument.family is ProductFamily.IPCA_PRINCIPAL:
            if self.exit.order_date >= self.instrument.maturity_date:
                raise ValidationError("OUTSIDE_HORIZON", "Saída do Principal deve ocorrer antes do vencimento.")
        else:
            assert self.instrument.conversion_date is not None
            assert self.instrument.first_income_date is not None
            if self.exit.order_date >= self.instrument.first_income_date:
                raise ValidationError("OUTSIDE_HORIZON", "RendA+ deve ser vendido antes da primeira parcela.")
        if self.as_of.date < self.entry.order_date and self.intent is not ScenarioIntent.HYPOTHETICAL:
            raise ValidationError("INVALID_AS_OF", "Data de referência não pode preceder a compra.")


@dataclass(frozen=True, slots=True)
class Metric:
    name: str
    value: Decimal | float | int | None
    unit: str
    as_of: date
    status: MetricStatus
    quality: Quality
    provenance: Provenance | None = None
    policy_id: str | None = None

    def __post_init__(self) -> None:
        if not self.name.strip() or not self.unit.strip():
            raise ValidationError("INVALID_METRIC", "Métrica exige nome e unidade.")
        if self.value is None and self.status is MetricStatus.AVAILABLE:
            raise ValidationError("INVALID_METRIC", "Métrica disponível precisa ter valor.")
        if self.value is not None:
            if isinstance(self.value, Decimal):
                if not self.value.is_finite():
                    raise ValidationError("NON_FINITE", "Métrica precisa ser finita.")
            elif isinstance(self.value, bool) or not isinstance(self.value, (int, float)) or not isfinite(self.value):
                raise ValidationError("NON_FINITE", "Métrica precisa ser numérica e finita.")


@dataclass(frozen=True, slots=True)
class Result:
    scenario_id: str
    metrics: tuple[Metric, ...]
    warnings: tuple[str, ...] = ()
    schema_version: int = 1

    def __post_init__(self) -> None:
        if not self.scenario_id.strip() or self.schema_version < 1:
            raise ValidationError("INVALID_RESULT", "Resultado exige cenário e versão válidos.")
        names = [metric.name for metric in self.metrics]
        if len(names) != len(set(names)):
            raise ValidationError("INVALID_RESULT", "Nomes de métricas devem ser únicos.")

    def to_dict(self) -> dict[str, Any]:
        def provenance_dict(value: Provenance | None) -> dict[str, Any] | None:
            if value is None:
                return None
            return {
                "source_id": value.source_id,
                "source_ref": value.source_ref,
                "quality": value.quality.value,
                "observed_on": value.observed_on.isoformat() if value.observed_on else None,
                "published_at": value.published_at.isoformat() if value.published_at else None,
                "version": value.version,
                "sha256": value.sha256,
                "revision_id": value.revision_id,
                "supersedes_revision": value.supersedes_revision,
                "settlement_date": value.settlement_date.isoformat() if value.settlement_date else None,
            }

        serialized = []
        for metric in self.metrics:
            val = metric.value
            serialized.append({
                "name": metric.name,
                "value": str(val) if isinstance(val, Decimal) else val,
                "unit": metric.unit,
                "as_of": metric.as_of.isoformat(),
                "status": metric.status.value,
                "quality": metric.quality.value,
                "provenance": provenance_dict(metric.provenance),
                "policy_id": metric.policy_id,
            })
        return {
            "schema_version": self.schema_version,
            "scenario_id": self.scenario_id,
            "metrics": serialized,
            "warnings": list(self.warnings),
        }

    def to_json(self) -> str:
        try:
            return json.dumps(self.to_dict(), ensure_ascii=False, allow_nan=False, sort_keys=True)
        except (TypeError, ValueError) as exc:
            raise ValidationError("SERIALIZATION_ERROR", "Resultado não pode ser serializado em JSON finito.") from exc

    @classmethod
    def from_json(cls, payload: str) -> "Result":
        try:
            raw = json.loads(payload, parse_constant=lambda value: (_ for _ in ()).throw(ValueError(value)))
            metrics = []
            for item in raw["metrics"]:
                prov_raw = item.get("provenance")
                provenance = None
                if prov_raw is not None:
                    provenance = Provenance(
                        source_id=prov_raw["source_id"],
                        source_ref=prov_raw["source_ref"],
                        quality=Quality(prov_raw["quality"]),
                        observed_on=date.fromisoformat(prov_raw["observed_on"]) if prov_raw.get("observed_on") else None,
                        published_at=datetime.fromisoformat(prov_raw["published_at"]) if prov_raw.get("published_at") else None,
                        version=prov_raw.get("version"),
                        sha256=prov_raw.get("sha256"),
                        revision_id=prov_raw.get("revision_id"),
                        supersedes_revision=prov_raw.get("supersedes_revision"),
                        settlement_date=date.fromisoformat(prov_raw["settlement_date"]) if prov_raw.get("settlement_date") else None,
                    )
                value = item["value"]
                if isinstance(value, str):
                    value = Decimal(value)
                metrics.append(Metric(
                    name=item["name"],
                    value=value,
                    unit=item["unit"],
                    as_of=date.fromisoformat(item["as_of"]),
                    status=MetricStatus(item["status"]),
                    quality=Quality(item["quality"]),
                    provenance=provenance,
                    policy_id=item.get("policy_id"),
                ))
            return cls(
                scenario_id=raw["scenario_id"],
                metrics=tuple(metrics),
                warnings=tuple(raw.get("warnings", ())),
                schema_version=raw["schema_version"],
            )
        except (KeyError, TypeError, ValueError, InvalidOperation) as exc:
            raise ValidationError("INVALID_RESULT_JSON", "JSON do resultado inválido.") from exc
