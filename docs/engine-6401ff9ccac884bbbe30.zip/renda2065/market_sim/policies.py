"""Políticas tributárias e de custódia com vigência e qualidade explícitas."""
from __future__ import annotations

from dataclasses import dataclass
from datetime import date
from decimal import Decimal, ROUND_HALF_UP, localcontext

from .contracts import ProductFamily, ValidationError, decimal_value
from .provenance import Quality

D = Decimal
CENT = D("0.01")
IR_POLICY_ID = "BR_IR_RF_LEI_11033_ART1"
IOF_POLICY_ID = "BR_IOF_RF_DECRETO_6306_ART32_ANEXO"
PRINCIPAL_CUSTODY_POLICY_ID = "B3_TESOURO_PRINCIPAL_020_ESTIMATED_v1"
PRINCIPAL_DAILY_CUSTODY_POLICY_ID = "B3_TESOURO_PRINCIPAL_020_DAILY_BASE_ESTIMATED_v1"
RENDA_CUSTODY_POLICY_ID = "B3_RENDA_PLUS_EXIT_TIERS_ESTIMATED_v1"

# Percentual máximo do rendimento tributável para IOF, por idade em dias.
IOF_GAIN_CAPS = tuple(D(value) / D(100) for value in (
    96, 93, 90, 86, 83, 80, 76, 73, 70, 66,
    63, 60, 56, 53, 50, 46, 43, 40, 36, 33,
    30, 26, 23, 20, 16, 13, 10, 6, 3, 0,
))


@dataclass(frozen=True, slots=True)
class PolicyAmount:
    amount: Decimal
    policy_id: str
    quality: Quality
    status: str
    explanation: str


def round_money(value: Decimal | str | int) -> Decimal:
    return decimal_value(value, "valor monetário").quantize(CENT, rounding=ROUND_HALF_UP)


def income_tax_rate(holding_days: int) -> Decimal:
    if isinstance(holding_days, bool) or not isinstance(holding_days, int) or holding_days < 0:
        raise ValidationError("INVALID_HOLDING_DAYS", "Prazo fiscal precisa ser inteiro não negativo.")
    if holding_days <= 180:
        return D("0.225")
    if holding_days <= 360:
        return D("0.20")
    if holding_days <= 720:
        return D("0.175")
    return D("0.15")


def iof_gain_cap(holding_days: int) -> Decimal:
    if isinstance(holding_days, bool) or not isinstance(holding_days, int) or holding_days < 0:
        raise ValidationError("INVALID_HOLDING_DAYS", "Prazo fiscal precisa ser inteiro não negativo.")
    if holding_days == 0 or holding_days >= 30:
        return D(0)
    return IOF_GAIN_CAPS[holding_days - 1]


def calculate_iof(gross_redemption: Decimal, taxable_gain_before_iof: Decimal, holding_days: int) -> PolicyAmount:
    gross = decimal_value(gross_redemption, "resgate bruto")
    gain = decimal_value(taxable_gain_before_iof, "rendimento")
    if gross < 0:
        raise ValidationError("INVALID_AMOUNT", "Resgate bruto não pode ser negativo.")
    if isinstance(holding_days, bool) or not isinstance(holding_days, int) or holding_days < 0:
        raise ValidationError("INVALID_HOLDING_DAYS", "Prazo não pode ser negativo.")
    positive_gain = max(gain, D(0))
    if not positive_gain or holding_days == 0 or holding_days >= 30:
        amount = D(0)
    else:
        statutory_daily_amount = gross * D("0.01") * holding_days
        annex_gain_limit = positive_gain * iof_gain_cap(holding_days)
        amount = min(statutory_daily_amount, annex_gain_limit, positive_gain)
    return PolicyAmount(
        round_money(amount), IOF_POLICY_ID, Quality.RECONSTRUCTED, "AVAILABLE",
        "IOF: 1% ao dia sobre o resgate, limitado ao percentual do rendimento no Anexo legal; arredondamento em centavos half-up.",
    )


def calculate_income_tax(taxable_gain_before_iof: Decimal, iof: Decimal, holding_days: int) -> PolicyAmount:
    gain = decimal_value(taxable_gain_before_iof, "rendimento tributável")
    iof_amount = decimal_value(iof, "IOF")
    if iof_amount < 0:
        raise ValidationError("INVALID_AMOUNT", "IOF não pode ser negativo.")
    taxable_after_iof = max(gain - iof_amount, D(0))
    amount = round_money(taxable_after_iof * income_tax_rate(holding_days))
    return PolicyAmount(
        amount, IR_POLICY_ID, Quality.RECONSTRUCTED, "AVAILABLE",
        "IR regressivo sobre rendimento nominal positivo após IOF aplicável; custo de aquisição separado.",
    )


def renda_plus_custody_rate(settlement_date: date, exit_date: date) -> Decimal:
    if exit_date < settlement_date:
        raise ValidationError("INVALID_DATES", "Saída não pode preceder a liquidação.")
    def anniversary(years: int) -> date:
        try:
            return settlement_date.replace(year=settlement_date.year + years)
        except ValueError:
            return settlement_date.replace(year=settlement_date.year + years, day=28)

    ten_year_date = anniversary(10)
    twenty_year_date = anniversary(20)
    # Leitura da tabela B3: “até 10”, “10 a 20” e “acima de 20”.
    # O prazo é contado em dias corridos desde a liquidação.
    if exit_date <= ten_year_date:
        return D("0.005")
    if exit_date <= twenty_year_date:
        return D("0.002")
    return D("0.001")


def estimate_custody(
    family: ProductFamily,
    settlement_date: date,
    exit_settlement_date: date,
    gross_redemption: Decimal,
    *,
    position_value_days: Decimal | None = None,
) -> PolicyAmount:
    gross = decimal_value(gross_redemption, "resgate bruto")
    days = (exit_settlement_date - settlement_date).days
    if gross < 0 or days < 0:
        raise ValidationError("INVALID_AMOUNT", "Resgate e prazo precisam ser não negativos.")
    value_days = None
    if position_value_days is not None:
        value_days = decimal_value(position_value_days, "soma das posições diárias")
        if family is not ProductFamily.IPCA_PRINCIPAL or value_days < 0:
            raise ValidationError("INVALID_AMOUNT", "Trajetória de custódia exige valores não negativos do IPCA+ Principal.")
    if family is ProductFamily.IPCA_PRINCIPAL:
        annual_rate = D("0.002")
        policy_id = PRINCIPAL_CUSTODY_POLICY_ID
        explanation = (
            "Estimativa: 0,20% a.a. pró-rata sobre o PU/posição de saída constante. "
            "A B3 provisiona diariamente sobre a posição; sem a trajetória diária e o arredondamento do agente, "
            "não é líquido institucional exato."
        )
        if position_value_days is not None:
            policy_id = PRINCIPAL_DAILY_CUSTODY_POLICY_ID
            explanation = (
                "Estimativa a 0,20% a.a., com posições diárias e divisor 365. "
                "Consulte a cobertura e as aproximações de preço."
            )
    elif family is ProductFamily.RENDA_PLUS:
        annual_rate = renda_plus_custody_rate(settlement_date, exit_settlement_date)
        policy_id = RENDA_CUSTODY_POLICY_ID
        explanation = (
            f"Estimativa: taxa anual de {annual_rate} pela faixa de prazo B3 aplicada pró-rata ao valor de saída; "
            "nos aniversários exatos de 10 e 20 anos da liquidação, usa a maior taxa entre as faixas sobrepostas "
            "por conservadorismo, pois a tabela publicada não define o limite inclusivo; "
            "a política publicada não especifica aqui o arredondamento operacional da posição diária."
        )
    else:
        raise ValidationError("UNSUPPORTED_POLICY", "Produto sem política de custódia nesta versão.")
    with localcontext() as ctx:
        ctx.prec = 32
        if value_days is None:
            amount = gross * annual_rate * D(days) / D(365)
        else:
            amount = value_days * annual_rate / D(365)
    return PolicyAmount(round_money(amount), policy_id, Quality.ESTIMATED, "ESTIMATED", explanation)
