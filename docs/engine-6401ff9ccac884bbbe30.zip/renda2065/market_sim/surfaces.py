"""Pontos de curvas e mapas; cada célula passa pelo serviço financeiro direto."""
from __future__ import annotations

from dataclasses import dataclass, field, replace
from datetime import date, timedelta
from decimal import Decimal
from enum import StrEnum
from hashlib import sha256
from typing import Any, MutableMapping, Protocol, Sequence

from .contracts import Exit, Scenario, Side, ValidationError, decimal_value
from .dates import event_coverage_for_order_date, event_uncertification_order_dates
from .operation import OperationResult
from .policies import IR_POLICY_ID, IOF_POLICY_ID, PRINCIPAL_CUSTODY_POLICY_ID, RENDA_CUSTODY_POLICY_ID
from .principal import PRICING_VERSION as PRINCIPAL_VERSION
from .provenance import Provenance, Quality
from .renda_plus import PRICING_VERSION as RENDA_PLUS_VERSION
from .renda_plus import (
    MAX_YIELD as RENDA_MAX_YIELD,
    MIN_YIELD as RENDA_MIN_YIELD,
    RendaPlusSeries,
    sale_eligibility,
)
from .service import EvaluationContext, IndexKind, ScenarioEvaluation, evaluate_scenario
from .targets import (
    RateSolution, TargetDefinition, TargetMetric, TargetSolution, TargetStatus,
    solve_minimum_exit_pu, solve_rate_for_pu_limit,
)

D = Decimal
MAX_DATE_POINTS = 1260
MAX_CONSTRAINT_FRONTIER_DATES = 15
MAX_RATE_POINTS = 101
# O teto foi calibrado em CPython 3.12 local com a fórmula decimal de 240
# fluxos do RendA+: 1.600 células consumiram 13,1 s; 256 mantém o mapa em
# uma janela interativa curta mesmo no produto mais caro por ponto.
MAX_SURFACE_CELLS = 256


class SurfaceMetric(StrEnum):
    GROSS_REDEMPTION = "gross_redemption"
    NET_REDEMPTION = "net_redemption"
    NOMINAL_PROFIT = "nominal_profit"
    NOMINAL_RETURN = "nominal_return"
    ANNUALIZED_NOMINAL_RETURN = "annualized_nominal_return"
    REAL_PROFIT = "real_profit_in_exit_date_currency"
    REAL_RETURN = "real_return"


class SurfaceStatus(StrEnum):
    READY = "READY"
    NON_SESSION = "NON_SESSION"
    OUTSIDE_HORIZON = "OUTSIDE_HORIZON"
    EVENT_COVERAGE_UNCERTIFIED = "EVENT_COVERAGE_UNCERTIFIED"
    MISSING_INDEX = "MISSING_INDEX"
    MISSING_PRICE = "MISSING_PRICE"
    MISSING_CALENDAR = "MISSING_CALENDAR"
    BLOCKED_POLICY = "BLOCKED_POLICY"
    MISSING_METRIC = "MISSING_METRIC"
    CANCELLED = "CANCELLED"
    NO_TARGET = "NO_TARGET"
    UNATTAINABLE = "UNATTAINABLE"
    NO_ROOT = "NO_ROOT"
    ALL_DOMAIN = "ALL_DOMAIN"
    AMBIGUOUS_ROOT = "AMBIGUOUS_ROOT"
    VERIFICATION_FAILED = "VERIFICATION_FAILED"
    METRIC_UNAVAILABLE = "METRIC_UNAVAILABLE"


@dataclass(frozen=True, slots=True)
class SurfaceMetricValue:
    """One operation metric projected without another engine evaluation."""

    metric: SurfaceMetric
    value: Decimal | None
    unit: str
    status: SurfaceStatus
    quality: Quality
    reason: str | None = None


class CancelSignal(Protocol):
    def is_set(self) -> bool: ...


@dataclass(frozen=True, slots=True)
class SurfaceSession:
    """Datas explícitas de negociação/liquidação de uma coordenada temporal."""

    order_date: date
    settlement_date: date

    def __post_init__(self) -> None:
        if self.settlement_date < self.order_date:
            raise ValidationError("INVALID_DATES", "Liquidação da superfície precede a ordem.")


@dataclass(frozen=True, slots=True)
class SurfaceDomain:
    order_dates: tuple[date, ...]
    values: tuple[Decimal, ...]
    candidate_order_dates: tuple[date, ...]
    candidate_values: tuple[Decimal, ...]
    omitted_dates: tuple[date, ...]
    omitted_values: tuple[Decimal, ...]
    policy_dates: tuple[date, ...]
    complete: bool
    date_range: tuple[date, date]
    resolution: tuple[int, int]

    @property
    def coverage_status(self) -> str:
        return "exhaustive_discrete" if self.complete else "sampled"


def generate_surface_domain(
    scenario: Scenario,
    context: EvaluationContext,
    mode: str,
    value_unit: str,
    selected_order_date: date,
    selected_value: Decimal | str,
    *,
    requested_order_dates: Sequence[date] | None = None,
    requested_values: Sequence[Decimal | str] | None = None,
    max_value_points: int = 15,
) -> SurfaceDomain:
    """Create a bounded, explicit visual grid and report every omitted axis point."""
    if context.calendar is None:
        raise ValidationError("CALENDAR_REQUIRED", "Domínio de superfície exige calendário identificado.")
    if mode not in {"PRICE_DATE_MAP", "RATE_DATE_MAP", "RATE_CURVE", "DATE_CURVE"}:
        raise ValidationError("INVALID_DOMAIN", "Modo de superfície desconhecido.")
    if value_unit not in {"BRL_PER_TITLE", "ratio"}:
        raise ValidationError("INVALID_UNIT", "Coordenada da superfície exige PU ou taxa.")
    if (mode == "PRICE_DATE_MAP") != (value_unit == "BRL_PER_TITLE") and mode != "DATE_CURVE":
        raise ValidationError("INVALID_UNIT", "Unidade de coordenada incompatível com o modo de superfície.")

    chosen = decimal_value(selected_value, "coordenada selecionada")
    if value_unit == "BRL_PER_TITLE" and chosen <= 0:
        raise ValidationError("INVALID_SELECTION", "PU selecionado precisa ser positivo.")
    if value_unit == "ratio" and chosen <= -1:
        raise ValidationError("INVALID_SELECTION", "Taxa selecionada precisa ser maior que −100%.")

    if requested_order_dates is not None:
        raw_dates = tuple(requested_order_dates)
        if not raw_dates or raw_dates != tuple(sorted(set(raw_dates))):
            raise ValidationError("INVALID_DOMAIN", "Datas solicitadas precisam ser crescentes e únicas.")
        candidate_dates = set(raw_dates)
        span_start, span_end = raw_dates[0], raw_dates[-1]
    elif mode == "RATE_CURVE":
        candidate_dates = {selected_order_date}
        span_start = span_end = selected_order_date
    else:
        requested_start = selected_order_date - timedelta(days=30)
        requested_end = selected_order_date + timedelta(days=30)
        entry_floor = scenario.entry.settlement_date + timedelta(days=1)
        product_end = scenario.instrument.maturity_date - timedelta(days=1)
        if scenario.instrument.first_income_date is not None:
            product_end = min(product_end, scenario.instrument.first_income_date - timedelta(days=1))
        span_start, span_end = max(requested_start, entry_floor), min(requested_end, product_end)
        candidate_dates = set()
        if span_start <= span_end:
            cursor = span_start
            while cursor <= span_end:
                if context.calendar.is_session(cursor):
                    candidate_dates.add(cursor)
                cursor += timedelta(days=1)

    if mode == "RATE_CURVE":
        if requested_order_dates is not None and tuple(requested_order_dates) != (selected_order_date,):
            raise ValidationError("INVALID_DOMAIN", "RATE_CURVE varia taxa em uma única data selecionada.")
        candidate_dates = {selected_order_date}
        span_start = span_end = selected_order_date

    policy_dates = _surface_policy_dates(scenario, context, span_start, span_end)
    candidate_dates.update(policy_dates)
    candidate_dates.add(selected_order_date)
    ordered_dates = tuple(sorted(candidate_dates))

    if mode == "DATE_CURVE":
        if requested_values is not None and tuple(decimal_value(item, "coordenada") for item in requested_values) != (chosen,):
            raise ValidationError("INVALID_DOMAIN", "DATE_CURVE mantém a coordenada selecionada constante.")
        candidate_value_axis = (chosen,)
    elif requested_values is not None:
        raw_values = tuple(decimal_value(item, "coordenada da superfície") for item in requested_values)
        if not raw_values or raw_values != tuple(sorted(set(raw_values))):
            raise ValidationError("INVALID_DOMAIN", "Valores solicitados precisam ser crescentes e únicos.")
        if value_unit == "BRL_PER_TITLE" and any(item <= 0 for item in raw_values):
            raise ValidationError("INVALID_DOMAIN", "PUs da superfície precisam ser positivos.")
        if value_unit == "ratio" and any(item <= -1 for item in raw_values):
            raise ValidationError("INVALID_DOMAIN", "Taxas da superfície precisam ser maiores que −100%.")
        if scenario.instrument.family.value == "RENDA_PLUS" and value_unit == "ratio" and any(
            item < RENDA_MIN_YIELD or item > RENDA_MAX_YIELD for item in raw_values
        ):
            raise ValidationError("INVALID_YIELD", "RendA+ aceita taxa entre −95% e 1.000% a.a.")
        candidate_value_axis = tuple(sorted(set((*raw_values, chosen))))
    else:
        candidate_value_axis = _default_surface_values(
            chosen, value_unit, scenario.instrument.family.value == "RENDA_PLUS",
        )

    if scenario.instrument.family.value == "RENDA_PLUS" and value_unit == "ratio" and any(
        item < RENDA_MIN_YIELD or item > RENDA_MAX_YIELD for item in candidate_value_axis
    ):
        raise ValidationError("INVALID_YIELD", "RendA+ aceita taxa entre −95% e 1.000% a.a.")

    # Endpoints, selection and policy dates are mandatory coordinates. Other
    # dates/values are spread evenly through the explicitly requested domain.
    mandatory_dates = {selected_order_date, *policy_dates}
    if ordered_dates:
        mandatory_dates.update((ordered_dates[0], ordered_dates[-1]))
    mandatory_dates.intersection_update(ordered_dates)
    mandatory_values = {candidate_value_axis[0], candidate_value_axis[-1], chosen}
    mandatory_values.intersection_update(candidate_value_axis)
    date_count = min(len(ordered_dates), max(15, len(mandatory_dates)))
    if type(max_value_points) is not int or max_value_points < 1 or max_value_points > MAX_RATE_POINTS:
        raise ValueError("max_value_points precisa ficar entre 1 e o limite de taxas suportado")
    value_count = min(len(candidate_value_axis), max_value_points)
    if date_count * value_count > MAX_SURFACE_CELLS:
        value_count = max(len(mandatory_values), MAX_SURFACE_CELLS // date_count)
        if date_count * value_count > MAX_SURFACE_CELLS:
            date_count = min(len(ordered_dates), MAX_SURFACE_CELLS // value_count)
    if date_count * value_count > MAX_SURFACE_CELLS:
        raise ValidationError("SURFACE_LIMIT", "Pontos obrigatórios excedem o limite da superfície.")
    sampled_dates = _evenly_sample_axis(ordered_dates, mandatory_dates, date_count)
    sampled_values = _evenly_sample_axis(candidate_value_axis, mandatory_values, value_count)
    omitted_dates = tuple(item for item in ordered_dates if item not in set(sampled_dates))
    omitted_values = tuple(item for item in candidate_value_axis if item not in set(sampled_values))
    return SurfaceDomain(
        sampled_dates, sampled_values, ordered_dates, candidate_value_axis,
        omitted_dates, omitted_values, tuple(sorted(policy_dates)),
        not omitted_dates and not omitted_values,
        (span_start, span_end), (len(sampled_dates), len(sampled_values)),
    )


def _default_surface_values(chosen: Decimal, unit: str, renda_plus: bool) -> tuple[Decimal, ...]:
    count = 15
    if unit == "ratio":
        minimum = RENDA_MIN_YIELD if renda_plus else Decimal("-0.999999999")
        maximum = RENDA_MAX_YIELD if renda_plus else None
        low = max(minimum, chosen - Decimal("0.01"))
        high = chosen + Decimal("0.01")
        if maximum is not None:
            high = min(maximum, high)
        if chosen <= low:
            values = [low + (high - low) * Decimal(index) / Decimal(count - 1) for index in range(count)]
            values[0] = chosen
        elif chosen >= high:
            values = [low + (high - low) * Decimal(index) / Decimal(count - 1) for index in range(count)]
            values[-1] = chosen
        else:
            values = [low + (high - low) * Decimal(index) / Decimal(count - 1) for index in range(count)]
            values[count // 2] = chosen
        return tuple(sorted(set(values)))
    low, high = chosen * Decimal("0.8"), chosen * Decimal("1.2")
    values = [
        (low + (high - low) * Decimal(index) / Decimal(count - 1)).quantize(Decimal("0.0001"))
        for index in range(count)
    ]
    values[count // 2] = chosen
    return tuple(sorted(set(values)))


def _surface_policy_dates(
    scenario: Scenario, context: EvaluationContext, start: date, end: date,
) -> tuple[date, ...]:
    if start > end:
        return ()
    calendar = context.calendar
    candidates: set[date] = set()
    if scenario.instrument.family.value == "RENDA_PLUS":
        series = RendaPlusSeries.for_conversion_year(scenario.instrument.conversion_date.year)
        eligibility = sale_eligibility(
            series, scenario.entry.settlement_date, start, calendar, context.institution_release_date,
        )
        candidates.add(eligibility.earliest_eligible_session)
        cutoffs = {series.first_income_date}
        if scenario.instrument.first_income_date is not None:
            cutoffs.add(scenario.instrument.first_income_date)
    else:
        cutoffs = {scenario.instrument.maturity_date}
    for cutoff in cutoffs:
        previous = cutoff - timedelta(days=1)
        for _ in range(8):
            if calendar.is_session(previous):
                candidates.add(previous)
                break
            previous -= timedelta(days=1)
    candidates.update(event_uncertification_order_dates(scenario.instrument, calendar))
    return tuple(sorted(item for item in candidates if start <= item <= end))


def _evenly_sample_axis(values: Sequence[Any], mandatory: set[Any], count: int) -> tuple[Any, ...]:
    if len(values) <= count:
        return tuple(values)
    indexes = {index for index, value in enumerate(values) if value in mandatory}
    if len(indexes) > count:
        raise ValidationError("SURFACE_LIMIT", "Pontos obrigatórios excedem a resolução disponível.")
    while len(indexes) < count:
        candidate = max(
            (index for index in range(len(values)) if index not in indexes),
            key=lambda index: (min(abs(index - selected) for selected in indexes), -index),
        )
        indexes.add(candidate)
    return tuple(values[index] for index in sorted(indexes))


@dataclass(frozen=True, slots=True)
class ExitObservation:
    order_date: date
    settlement_date: date
    unit_price: Decimal | None = None
    real_yield: Decimal | None = None
    provenance: Provenance | None = None
    quality: Quality = Quality.INFORMED

    def __post_init__(self) -> None:
        if self.settlement_date < self.order_date:
            raise ValidationError("INVALID_DATES", "Liquidação da observação precede a ordem.")
        if self.unit_price is not None and self.real_yield is not None:
            raise ValidationError("INVALID_SURFACE_QUOTE", "Observação deve informar PU ou taxa, exclusivamente.")
        if self.unit_price is not None:
            pu = decimal_value(self.unit_price, "PU da observação")
            if pu <= 0:
                raise ValidationError("INVALID_PRICE", "PU da observação precisa ser positivo.")
            object.__setattr__(self, "unit_price", pu)
        if self.real_yield is not None:
            rate = decimal_value(self.real_yield, "taxa da observação")
            if rate <= -1:
                raise ValidationError("INVALID_YIELD", "Taxa da observação precisa ser maior que −100%.")
            object.__setattr__(self, "real_yield", rate)
        if not isinstance(self.quality, Quality):
            object.__setattr__(self, "quality", Quality(self.quality))
        if self.provenance is not None and self.provenance.quality is not self.quality:
            raise ValidationError("INVALID_PROVENANCE", "Qualidade da cotação e proveniência divergem.")
        if self.quality in (Quality.OBSERVED, Quality.REVISED) and self.provenance is None:
            raise ValidationError("MISSING_PROVENANCE", "Cotação observada exige fonte e datas de proveniência.")
        if self.quality not in (Quality.INFORMED, Quality.MISSING) and self.provenance is None:
            raise ValidationError("MISSING_PROVENANCE", "Cotação não manual exige proveniência declarada.")
        if self.unit_price is None and self.real_yield is None:
            if self.provenance is not None:
                raise ValidationError("INVALID_SURFACE_QUOTE", "Ponto sem preço não pode carregar proveniência de cotação.")
            object.__setattr__(self, "quality", Quality.MISSING)
        if self.provenance and self.provenance.settlement_date not in (None, self.settlement_date):
            raise ValidationError("QUOTE_SETTLEMENT_MISMATCH", "Liquidação da proveniência não corresponde ao ponto.")


@dataclass(frozen=True, slots=True)
class SurfacePoint:
    order_date: date
    settlement_date: date
    rate: Decimal | None
    unit_price: Decimal | None
    value: Decimal | None
    metric: SurfaceMetric
    unit: str
    status: SurfaceStatus
    quality: Quality
    source_ref: str | None = None
    reason: str | None = None
    selected: bool = False
    metrics: tuple[SurfaceMetricValue, ...] = ()
    evaluation: ScenarioEvaluation | None = field(default=None, repr=False, compare=False)

    def to_dict(self) -> dict[str, object]:
        return {
            "order_date": self.order_date.isoformat(),
            "settlement_date": self.settlement_date.isoformat(),
            "rate": str(self.rate) if self.rate is not None else None,
            "unit_price": str(self.unit_price) if self.unit_price is not None else None,
            "value": str(self.value) if self.value is not None else None,
            "metric": self.metric.value,
            "unit": self.unit,
            "status": self.status.value,
            "quality": self.quality.value,
            "source_ref": self.source_ref,
            "reason": self.reason,
            "selected": self.selected,
        }


@dataclass(frozen=True, slots=True)
class SurfaceResult:
    mode: str
    metric: SurfaceMetric
    points: tuple[SurfacePoint, ...]
    status: SurfaceStatus
    selected_date: date | None
    selected_rate: Decimal | None
    requested_cells: int
    evaluated_scenarios: int
    resolution: tuple[int, int]
    cache_id: str
    warnings: tuple[str, ...] = ()
    reused_scenarios: int = 0

    def to_dict(self) -> dict[str, object]:
        return {
            "schema_version": 1,
            "mode": self.mode,
            "metric": self.metric.value,
            "status": self.status.value,
            "selected_date": self.selected_date.isoformat() if self.selected_date else None,
            "selected_rate": str(self.selected_rate) if self.selected_rate is not None else None,
            "requested_cells": self.requested_cells,
            "evaluated_scenarios": self.evaluated_scenarios,
            "resolution": {"dates": self.resolution[0], "rates": self.resolution[1]},
            "cache_id": self.cache_id,
            "warnings": list(self.warnings),
            "points": [point.to_dict() for point in self.points],
        }


@dataclass(frozen=True, slots=True)
class FrontierPoint:
    order_date: date
    settlement_date: date
    minimum_exit_pu: Decimal | None
    maximum_exit_yield: Decimal | None
    status: SurfaceStatus
    source_ref: str | None
    reason: str | None = None
    selected: bool = False


@dataclass(frozen=True, slots=True)
class FrontierResult:
    mode: str
    target: TargetDefinition | None
    points: tuple[FrontierPoint, ...]
    selected_evaluation: ScenarioEvaluation | None
    status: SurfaceStatus
    evaluations: int
    warnings: tuple[str, ...] = ()


@dataclass(frozen=True, slots=True)
class DecisionCell:
    order_date: date
    settlement_date: date
    unit_price: Decimal
    value: Decimal | None
    nominal_profit: Decimal | None
    nominal_return: Decimal | None
    net_redemption: Decimal | None
    annualized_nominal_return: Decimal | None
    status: SurfaceStatus
    quality: Quality
    meets_targets: bool | None
    failed_targets: tuple[str, ...] = ()
    unavailable_targets: tuple[str, ...] = ()
    reason: str | None = None
    selected: bool = False
    metrics: tuple[SurfaceMetricValue, ...] = ()
    source_ref: str | None = None

    def to_dict(self) -> dict[str, object]:
        return {
            "order_date": self.order_date.isoformat(),
            "settlement_date": self.settlement_date.isoformat(),
            "unit_price": str(self.unit_price),
            "value": str(self.value) if self.value is not None else None,
            "nominal_profit": str(self.nominal_profit) if self.nominal_profit is not None else None,
            "nominal_return": str(self.nominal_return) if self.nominal_return is not None else None,
            "net_redemption": str(self.net_redemption) if self.net_redemption is not None else None,
            "annualized_nominal_return": str(self.annualized_nominal_return) if self.annualized_nominal_return is not None else None,
            "status": self.status.value,
            "quality": self.quality.value,
            "meets_targets": self.meets_targets,
            "failed_targets": list(self.failed_targets),
            "unavailable_targets": list(self.unavailable_targets),
            "reason": self.reason,
            "selected": self.selected,
        }


@dataclass(frozen=True, slots=True)
class DecisionMapResult:
    metric: SurfaceMetric
    targets: tuple[TargetDefinition, ...]
    points: tuple[DecisionCell, ...]
    status: SurfaceStatus
    selected_date: date
    selected_pu: Decimal
    evaluated_scenarios: int
    resolution: tuple[int, int]
    cache_id: str
    reused_scenarios: int = 0

    def to_dict(self) -> dict[str, object]:
        return {
            "schema_version": 1,
            "mode": "DECISION_MAP",
            "metric": self.metric.value,
            "unit": _metric_unit(self.metric),
            "targets": [{"metric": item.metric.value, "minimum_value": str(item.minimum_value),
                         "unit": item.unit} for item in self.targets],
            "status": self.status.value,
            "selected_date": self.selected_date.isoformat(),
            "selected_pu": str(self.selected_pu),
            "requested_cells": len(self.points),
            "evaluated_scenarios": self.evaluated_scenarios,
            "resolution": {"dates": self.resolution[0], "prices": self.resolution[1]},
            "cache_id": self.cache_id,
            "matched_cells": sum(point.meets_targets is True for point in self.points),
            "unavailable_cells": sum(point.meets_targets is None for point in self.points),
            "points": [point.to_dict() for point in self.points],
        }


class SurfaceEvaluationBudgetExceeded(RuntimeError):
    """Raised before a direct evaluation when a shared query budget is spent."""


class _RequestEvaluator:
    """Cache isolado à requisição; inclui cenário, contexto, métodos e políticas."""

    def __init__(self, context: EvaluationContext, evaluation_cache: MutableMapping[str, ScenarioEvaluation] | None = None,
                 evaluation_budget: Any | None = None):
        self.context = context
        self.cache: MutableMapping[str, ScenarioEvaluation] = evaluation_cache if evaluation_cache is not None else {}
        self.evaluation_budget = evaluation_budget
        self.evaluated = 0
        self.reused = 0

    def evaluate(self, scenario: Scenario) -> ScenarioEvaluation:
        identity = _cache_identity(scenario, self.context)
        key = sha256(identity.encode("utf-8")).hexdigest()
        if key not in self.cache:
            if self.evaluation_budget is not None and not self.evaluation_budget.try_consume():
                reason = self.evaluation_budget.reason or "EVALUATION_LIMIT"
                raise SurfaceEvaluationBudgetExceeded(reason)
            self.cache[key] = evaluate_scenario(scenario, self.context)
            self.evaluated += 1
        else:
            self.reused += 1
            move_to_end = getattr(self.cache, "move_to_end", None)
            if move_to_end is not None:
                move_to_end(key)
        return self.cache[key]


def build_rate_curve(
    scenario: Scenario,
    rates: Sequence[Decimal | str],
    context: EvaluationContext,
    metric: SurfaceMetric,
    *,
    selected_rate: Decimal | str | None = None,
    cancel_event: CancelSignal | None = None,
    evaluation_cache: MutableMapping[str, ScenarioEvaluation] | None = None,
) -> SurfaceResult:
    values = _rates(rates)
    _validate_rates_for_instrument(scenario, values)
    if len(values) > MAX_RATE_POINTS:
        raise ValidationError("SURFACE_LIMIT", f"Curva aceita no máximo {MAX_RATE_POINTS} pontos de taxa.")
    _require_sell_scenario(scenario)
    chosen = decimal_value(selected_rate, "taxa selecionada") if selected_rate is not None else None
    if chosen is not None and chosen not in values:
        raise ValidationError("INVALID_SELECTION", "Taxa selecionada precisa estar na grade solicitada.")
    evaluator = _RequestEvaluator(context, evaluation_cache)
    points: list[SurfacePoint] = []
    date_status = _date_status(scenario, scenario.exit.order_date, scenario.exit.settlement_date, context)
    for rate in values:
        if _cancelled(cancel_event):
            break
        if date_status is not None:
            reason, source_ref = _date_issue_details(
                date_status, scenario, scenario.exit.order_date, context,
            )
            points.append(_masked_point(
                scenario.exit.order_date, scenario.exit.settlement_date, metric,
                date_status, rate=rate, selected=(rate == chosen),
                source_ref=source_ref, reason=reason,
            ))
            continue
        if _cost_paid_after(context, scenario.exit.settlement_date):
            points.append(_masked_point(
                scenario.exit.order_date, scenario.exit.settlement_date, metric,
                SurfaceStatus.MISSING_METRIC, rate=rate, selected=(rate == chosen),
            ))
            continue
        exit_quote = replace(scenario.exit, unit_price=None, real_yield=rate, provenance=None)
        candidate = replace(scenario, exit=exit_quote)
        evaluation = evaluator.evaluate(candidate)
        point = _evaluation_point(
            evaluation, metric, scenario.exit.order_date, scenario.exit.settlement_date,
            rate=rate, source_ref=_rate_source(evaluation), selected=(rate == chosen),
        )
        points.append(point)
    cancelled = len(points) != len(values)
    return SurfaceResult(
        "RATE_CURVE", metric, tuple(points), SurfaceStatus.CANCELLED if cancelled else _aggregate_status(points),
        None, chosen, len(values), evaluator.evaluated, (1, len(values)),
        _cache_id(scenario, context, repr(("RATE_CURVE", metric, values, chosen))),
        reused_scenarios=evaluator.reused,
    )


def build_date_curve(
    scenario: Scenario,
    observations: Sequence[ExitObservation],
    context: EvaluationContext,
    metric: SurfaceMetric,
    *,
    selected_order_date: date | None = None,
    cancel_event: CancelSignal | None = None,
    evaluation_cache: MutableMapping[str, ScenarioEvaluation] | None = None,
) -> SurfaceResult:
    _check_dates(observations)
    _validate_rates_for_instrument(scenario, tuple(
        item.real_yield for item in observations if item.real_yield is not None
    ))
    if len(observations) > MAX_DATE_POINTS:
        raise ValidationError("SURFACE_LIMIT", f"Curva aceita no máximo {MAX_DATE_POINTS} datas.")
    if context.calendar is None:
        raise ValidationError("CALENDAR_REQUIRED", "Curva por data exige calendário identificado para mascarar sessões.")
    _require_sell_scenario(scenario)
    dates = [item.order_date for item in observations]
    if selected_order_date is not None and selected_order_date not in dates:
        raise ValidationError("INVALID_SELECTION", "Data selecionada precisa estar na curva.")
    evaluator = _RequestEvaluator(context, evaluation_cache)
    points: list[SurfacePoint] = []
    for quote in observations:
        if _cancelled(cancel_event):
            break
        status = _date_status(scenario, quote.order_date, quote.settlement_date, context)
        if status is not None:
            reason, source_ref = _date_issue_details(status, scenario, quote.order_date, context)
            points.append(_masked_point(
                quote.order_date, quote.settlement_date, metric, status,
                selected=quote.order_date == selected_order_date,
                source_ref=source_ref or (quote.provenance.source_ref if quote.provenance else None),
                reason=reason,
            ))
            continue
        if _cost_paid_after(context, quote.settlement_date):
            points.append(_masked_point(
                quote.order_date, quote.settlement_date, metric, SurfaceStatus.MISSING_METRIC,
                selected=quote.order_date == selected_order_date,
                source_ref=quote.provenance.source_ref if quote.provenance else None,
            ))
            continue
        if quote.unit_price is None and quote.real_yield is None:
            points.append(_masked_point(
                quote.order_date, quote.settlement_date, metric, SurfaceStatus.MISSING_PRICE,
                selected=quote.order_date == selected_order_date,
            ))
            continue
        exit_quote = Exit(
            scenario.exit.instrument_id, quote.order_date, quote.settlement_date,
            Side.SELL, quote.unit_price, quote.real_yield,
            quoted_side=Side.SELL, provenance=quote.provenance,
        )
        candidate = replace(scenario, exit=exit_quote)
        evaluation = evaluator.evaluate(candidate)
        points.append(_evaluation_point(
            evaluation, metric, quote.order_date, quote.settlement_date,
            rate=quote.real_yield, source_ref=(
                quote.provenance.source_ref if quote.provenance
                else "Entrada manual" if quote.unit_price is not None
                else _rate_source(evaluation)
            ),
            selected=quote.order_date == selected_order_date,
        ))
    cancelled = len(points) != len(observations)
    return SurfaceResult(
        "DATE_CURVE", metric, tuple(points), SurfaceStatus.CANCELLED if cancelled else _aggregate_status(points),
        selected_order_date, None, len(observations), evaluator.evaluated, (len(observations), 1),
        _cache_id(scenario, context, repr(("DATE_CURVE", metric, tuple(observations), selected_order_date))),
        reused_scenarios=evaluator.reused,
    )


def build_rate_date_map(
    scenario: Scenario,
    sessions: Sequence[SurfaceSession],
    rates: Sequence[Decimal | str],
    context: EvaluationContext,
    metric: SurfaceMetric,
    *,
    selected_order_date: date,
    selected_rate: Decimal | str,
    cancel_event: CancelSignal | None = None,
    evaluation_cache: MutableMapping[str, ScenarioEvaluation] | None = None,
    evaluation_budget: Any | None = None,
) -> SurfaceResult:
    dates = _sessions(sessions)
    rate_values = _rates(rates)
    _validate_rates_for_instrument(scenario, rate_values)
    cells = len(dates) * len(rate_values)
    if len(dates) > MAX_DATE_POINTS or len(rate_values) > MAX_RATE_POINTS or cells > MAX_SURFACE_CELLS:
        raise ValidationError(
            "SURFACE_LIMIT",
            f"Mapa excede limites: até {MAX_DATE_POINTS} datas, {MAX_RATE_POINTS} taxas e {MAX_SURFACE_CELLS} células.",
        )
    _require_sell_scenario(scenario)
    rate_choice = decimal_value(selected_rate, "taxa selecionada")
    by_date = {session.order_date: session for session in dates}
    if selected_order_date not in by_date or rate_choice not in rate_values:
        raise ValidationError("INVALID_SELECTION", "Coordenada selecionada precisa estar na grade do mapa.")
    if context.calendar is None:
        raise ValidationError("CALENDAR_REQUIRED", "Mapa data×taxa exige calendário identificado.")
    evaluator = _RequestEvaluator(context, evaluation_cache, evaluation_budget)
    points: list[SurfacePoint] = []
    cancelled = False
    budget_exhausted = False
    for session in dates:
        date_status = _date_status(scenario, session.order_date, session.settlement_date, context)
        for rate in rate_values:
            if _cancelled(cancel_event):
                cancelled = True
                break
            selected = session.order_date == selected_order_date and rate == rate_choice
            if date_status is not None:
                reason, source_ref = _date_issue_details(
                    date_status, scenario, session.order_date, context,
                )
                points.append(_masked_point(
                    session.order_date, session.settlement_date, metric, date_status,
                    rate=rate, selected=selected, source_ref=source_ref, reason=reason,
                ))
                continue
            if _cost_paid_after(context, session.settlement_date):
                points.append(_masked_point(
                    session.order_date, session.settlement_date, metric,
                    SurfaceStatus.MISSING_METRIC, rate=rate, selected=selected,
                ))
                continue
            exit_quote = replace(
                scenario.exit,
                order_date=session.order_date,
                settlement_date=session.settlement_date,
                unit_price=None,
                real_yield=rate,
                provenance=None,
                side=Side.SELL,
                quoted_side=Side.SELL,
                spread=None,
                spread_source=None,
            )
            candidate = replace(scenario, exit=exit_quote)
            try:
                evaluation = evaluator.evaluate(candidate)
            except SurfaceEvaluationBudgetExceeded as exc:
                points.append(_masked_point(
                    session.order_date, session.settlement_date, metric,
                    SurfaceStatus.CANCELLED, rate=rate, selected=selected,
                    reason=f"Busca cooperativamente interrompida: {exc}.",
                ))
                cancelled = True
                budget_exhausted = True
                break
            points.append(_evaluation_point(
                evaluation, metric, session.order_date, session.settlement_date,
                rate=rate, source_ref=_rate_source(evaluation), selected=selected,
            ))
        if cancelled:
            break
    if budget_exhausted:
        represented = {
            (point.order_date, point.rate) for point in points
        }
        for session in dates:
            for rate in rate_values:
                if (session.order_date, rate) not in represented:
                    points.append(_masked_point(
                        session.order_date, session.settlement_date, metric,
                        SurfaceStatus.CANCELLED, rate=rate,
                        selected=session.order_date == selected_order_date and rate == rate_choice,
                        reason="Ponto n\u00e3o avaliado: o or\u00e7amento cooperativo do pedido foi consumido.",
                    ))
        points.sort(key=lambda point: (point.order_date, point.rate if point.rate is not None else Decimal("Infinity")))
    return SurfaceResult(
        "RATE_DATE_MAP", metric, tuple(points), SurfaceStatus.CANCELLED if cancelled else _aggregate_status(points),
        selected_order_date, rate_choice, cells, evaluator.evaluated, (len(dates), len(rate_values)),
        _cache_id(scenario, context, repr(("RATE_DATE_MAP", metric, dates, rate_values, selected_order_date, rate_choice))),
        reused_scenarios=evaluator.reused,
    )


def build_decision_map(
    scenario: Scenario,
    order_dates: Sequence[date],
    prices: Sequence[Decimal | str],
    context: EvaluationContext,
    metric: SurfaceMetric,
    targets: Sequence[TargetDefinition],
    *,
    selected_order_date: date,
    selected_pu: Decimal | str,
    cancel_event: CancelSignal | None = None,
    evaluation_cache: MutableMapping[str, ScenarioEvaluation] | None = None,
) -> DecisionMapResult:
    """Grade hipotética data × PU com metas simultâneas avaliadas no caixa líquido."""
    if context.calendar is None:
        raise ValidationError("CALENDAR_REQUIRED", "Mapa de decisão exige calendário identificado.")
    if context.institution_net_override is not None:
        raise ValidationError(
            "DECISION_MAP_NET_OVERRIDE",
            "Líquido informado para uma venda não pode ser repetido nos PUs e datas hipotéticos do mapa.",
        )
    if context.custody_override is not None:
        raise ValidationError(
            "DECISION_MAP_CUSTODY_OVERRIDE",
            "Custódia informada para uma venda não pode ser repetida nos PUs e datas hipotéticos do mapa.",
        )
    orders = tuple(order_dates)
    if not orders or orders != tuple(sorted(set(orders))):
        raise ValidationError("INVALID_SURFACE_AXIS", "Datas de venda devem ser crescentes e sem duplicatas.")
    same_day = scenario.exit.settlement_date == scenario.exit.order_date
    # A liquidação observada do ponto inicial pode coincidir com a projeção de
    # outra ordem; o eixo do mapa é a data de venda, que permanece único.
    dates = tuple(SurfaceSession(
        order,
        order if same_day else (
            scenario.exit.settlement_date if order == scenario.exit.order_date
            else context.calendar.next_session(order)
        ),
    ) for order in orders)
    values = tuple(decimal_value(price, "PU da grade") for price in prices)
    if not values or any(price <= 0 for price in values) or values != tuple(sorted(set(values))):
        raise ValidationError("INVALID_SURFACE_AXIS", "PUs devem ser positivos, crescentes e sem duplicatas.")
    if len(dates) * len(values) > MAX_SURFACE_CELLS:
        raise ValidationError("SURFACE_LIMIT", f"Mapa aceita no máximo {MAX_SURFACE_CELLS} células.")
    supported = {
        TargetMetric.NET_REDEMPTION: "net_redemption",
        TargetMetric.NOMINAL_PROFIT: "nominal_profit",
        TargetMetric.NOMINAL_RETURN: "nominal_return",
        TargetMetric.ANNUALIZED_NOMINAL_RETURN: "annualized_nominal_return",
    }
    limits = tuple(targets)
    if len(limits) > len(supported) or any(item.metric not in supported for item in limits):
        raise ValidationError("INVALID_TARGET", "O mapa aceita até quatro metas de caixa e retorno nominal.")
    if len({item.metric for item in limits}) != len(limits):
        raise ValidationError("INVALID_TARGET", "Cada medida pode ter apenas uma meta mínima.")
    if scenario.exit.side is not Side.SELL:
        raise ValidationError("SURFACE_SELL_REQUIRED", "Mapa de lucro exige cenário de venda; PU Base não é resgate.")
    chosen_pu = decimal_value(selected_pu, "PU selecionado")
    if selected_order_date not in {item.order_date for item in dates} or chosen_pu not in values:
        raise ValidationError("INVALID_SELECTION", "A data e o PU selecionados precisam estar na grade.")
    evaluator = _RequestEvaluator(context, evaluation_cache)
    points: list[DecisionCell] = []
    cancelled = False
    for session in dates:
        date_status = _date_status(scenario, session.order_date, session.settlement_date, context)
        for price in values:
            if _cancelled(cancel_event):
                cancelled = True
                break
            selected = session.order_date == selected_order_date and price == chosen_pu
            if date_status is not None:
                reason, source_ref = _date_issue_details(
                    date_status, scenario, session.order_date, context,
                )
                reason = reason or "Data sem sessão ou fora do horizonte."
                points.append(DecisionCell(session.order_date, session.settlement_date, price,
                                           None, None, None, None, None, date_status,
                                           Quality.MISSING, None,
                                           unavailable_targets=tuple(item.metric.value for item in limits),
                                           reason=reason,
                                           selected=selected,
                                           metrics=_missing_metric_values(date_status, reason),
                                           source_ref=source_ref))
                continue
            if any(cost.date > session.settlement_date for cost in context.intermediate_paid_costs):
                points.append(DecisionCell(
                    session.order_date, session.settlement_date, price,
                    None, None, None, None, None, SurfaceStatus.MISSING_METRIC,
                    Quality.MISSING, None,
                    unavailable_targets=tuple(item.metric.value for item in limits),
                    reason="Há custo intermediário informado depois da venda hipotética.",
                    selected=selected,
                    metrics=_missing_metric_values(
                        SurfaceStatus.MISSING_METRIC,
                        "Há custo intermediário informado depois da venda hipotética.",
                    ),
                ))
                continue
            exit_quote = replace(
                scenario.exit, order_date=session.order_date, settlement_date=session.settlement_date,
                unit_price=price, real_yield=None, side=Side.SELL, quoted_side=Side.SELL,
                spread=None, spread_source=None, provenance=None,
            )
            evaluation = evaluator.evaluate(replace(scenario, exit=exit_quote))
            outcome = _evaluation_point(evaluation, metric, session.order_date, session.settlement_date)
            operation = evaluation.operation
            values_by_target = {name: getattr(operation, field) if operation is not None else None
                                for name, field in supported.items()}
            unavailable = tuple(item.metric.value for item in limits
                                if values_by_target[item.metric] is None)
            failed = tuple(item.metric.value for item in limits
                           if values_by_target[item.metric] is not None
                           and values_by_target[item.metric] < item.minimum_value)
            meets = None if not limits or outcome.status is not SurfaceStatus.READY or unavailable else not failed
            points.append(DecisionCell(
                session.order_date, session.settlement_date, price,
                outcome.value, operation.nominal_profit if operation else None,
                operation.nominal_return if operation else None,
                operation.net_redemption if operation else None,
                operation.annualized_nominal_return if operation else None,
                outcome.status, Quality.HYPOTHETICAL, meets, failed, unavailable,
                outcome.reason or "; ".join(evaluation.warnings) or None, selected,
                outcome.metrics,
                outcome.source_ref,
            ))
        if cancelled:
            break
    return DecisionMapResult(
        metric, limits, tuple(points),
        SurfaceStatus.CANCELLED if cancelled else _aggregate_status(points),
        selected_order_date, chosen_pu, evaluator.evaluated, (len(dates), len(values)),
        _cache_id(scenario, context, repr(("DECISION_MAP", metric, dates, values, limits,
                                           selected_order_date, chosen_pu))),
        reused_scenarios=evaluator.reused,
    )


def build_exit_frontier(
    scenario: Scenario,
    sessions: Sequence[SurfaceSession],
    context: EvaluationContext,
    target: TargetDefinition | None,
    *,
    selected_order_date: date | None = None,
    rate_bounds: tuple[Decimal | str, Decimal | str] | None = None,
    rate_tolerance: Decimal | str = "0.000000001",
    cancel_event: CancelSignal | None = None,
) -> FrontierResult:
    dates = _sessions(sessions)
    if len(dates) > MAX_DATE_POINTS:
        raise ValidationError("SURFACE_LIMIT", f"Fronteira aceita no máximo {MAX_DATE_POINTS} datas.")
    if context.calendar is None:
        raise ValidationError("CALENDAR_REQUIRED", "Fronteira por data exige calendário identificado.")
    _require_sell_scenario(scenario)
    if selected_order_date is not None and selected_order_date not in {row.order_date for row in dates}:
        raise ValidationError("INVALID_SELECTION", "Data selecionada precisa estar na fronteira.")
    if rate_bounds is not None:
        low_rate = decimal_value(rate_bounds[0], "taxa mínima")
        high_rate = decimal_value(rate_bounds[1], "taxa máxima")
        if low_rate <= -1 or high_rate <= low_rate:
            raise ValidationError("INVALID_RATE_DOMAIN", "Domínio da fronteira por taxa inválido.")
        if scenario.instrument.family.value == "RENDA_PLUS" and (
            low_rate < RENDA_MIN_YIELD or high_rate > RENDA_MAX_YIELD
        ):
            raise ValidationError("INVALID_RATE_DOMAIN", "RendA+ aceita taxa entre −95% e 1.000% a.a.")
    else:
        low_rate = high_rate = None
    if target is None:
        selected_eval = None
        if selected_order_date is not None:
            session = next(row for row in dates if row.order_date == selected_order_date)
            if _date_status(scenario, session.order_date, session.settlement_date, context) is None:
                candidate = replace(scenario, exit=replace(
                    scenario.exit, order_date=session.order_date,
                    settlement_date=session.settlement_date,
                ))
                selected_eval = evaluate_scenario(candidate, context)
        return FrontierResult("SELECTED_SCENARIO", None, (), selected_eval, SurfaceStatus.NO_TARGET, 1 if selected_eval else 0,
                             ("Meta não declarada; retornado apenas o cenário selecionado, sem alvo padrão.",))
    points: list[FrontierPoint] = []
    evaluations = 0
    overall_status = SurfaceStatus.READY
    for session in dates:
        if _cancelled(cancel_event):
            overall_status = SurfaceStatus.CANCELLED
            break
        status = _date_status(scenario, session.order_date, session.settlement_date, context)
        if status is not None:
            reason, source_ref = _date_issue_details(status, scenario, session.order_date, context)
            points.append(FrontierPoint(
                session.order_date, session.settlement_date, None, None, status,
                source_ref, reason or "Data sem sessão ou fora do horizonte.",
                session.order_date == selected_order_date,
            ))
            continue
        exit_quote = replace(scenario.exit, order_date=session.order_date,
                             settlement_date=session.settlement_date, provenance=None)
        candidate = replace(scenario, exit=exit_quote)
        date_target = replace(target, target_date=session.settlement_date) if target.metric.value == "REAL_RETURN" else target
        limit: TargetSolution = solve_minimum_exit_pu(candidate, date_target, context)
        evaluations += limit.evaluations
        if limit.status is not TargetStatus.SOLVED or limit.pu is None:
            point_status = _target_status(limit.status)
            points.append(FrontierPoint(session.order_date, session.settlement_date, None, None,
                                        point_status, None, limit.reason, session.order_date == selected_order_date))
            continue
        maximum_yield = None
        reason = limit.reason
        if low_rate is not None and high_rate is not None:
            rate_result: RateSolution = solve_rate_for_pu_limit(
                candidate, "EXIT", limit.pu, context,
                minimum_yield=low_rate, maximum_yield=high_rate,
                tolerance=rate_tolerance,
            )
            evaluations += rate_result.evaluations
            if rate_result.status is TargetStatus.SOLVED:
                maximum_yield = rate_result.rate
            else:
                point_status = _target_status(rate_result.status)
                points.append(FrontierPoint(session.order_date, session.settlement_date, limit.pu, None,
                                            point_status, None, rate_result.reason, session.order_date == selected_order_date))
                continue
        points.append(FrontierPoint(session.order_date, session.settlement_date, limit.pu,
                                    maximum_yield, SurfaceStatus.READY,
                                    _index_source(candidate, context, session.settlement_date) if maximum_yield is not None
                                    else "Cálculo direto do cenário com PU e políticas selecionados",
                                    reason, session.order_date == selected_order_date))
    if overall_status is SurfaceStatus.READY:
        statuses = [point.status for point in points]
        if any(status not in (SurfaceStatus.READY, SurfaceStatus.NON_SESSION, SurfaceStatus.OUTSIDE_HORIZON) for status in statuses):
            overall_status = SurfaceStatus.METRIC_UNAVAILABLE
    return FrontierResult("TARGET_FRONTIER", target, tuple(points), None, overall_status, evaluations)


@dataclass(frozen=True, slots=True)
class ConstraintFrontierPoint:
    order_date: date
    settlement_date: date
    minimum_exit_pu: Decimal | None
    maximum_exit_pu: Decimal | None
    candidate_pu: Decimal | None
    maximum_exit_yield: Decimal | None
    status: SurfaceStatus
    quality: tuple[str, ...]
    limiting_minimum_ids: tuple[str, ...]
    limiting_maximum_ids: tuple[str, ...]
    selected: bool
    reason: str | None
    constraint_limit: Any | None = None


@dataclass(frozen=True, slots=True)
class ConstraintFrontierResult:
    mode: str
    constraints_fingerprint: str
    points: tuple[ConstraintFrontierPoint, ...]
    status: SurfaceStatus
    requested_sessions: tuple[SurfaceSession, ...]
    sessions_examined: int
    evaluations: int
    domain_scope: str = "explicit_candidate_sessions_only"
    proof_domain: None = None


def build_constraint_exit_frontier(
    scenario: Scenario,
    sessions: Sequence[SurfaceSession],
    context: EvaluationContext,
    constraints: Any,
    *,
    selected_order_date: date | None = None,
    rate_bounds: tuple[Decimal | str, Decimal | str] | None = None,
    rate_tolerance: Decimal | str = "0.000000001",
    tick: Decimal | str = "0.01",
    maximum_pu: Decimal | str = "1000000000",
    cancel_event: CancelSignal | None = None,
) -> ConstraintFrontierResult:
    """Build a discrete date frontier by solving all supplied constraints jointly."""
    from .constraints import (
        CombinedLimitStatus, ConstraintSetDefinition, solve_combined_exit_constraints,
    )

    dates = _sessions(sessions)
    if len(dates) > MAX_CONSTRAINT_FRONTIER_DATES:
        raise ValidationError(
            "SURFACE_LIMIT",
            f"Fronteira combinada aceita no máximo {MAX_CONSTRAINT_FRONTIER_DATES} datas explícitas por avaliação.",
        )
    if context.calendar is None:
        raise ValidationError("CALENDAR_REQUIRED", "Fronteira combinada por data exige calendário identificado.")
    _require_sell_scenario(scenario)
    if not isinstance(constraints, ConstraintSetDefinition):
        raise ValidationError("INVALID_CONSTRAINTS", "Fronteira combinada exige ConstraintSetDefinition validado.")
    if selected_order_date is not None and selected_order_date not in {row.order_date for row in dates}:
        raise ValidationError("INVALID_SELECTION", "Data selecionada precisa estar na fronteira.")
    if rate_bounds is not None:
        lower, upper = (decimal_value(item, "limite de taxa") for item in rate_bounds)
        if lower <= -1 or upper <= lower:
            raise ValidationError("INVALID_RATE_DOMAIN", "Domínio da fronteira por taxa inválido.")

    if not constraints.criteria:
        return ConstraintFrontierResult(
            "CONSTRAINT_FRONTIER", constraints.fingerprint, (), SurfaceStatus.NO_TARGET,
            dates, 0, 0,
        )

    status_by_limit = {
        CombinedLimitStatus.SOLVED: SurfaceStatus.READY,
        CombinedLimitStatus.INFEASIBLE: SurfaceStatus.UNATTAINABLE,
        CombinedLimitStatus.UNKNOWN: SurfaceStatus.MISSING_METRIC,
        CombinedLimitStatus.AMBIGUOUS: SurfaceStatus.AMBIGUOUS_ROOT,
        CombinedLimitStatus.BLOCKED_POLICY: SurfaceStatus.BLOCKED_POLICY,
        CombinedLimitStatus.VERIFICATION_FAILED: SurfaceStatus.VERIFICATION_FAILED,
        CombinedLimitStatus.NO_CONSTRAINTS: SurfaceStatus.NO_TARGET,
        CombinedLimitStatus.NO_FINANCIAL_BOUND: SurfaceStatus.NO_TARGET,
    }
    points: list[ConstraintFrontierPoint] = []
    evaluations = 0
    overall_status = SurfaceStatus.READY
    for session in dates:
        if _cancelled(cancel_event):
            overall_status = SurfaceStatus.CANCELLED
            break
        date_status = _date_status(scenario, session.order_date, session.settlement_date, context)
        selected = session.order_date == selected_order_date
        if date_status is not None:
            reason, source_ref = _date_issue_details(
                date_status, scenario, session.order_date, context,
            )
            reason = reason or "Data sem sessão ou fora do horizonte."
            if source_ref:
                reason = f"{reason} Fonte: {source_ref} (seção 9)."
            points.append(ConstraintFrontierPoint(
                session.order_date, session.settlement_date, None, None, None, None,
                date_status,
                (Quality.MISSING.value,) if date_status is SurfaceStatus.EVENT_COVERAGE_UNCERTIFIED else (),
                (), (), selected, reason,
            ))
            continue
        candidate = replace(
            scenario,
            exit=replace(
                scenario.exit, order_date=session.order_date,
                settlement_date=session.settlement_date,
            ),
        )
        limit = solve_combined_exit_constraints(
            candidate, constraints, context, tick=tick, maximum_pu=maximum_pu,
            rate_bounds=rate_bounds, rate_tolerance=rate_tolerance,
        )
        evaluations += limit.evaluations
        point_status = status_by_limit[limit.status]
        if point_status not in (SurfaceStatus.READY, SurfaceStatus.NON_SESSION, SurfaceStatus.OUTSIDE_HORIZON):
            overall_status = SurfaceStatus.METRIC_UNAVAILABLE
        quality = tuple(sorted({
            item.quality for item in limit.candidate_evaluation.criteria
            if item.quality is not None
        })) if limit.candidate_evaluation is not None else ()
        points.append(ConstraintFrontierPoint(
            session.order_date, session.settlement_date,
            limit.minimum_exit_pu, limit.maximum_exit_pu, limit.candidate_pu,
            limit.maximum_exit_yield, point_status, quality,
            limit.limiting_minimum_ids, limit.limiting_maximum_ids,
            selected, limit.reason, limit,
        ))

    if overall_status is SurfaceStatus.READY and len(points) < len(dates):
        overall_status = SurfaceStatus.CANCELLED
    return ConstraintFrontierResult(
        "CONSTRAINT_FRONTIER", constraints.fingerprint, tuple(points), overall_status,
        dates, len(points), evaluations,
    )


def _evaluation_point(
    evaluation: ScenarioEvaluation,
    metric: SurfaceMetric,
    order_date: date,
    settlement_date: date,
    *,
    rate: Decimal | None = None,
    source_ref: str | None = None,
    selected: bool = False,
) -> SurfacePoint:
    operation: OperationResult | None = evaluation.operation
    value = None if operation is None else getattr(operation, metric.value)
    if operation is None:
        status = _evaluation_status(evaluation.status)
        quality = Quality.MISSING
    elif operation.status == "BLOCKED_POLICY":
        status, quality = SurfaceStatus.BLOCKED_POLICY, operation.quality
    elif value is None:
        status, quality = SurfaceStatus.MISSING_METRIC, operation.quality
    else:
        status, quality = SurfaceStatus.READY, operation.quality
    unit = _metric_unit(metric)
    metrics = _metric_values(evaluation)
    return SurfacePoint(
        order_date, settlement_date, rate, evaluation.exit_pu, value, metric, unit,
        status, quality, source_ref, "; ".join(evaluation.warnings) or None, selected, metrics,
        evaluation=evaluation,
    )


def _masked_point(order_date: date, settlement_date: date, metric: SurfaceMetric,
                  status: SurfaceStatus, *, rate: Decimal | None = None,
                  selected: bool = False, source_ref: str | None = None,
                  reason: str | None = None) -> SurfacePoint:
    unit = _metric_unit(metric)
    point_reason = reason or status.value
    return SurfacePoint(order_date, settlement_date, rate, None, None, metric, unit,
                        status, Quality.MISSING, source_ref, point_reason, selected,
                        _missing_metric_values(status, point_reason))


def _metric_values(evaluation: ScenarioEvaluation) -> tuple[SurfaceMetricValue, ...]:
    operation = evaluation.operation
    if operation is None:
        status = _evaluation_status(evaluation.status)
        reason = "; ".join(evaluation.warnings) or status.value
        return _missing_metric_values(status, reason)
    if operation.status == "BLOCKED_POLICY":
        return _missing_metric_values(SurfaceStatus.BLOCKED_POLICY, "; ".join(operation.warnings) or "BLOCKED_POLICY")
    missing_reason = "; ".join(operation.warnings) or "Métrica indisponível com os dados fornecidos."
    values: list[SurfaceMetricValue] = []
    for metric in SurfaceMetric:
        value = getattr(operation, metric.value)
        values.append(SurfaceMetricValue(
            metric, value, _metric_unit(metric),
            SurfaceStatus.READY if value is not None else SurfaceStatus.MISSING_METRIC,
            operation.quality if value is not None else Quality.MISSING,
            None if value is not None else missing_reason,
        ))
    return tuple(values)


def _missing_metric_values(status: SurfaceStatus, reason: str) -> tuple[SurfaceMetricValue, ...]:
    return tuple(
        SurfaceMetricValue(metric, None, _metric_unit(metric), status, Quality.MISSING, reason)
        for metric in SurfaceMetric
    )


def _cost_paid_after(context: EvaluationContext, settlement_date: date) -> bool:
    return any(cost.date > settlement_date for cost in context.intermediate_paid_costs)


def _date_status(scenario: Scenario, order_date: date, settlement_date: date,
                 context: EvaluationContext) -> SurfaceStatus | None:
    if context.calendar is None:
        return SurfaceStatus.MISSING_CALENDAR
    if not context.calendar.is_session(order_date):
        return SurfaceStatus.NON_SESSION
    if not context.calendar.is_session(settlement_date):
        return SurfaceStatus.NON_SESSION
    if order_date <= scenario.entry.order_date or settlement_date <= scenario.entry.settlement_date:
        return SurfaceStatus.OUTSIDE_HORIZON
    if scenario.instrument.maturity_date <= order_date:
        return SurfaceStatus.OUTSIDE_HORIZON
    if scenario.instrument.first_income_date is not None and scenario.instrument.first_income_date <= order_date:
        return SurfaceStatus.OUTSIDE_HORIZON
    if event_coverage_for_order_date(scenario.instrument, order_date, context.calendar) is not None:
        return SurfaceStatus.EVENT_COVERAGE_UNCERTIFIED
    return None


def _date_issue_details(
    status: SurfaceStatus,
    scenario: Scenario,
    order_date: date,
    context: EvaluationContext,
) -> tuple[str | None, str | None]:
    if status is SurfaceStatus.EVENT_COVERAGE_UNCERTIFIED and context.calendar is not None:
        coverage = event_coverage_for_order_date(scenario.instrument, order_date, context.calendar)
        if coverage is not None:
            return coverage.reason, coverage.source_ref
    return None, None


def _rates(rates: Sequence[Decimal | str]) -> tuple[Decimal, ...]:
    if not rates:
        raise ValidationError("INVALID_SURFACE_AXIS", "Curva exige ao menos um ponto de taxa.")
    values = tuple(decimal_value(rate, "taxa da superfície") for rate in rates)
    if any(value <= -1 for value in values) or values != tuple(sorted(set(values))):
        raise ValidationError("INVALID_SURFACE_AXIS", "Taxas devem ser crescentes, maiores que −100% e sem duplicatas.")
    return values


def _validate_rates_for_instrument(scenario: Scenario, rates: Sequence[Decimal]) -> None:
    if scenario.instrument.family.value == "RENDA_PLUS" and any(
        rate < RENDA_MIN_YIELD or rate > RENDA_MAX_YIELD for rate in rates
    ):
        raise ValidationError("INVALID_YIELD", "RendA+ aceita taxa entre −95% e 1.000% a.a.")


def _metric_unit(metric: SurfaceMetric) -> str:
    if metric in (SurfaceMetric.GROSS_REDEMPTION, SurfaceMetric.NET_REDEMPTION,
                  SurfaceMetric.NOMINAL_PROFIT, SurfaceMetric.REAL_PROFIT):
        return "BRL"
    if metric is SurfaceMetric.ANNUALIZED_NOMINAL_RETURN:
        return "ratio_per_year"
    return "ratio"


def _check_dates(observations: Sequence[ExitObservation]) -> None:
    if not observations:
        raise ValidationError("INVALID_SURFACE_AXIS", "Curva exige ao menos uma data.")
    orders = [row.order_date for row in observations]
    settlements = [row.settlement_date for row in observations]
    if len(orders) != len(set(orders)) or orders != sorted(orders) or settlements != sorted(settlements):
        raise ValidationError("INVALID_SURFACE_AXIS", "Datas devem ser crescentes e sem duplicatas.")


def _sessions(sessions: Sequence[SurfaceSession]) -> tuple[SurfaceSession, ...]:
    if not sessions:
        raise ValidationError("INVALID_SURFACE_AXIS", "Superfície exige ao menos uma data.")
    values = tuple(sessions)
    orders = [session.order_date for session in values]
    settlements = [session.settlement_date for session in values]
    if orders != sorted(set(orders)) or settlements != sorted(set(settlements)):
        raise ValidationError("INVALID_SURFACE_AXIS", "Datas de ordem e liquidação devem crescer sem duplicatas.")
    return values


def _require_sell_scenario(scenario: Scenario) -> None:
    if scenario.exit.side is not Side.SELL or scenario.exit.quoted_side is not Side.SELL:
        raise ValidationError("SURFACE_SELL_REQUIRED", "Curvas de resultado exigem cenário SELL; PU Base não é resgate.")


def _evaluation_status(status: str) -> SurfaceStatus:
    mapping = {
        "MISSING_INDEX": SurfaceStatus.MISSING_INDEX,
        "MISSING_CALENDAR": SurfaceStatus.MISSING_CALENDAR,
        "MISSING_PRICE": SurfaceStatus.MISSING_PRICE,
        "BLOCKED_POLICY": SurfaceStatus.BLOCKED_POLICY,
        "OBSERVATION_AFTER_AS_OF": SurfaceStatus.MISSING_PRICE,
        "PUBLICATION_DATE_UNKNOWN": SurfaceStatus.MISSING_PRICE,
    }
    return mapping.get(status, SurfaceStatus.MISSING_PRICE)


def _target_status(status: TargetStatus) -> SurfaceStatus:
    mapping = {
        TargetStatus.UNATTAINABLE: SurfaceStatus.UNATTAINABLE,
        TargetStatus.NO_ROOT: SurfaceStatus.NO_ROOT,
        TargetStatus.ALL_DOMAIN: SurfaceStatus.ALL_DOMAIN,
        TargetStatus.AMBIGUOUS_ROOT: SurfaceStatus.AMBIGUOUS_ROOT,
        TargetStatus.VERIFICATION_FAILED: SurfaceStatus.VERIFICATION_FAILED,
        TargetStatus.METRIC_UNAVAILABLE: SurfaceStatus.METRIC_UNAVAILABLE,
        TargetStatus.BLOCKED_POLICY: SurfaceStatus.BLOCKED_POLICY,
        TargetStatus.SOLVED: SurfaceStatus.READY,
    }
    return mapping[status]


def _aggregate_status(points: Sequence[SurfacePoint | DecisionCell]) -> SurfaceStatus:
    if not points:
        return SurfaceStatus.MISSING_METRIC
    if all(point.status is SurfaceStatus.READY for point in points):
        return SurfaceStatus.READY
    if any(point.status is SurfaceStatus.READY for point in points):
        return SurfaceStatus.METRIC_UNAVAILABLE
    return points[0].status


def _cancelled(signal: CancelSignal | None) -> bool:
    return signal is not None and signal.is_set()


def _rate_source(evaluation: ScenarioEvaluation) -> str | None:
    for step in evaluation.steps:
        if "PU teórico de saída" == step.name:
            return step.source_ref
    return None


def _index_source(scenario: Scenario, context: EvaluationContext, settlement_date: date) -> str | None:
    kind = IndexKind.VNA if scenario.instrument.family.value == "IPCA_PRINCIPAL" else IndexKind.VNI
    matches = [anchor for anchor in context.index_anchors
               if anchor.kind is kind and anchor.reference_date == settlement_date]
    return matches[0].source_ref if len(matches) == 1 else None


def _cache_id(scenario: Scenario, context: EvaluationContext, request_signature: str) -> str:
    raw = _cache_identity(scenario, context) + "|" + request_signature
    return sha256(raw.encode("utf-8")).hexdigest()


def _cache_identity(scenario: Scenario, context: EvaluationContext) -> str:
    calendar = context.calendar
    calendar_signature = (
        getattr(calendar, "calendar_id", None),
        repr(getattr(calendar, "knowledge_date", None)),
        repr(getattr(calendar, "verified_until", None)),
        repr(getattr(calendar, "overlay", None)),
    )
    context_parts = (
        repr(calendar_signature),
        repr(context.tax_cost_basis),
        repr(context.index_anchors), repr(context.entry_expense_paid),
        repr(context.exit_expense), repr(context.custody_override),
        repr(context.institution_net_override), repr(context.intermediate_paid_costs),
        repr(context.index_levels), repr(context.institution_release_date),
    )
    return "|".join((
        repr(scenario), *context_parts, PRINCIPAL_VERSION, RENDA_PLUS_VERSION,
        IR_POLICY_ID, IOF_POLICY_ID, PRINCIPAL_CUSTODY_POLICY_ID, RENDA_CUSTODY_POLICY_ID,
    ))
