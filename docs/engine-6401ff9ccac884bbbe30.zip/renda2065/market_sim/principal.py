"""Precificação auditável do IPCA+ Principal (NTN-B Principal, sem cupom)."""
from __future__ import annotations

from dataclasses import dataclass
from datetime import date
from decimal import Decimal, ROUND_DOWN, localcontext
from typing import Protocol

from .contracts import Side, ValidationError, decimal_value
from .provenance import Provenance, Quality
from .market_data import SELL_D0_EFFECTIVE_DATE

D = Decimal
PRECISION = 40
PRICE_PRECISION = 60
PRICING_VERSION = "IPCA_PRINCIPAL_DU252_TRUNCATION_v1"


class BusinessCalendar(Protocol):
    calendar_id: str

    def business_days(self, start: date, end: date) -> int: ...
    def next_session(self, day: date, include: bool = False) -> date: ...


@dataclass(frozen=True, slots=True)
class VnaProjection:
    previous_vna: Decimal
    previous_reference_date: date
    settlement_date: date
    monthly_ipca: Decimal
    exponent_numerator_days: int
    exponent_denominator_days: int
    continuous_vna: Decimal
    published_vna: Decimal
    quality: Quality = Quality.HYPOTHETICAL
    method_version: str = PRICING_VERSION


@dataclass(frozen=True, slots=True)
class PrincipalPrice:
    vna: Decimal
    annual_real_yield: Decimal
    business_days: int
    continuous_quotation_percent: Decimal
    published_quotation_percent: Decimal
    continuous_pu: Decimal
    pu_after_quotation_truncation: Decimal
    pu_truncated_4dp: Decimal
    published_pu: Decimal
    method_version: str = PRICING_VERSION


@dataclass(frozen=True, slots=True)
class PrincipalMarketQuote:
    instrument_id: str
    observation_date: date
    settlement_date: date
    side: Side
    pu: Decimal
    real_yield: Decimal | None
    provenance: Provenance
    source_timing: str = "TESOURO_TRANSPARENTE_MORNING"

    def __post_init__(self) -> None:
        pu = decimal_value(self.pu, "PU observado")
        if pu <= 0:
            raise ValidationError("INVALID_PRICE", "PU observado precisa ser positivo.")
        object.__setattr__(self, "pu", pu)
        if self.real_yield is not None:
            rate = decimal_value(self.real_yield, "taxa observada")
            if rate <= -1:
                raise ValidationError("INVALID_YIELD", "Taxa real precisa ser maior que −100%.")
            object.__setattr__(self, "real_yield", rate)
        if self.side not in (Side.BUY, Side.SELL, Side.BASE):
            raise ValidationError("WRONG_MARKET_SIDE", "Lado observado deve ser BUY, SELL ou BASE.")
        if not self.instrument_id.strip():
            raise ValidationError("INVALID_INSTRUMENT", "Cotação precisa identificar o título.")

    @property
    def is_executable_sale_price(self) -> bool:
        return self.side is Side.SELL

    def validate_timing(self, calendar: BusinessCalendar) -> None:
        """Confere liquida\u00e7\u00e3o matinal conforme a regra B3 vigente."""
        if self.source_timing != "TESOURO_TRANSPARENTE_MORNING":
            return
        if self.side is Side.BASE or (
            self.side is Side.SELL and self.observation_date >= SELL_D0_EFFECTIVE_DATE
        ):
            expected = self.observation_date
        else:
            expected = calendar.next_session(self.observation_date)
        if self.settlement_date != expected:
            raise ValidationError(
                "QUOTE_SETTLEMENT_MISMATCH",
                f"{self.side.value} da manh\u00e3 exige liquida\u00e7\u00e3o {expected.isoformat()}.",
            )


@dataclass(frozen=True, slots=True)
class PriceComparison:
    observed_pu: Decimal
    theoretical_pu: Decimal
    difference: Decimal
    tolerance: Decimal
    within_tolerance: bool
    observed_is_authoritative: bool = True


def _truncate(value: Decimal, places: int) -> Decimal:
    quantum = D(1).scaleb(-places)
    return value.quantize(quantum, rounding=ROUND_DOWN)


def _month_reference(day: date) -> date:
    return date(day.year, day.month, 15)


def _next_month_reference(day: date) -> date:
    if day.month == 12:
        return date(day.year + 1, 1, 15)
    return date(day.year, day.month + 1, 15)


def project_vna(
    previous_vna: Decimal | str | int,
    monthly_ipca: Decimal | str | int,
    settlement_date: date,
    previous_reference_date: date | None = None,
) -> VnaProjection:
    """Projeta o VNA para liquidação a partir do IPCA mensal hipotético.

    A convenção do manual usa fração de dias corridos entre o dia 15 anterior
    e a liquidação, dividida pelos dias do mês de referência.
    """
    vna = decimal_value(previous_vna, "VNA")
    ipca = decimal_value(monthly_ipca, "IPCA mensal")
    if vna <= 0:
        raise ValidationError("INVALID_VNA", "VNA precisa ser positivo.")
    if ipca <= -1:
        raise ValidationError("INVALID_IPCA", "IPCA projetado precisa ser maior que −100%.")
    default_reference = _month_reference(settlement_date)
    if default_reference >= settlement_date:
        default_reference = (
            date(settlement_date.year - 1, 12, 15) if settlement_date.month == 1
            else date(settlement_date.year, settlement_date.month - 1, 15)
        )
    previous_ref = previous_reference_date or default_reference
    if previous_ref.day != 15 or previous_ref >= settlement_date:
        raise ValidationError("INVALID_VNA_REFERENCE", "A referência VNA deve ser o dia 15 anterior à liquidação.")
    next_ref = _next_month_reference(previous_ref)
    numerator = (settlement_date - previous_ref).days
    denominator = (next_ref - previous_ref).days
    if not 0 <= numerator <= denominator:
        raise ValidationError("INVALID_VNA_REFERENCE", "Liquidação fora do mês de projeção do IPCA informado.")
    with localcontext() as ctx:
        ctx.prec = PRECISION
        exponent = D(numerator) / D(denominator)
        continuous = vna * ((D(1) + ipca) ** exponent)
        published = _truncate(continuous, 6)
    return VnaProjection(
        previous_vna=vna,
        previous_reference_date=previous_ref,
        settlement_date=settlement_date,
        monthly_ipca=ipca,
        exponent_numerator_days=numerator,
        exponent_denominator_days=denominator,
        continuous_vna=continuous,
        published_vna=published,
    )


def business_days_to_maturity(
    settlement_date: date,
    maturity_date: date,
    calendar: BusinessCalendar,
) -> int:
    if maturity_date <= settlement_date:
        raise ValidationError("OUTSIDE_HORIZON", "Vencimento deve ser posterior à liquidação.")
    du = calendar.business_days(settlement_date, maturity_date)
    if du <= 0:
        raise ValidationError("INVALID_CALENDAR", "Calendário não produziu DU positivo.")
    return du


def price_principal(
    vna: Decimal | str | int,
    annual_real_yield: Decimal | str | int,
    business_days: int,
) -> PrincipalPrice:
    """Desconta o fluxo único do Principal com DU/252 e gera perfil publicado."""
    value = decimal_value(vna, "VNA")
    rate = decimal_value(annual_real_yield, "taxa real")
    if value <= 0:
        raise ValidationError("INVALID_VNA", "VNA precisa ser positivo.")
    if rate <= -1:
        raise ValidationError("INVALID_YIELD", "Taxa real precisa ser maior que −100%.")
    if isinstance(business_days, bool) or not isinstance(business_days, int) or business_days < 0:
        raise ValidationError("INVALID_DU", "DU precisa ser inteiro não negativo.")
    with localcontext() as ctx:
        ctx.prec = PRICE_PRECISION
        quotation = D(100) / ((D(1) + rate) ** (D(business_days) / D(252)))
        published_quotation = _truncate(quotation, 4)
        continuous_pu = value * quotation / D(100)
        rounded_quotation_pu = value * published_quotation / D(100)
        working_pu = _truncate(rounded_quotation_pu, 4)
        published_pu = _truncate(working_pu, 2)
    return PrincipalPrice(
        vna=value,
        annual_real_yield=rate,
        business_days=business_days,
        continuous_quotation_percent=quotation,
        published_quotation_percent=published_quotation,
        continuous_pu=continuous_pu,
        pu_after_quotation_truncation=rounded_quotation_pu,
        pu_truncated_4dp=working_pu,
        published_pu=published_pu,
    )


def compare_observed_price(
    observed: PrincipalMarketQuote,
    theoretical: PrincipalPrice,
    tolerance: Decimal | str = "0.01",
) -> PriceComparison:
    tol = decimal_value(tolerance, "tolerância")
    if tol < 0:
        raise ValidationError("INVALID_TOLERANCE", "Tolerância não pode ser negativa.")
    difference = observed.pu - theoretical.published_pu
    return PriceComparison(
        observed_pu=observed.pu,
        theoretical_pu=theoretical.published_pu,
        difference=difference,
        tolerance=tol,
        within_tolerance=abs(difference) <= tol,
        observed_is_authoritative=True,
    )
