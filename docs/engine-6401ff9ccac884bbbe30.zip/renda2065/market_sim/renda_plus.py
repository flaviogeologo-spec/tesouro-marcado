"""Precificação RendA+ durante acumulação, separada do motor legado."""
from __future__ import annotations

from dataclasses import dataclass
from datetime import date, timedelta
from decimal import Decimal, ROUND_DOWN, ROUND_HALF_UP, localcontext
from enum import StrEnum
from functools import lru_cache
from typing import Protocol, Sequence

from ..calendar_rules import CALENDAR_START, CALENDAR_END
from .contracts import ValidationError, decimal_value
from .provenance import Quality

D = Decimal
PRECISION = 50
PRICING_VERSION = "RENDA_PLUS_240_DU252_DECIMAL_v1"
MIN_YIELD = D("-0.95")
MAX_YIELD = D("10")
MONTHLY_WEIGHTS = (D("0.00416666"),) * 239 + (D("0.00416826"),)
# All 240 monthly payments, including the last one, must fit the calendar.
MIN_CONVERSION_YEAR = CALENDAR_START.year
MAX_CONVERSION_YEAR = CALENDAR_END.year - (len(MONTHLY_WEIGHTS) - 1) // 12
SUPPORTED_CONVERSION_YEARS = frozenset(range(MIN_CONVERSION_YEAR, MAX_CONVERSION_YEAR + 1))


class Calendar(Protocol):
    calendar_id: str

    def roll_payment(self, day: date) -> date: ...
    def days_to_payments(self, valuation: date, payments: Sequence[date]): ...
    def next_session(self, day: date, include: bool = False) -> date: ...
    def is_session(self, day: date) -> bool: ...


@dataclass(frozen=True, slots=True)
class RendaPlusSeries:
    series_id: str
    conversion_year: int
    conversion_date: date
    first_income_date: date
    payment_dates: tuple[date, ...]
    weights: tuple[Decimal, ...]
    source_ref: str
    supported: bool = True

    def __post_init__(self) -> None:
        if len(self.payment_dates) != 240 or len(self.weights) != 240:
            raise ValidationError("INVALID_SERIES", "RendA+ exige exatamente 240 pagamentos e pesos.")
        if sum(self.weights, D(0)) != D(1):
            raise ValidationError("INVALID_SERIES", "Os pesos das 240 parcelas precisam somar exatamente 1.")
        if self.payment_dates[0] != self.first_income_date:
            raise ValidationError("INVALID_SERIES", "Primeira parcela não coincide com o cronograma.")
        if any(a >= b for a, b in zip(self.payment_dates, self.payment_dates[1:])):
            raise ValidationError("INVALID_SERIES", "Datas das parcelas devem ser crescentes e distintas.")
        if self.first_income_date < self.conversion_date:
            raise ValidationError("INVALID_SERIES", "Primeira parcela não pode anteceder a conversão.")
        if not self.source_ref.strip():
            raise ValidationError("INVALID_SERIES", "Série precisa indicar a fonte dos seus parâmetros.")

    @property
    def last_income_date(self) -> date:
        return self.payment_dates[-1]

    @classmethod
    @lru_cache(maxsize=16)
    def for_conversion_year(cls, year: int) -> "RendaPlusSeries":
        if type(year) is not int:
            raise ValidationError("INVALID_SERIES", "Ano de início da renda precisa ser inteiro.")
        if year not in SUPPORTED_CONVERSION_YEARS:
            raise ValidationError(
                "UNSUPPORTED_SERIES",
                f"Ano de início da renda fora de {MIN_CONVERSION_YEAR} a {MAX_CONVERSION_YEAR}; "
                f"as 240 parcelas precisam caber no calendário até {CALENDAR_END.year}.",
            )
        dates = tuple(date(year + i // 12, i % 12 + 1, 15) for i in range(240))
        return cls(
            series_id=f"RENDA_PLUS_{year}",
            conversion_year=year,
            conversion_date=date(year, 1, 15),
            first_income_date=dates[0],
            payment_dates=dates,
            weights=MONTHLY_WEIGHTS,
            source_ref=("Manual oficial RendA+; série 2065 preservada do motor legado."
                        if year in (2030, 2065) else
                        "Cronograma hipotético anual de 240 parcelas pela metodologia do Manual oficial RendA+; "
                        "não presume título ofertado no mercado."),
        )


@dataclass(frozen=True, slots=True)
class RendaPlusPrice:
    series_id: str
    valuation_date: date | None
    vni: Decimal
    annual_real_yield: Decimal
    business_days: tuple[int, ...]
    continuous_quotation_percent: Decimal
    published_quotation_percent: Decimal
    continuous_pu: Decimal
    published_pu: Decimal
    quality: Quality
    calendar_id: str | None
    method_version: str = PRICING_VERSION


class SaleEligibilityStatus(StrEnum):
    LOCKED = "LOCKED"
    NOT_SESSION = "NOT_SESSION"
    ELIGIBLE = "ELIGIBLE"
    AFTER_FIRST_INCOME = "AFTER_FIRST_INCOME"


@dataclass(frozen=True, slots=True)
class SaleEligibility:
    status: SaleEligibilityStatus
    earliest_eligible_session: date
    proposed_trade_date: date
    lock_end: date
    reason: str | None = None


def payment_dates(conversion_year: int) -> tuple[date, ...]:
    if conversion_year < 1 or conversion_year > 9999 - 20:
        raise ValidationError("INVALID_SERIES", "Ano de conversão fora do domínio de datas.")
    return tuple(date(conversion_year + i // 12, i % 12 + 1, 15) for i in range(240))


def _trunc(value: Decimal, places: int) -> Decimal:
    return value.quantize(D(1).scaleb(-places), rounding=ROUND_DOWN)


def projected_continuous_pu(series, vni, rate, business_days):
    """Fast continuous value for the historical projection's ordered future flows."""
    with localcontext() as ctx:
        ctx.prec = PRECISION
        log_rate = -(1 + rate).ln()
        factor = D(0)
        previous = None
        multipliers = {}
        for day, weight in zip(business_days, series.weights):
            # Exact integer representation of TRUNC14(DU/252).
            exponent = int(day) * 10**14 // 252
            if previous is None:
                discount = (log_rate * D(exponent).scaleb(-14)).exp()
            else:
                gap = exponent - previous
                multiplier = multipliers.get(gap)
                if multiplier is None:
                    multiplier = (log_rate * D(gap).scaleb(-14)).exp()
                    multipliers[gap] = multiplier
                discount *= multiplier
            factor += weight * discount
            previous = exponent
        return vni * factor


def price_renda_plus_from_du(
    series: RendaPlusSeries,
    vni: Decimal | str | int,
    annual_real_yield: Decimal | str | int,
    business_days: Sequence[int],
    quality: Quality = Quality.HYPOTHETICAL,
) -> RendaPlusPrice:
    """Precifica somente antes da primeira parcela; não representa recebimentos."""
    vni_value = decimal_value(vni, "VNI")
    rate = decimal_value(annual_real_yield, "taxa real")
    if not series.supported:
        raise ValidationError("UNSUPPORTED_SERIES", "Parâmetros da série não foram validados.")
    if vni_value <= 0:
        raise ValidationError("INVALID_VNI", "VNI precisa ser positivo.")
    if not MIN_YIELD <= rate <= MAX_YIELD:
        raise ValidationError("INVALID_YIELD", "Taxa real fora do domínio de −95% a 1.000% a.a.")
    if len(business_days) != 240:
        raise ValidationError("INVALID_DU", "São necessários 240 valores DU, um para cada parcela futura.")
    du = tuple(business_days)
    if any(isinstance(value, bool) or not isinstance(value, int) or value < 0 for value in du):
        raise ValidationError("INVALID_DU", "DU precisa conter inteiros não negativos.")
    with localcontext() as ctx:
        ctx.prec = PRECISION
        pv_percent: list[Decimal] = []
        continuous_factor = D(0)
        negative_log_rate = -(D(1) + rate).ln()
        for weight, days in zip(series.weights, du):
            exponent = _trunc(D(days) / D(252), 14)
            discount = (negative_log_rate * exponent).exp()
            contribution = weight * discount
            continuous_factor += contribution
            # Perfil publicado legado: arredonda cada parcela monetária half-up
            # a 10 casas, soma, trunca cotação a 4 e PU a 2.
            pv_percent.append((contribution * D(100)).quantize(D("0.0000000001"), rounding=ROUND_HALF_UP))
        quotation = _trunc(sum(pv_percent, D(0)), 4)
        vni_published = _trunc(vni_value, 6)
        published_pu = _trunc(vni_published * quotation / D(100), 2)
        continuous_quotation = continuous_factor * D(100)
        continuous_pu = vni_value * continuous_factor
    return RendaPlusPrice(
        series_id=series.series_id,
        valuation_date=None,
        vni=vni_value,
        annual_real_yield=rate,
        business_days=du,
        continuous_quotation_percent=continuous_quotation,
        published_quotation_percent=quotation,
        continuous_pu=continuous_pu,
        published_pu=published_pu,
        quality=quality,
        calendar_id=None,
    )


def price_renda_plus(
    series: RendaPlusSeries,
    valuation_date: date,
    vni: Decimal | str | int,
    annual_real_yield: Decimal | str | int,
    calendar: Calendar,
    quality: Quality = Quality.HYPOTHETICAL,
) -> RendaPlusPrice:
    if calendar is None or not getattr(calendar, "calendar_id", None):
        raise ValidationError("CALENDAR_REQUIRED", "Precificação por data exige calendário identificado.")
    effective_dates = tuple(calendar.roll_payment(day) for day in series.payment_dates)
    if valuation_date >= effective_dates[0]:
        raise ValidationError("OUTSIDE_HORIZON", "RendA+ só pode ser precificado antes da primeira parcela.")
    du_values = calendar.days_to_payments(valuation_date, effective_dates)
    du = tuple(int(value) for value in du_values)
    result = price_renda_plus_from_du(series, vni, annual_real_yield, du, quality)
    return RendaPlusPrice(
        series_id=result.series_id,
        valuation_date=valuation_date,
        vni=result.vni,
        annual_real_yield=result.annual_real_yield,
        business_days=result.business_days,
        continuous_quotation_percent=result.continuous_quotation_percent,
        published_quotation_percent=result.published_quotation_percent,
        continuous_pu=result.continuous_pu,
        published_pu=result.published_pu,
        quality=result.quality,
        calendar_id=calendar.calendar_id,
        method_version=result.method_version,
    )


def sale_eligibility(
    series: RendaPlusSeries,
    settlement_date: date,
    proposed_trade_date: date,
    calendar: Calendar,
    institution_release_date: date | None = None,
) -> SaleEligibility:
    lock_end = settlement_date + timedelta(days=60)
    if institution_release_date is not None:
        lock_end = max(lock_end, institution_release_date)
    earliest_session = calendar.next_session(lock_end, include=True)
    if proposed_trade_date >= series.first_income_date:
        return SaleEligibility(
            SaleEligibilityStatus.AFTER_FIRST_INCOME,
            earliest_session,
            proposed_trade_date,
            lock_end,
            "Venda fora do período de acumulação.",
        )
    if proposed_trade_date < lock_end:
        return SaleEligibility(
            SaleEligibilityStatus.LOCKED, earliest_session, proposed_trade_date, lock_end,
            "Carência mínima de 60 dias corridos ainda não terminou.",
        )
    if not calendar.is_session(proposed_trade_date):
        return SaleEligibility(
            SaleEligibilityStatus.NOT_SESSION, earliest_session, proposed_trade_date, lock_end,
            "Data sem sessão elegível; ela não é deslocada silenciosamente.",
        )
    if proposed_trade_date < earliest_session:
        return SaleEligibility(
            SaleEligibilityStatus.LOCKED, earliest_session, proposed_trade_date, lock_end,
            "Liberação institucional informada posterga a elegibilidade.",
        )
    return SaleEligibility(SaleEligibilityStatus.ELIGIBLE, earliest_session, proposed_trade_date, lock_end)
