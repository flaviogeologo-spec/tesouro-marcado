"""Discrete, evidence-backed condition summaries for coordinated G4 maps."""
from __future__ import annotations

from decimal import Decimal, InvalidOperation
from typing import Any, Mapping, Sequence


_CONDITION_IDS = (
    "nominal_equilibrium",
    "personal_goals",
    "sell_wait_indifference",
)


def analyze_g4_frontiers(
    points: Sequence[Mapping[str, Any]],
    *,
    order_dates: Sequence[str],
    values: Sequence[str],
) -> dict[str, Any]:
    """Classify evaluated cells and report only observed adjacent transitions.

    This function intentionally makes no claim about rates between the supplied
    coordinates.  A numeric zero is a tie at the evaluated coordinate; it is
    never converted to an interpolated rate.
    """
    normalized_values = tuple(_decimal_text(item) for item in values)
    expected_dates = tuple(str(item) for item in order_dates)
    ordered = []
    by_cell: dict[tuple[str, str], dict[str, Any]] = {}
    for raw in points:
        item = dict(raw)
        order_date = str(item.get("order_date") or "")
        coordinate = item.get("coordinate")
        raw_value = coordinate.get("value") if isinstance(coordinate, Mapping) else None
        value = None if raw_value is None else _decimal_text(raw_value)
        item["frontier_conditions"] = _classify_conditions(item)
        ordered.append(item)
        if order_date and value is not None:
            by_cell[(order_date, value)] = item

    ordered.sort(key=lambda item: (
        str(item.get("order_date") or ""),
        _sort_decimal(item.get("coordinate", {}).get("value") if isinstance(item.get("coordinate"), Mapping) else None),
    ))
    expected_count = len(expected_dates) * len(normalized_values)
    result_frontiers: dict[str, Any] = {}
    for condition in _CONDITION_IDS:
        condition_points = []
        ties = []
        brackets = []
        feasible_points = []
        available_count = 0
        unknown_count = 0
        not_applicable_count = 0
        for order_date in expected_dates:
            statuses = []
            for value in normalized_values:
                point = by_cell.get((order_date, value))
                condition_value = None if point is None else point["frontier_conditions"][condition]
                status = "UNAVAILABLE" if condition_value is None else condition_value["status"]
                statuses.append((value, point, condition_value, status))
                if status == "NO_GOALS":
                    not_applicable_count += 1
                elif status in {"MET", "NOT_MET", "TIE"}:
                    available_count += 1
                    if status in {"MET", "TIE"}:
                        feasible_points.append({"order_date": order_date, "value": value})
                    if status == "TIE":
                        ties.append({"order_date": order_date, "value": value})
                else:
                    unknown_count += 1

            for index in range(len(statuses) - 1):
                left_value, left_point, left_condition, left_status = statuses[index]
                right_value, right_point, right_condition, right_status = statuses[index + 1]
                if left_point is None or right_point is None:
                    continue
                if left_status not in {"MET", "NOT_MET"} or right_status not in {"MET", "NOT_MET"}:
                    continue
                if left_status == right_status:
                    continue
                kind = "observed_sign_change_between_evaluated_rates"
                if condition == "personal_goals":
                    kind = "observed_goal_status_change_between_evaluated_rates"
                left_margin = None if left_condition is None else left_condition.get("margin")
                right_margin = None if right_condition is None else right_condition.get("margin")
                # A numeric condition only brackets a strict sign change. Goal
                # sets are boolean and their adjacent status change is the
                # observable boundary for this discrete map.
                if condition != "personal_goals":
                    if not _strict_opposite_signs(left_margin, right_margin):
                        continue
                brackets.append({
                    "order_date": order_date,
                    "left": {"value": left_value, "status": left_status},
                    "right": {"value": right_value, "status": right_status},
                    "kind": kind,
                    "inference": "no_interpolation_or_root_claim",
                })

        for item in ordered:
            detail = item["frontier_conditions"].get(condition)
            condition_points.append({
                "order_date": item.get("order_date"),
                "value": item.get("coordinate", {}).get("value") if isinstance(item.get("coordinate"), Mapping) else None,
                "status": "UNAVAILABLE" if detail is None else detail["status"],
            })

        if expected_count > 0 and not_applicable_count == expected_count:
            coverage_status = "not_applicable"
        elif available_count == 0 and not_applicable_count == 0:
            coverage_status = "unavailable"
        elif unknown_count or available_count + not_applicable_count < expected_count or not_applicable_count:
            coverage_status = "partial"
        else:
            coverage_status = "complete"
        result_frontiers[condition] = {
            "coverage": {
                "status": coverage_status,
                "requested_points": expected_count,
                "available_points": available_count,
                "not_applicable_points": not_applicable_count,
                "unavailable_points": max(0, expected_count - available_count - not_applicable_count),
                "interpretation": (
                    "Discrete evaluated grid only; brackets describe adjacent observations. "
                    "No bracket outside this sampled domain is not proof that no boundary exists."
                ),
            },
            "point_statuses": condition_points,
            "brackets": brackets,
            "ties": ties,
            "feasible_points": feasible_points,
            "feasible_runs": _feasible_runs(expected_dates, normalized_values, by_cell, condition),
        }

    return {
        "schema": "G4_DISCRETE_FRONTIERS_v1",
        "points": ordered,
        "frontiers": result_frontiers,
        "domain": {
            "order_dates": list(expected_dates),
            "values": list(normalized_values),
            "coordinate_unit": "ratio",
            "requested_points": expected_count,
            "method": "direct_evaluated_grid",
        },
    }


def _classify_conditions(point: Mapping[str, Any]) -> dict[str, dict[str, Any]]:
    metrics = point.get("metrics") if isinstance(point.get("metrics"), Mapping) else {}
    profit = metrics.get("nominal_profit") if isinstance(metrics.get("nominal_profit"), Mapping) else None
    equilibrium = _numeric_condition(profit, unavailable_reason="nominal profit was not evaluated")

    goal_eval = point.get("constraint_evaluation")
    goal_status = "NO_GOALS" if "constraint_evaluation" not in point else _constraint_status(goal_eval)
    goals = {
        "status": goal_status,
        "meets_condition": True if goal_status == "MET" else False if goal_status == "NOT_MET" else None,
        "margin": None,
        "threshold": None,
        "reason": (
            "no personal goals were declared" if goal_status == "NO_GOALS"
            else None if goal_status in {"MET", "NOT_MET"}
            else "personal goals were not fully evaluated"
        ),
    }

    wealth = point.get("wealth_advantage_vs_reference")
    indifference = _numeric_condition(
        wealth,
        unavailable_reason="reference wealth comparison is unavailable under the declared horizon/cash premise",
        reference="FIXED_POSITION_REFERENCE_AT_COMMON_HORIZON",
    )
    return {
        "nominal_equilibrium": equilibrium,
        "personal_goals": goals,
        "sell_wait_indifference": indifference,
    }


def _numeric_condition(
    raw: Any,
    *,
    unavailable_reason: str,
    reference: str | None = None,
) -> dict[str, Any]:
    if not isinstance(raw, Mapping) or raw.get("value") is None:
        return {
            "status": "UNAVAILABLE",
            "meets_condition": None,
            "margin": None,
            "threshold": {"value": "0", "unit": "BRL"},
            "reference": reference,
            "reason": unavailable_reason,
        }
    try:
        margin = Decimal(str(raw["value"]))
    except (InvalidOperation, TypeError, ValueError):
        margin = Decimal("NaN")
    if not margin.is_finite():
        return {
            "status": "UNAVAILABLE", "meets_condition": None, "margin": None,
            "threshold": {"value": "0", "unit": "BRL"}, "reference": reference,
            "reason": unavailable_reason,
        }
    status = "TIE" if margin == 0 else "MET" if margin > 0 else "NOT_MET"
    return {
        "status": status,
        "meets_condition": margin >= 0,
        "margin": {"value": format(margin, "f"), "unit": str(raw.get("unit") or "BRL")},
        "threshold": {"value": "0", "unit": str(raw.get("unit") or "BRL")},
        "reference": reference,
        "reason": None,
    }


def _constraint_status(raw: Any) -> str:
    if not isinstance(raw, Mapping):
        return "UNAVAILABLE"
    status = str(raw.get("status") or "").upper()
    if status in {"NO_CONSTRAINTS", "NO_GOALS"} or (
        not status and raw.get("met") is None and not raw.get("criteria")
    ):
        return "NO_GOALS"
    if status in {"MET", "SATISFIED", "PASS"} or raw.get("met") is True:
        return "MET"
    if status in {"NOT_MET", "UNSATISFIED", "FAIL"} or raw.get("met") is False:
        return "NOT_MET"
    return "UNAVAILABLE"


def _strict_opposite_signs(left: Any, right: Any) -> bool:
    if not isinstance(left, Mapping) or not isinstance(right, Mapping):
        return False
    try:
        first = Decimal(str(left["value"]))
        second = Decimal(str(right["value"]))
    except (InvalidOperation, KeyError, TypeError, ValueError):
        return False
    return first.is_finite() and second.is_finite() and first * second < 0


def _feasible_runs(
    order_dates: Sequence[str],
    values: Sequence[str],
    by_cell: Mapping[tuple[str, str], Mapping[str, Any]],
    condition: str,
) -> list[dict[str, Any]]:
    runs = []
    for order_date in order_dates:
        active: list[str] = []
        for value in values:
            point = by_cell.get((order_date, value))
            detail = None if point is None else point.get("frontier_conditions", {}).get(condition)
            status = "UNAVAILABLE" if detail is None else detail["status"]
            if status in {"MET", "TIE"}:
                active.append(value)
            elif active:
                runs.append({"order_date": order_date, "values": active})
                active = []
        if active:
            runs.append({"order_date": order_date, "values": active})
    return runs


def _decimal_text(value: Any) -> str:
    number = Decimal(str(value))
    if not number.is_finite():
        raise ValueError("A coordenada do mapa precisa ser finita.")
    return format(number, "f")


def _sort_decimal(value: Any) -> Decimal:
    try:
        return Decimal(str(value))
    except (InvalidOperation, TypeError, ValueError):
        return Decimal("Infinity")
