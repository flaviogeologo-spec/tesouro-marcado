"""Origem, qualidade e disponibilidade temporal de dados financeiros."""
from __future__ import annotations

from dataclasses import dataclass
from datetime import date, datetime
from enum import StrEnum
import re


class Quality(StrEnum):
    OBSERVED = "OBSERVED"
    INFORMED = "INFORMED"
    RECONSTRUCTED = "RECONSTRUCTED"
    HYPOTHETICAL = "HYPOTHETICAL"
    ESTIMATED = "ESTIMATED"
    REVISED = "REVISED"
    MISSING = "MISSING"


class EvidenceMode(StrEnum):
    CAUSAL = "CAUSAL"
    EX_POST = "EX_POST"


class EvidenceStatus(StrEnum):
    AVAILABLE = "AVAILABLE"
    MISSING = "MISSING"
    PUBLISHED_AFTER_AS_OF = "PUBLISHED_AFTER_AS_OF"
    PUBLICATION_DATE_UNKNOWN = "PUBLICATION_DATE_UNKNOWN"
    OBSERVATION_AFTER_AS_OF = "OBSERVATION_AFTER_AS_OF"
    AVAILABLE_EX_POST = "AVAILABLE_EX_POST"


@dataclass(frozen=True, slots=True)
class Provenance:
    source_id: str
    source_ref: str
    quality: Quality
    observed_on: date | None
    published_at: datetime | None
    version: str | None = None
    sha256: str | None = None
    revision_id: str | None = None
    supersedes_revision: str | None = None
    settlement_date: date | None = None

    def __post_init__(self) -> None:
        if not self.source_id.strip() or not self.source_ref.strip():
            raise ValueError("Identifique a fonte e sua referência.")
        if self.published_at is not None and self.published_at.tzinfo is None:
            raise ValueError("Data de publicação precisa incluir fuso horário.")
        if self.sha256 is not None and not re.fullmatch(r"[0-9a-fA-F]{64}", self.sha256):
            raise ValueError("SHA-256 precisa conter exatamente 64 dígitos hexadecimais.")
        if self.quality is Quality.MISSING and (self.observed_on is not None or self.published_at is not None):
            raise ValueError("Evidência ausente não pode declarar data observada ou publicada.")

    @property
    def is_revision(self) -> bool:
        return self.quality is Quality.REVISED or self.supersedes_revision is not None


@dataclass(frozen=True, slots=True)
class EvidenceDecision:
    status: EvidenceStatus
    usable: bool
    label: str
    reason: str | None = None


def assess_evidence(
    provenance: Provenance,
    as_of: date,
    mode: EvidenceMode = EvidenceMode.CAUSAL,
) -> EvidenceDecision:
    """Decide se a observação pode participar do conjunto de informação escolhido."""
    if provenance.quality is Quality.MISSING:
        return EvidenceDecision(EvidenceStatus.MISSING, False, "sem dado", "Fonte ou observação ausente.")

    if mode is EvidenceMode.EX_POST:
        return EvidenceDecision(
            EvidenceStatus.AVAILABLE_EX_POST,
            True,
            "ex-post; pode conter informação publicada depois da data de referência",
        )

    if provenance.observed_on is not None and provenance.observed_on > as_of:
        return EvidenceDecision(
            EvidenceStatus.OBSERVATION_AFTER_AS_OF,
            False,
            "indisponível na data de referência",
            "A data observada é posterior à data de referência.",
        )
    if provenance.published_at is None:
        return EvidenceDecision(
            EvidenceStatus.PUBLICATION_DATE_UNKNOWN,
            False,
            "publicação sem data conhecida",
            "Não é possível provar que a informação já estava disponível.",
        )
    if provenance.published_at.date() > as_of:
        return EvidenceDecision(
            EvidenceStatus.PUBLISHED_AFTER_AS_OF,
            False,
            "publicado depois da data de referência",
            "A publicação posterior foi excluída do modo causal.",
        )
    label = "revisado; disponível na data de referência" if provenance.is_revision else "disponível na data de referência"
    return EvidenceDecision(EvidenceStatus.AVAILABLE, True, label)
