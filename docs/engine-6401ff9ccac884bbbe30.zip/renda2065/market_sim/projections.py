"""Explicit, versioned ACT/365 projections for index levels.

These projections are economic hypotheses. They do not reproduce the official
monthly update rules for VNA/VNI and never fill a gap before the last supplied
point.
"""
from __future__ import annotations

from dataclasses import dataclass
from datetime import date
from decimal import Decimal, InvalidOperation, localcontext

from .contracts import ValidationError, decimal_value
from .provenance import Quality

D = Decimal
PROJECTION_PROFILE_ID = "HYPOTHETICAL_ACT365_COMPOUND_v1"
INTERPOLATED_PROFILE_ID = "HYPOTHETICAL_ACT365_LOG_LINEAR_ANNUAL_v1"


@dataclass(frozen=True, slots=True)
class InflationProjection:
    mode: str
    annual_rate: Decimal
    anchor_date: date
    anchor_level: Decimal
    source_ref: str
    end_annual_rate: Decimal | None = None
    end_date: date | None = None

    def __post_init__(self) -> None:
        if self.mode not in ("CONSTANT_ANNUAL", "INTERPOLATED_ANNUAL"):
            raise ValidationError("INVALID_PROJECTION", "Modo de projeção de inflação inválido.")
        rate = decimal_value(self.annual_rate, "taxa anual de inflação")
        level = decimal_value(self.anchor_level, "nível-âncora do índice")
        if not isinstance(self.anchor_date, date):
            raise ValidationError("INVALID_PROJECTION", "Data-âncora inválida.")
        if rate <= -1:
            raise ValidationError("INVALID_PROJECTION", "Inflação anual precisa ser maior que −100%.")
        if self.mode == "INTERPOLATED_ANNUAL":
            if self.end_annual_rate is None or not isinstance(self.end_date, date):
                raise ValidationError("INVALID_PROJECTION", "Interpolação exige taxa e data finais.")
            end_rate = decimal_value(self.end_annual_rate, "taxa anual final de inflação")
            if end_rate <= -1 or self.end_date <= self.anchor_date:
                raise ValidationError("INVALID_PROJECTION", "A taxa final deve superar −100% e sua data deve ser posterior à inicial.")
            object.__setattr__(self, "end_annual_rate", end_rate)
        elif self.end_annual_rate is not None or self.end_date is not None:
            raise ValidationError("INVALID_PROJECTION", "Projeção constante não aceita ponto final.")
        if level <= 0:
            raise ValidationError("INVALID_PROJECTION", "Nível-âncora do índice precisa ser positivo.")
        if not isinstance(self.source_ref, str) or not self.source_ref.strip():
            raise ValidationError("INVALID_PROJECTION", "Identifique a hipótese de inflação.")
        object.__setattr__(self, "annual_rate", rate)
        object.__setattr__(self, "anchor_level", level)
        object.__setattr__(self, "source_ref", self.source_ref.strip())

    def to_dict(self) -> dict[str, str]:
        value = {
            "mode": self.mode,
            "annual_rate": str(self.annual_rate),
            "anchor_date": self.anchor_date.isoformat(),
            "anchor_level": str(self.anchor_level),
            "source_ref": self.source_ref,
            "profile_id": self.profile_id,
            "quality": Quality.HYPOTHETICAL.value,
        }
        if self.mode == "INTERPOLATED_ANNUAL":
            value["end_annual_rate"] = str(self.end_annual_rate)
            value["end_date"] = self.end_date.isoformat()
        return value

    @property
    def profile_id(self) -> str:
        return INTERPOLATED_PROFILE_ID if self.mode == "INTERPOLATED_ANNUAL" else PROJECTION_PROFILE_ID


@dataclass(frozen=True, slots=True)
class DatedLevel:
    reference_date: date
    value: Decimal
    quality: Quality
    source_ref: str

    def __post_init__(self) -> None:
        value = decimal_value(self.value, "nível do índice")
        if value <= 0:
            raise ValidationError("INVALID_INDEX", "Nível do índice precisa ser positivo.")
        quality = self.quality if isinstance(self.quality, Quality) else Quality(self.quality)
        if quality is Quality.MISSING:
            raise ValidationError("INVALID_INDEX", "Nível preenchido não pode ter qualidade MISSING.")
        if not isinstance(self.reference_date, date) or not isinstance(self.source_ref, str) or not self.source_ref.strip():
            raise ValidationError("INVALID_INDEX", "Nível exige data e identificação da fonte.")
        object.__setattr__(self, "value", value)
        object.__setattr__(self, "quality", quality)


@dataclass(frozen=True, slots=True)
class ProjectionPoint:
    series_id: str
    reference_date: date
    status: str
    reason_code: str | None
    value: Decimal | None
    quality: Quality
    source_ref: str | None
    anchor_date: date | None = None
    profile_id: str | None = None

    def to_dict(self) -> dict[str, str | None]:
        return {
            "series_id": self.series_id,
            "unit": "INDEX_LEVEL",
            "reference_date": self.reference_date.isoformat(),
            "status": self.status,
            "reason_code": self.reason_code,
            "value": None if self.value is None else str(self.value),
            "quality": self.quality.value,
            "source_ref": self.source_ref,
            "anchor_date": None if self.anchor_date is None else self.anchor_date.isoformat(),
            "profile_id": self.profile_id,
        }


def project_level(
    anchor: DatedLevel,
    target_date: date,
    annual_rate: Decimal | InflationProjection,
    *,
    series_id: str,
) -> ProjectionPoint:
    """Project a level with ACT/365 compounding; interpolate annual log growth if selected."""
    if target_date < anchor.reference_date:
        return ProjectionPoint(
            series_id, target_date, "needs_input", "DATE_BEFORE_PROJECTION_ANCHOR",
            None, Quality.MISSING, None, anchor.reference_date,
        )
    projection = annual_rate if isinstance(annual_rate, InflationProjection) else None
    rate = projection.annual_rate if projection is not None else decimal_value(annual_rate, "taxa anual")
    if rate <= -1:
        raise ValidationError("INVALID_PROJECTION", "Taxa anual precisa ser maior que −100%.")
    days = (target_date - anchor.reference_date).days
    with localcontext() as ctx:
        ctx.prec = 36
        try:
            if projection is not None and projection.mode == "INTERPOLATED_ANNUAL":
                # Integrating a straight line between log(1+r0) and log(1+r1)
                # preserves compound growth and gives the constant model when r0 == r1.
                start = projection.anchor_date
                duration = D((projection.end_date - start).days)
                start_log = (D(1) + rate).ln()
                end_log = (D(1) + projection.end_annual_rate).ln()

                def accumulated(day: date) -> Decimal:
                    elapsed = D((day - start).days)
                    if elapsed <= 0:
                        return elapsed * start_log
                    bounded = min(elapsed, duration)
                    total = bounded * start_log + (end_log - start_log) * bounded * bounded / (D(2) * duration)
                    return total + max(elapsed - duration, D(0)) * end_log
                factor = ((accumulated(target_date) - accumulated(anchor.reference_date)) / D(365)).exp()
            else:
                factor = (D(1) + rate) ** (D(days) / D(365))
            value = anchor.value * factor
        except (ArithmeticError, InvalidOperation) as exc:
            raise ValidationError("PROJECTION_OVERFLOW", "A projeção excede o domínio numérico suportado.") from exc
    if not value.is_finite() or value <= 0:
        raise ValidationError("PROJECTION_OVERFLOW", "A projeção excede o domínio numérico suportado.")
    return ProjectionPoint(
        series_id,
        target_date,
        "available",
        "HYPOTHETICAL_PROJECTION",
        value,
        Quality.HYPOTHETICAL,
        f"{projection.profile_id if projection is not None else PROJECTION_PROFILE_ID}; hipótese {anchor.source_ref}",
        anchor.reference_date,
        projection.profile_id if projection is not None else PROJECTION_PROFILE_ID,
    )


def project_level_series(
    series_id: str,
    explicit_levels: tuple[DatedLevel, ...] | list[DatedLevel],
    target_dates: tuple[date, ...] | list[date],
    annual_rate: Decimal | InflationProjection | None,
    *,
    projection_seed: DatedLevel | None = None,
) -> tuple[ProjectionPoint, ...]:
    """Resolve exact explicit levels and project only after the latest input.

    Exact supplied points always win. Missing dates inside the supplied window
    are left unresolved; only dates strictly after the latest point may extend
    the latest prior anchor. ``projection_seed`` is used for the general price
    index hypothesis and never merged over an explicit point on the same date.
    """
    levels: dict[date, DatedLevel] = {}
    for item in explicit_levels:
        if item.reference_date in levels:
            raise ValidationError("CONFLICTING_INDEX", f"Série {series_id} tem mais de um nível na mesma data.")
        levels[item.reference_date] = item
    seed_date = None
    if projection_seed is not None and projection_seed.reference_date not in levels:
        levels[projection_seed.reference_date] = projection_seed
        seed_date = projection_seed.reference_date
    if annual_rate is not None:
        rate = annual_rate.annual_rate if isinstance(annual_rate, InflationProjection) else decimal_value(annual_rate, "taxa anual")
        if rate <= -1:
            raise ValidationError("INVALID_PROJECTION", "Taxa anual precisa ser maior que −100%.")
    else:
        rate = None
    latest_input_date = max(levels) if levels else None

    points: list[ProjectionPoint] = []
    seen_targets: set[date] = set()
    for target in target_dates:
        if target in seen_targets:
            continue
        seen_targets.add(target)
        exact = levels.get(target)
        if exact is not None:
            is_projection_seed = target == seed_date
            points.append(ProjectionPoint(
                series_id, target, "available",
                "HYPOTHETICAL_PROJECTION_ANCHOR" if is_projection_seed else "EXPLICIT_EXACT_LEVEL",
                exact.value, exact.quality, exact.source_ref, exact.reference_date,
                annual_rate.profile_id if is_projection_seed and isinstance(annual_rate, InflationProjection)
                else PROJECTION_PROFILE_ID if is_projection_seed else None,
            ))
            continue
        anchors = [item for item in levels.values() if item.reference_date < target]
        if not anchors:
            points.append(ProjectionPoint(
                series_id, target, "needs_input", "NO_PRIOR_ANCHOR",
                None, Quality.MISSING, None,
            ))
            continue
        if latest_input_date is not None and target < latest_input_date:
            points.append(ProjectionPoint(
                series_id, target, "needs_input", "EXPLICIT_GAP_NOT_INTERPOLATED",
                None, Quality.MISSING, None,
            ))
            continue
        if rate is None:
            points.append(ProjectionPoint(
                series_id, target, "needs_input", "MISSING_PROJECTION",
                None, Quality.MISSING, None, max(anchors, key=lambda item: item.reference_date).reference_date,
            ))
            continue
        anchor = max(anchors, key=lambda item: item.reference_date)
        points.append(project_level(anchor, target, annual_rate, series_id=series_id))
    return tuple(points)
