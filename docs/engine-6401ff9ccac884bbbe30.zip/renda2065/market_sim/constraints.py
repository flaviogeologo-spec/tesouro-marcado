"""Named, composable decision criteria with explicit three-valued results."""
from __future__ import annotations

from dataclasses import dataclass, replace
from datetime import date, datetime
from decimal import Decimal, ROUND_FLOOR
from enum import StrEnum
from hashlib import sha256
import json
import re
from typing import Any, Callable, Mapping

from .contracts import Scenario, Side, ValidationError, decimal_value
from .service import EvaluationContext, ScenarioEvaluation, evaluate_scenario
from .targets import (
    ExitPuCeilingSolution, RateSolution, TargetDefinition, TargetMetric,
    TargetSolution, TargetStatus, solve_maximum_entry_pu, solve_maximum_exit_pu,
    solve_minimum_exit_pu, solve_rate_for_pu_limit,
)


MAX_CONSTRAINTS = 8
_MAX_EXACT_COMBINED_PU_TICKS = 4096
_CONSTRAINT_ID = re.compile(r"[A-Za-z0-9][A-Za-z0-9._:-]{0,63}\Z")
_DECIMAL_TEXT = re.compile(r"[+-]?(?:0|[1-9]\d*)(?:\.\d+)?\Z")
STRESS_DIMENSION_UNITS = {
    "rate_shock_ratio": "ratio",
    "annual_inflation_ratio": "ratio",
    "entry_expense_delta_brl": "BRL",
    "exit_expense_delta_brl": "BRL",
}


def search_stress_margin(
    constraints: "ConstraintSetDefinition",
    *,
    criterion_id: str,
    dimension: str,
    direction: str,
    maximum_magnitude: Decimal | str,
    resolution: Decimal | str,
    evaluate_at_shift: Callable[[Decimal], "ConstraintSetEvaluation | None"],
    baseline: "ConstraintSetEvaluation | None" = None,
) -> dict[str, Any]:
    """Find the first failing tick along one declared stress dimension.

    Every shift between zero and the first failing point is directly evaluated.
    The search makes no monotonicity claim about shocks outside that ray/domain.
    """
    criteria_by_id = {item.constraint_id: item for item in constraints.criteria}
    criterion = criteria_by_id.get(criterion_id)
    if criterion is None:
        raise ValidationError("UNKNOWN_STRESS_CRITERION", "criterion_id não corresponde a uma restrição de input.")
    if dimension not in STRESS_DIMENSION_UNITS:
        raise ValidationError("INVALID_STRESS_DIMENSION", "Dimensão de estresse não reconhecida.")
    if direction not in {"INCREASE", "DECREASE"}:
        raise ValidationError("INVALID_STRESS_DIRECTION", "direction precisa ser INCREASE ou DECREASE.")
    unit = STRESS_DIMENSION_UNITS[dimension]
    maximum = decimal_value(maximum_magnitude, "maximum_magnitude")
    step = decimal_value(resolution, "resolution")
    if maximum <= 0 or step <= 0 or maximum / step != (maximum / step).to_integral_value():
        raise ValidationError("INVALID_STRESS_DOMAIN", "maximum_magnitude deve ser positivo e múltiplo inteiro de resolution.")
    ticks = int(maximum / step)
    if ticks > 4095:
        raise ValidationError("INVALID_STRESS_DOMAIN", "A margem admite no máximo 4096 pontos, incluindo a base.")
    sign = Decimal(1) if direction == "INCREASE" else Decimal(-1)

    def target_result(evaluation: ConstraintSetEvaluation | None) -> CriterionEvaluation | None:
        if evaluation is None:
            return None
        return next((item for item in evaluation.criteria if item.constraint_id == criterion_id), None)

    evaluated_points = 0

    def probe(shift: Decimal) -> tuple[ConstraintSetEvaluation | None, CriterionEvaluation | None]:
        nonlocal evaluated_points
        evaluation = baseline if shift == 0 and baseline is not None else evaluate_at_shift(shift)
        if not (shift == 0 and baseline is not None):
            evaluated_points += 1
        return evaluation, target_result(evaluation)

    baseline_evaluation, baseline_criterion = probe(Decimal(0))
    domain = {
        "minimum_magnitude": "0",
        "maximum_magnitude": str(maximum),
        "resolution": str(step),
        "unit": unit,
    }
    if baseline_criterion is None or baseline_criterion.status is CriterionStatus.UNKNOWN:
        return {
            "status": "UNKNOWN", "criterion_id": criterion_id, "dimension": dimension,
            "direction": direction, "unit": unit, "domain": domain,
            "margin_to_failure": None, "last_passing": None, "first_failing": None,
            "evaluated_points": evaluated_points,
            "reason": "A restrição de referência está indisponível; margem não demonstrada.",
        }
    if baseline_criterion.status is CriterionStatus.NOT_MET:
        return {
            "status": "BASE_NOT_MET", "criterion_id": criterion_id, "dimension": dimension,
            "direction": direction, "unit": unit, "domain": domain,
            "margin_to_failure": {"value": "0", "unit": unit},
            "last_passing": None,
            "first_failing": {"shift": "0", "actual_value": _string_or_none(baseline_criterion.achieved_value),
                              "threshold": _string_or_none(baseline_criterion.target_value),
                              "criterion_margin": _string_or_none(baseline_criterion.margin),
                              "criterion_unit": baseline_criterion.margin_unit},
            "evaluated_points": evaluated_points,
            "reason": "A restrição já falha no cenário de referência.",
        }

    last_passing = {
        "shift": "0",
        "actual_value": _string_or_none(baseline_criterion.achieved_value),
        "threshold": _string_or_none(baseline_criterion.target_value),
        "criterion_margin": _string_or_none(baseline_criterion.margin),
        "criterion_unit": baseline_criterion.margin_unit,
    }
    for tick_index in range(1, ticks + 1):
        magnitude = step * tick_index
        shift = sign * magnitude
        _, criterion_result = probe(shift)
        if criterion_result is None or criterion_result.status is CriterionStatus.UNKNOWN:
            return {
                "status": "UNKNOWN", "criterion_id": criterion_id, "dimension": dimension,
                "direction": direction, "unit": unit, "domain": domain,
                "margin_to_failure": None, "last_passing": last_passing, "first_failing": None,
                "first_unavailable": {"shift": str(shift)},
                "evaluated_points": evaluated_points,
                "reason": "Um ponto do domínio não pôde ser avaliado; a folga não foi presumida.",
            }
        if criterion_result.status is CriterionStatus.NOT_MET:
            first_failing = {
                "shift": str(shift),
                "actual_value": _string_or_none(criterion_result.achieved_value),
                "threshold": _string_or_none(criterion_result.target_value),
                "criterion_margin": _string_or_none(criterion_result.margin),
                "criterion_unit": criterion_result.margin_unit,
            }
            return {
                "status": "FAILURE_FOUND", "criterion_id": criterion_id, "dimension": dimension,
                "direction": direction, "unit": unit, "domain": domain,
                "margin_to_failure": {"value": str(magnitude - step), "unit": unit},
                "last_passing": last_passing, "first_failing": first_failing,
                "evaluated_points": evaluated_points,
                "reason": "Primeiro tick que falha após busca exaustiva desde zero neste domínio unidimensional.",
            }
        last_passing = {
            "shift": str(shift),
            "actual_value": _string_or_none(criterion_result.achieved_value),
            "threshold": _string_or_none(criterion_result.target_value),
            "criterion_margin": _string_or_none(criterion_result.margin),
            "criterion_unit": criterion_result.margin_unit,
        }

    return {
        "status": "NO_FAILURE_IN_DOMAIN", "criterion_id": criterion_id,
        "dimension": dimension, "direction": direction, "unit": unit, "domain": domain,
        "margin_to_failure": {"value": str(maximum), "unit": unit},
        "last_passing": last_passing, "first_failing": None,
        "evaluated_points": evaluated_points,
        "reason": "Toda a grade declarada passou; isso não demonstra folga além do domínio examinado.",
    }


class ConstraintMetric(StrEnum):
    NET_REDEMPTION = "NET_REDEMPTION"
    NOMINAL_PROFIT = "NOMINAL_PROFIT"
    NOMINAL_RETURN = "NOMINAL_RETURN"
    REAL_RETURN = "REAL_RETURN"
    ANNUALIZED_NOMINAL_RETURN = "ANNUALIZED_NOMINAL_RETURN"
    REQUESTED_ORDER_DATE = "REQUESTED_ORDER_DATE"


class ConstraintOperator(StrEnum):
    AT_LEAST = "AT_LEAST"
    AT_MOST = "AT_MOST"


class CriterionStatus(StrEnum):
    MET = "MET"
    NOT_MET = "NOT_MET"
    UNKNOWN = "UNKNOWN"


class ConstraintSetStatus(StrEnum):
    MET = "MET"
    NOT_MET = "NOT_MET"
    UNKNOWN = "UNKNOWN"
    NO_CONSTRAINTS = "NO_CONSTRAINTS"


class CombinedLimitStatus(StrEnum):
    SOLVED = "SOLVED"
    INFEASIBLE = "INFEASIBLE"
    UNKNOWN = "UNKNOWN"
    AMBIGUOUS = "AMBIGUOUS"
    BLOCKED_POLICY = "BLOCKED_POLICY"
    VERIFICATION_FAILED = "VERIFICATION_FAILED"
    NO_CONSTRAINTS = "NO_CONSTRAINTS"
    NO_FINANCIAL_BOUND = "NO_FINANCIAL_BOUND"


class EntryBoundaryStatus(StrEnum):
    SOLVED = "SOLVED"
    INCOMPLETE = "INCOMPLETE"
    NO_SOLUTION = "NO_SOLUTION"
    UNKNOWN = "UNKNOWN"
    OUTSIDE_DOMAIN = "OUTSIDE_DOMAIN"
    BLOCKED_POLICY = "BLOCKED_POLICY"
    UNSUPPORTED = "UNSUPPORTED"


_UNITS = {
    ConstraintMetric.NET_REDEMPTION: "BRL",
    ConstraintMetric.NOMINAL_PROFIT: "BRL",
    ConstraintMetric.NOMINAL_RETURN: "ratio",
    ConstraintMetric.REAL_RETURN: "ratio",
    ConstraintMetric.ANNUALIZED_NOMINAL_RETURN: "ratio_per_year",
    ConstraintMetric.REQUESTED_ORDER_DATE: "date",
}
_OPERATION_FIELDS = {
    ConstraintMetric.NET_REDEMPTION: "net_redemption",
    ConstraintMetric.NOMINAL_PROFIT: "nominal_profit",
    ConstraintMetric.NOMINAL_RETURN: "nominal_return",
    ConstraintMetric.REAL_RETURN: "real_return",
    ConstraintMetric.ANNUALIZED_NOMINAL_RETURN: "annualized_nominal_return",
}


@dataclass(frozen=True, slots=True)
class ConstraintDefinition:
    constraint_id: str
    metric: ConstraintMetric
    operator: ConstraintOperator
    value: Decimal | date
    unit: str

    def __post_init__(self) -> None:
        if not isinstance(self.constraint_id, str) or not _CONSTRAINT_ID.fullmatch(self.constraint_id):
            raise ValidationError("INVALID_CONSTRAINT_ID", "ID de critério inválido; use até 64 caracteres alfanuméricos, ponto, hífen, sublinhado ou dois-pontos.")
        try:
            metric = self.metric if isinstance(self.metric, ConstraintMetric) else ConstraintMetric(self.metric)
            operator = self.operator if isinstance(self.operator, ConstraintOperator) else ConstraintOperator(self.operator)
        except (TypeError, ValueError) as exc:
            raise ValidationError("INVALID_CONSTRAINT", "Medida ou operador de critério não reconhecido.") from exc
        object.__setattr__(self, "metric", metric)
        object.__setattr__(self, "operator", operator)
        if not isinstance(self.unit, str) or self.unit != _UNITS[metric]:
            raise ValidationError("INVALID_CONSTRAINT_UNIT", f"{metric.value} exige unidade {_UNITS[metric]}.")
        if metric is ConstraintMetric.REQUESTED_ORDER_DATE:
            if operator is not ConstraintOperator.AT_MOST:
                raise ValidationError("INVALID_CONSTRAINT_OPERATOR", "Data solicitada aceita somente limite AT_MOST.")
            if isinstance(self.value, datetime) or not isinstance(self.value, date):
                raise ValidationError("INVALID_CONSTRAINT_VALUE", "Limite de data precisa ser uma data civil.")
        else:
            if isinstance(self.value, (date, datetime)):
                raise ValidationError("INVALID_CONSTRAINT_VALUE", "Meta numérica precisa usar valor decimal.")
            object.__setattr__(self, "value", decimal_value(self.value, "limite do critério"))


@dataclass(frozen=True, slots=True)
class ConstraintSetDefinition:
    criteria: tuple[ConstraintDefinition, ...]

    def __post_init__(self) -> None:
        items = tuple(self.criteria)
        if len(items) > MAX_CONSTRAINTS:
            raise ValidationError("CONSTRAINT_LIMIT", f"O conjunto aceita até {MAX_CONSTRAINTS} critérios.")
        if any(not isinstance(item, ConstraintDefinition) for item in items):
            raise ValidationError("INVALID_CONSTRAINT", "Cada critério precisa ter uma definição validada.")
        ids = [item.constraint_id for item in items]
        if len(ids) != len(set(ids)):
            raise ValidationError("DUPLICATE_CONSTRAINT_ID", "Cada critério precisa ter um ID exclusivo.")
        semantic_keys = [
            (item.metric, item.operator, item.unit, item.value)
            for item in items
        ]
        if len(semantic_keys) != len(set(semantic_keys)):
            raise ValidationError("DUPLICATE_CONSTRAINT", "O conjunto contém o mesmo limite mais de uma vez.")
        by_metric: dict[ConstraintMetric, list[ConstraintDefinition]] = {}
        for item in items:
            if item.metric is not ConstraintMetric.REQUESTED_ORDER_DATE:
                by_metric.setdefault(item.metric, []).append(item)
        for metric, group in by_metric.items():
            lower = [item.value for item in group if item.operator is ConstraintOperator.AT_LEAST]
            upper = [item.value for item in group if item.operator is ConstraintOperator.AT_MOST]
            if lower and upper and max(lower) > min(upper):
                raise ValidationError(
                    "CONTRADICTORY_CONSTRAINTS",
                    f"Os limites nomeados para {metric.value} não se sobrepõem.",
                )
        object.__setattr__(self, "criteria", items)

    @property
    def fingerprint(self) -> str:
        material = [
            {
                "id": item.constraint_id,
                "metric": item.metric.value,
                "operator": item.operator.value,
                "value": _canonical_value(item.value),
                "unit": item.unit,
            }
            for item in sorted(self.criteria, key=lambda criterion: criterion.constraint_id)
        ]
        encoded = json.dumps(material, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
        return sha256(encoded).hexdigest()


@dataclass(frozen=True, slots=True)
class MetricEvidence:
    value: Decimal | None
    unit: str
    status: str = "ready"
    quality: str | None = None
    reason: str | None = None


@dataclass(frozen=True, slots=True)
class CriterionEvaluation:
    constraint_id: str
    metric: ConstraintMetric
    operator: ConstraintOperator
    target_value: Decimal | date
    achieved_value: Decimal | date | None
    unit: str
    margin: Decimal | int | None
    margin_unit: str
    status: CriterionStatus
    quality: str | None
    reference_date: date | None
    reason: str | None


@dataclass(frozen=True, slots=True)
class ConstraintSetEvaluation:
    status: ConstraintSetStatus
    met: bool | None
    criteria: tuple[CriterionEvaluation, ...]
    fingerprint: str

    def to_dict(self) -> dict[str, Any]:
        return _evaluation_dict(self)


@dataclass(frozen=True, slots=True)
class EntrySearchPoint:
    """A fresh direct evaluation of one hypothetical entry PU."""

    status: str
    scenario: Scenario | None = None
    financial_result: ScenarioEvaluation | None = None
    quantity: Decimal | None = None
    cash_remainder: Decimal | None = None
    reason: str | None = None


@dataclass(frozen=True, slots=True)
class EffectiveConstraintBound:
    constraint_ids: tuple[str, ...]
    metric: ConstraintMetric
    operator: ConstraintOperator
    threshold: Decimal
    pu: Decimal | None
    achieved_value: Decimal | None
    adjacent_pu: Decimal | None
    adjacent_value: Decimal | None
    status: TargetStatus
    evaluations: int
    reason: str | None


@dataclass(frozen=True, slots=True)
class CombinedExitLimit:
    status: CombinedLimitStatus
    constraints_fingerprint: str
    requested_order_date: date
    settlement_date: date
    domain_minimum_pu: Decimal
    domain_maximum_pu: Decimal
    tick: Decimal
    minimum_exit_pu: Decimal | None
    maximum_exit_pu: Decimal | None
    candidate_pu: Decimal | None
    verification_pu: Decimal | None
    candidate_evaluation: ConstraintSetEvaluation | None
    adjacent_below_pu: Decimal | None
    adjacent_below: ConstraintSetEvaluation | None
    adjacent_above_pu: Decimal | None
    adjacent_above: ConstraintSetEvaluation | None
    limiting_minimum_ids: tuple[str, ...]
    limiting_maximum_ids: tuple[str, ...]
    effective_bounds: tuple[EffectiveConstraintBound, ...]
    maximum_exit_yield: Decimal | None
    rate_solution: RateSolution | None
    evaluations: int
    reason: str | None = None

    def to_dict(self) -> dict[str, Any]:
        return {
            "status": self.status.value,
            "constraints_fingerprint": self.constraints_fingerprint,
            "requested_order_date": self.requested_order_date.isoformat(),
            "settlement_date": self.settlement_date.isoformat(),
            "domain": {
                "minimum_pu": str(self.domain_minimum_pu),
                "maximum_pu": str(self.domain_maximum_pu),
                "tick": str(self.tick),
                "coverage": "declared_pu_tick_domain_with_exhaustive_small_sweeps_or_bounded_candidate_search_and_direct_verification",
            },
            "minimum_exit_pu": _string_or_none(self.minimum_exit_pu),
            "maximum_exit_pu": _string_or_none(self.maximum_exit_pu),
            "candidate_pu": _string_or_none(self.candidate_pu),
            "verification_pu": _string_or_none(self.verification_pu),
            "candidate_evaluation": _evaluation_dict(self.candidate_evaluation),
            "adjacent_below": {
                "pu": _string_or_none(self.adjacent_below_pu),
                "evaluation": _evaluation_dict(self.adjacent_below),
            },
            "adjacent_above": {
                "pu": _string_or_none(self.adjacent_above_pu),
                "evaluation": _evaluation_dict(self.adjacent_above),
            },
            "limiting_minimum_ids": list(self.limiting_minimum_ids),
            "limiting_maximum_ids": list(self.limiting_maximum_ids),
            "effective_bounds": [
                {
                    "constraint_ids": list(bound.constraint_ids),
                    "metric": bound.metric.value,
                    "operator": bound.operator.value,
                    "threshold": str(bound.threshold),
                    "pu": _string_or_none(bound.pu),
                    "achieved_value": _string_or_none(bound.achieved_value),
                    "adjacent_pu": _string_or_none(bound.adjacent_pu),
                    "adjacent_value": _string_or_none(bound.adjacent_value),
                    "status": bound.status.value,
                    "evaluations": bound.evaluations,
                    "reason": bound.reason,
                }
                for bound in self.effective_bounds
            ],
            "maximum_exit_yield": _string_or_none(self.maximum_exit_yield),
            "rate_solution": _rate_solution_dict(self.rate_solution),
            "evaluations": self.evaluations,
            "reason": self.reason,
        }


def parse_constraint_set(raw: object) -> ConstraintSetDefinition:
    """Parse an exact JSON list; numeric thresholds must be decimal strings."""
    if not isinstance(raw, (list, tuple)) or isinstance(raw, (str, bytes)):
        raise ValidationError("INVALID_CONSTRAINTS", "constraints precisa ser uma lista JSON.")
    if len(raw) > MAX_CONSTRAINTS:
        raise ValidationError("CONSTRAINT_LIMIT", f"O conjunto aceita até {MAX_CONSTRAINTS} critérios.")
    parsed: list[ConstraintDefinition] = []
    allowed = {"id", "metric", "operator", "value", "unit"}
    for index, raw_item in enumerate(raw):
        path = f"constraints[{index}]"
        if not isinstance(raw_item, Mapping) or any(not isinstance(key, str) for key in raw_item):
            raise ValidationError("INVALID_CONSTRAINT", f"{path} precisa ser um objeto JSON.")
        extra = set(raw_item) - allowed
        missing = allowed - set(raw_item)
        if extra:
            raise ValidationError("UNKNOWN_FIELD", f"Campo inesperado em {path}: " + ", ".join(sorted(extra)))
        if missing:
            raise ValidationError("MISSING_FIELD", f"Campo obrigatório ausente em {path}: " + ", ".join(sorted(missing)))
        metric_raw = raw_item["metric"]
        if not isinstance(metric_raw, str):
            raise ValidationError("INVALID_CONSTRAINT", f"{path}.metric precisa ser texto.")
        try:
            metric = ConstraintMetric(metric_raw)
        except ValueError as exc:
            raise ValidationError("INVALID_CONSTRAINT", f"{path}.metric não é suportada.") from exc
        value_raw = raw_item["value"]
        if metric is ConstraintMetric.REQUESTED_ORDER_DATE:
            if not isinstance(value_raw, str) or len(value_raw) != 10:
                raise ValidationError("INVALID_DATE", f"{path}.value precisa estar no formato AAAA-MM-DD.")
            try:
                value: Decimal | date = date.fromisoformat(value_raw)
            except ValueError as exc:
                raise ValidationError("INVALID_DATE", f"{path}.value não é uma data válida.") from exc
            if value.isoformat() != value_raw:
                raise ValidationError("INVALID_DATE", f"{path}.value precisa estar normalizada em AAAA-MM-DD.")
        else:
            if not isinstance(value_raw, str) or not _DECIMAL_TEXT.fullmatch(value_raw):
                raise ValidationError("INVALID_NUMBER_FORMAT", f"{path}.value deve ser texto decimal exato.")
            value = decimal_value(value_raw, f"{path}.value")
        parsed.append(ConstraintDefinition(
            raw_item["id"], metric, raw_item["operator"], value, raw_item["unit"],
        ))
    return ConstraintSetDefinition(tuple(parsed))


def evaluate_constraint_set(
    scenario: Scenario,
    evaluation: ScenarioEvaluation,
    constraints: ConstraintSetDefinition,
) -> ConstraintSetEvaluation:
    """Evaluate criteria on one candidate; real-return basis follows its settlement."""
    operation = evaluation.operation
    step_qualities = {step.name: step.quality.value for step in evaluation.steps}
    quality_steps = {
        ConstraintMetric.NET_REDEMPTION: "Caixa líquido da venda",
        ConstraintMetric.NOMINAL_PROFIT: "Resultado econômico nominal",
        ConstraintMetric.NOMINAL_RETURN: "Retorno nominal simples",
        ConstraintMetric.ANNUALIZED_NOMINAL_RETURN: "Retorno nominal anualizado",
        ConstraintMetric.REAL_RETURN: "Retorno real",
    }
    metrics: dict[ConstraintMetric, MetricEvidence] = {}
    for metric, field in _OPERATION_FIELDS.items():
        value = getattr(operation, field) if operation is not None else None
        status = "ready" if value is not None else (
            "blocked_policy" if evaluation.status == "BLOCKED_POLICY" else "missing_metric"
        )
        metric_warnings = operation.warnings if operation is not None else evaluation.warnings
        unavailable_reason = None
        if value is None:
            unavailable_reason = (
                metric_warnings[0] if status == "blocked_policy" and metric_warnings
                else _unavailable_reason(status) if status == "blocked_policy"
                else _metric_unavailable_reason(metric, operation, metric_warnings)
            )
        metrics[metric] = MetricEvidence(
            value, _UNITS[metric], status,
            step_qualities.get(quality_steps.get(metric, ""), operation.quality.value if operation else None),
            unavailable_reason,
        )
    return evaluate_constraint_metrics(
        constraints,
        requested_order_date=scenario.exit.order_date,
        settlement_date=scenario.exit.settlement_date,
        metrics=metrics,
        base_status=evaluation.status.lower(),
        base_reason="; ".join(evaluation.warnings) if evaluation.warnings else None,
    )


def evaluate_constraint_metrics(
    constraints: ConstraintSetDefinition,
    *,
    requested_order_date: date,
    settlement_date: date,
    metrics: Mapping[ConstraintMetric | str, MetricEvidence | Mapping[str, Any] | Any],
    quality: str | None = None,
    base_status: str = "ready",
    base_reason: str | None = None,
) -> ConstraintSetEvaluation:
    """Evaluate criteria against already calculated operation metrics (no recalculation)."""
    results: list[CriterionEvaluation] = []
    for item in constraints.criteria:
        reference_date = settlement_date if item.metric is ConstraintMetric.REAL_RETURN else None
        if item.metric is ConstraintMetric.REQUESTED_ORDER_DATE:
            achieved: Decimal | date | None = requested_order_date
            margin: Decimal | int | None = (item.value - requested_order_date).days
            status = CriterionStatus.MET if margin >= 0 else CriterionStatus.NOT_MET
            reason = "Data solicitada respeita o prazo." if status is CriterionStatus.MET else "Data solicitada excede o prazo definido."
            results.append(CriterionEvaluation(
                item.constraint_id, item.metric, item.operator, item.value, achieved,
                item.unit, margin, "calendar_days", status, quality, None, reason,
            ))
            continue

        evidence = _metric_evidence(metrics, item.metric)
        if evidence is None or evidence.value is None:
            reason = (evidence.reason if evidence else None) or base_reason or _unavailable_reason(base_status)
            results.append(CriterionEvaluation(
                item.constraint_id, item.metric, item.operator, item.value, None,
                item.unit, None, item.unit, CriterionStatus.UNKNOWN,
                evidence.quality if evidence else quality, reference_date, reason,
            ))
            continue
        if evidence.unit != item.unit:
            results.append(CriterionEvaluation(
                item.constraint_id, item.metric, item.operator, item.value, None,
                item.unit, None, item.unit, CriterionStatus.UNKNOWN,
                evidence.quality or quality, reference_date,
                "Unidade calculada não corresponde à unidade do critério.",
            ))
            continue
        if evidence.status.lower() not in {"ready", "available"}:
            results.append(CriterionEvaluation(
                item.constraint_id, item.metric, item.operator, item.value, None,
                item.unit, None, item.unit, CriterionStatus.UNKNOWN,
                evidence.quality or quality, reference_date,
                evidence.reason or base_reason or _unavailable_reason(evidence.status),
            ))
            continue
        achieved = decimal_value(evidence.value, f"{item.metric.value} calculado")
        margin = achieved - item.value if item.operator is ConstraintOperator.AT_LEAST else item.value - achieved
        status = CriterionStatus.MET if margin >= 0 else CriterionStatus.NOT_MET
        if status is CriterionStatus.MET:
            reason = "Valor calculado respeita o limite."
        elif item.operator is ConstraintOperator.AT_LEAST:
            reason = "Valor calculado ficou abaixo do mínimo."
        else:
            reason = "Valor calculado excedeu o máximo."
        results.append(CriterionEvaluation(
            item.constraint_id, item.metric, item.operator, item.value, achieved,
            item.unit, margin, item.unit, status, evidence.quality or quality,
            reference_date, reason,
        ))

    statuses = {item.status for item in results}
    if not results:
        overall, met = ConstraintSetStatus.NO_CONSTRAINTS, None
    elif CriterionStatus.NOT_MET in statuses:
        overall, met = ConstraintSetStatus.NOT_MET, False
    elif CriterionStatus.UNKNOWN in statuses:
        overall, met = ConstraintSetStatus.UNKNOWN, None
    else:
        overall, met = ConstraintSetStatus.MET, True
    return ConstraintSetEvaluation(overall, met, tuple(results), constraints.fingerprint)


def solve_combined_exit_constraints(
    scenario: Scenario,
    constraints: ConstraintSetDefinition,
    context: EvaluationContext = EvaluationContext(),
    *,
    tick: Decimal | str = "0.01",
    minimum_pu: Decimal | str | None = None,
    maximum_pu: Decimal | str = "1000000000",
    rate_bounds: tuple[Decimal | str, Decimal | str] | None = None,
    rate_tolerance: Decimal | str = "0.000000001",
    rate_step: Decimal | str | None = None,
) -> CombinedExitLimit:
    """Resolve a feasible exit-PU interval using direct scenario evaluation.

    Domains up to 4096 ticks are fully enumerated, including joint feasibility.
    Larger domains use scalar target solvers only to locate candidates and return
    a solved interval only when the required bounds and adjacent ticks are
    directly verified; separate roots cannot silently imply a joint interval.
    """
    if scenario.exit.side is not Side.SELL or scenario.exit.quoted_side is not Side.SELL:
        raise ValidationError("EXIT_CONSTRAINT_SIDE_UNSUPPORTED", "Limite combinado exige cenário de saída PU SELL.")
    increment = decimal_value(tick, "tick de PU")
    maximum = decimal_value(maximum_pu, "PU máximo")
    minimum = increment if minimum_pu is None else decimal_value(minimum_pu, "PU mínimo")
    if increment <= 0 or minimum <= 0 or maximum < minimum:
        raise ValidationError("INVALID_TARGET_DOMAIN", "Tick e domínio de PU inválidos.")
    minimum_ratio = minimum / increment
    if minimum_ratio != minimum_ratio.to_integral_value():
        raise ValidationError("INVALID_TARGET_DOMAIN", "PU mínimo deve coincidir com o tick de PU.")
    minimum_ticks = int(minimum_ratio)
    max_ticks = int((maximum / increment).to_integral_value(rounding=ROUND_FLOOR))
    if minimum_ticks > max_ticks:
        raise ValidationError("INVALID_TARGET_DOMAIN", "PU mínimo excede o PU máximo declarado.")
    domain_minimum_pu = increment * minimum_ticks
    domain_maximum = increment * max_ticks
    domain_ticks = max_ticks - minimum_ticks + 1
    if rate_bounds is not None:
        # Validate the requested conversion domain even if a financial target is
        # unavailable; an invalid domain should never be hidden by missing data.
        low_rate = decimal_value(rate_bounds[0], "taxa mínima")
        high_rate = decimal_value(rate_bounds[1], "taxa máxima")
        if low_rate <= -1 or high_rate <= low_rate:
            raise ValidationError("INVALID_RATE_DOMAIN", "Domínio de taxa inválido.")

    def blank(
        status: CombinedLimitStatus,
        *,
        minimum_pu: Decimal | None = None,
        maximum_allowed_pu: Decimal | None = None,
        candidate_pu: Decimal | None = None,
        verification_pu: Decimal | None = None,
        candidate_eval: ConstraintSetEvaluation | None = None,
        below_pu: Decimal | None = None,
        below_eval: ConstraintSetEvaluation | None = None,
        above_pu: Decimal | None = None,
        above_eval: ConstraintSetEvaluation | None = None,
        minimum_ids: tuple[str, ...] = (),
        maximum_ids: tuple[str, ...] = (),
        bounds: tuple[EffectiveConstraintBound, ...] = (),
        maximum_yield: Decimal | None = None,
        rate_result: RateSolution | None = None,
        evaluations: int = 0,
        reason: str | None = None,
    ) -> CombinedExitLimit:
        return CombinedExitLimit(
            status, constraints.fingerprint, scenario.exit.order_date,
            scenario.exit.settlement_date, domain_minimum_pu, domain_maximum, increment,
            minimum_pu, maximum_allowed_pu, candidate_pu, verification_pu,
            candidate_eval, below_pu, below_eval, above_pu, above_eval,
            minimum_ids, maximum_ids, bounds, maximum_yield, rate_result,
            evaluations, reason,
        )

    if not constraints.criteria:
        return blank(CombinedLimitStatus.NO_CONSTRAINTS, reason="Nenhum critério declarado; não há limite de PU a resolver.")

    financial_evaluations: dict[Decimal, ScenarioEvaluation] = {}

    def direct_at(pu: Decimal) -> ConstraintSetEvaluation:
        candidate = replace(
            scenario,
            exit=replace(
                scenario.exit, unit_price=pu, real_yield=None, side=Side.SELL,
                quoted_side=Side.SELL, spread=None, spread_source=None,
                provenance=None,
            ),
        )
        evaluation = financial_evaluations.get(pu)
        if evaluation is None:
            evaluation = evaluate_scenario(candidate, context)
            financial_evaluations[pu] = evaluation
        return evaluate_constraint_set(candidate, evaluation, constraints)

    cache: dict[Decimal, ConstraintSetEvaluation] = {}

    def checked_at(pu: Decimal) -> ConstraintSetEvaluation:
        if pu not in cache:
            cache[pu] = direct_at(pu)
        return cache[pu]

    def verify_rate_boundary(rate_result: RateSolution | None) -> tuple[RateSolution | None, Decimal | None, int]:
        """Approve a converted rate only after checking the full joint contract."""
        if (rate_result is None
                or rate_result.status not in (TargetStatus.SOLVED, TargetStatus.ALL_DOMAIN)
                or rate_result.rate is None):
            return rate_result, None, 0

        checked_points = 0

        def rate_candidate(rate: Decimal) -> tuple[ScenarioEvaluation, Decimal | None, ConstraintSetEvaluation]:
            nonlocal checked_points
            candidate = replace(
                scenario,
                exit=replace(scenario.exit, unit_price=None, real_yield=rate, provenance=None),
            )
            financial = evaluate_scenario(candidate, context)
            checked_points += 1
            return financial, financial.exit_pu, evaluate_constraint_set(candidate, financial, constraints)

        candidate_financial, candidate_pu, candidate_constraints = rate_candidate(rate_result.rate)
        failure_status = TargetStatus.VERIFICATION_FAILED
        failure_reason: str | None = None
        if candidate_pu is None:
            failure_status = TargetStatus.METRIC_UNAVAILABLE
            failure_reason = "A taxa convertida não produziu PU diretamente avaliável."
        elif candidate_pu < domain_minimum_pu or candidate_pu > domain_maximum:
            failure_reason = "A taxa convertida reprecificou para fora do domínio declarado de PU."
        elif candidate_constraints.status is ConstraintSetStatus.UNKNOWN:
            failure_status = TargetStatus.METRIC_UNAVAILABLE
            failure_reason = "A taxa convertida deixou critério conjunto sem dado suficiente."
        elif candidate_constraints.status is not ConstraintSetStatus.MET:
            failure_reason = "A taxa convertida não atende diretamente ao conjunto completo de critérios."
        elif rate_result.pu_at_rate != candidate_pu:
            failure_reason = "O PU da taxa mudou na reavaliação direta da fronteira."

        adjacent_pu = rate_result.adjacent_pu
        if failure_reason is None and rate_result.status is TargetStatus.SOLVED:
            if rate_result.adjacent_rate is None:
                failure_reason = "A taxa convertida não preservou a adjacência que prova a fronteira."
            else:
                _, adjacent_pu, adjacent_constraints = rate_candidate(rate_result.adjacent_rate)
                if adjacent_pu is None:
                    failure_status = TargetStatus.METRIC_UNAVAILABLE
                    failure_reason = "A taxa adjacente não produziu PU diretamente avaliável."
                elif adjacent_pu != rate_result.adjacent_pu:
                    failure_reason = "O PU da taxa adjacente mudou na reavaliação direta."
                elif (domain_minimum_pu <= adjacent_pu <= domain_maximum
                      and adjacent_constraints.status is ConstraintSetStatus.UNKNOWN):
                    failure_status = TargetStatus.METRIC_UNAVAILABLE
                    failure_reason = "A taxa adjacente deixou critério conjunto sem dado suficiente."
                elif (domain_minimum_pu <= adjacent_pu <= domain_maximum
                      and adjacent_constraints.status is ConstraintSetStatus.MET):
                    failure_reason = "A taxa adjacente também atende ao conjunto completo de critérios."

        if failure_reason is not None:
            return replace(
                rate_result, status=failure_status, pu_at_rate=candidate_pu,
                adjacent_pu=adjacent_pu, reason=failure_reason,
            ), None, checked_points
        return replace(
            rate_result, pu_at_rate=candidate_pu, adjacent_pu=adjacent_pu,
        ), rate_result.rate, checked_points

    financial = [item for item in constraints.criteria if item.metric is not ConstraintMetric.REQUESTED_ORDER_DATE]
    if not financial:
        set_evaluation = evaluate_constraint_metrics(
            constraints,
            requested_order_date=scenario.exit.order_date,
            settlement_date=scenario.exit.settlement_date,
            metrics={},
        )
        status = (
            CombinedLimitStatus.NO_FINANCIAL_BOUND if set_evaluation.status is ConstraintSetStatus.MET
            else CombinedLimitStatus.INFEASIBLE if set_evaluation.status is ConstraintSetStatus.NOT_MET
            else CombinedLimitStatus.UNKNOWN
        )
        return blank(
            status,
            candidate_pu=scenario.exit.unit_price,
            verification_pu=scenario.exit.unit_price,
            candidate_eval=set_evaluation,
            evaluations=0,
            reason=("Os critérios só limitam a data solicitada; PU atual preservado sem inventar alvo financeiro."
                    if status is CombinedLimitStatus.NO_FINANCIAL_BOUND
                    else "Data solicitada excede o prazo; não há PU que possa corrigir este critério."
                    if status is CombinedLimitStatus.INFEASIBLE
                    else "O critério de data não pôde ser avaliado."),
        )

    effective: list[tuple[ConstraintMetric, ConstraintOperator, Decimal, tuple[str, ...]]] = []
    for metric in ConstraintMetric:
        if metric is ConstraintMetric.REQUESTED_ORDER_DATE:
            continue
        for operator in (ConstraintOperator.AT_LEAST, ConstraintOperator.AT_MOST):
            matching = [item for item in financial if item.metric is metric and item.operator is operator]
            if not matching:
                continue
            strongest = (max if operator is ConstraintOperator.AT_LEAST else min)(item.value for item in matching)
            identifiers = tuple(item.constraint_id for item in matching if item.value == strongest)
            effective.append((metric, operator, strongest, identifiers))

    if domain_ticks <= _MAX_EXACT_COMBINED_PU_TICKS:
        exact_rows: dict[int, ConstraintSetEvaluation] = {}
        feasible_ticks: list[int] = []
        has_unknown = False
        for ticks in range(minimum_ticks, max_ticks + 1):
            pu = increment * ticks
            checked = checked_at(pu)
            exact_rows[ticks] = checked
            if financial_evaluations[pu].status == "BLOCKED_POLICY":
                return blank(
                    CombinedLimitStatus.BLOCKED_POLICY, evaluations=len(financial_evaluations),
                    reason="Produto bloqueado por política em PU do domínio diretamente coberto.",
                )
            if checked.status is ConstraintSetStatus.UNKNOWN:
                has_unknown = True
            elif checked.status is ConstraintSetStatus.MET:
                feasible_ticks.append(ticks)

        if has_unknown:
            return blank(
                CombinedLimitStatus.UNKNOWN, evaluations=len(financial_evaluations),
                reason="Há PU do domínio sem dados suficientes para classificar todos os critérios.",
            )
        if not feasible_ticks:
            return blank(
                CombinedLimitStatus.INFEASIBLE, evaluations=len(financial_evaluations),
                reason="Nenhum tick do domínio declarado atende ao conjunto completo de critérios.",
            )
        first_feasible, last_feasible = feasible_ticks[0], feasible_ticks[-1]
        if len(feasible_ticks) != last_feasible - first_feasible + 1:
            return blank(
                CombinedLimitStatus.AMBIGUOUS, evaluations=len(financial_evaluations),
                reason=("A cobertura direta encontrou ilhas de PU viáveis separadas; "
                        "a resposta de intervalo único não pode representá-las."),
            )

        has_minimum = any(operator is ConstraintOperator.AT_LEAST
                          for _, operator, _, _ in effective)
        has_maximum = any(operator is ConstraintOperator.AT_MOST
                          for _, operator, _, _ in effective)

        def criteria_by_id(ticks: int) -> dict[str, CriterionEvaluation]:
            return {item.constraint_id: item for item in exact_rows[ticks].criteria}

        exact_bounds: list[EffectiveConstraintBound] = []
        for metric, operator, threshold, identifiers in effective:
            passes = []
            group_has_unknown = False
            for ticks in range(minimum_ticks, max_ticks + 1):
                by_id = criteria_by_id(ticks)
                statuses = [by_id[identifier].status for identifier in identifiers]
                group_has_unknown = group_has_unknown or any(
                    status is CriterionStatus.UNKNOWN for status in statuses
                )
                if statuses and all(status is CriterionStatus.MET for status in statuses):
                    passes.append(ticks)
            if group_has_unknown:
                exact_bounds.append(EffectiveConstraintBound(
                    identifiers, metric, operator, threshold, None, None, None, None,
                    TargetStatus.METRIC_UNAVAILABLE, domain_ticks,
                    "Critério sem dado em pelo menos um tick diretamente avaliado.",
                ))
                continue
            if not passes:
                exact_bounds.append(EffectiveConstraintBound(
                    identifiers, metric, operator, threshold, None, None, None, None,
                    TargetStatus.UNATTAINABLE, domain_ticks,
                    "Critério não foi atendido em nenhum tick do domínio enumerado.",
                ))
                continue
            if len(passes) == domain_ticks:
                bound_pu = domain_maximum if operator is ConstraintOperator.AT_MOST else domain_minimum_pu
                achieved = criteria_by_id(max_ticks if operator is ConstraintOperator.AT_MOST else minimum_ticks)[identifiers[0]].achieved_value
                exact_bounds.append(EffectiveConstraintBound(
                    identifiers, metric, operator, threshold, bound_pu,
                    achieved if isinstance(achieved, Decimal) else None, None, None,
                    TargetStatus.ALL_DOMAIN, domain_ticks,
                    "Critério atendido em todo o domínio diretamente enumerado.",
                ))
                continue
            if operator is ConstraintOperator.AT_LEAST:
                bound_tick = passes[0]
                shape_proven = passes == list(range(bound_tick, max_ticks + 1))
                adjacent_tick = bound_tick - 1 if bound_tick > minimum_ticks else None
            else:
                bound_tick = passes[-1]
                shape_proven = passes == list(range(minimum_ticks, bound_tick + 1))
                adjacent_tick = bound_tick + 1 if bound_tick < max_ticks else None
            by_id = criteria_by_id(bound_tick)
            achieved = by_id[identifiers[0]].achieved_value
            adjacent_value = None
            adjacent_pu = None
            if adjacent_tick is not None:
                adjacent_pu = increment * adjacent_tick
                adjacent_value = criteria_by_id(adjacent_tick)[identifiers[0]].achieved_value
            exact_bounds.append(EffectiveConstraintBound(
                identifiers, metric, operator, threshold,
                increment * bound_tick if shape_proven else None,
                achieved if isinstance(achieved, Decimal) else None,
                adjacent_pu, adjacent_value if isinstance(adjacent_value, Decimal) else None,
                TargetStatus.SOLVED if shape_proven else TargetStatus.AMBIGUOUS_ROOT,
                domain_ticks,
                "Limite diretamente enumerado." if shape_proven
                else "Critério tem região viável descontínua no domínio enumerado.",
            ))

        lower = increment * first_feasible if has_minimum else None
        upper = increment * last_feasible if has_maximum else None
        minimum_ids: tuple[str, ...] = ()
        maximum_ids: tuple[str, ...] = ()

        def boundary_ids(boundary_tick: int, neighbor_tick: int | None,
                         operator: ConstraintOperator) -> tuple[str, ...]:
            at = criteria_by_id(boundary_tick)
            neighbor = criteria_by_id(neighbor_tick) if neighbor_tick is not None else None
            identifiers: set[str] = set()
            for _, bound_operator, _, group_ids in effective:
                if bound_operator is not operator:
                    continue
                if all(at[item].status is CriterionStatus.MET for item in group_ids):
                    if neighbor is None or any(neighbor[item].status is CriterionStatus.NOT_MET
                                               for item in group_ids):
                        identifiers.update(group_ids)
            return tuple(sorted(identifiers))

        if has_minimum:
            below_tick = first_feasible - 1 if first_feasible > minimum_ticks else None
            minimum_ids = boundary_ids(first_feasible, below_tick, ConstraintOperator.AT_LEAST)
        if has_maximum:
            above_tick = last_feasible + 1 if last_feasible < max_ticks else None
            maximum_ids = boundary_ids(last_feasible, above_tick, ConstraintOperator.AT_MOST)

        candidate_tick = first_feasible if has_minimum else last_feasible
        candidate_pu = increment * candidate_tick
        candidate_eval = exact_rows[candidate_tick]
        below_tick = first_feasible - 1 if has_minimum and first_feasible > minimum_ticks else None
        above_tick = last_feasible + 1 if has_maximum and last_feasible < max_ticks else None
        below_pu = increment * below_tick if below_tick is not None else None
        above_pu = increment * above_tick if above_tick is not None else None
        rate_result = None
        maximum_yield = None
        exact_evaluations = len(financial_evaluations)
        if lower is not None and rate_bounds is not None:
            rate_result = solve_rate_for_pu_limit(
                scenario, "EXIT", lower, context,
                minimum_yield=rate_bounds[0], maximum_yield=rate_bounds[1],
                tolerance=rate_tolerance, rate_step=rate_step,
            )
            rate_result, maximum_yield, checked_rate_points = verify_rate_boundary(rate_result)
            exact_evaluations += rate_result.evaluations + checked_rate_points
        return blank(
            CombinedLimitStatus.SOLVED, minimum_pu=lower,
            maximum_allowed_pu=upper, candidate_pu=candidate_pu,
            verification_pu=candidate_pu, candidate_eval=candidate_eval,
            below_pu=below_pu, below_eval=exact_rows[below_tick] if below_tick is not None else None,
            above_pu=above_pu, above_eval=exact_rows[above_tick] if above_tick is not None else None,
            minimum_ids=minimum_ids, maximum_ids=maximum_ids,
            bounds=tuple(exact_bounds), maximum_yield=maximum_yield,
            rate_result=rate_result, evaluations=exact_evaluations,
            reason="Faixa viável contígua confirmada por avaliação direta de todos os ticks do domínio declarado.",
        )

    effective_bounds: list[EffectiveConstraintBound] = []
    evaluations = 0
    minimum_candidates: list[tuple[Decimal, tuple[str, ...]]] = []
    maximum_candidates: list[tuple[Decimal, tuple[str, ...]]] = []

    def total_evaluations() -> int:
        return evaluations + len(financial_evaluations)

    def failed_solver_status(status: TargetStatus) -> CombinedLimitStatus:
        if status is TargetStatus.BLOCKED_POLICY:
            return CombinedLimitStatus.BLOCKED_POLICY
        if status in (TargetStatus.AMBIGUOUS_ROOT, TargetStatus.NO_ROOT):
            return CombinedLimitStatus.AMBIGUOUS
        if status is TargetStatus.VERIFICATION_FAILED:
            return CombinedLimitStatus.VERIFICATION_FAILED
        return CombinedLimitStatus.UNKNOWN

    for metric, operator, threshold, identifiers in effective:
        target_metric = TargetMetric(metric.value)
        target_date = scenario.exit.settlement_date if metric is ConstraintMetric.REAL_RETURN else None
        if operator is ConstraintOperator.AT_MOST:
            ceiling: ExitPuCeilingSolution = solve_maximum_exit_pu(
                scenario, target_metric, threshold, _UNITS[metric], context,
                increment, maximum, target_date,
                minimum_pu=domain_minimum_pu,
                evaluation_cache=financial_evaluations,
            )
            effective_bounds.append(EffectiveConstraintBound(
                identifiers, metric, operator, threshold, ceiling.pu,
                ceiling.achieved_value, ceiling.adjacent_pu, ceiling.adjacent_value,
                ceiling.status, ceiling.evaluations, ceiling.reason,
            ))
            if ceiling.status is TargetStatus.UNATTAINABLE:
                return blank(
                    CombinedLimitStatus.INFEASIBLE, bounds=tuple(effective_bounds),
                    evaluations=total_evaluations(),
                    reason=ceiling.reason or "O teto é excedido no menor PU do domínio declarado.",
                )
            if ceiling.status is TargetStatus.ALL_DOMAIN:
                maximum_candidates.append((domain_maximum, ()))
                continue
            if ceiling.status is not TargetStatus.SOLVED or ceiling.pu is None:
                return blank(
                    failed_solver_status(ceiling.status), bounds=tuple(effective_bounds),
                    evaluations=total_evaluations(),
                    reason=ceiling.reason or "Teto sem limite adjacente verificado no domínio declarado.",
                )
            maximum_candidates.append((ceiling.pu, identifiers))
            continue

        target = TargetDefinition(target_metric, threshold, _UNITS[metric], target_date)
        solution: TargetSolution = solve_minimum_exit_pu(
            scenario, target, context, increment, maximum,
            minimum_pu=domain_minimum_pu,
            evaluation_cache=financial_evaluations,
        )
        if operator is ConstraintOperator.AT_LEAST:
            effective_bounds.append(EffectiveConstraintBound(
                identifiers, metric, operator, threshold, solution.pu,
                solution.achieved_value, solution.neighbor_pu, solution.neighbor_value,
                solution.status, solution.evaluations, solution.reason,
            ))
            if solution.status is not TargetStatus.SOLVED or solution.pu is None:
                status = CombinedLimitStatus.INFEASIBLE if solution.status is TargetStatus.UNATTAINABLE else failed_solver_status(solution.status)
                return blank(
                    status, bounds=tuple(effective_bounds), evaluations=total_evaluations(),
                    reason=solution.reason or "Uma meta mínima não possui limite verificável no domínio declarado.",
                )
            minimum_candidates.append((solution.pu, identifiers))
            continue

    lower = max((item[0] for item in minimum_candidates), default=None)
    upper = min((item[0] for item in maximum_candidates), default=None)
    if upper is None and minimum_candidates:
        # No upper criterion was present; the maximum PU is the domain limit,
        # but it is not advertised as a proven maximum satisfying boundary.
        maximum_allowed = None
    else:
        maximum_allowed = upper
    minimum_ids = tuple(sorted({identifier for pu, identifiers in minimum_candidates if pu == lower for identifier in identifiers})) if lower is not None else ()
    maximum_ids = tuple(sorted({identifier for pu, identifiers in maximum_candidates if pu == upper for identifier in identifiers})) if upper is not None else ()

    if lower is not None and upper is not None and lower > upper:
        attempted = checked_at(lower)
        return blank(
            CombinedLimitStatus.INFEASIBLE, minimum_pu=lower, maximum_allowed_pu=upper,
            verification_pu=lower, candidate_eval=attempted,
            minimum_ids=minimum_ids, maximum_ids=maximum_ids,
            bounds=tuple(effective_bounds), evaluations=total_evaluations(),
            reason="Limite mínimo de PU excede o teto; não existe interseção de critérios no domínio.",
        )

    candidate_pu = lower if lower is not None else upper
    if candidate_pu is None:
        return blank(
            CombinedLimitStatus.NO_FINANCIAL_BOUND,
            bounds=tuple(effective_bounds), evaluations=total_evaluations(),
            reason="Nenhum critério financeiro forneceu um limite de PU aplicável.",
        )

    candidate_eval = checked_at(candidate_pu)
    if candidate_eval.status is ConstraintSetStatus.UNKNOWN:
        return blank(
            CombinedLimitStatus.UNKNOWN, minimum_pu=lower, maximum_allowed_pu=maximum_allowed,
            candidate_pu=candidate_pu, verification_pu=candidate_pu,
            candidate_eval=candidate_eval, minimum_ids=minimum_ids, maximum_ids=maximum_ids,
            bounds=tuple(effective_bounds), evaluations=total_evaluations(),
            reason="Pelo menos um critério ficou sem dado no candidato combinado.",
        )
    if candidate_eval.status is not ConstraintSetStatus.MET:
        failed_deadline = any(
            item.metric is ConstraintMetric.REQUESTED_ORDER_DATE
            and item.status is CriterionStatus.NOT_MET
            for item in candidate_eval.criteria
        )
        status = CombinedLimitStatus.INFEASIBLE if failed_deadline else CombinedLimitStatus.VERIFICATION_FAILED
        return blank(
            status, minimum_pu=lower,
            maximum_allowed_pu=maximum_allowed, candidate_pu=candidate_pu,
            verification_pu=candidate_pu, candidate_eval=candidate_eval,
            minimum_ids=minimum_ids, maximum_ids=maximum_ids,
            bounds=tuple(effective_bounds), evaluations=total_evaluations(),
            reason=("Data solicitada viola o prazo; candidato excluído sem mover a data financeira."
                    if failed_deadline else "A reavaliação direta não confirmou todos os critérios no candidato."),
        )

    below_pu = lower - increment if lower is not None and lower > domain_minimum_pu else None
    below_eval = checked_at(below_pu) if below_pu is not None else None
    if below_eval is not None and below_eval.status is not ConstraintSetStatus.NOT_MET:
        status = CombinedLimitStatus.UNKNOWN if below_eval.status is ConstraintSetStatus.UNKNOWN else CombinedLimitStatus.VERIFICATION_FAILED
        return blank(
            status, minimum_pu=lower, maximum_allowed_pu=maximum_allowed,
            candidate_pu=candidate_pu, verification_pu=lower,
            candidate_eval=candidate_eval, below_pu=below_pu, below_eval=below_eval,
            minimum_ids=minimum_ids, maximum_ids=maximum_ids,
            bounds=tuple(effective_bounds), evaluations=evaluations,
            reason="O tick anterior não demonstrou que o limite inferior é necessário.",
        )

    above_pu = upper + increment if upper is not None and upper < domain_maximum else None
    above_eval = checked_at(above_pu) if above_pu is not None else None
    if above_eval is not None and above_eval.status is not ConstraintSetStatus.NOT_MET:
        status = CombinedLimitStatus.UNKNOWN if above_eval.status is ConstraintSetStatus.UNKNOWN else CombinedLimitStatus.VERIFICATION_FAILED
        return blank(
            status, minimum_pu=lower, maximum_allowed_pu=maximum_allowed,
            candidate_pu=candidate_pu, verification_pu=upper,
            candidate_eval=candidate_eval, below_pu=below_pu, below_eval=below_eval,
            above_pu=above_pu, above_eval=above_eval,
            minimum_ids=minimum_ids, maximum_ids=maximum_ids,
            bounds=tuple(effective_bounds), evaluations=total_evaluations(),
            reason="O tick posterior não demonstrou que o teto combinado é limitante.",
        )

    rate_result = None
    maximum_yield = None
    if lower is not None and rate_bounds is not None:
        rate_result = solve_rate_for_pu_limit(
            scenario, "EXIT", lower, context,
            minimum_yield=rate_bounds[0], maximum_yield=rate_bounds[1],
            tolerance=rate_tolerance, rate_step=rate_step,
        )
        rate_result, maximum_yield, checked_rate_points = verify_rate_boundary(rate_result)
        evaluations += rate_result.evaluations + checked_rate_points

    if lower is not None and upper is not None:
        return blank(
            CombinedLimitStatus.AMBIGUOUS, minimum_pu=lower,
            maximum_allowed_pu=maximum_allowed, candidate_pu=candidate_pu,
            verification_pu=candidate_pu, candidate_eval=candidate_eval,
            below_pu=below_pu, below_eval=below_eval,
            above_pu=above_pu, above_eval=above_eval,
            minimum_ids=minimum_ids, maximum_ids=maximum_ids,
            bounds=tuple(effective_bounds), maximum_yield=maximum_yield,
            rate_result=rate_result, evaluations=total_evaluations(),
            reason=("Os limites escalares foram preservados, mas a contiguidade do conjunto completo "
                    "não foi provada no domínio amplo."),
        )

    return blank(
        CombinedLimitStatus.SOLVED, minimum_pu=lower,
        maximum_allowed_pu=maximum_allowed, candidate_pu=candidate_pu,
        verification_pu=candidate_pu, candidate_eval=candidate_eval,
        below_pu=below_pu, below_eval=below_eval,
        above_pu=above_pu, above_eval=above_eval,
        minimum_ids=minimum_ids, maximum_ids=maximum_ids,
        bounds=tuple(effective_bounds), maximum_yield=maximum_yield,
        rate_result=rate_result, evaluations=total_evaluations(),
        reason=("Critérios verificados por avaliação direta; PU pertence ao limite discreto declarado."
                if rate_result is None or maximum_yield is not None
                else "PU combinado verificado; a taxa convertida não foi aprovada: "
                f"{rate_result.reason or 'verificação da fronteira incompleta'}."),
    )


def _metric_evidence(
    metrics: Mapping[ConstraintMetric | str, MetricEvidence | Mapping[str, Any] | Any],
    metric: ConstraintMetric,
) -> MetricEvidence | None:
    raw = metrics.get(metric, metrics.get(metric.value, metrics.get(metric.value.lower())))
    if raw is None:
        return None
    if isinstance(raw, MetricEvidence):
        return raw
    if isinstance(raw, Mapping):
        return MetricEvidence(
            raw.get("value"), str(raw.get("unit", "")),
            str(raw.get("status", "ready")), raw.get("quality"), raw.get("reason"),
        )
    return MetricEvidence(getattr(raw, "value", None), str(getattr(raw, "unit", "")),
                          str(getattr(getattr(raw, "status", "ready"), "value", getattr(raw, "status", "ready"))).lower(),
                          str(getattr(getattr(raw, "quality", None), "value", getattr(raw, "quality", ""))) or None,
                          getattr(raw, "reason", None))


def _unavailable_reason(status: str) -> str:
    if status.lower() in {"blocked_policy", "blocked", "ineligible"}:
        return "Avaliação bloqueada pela política; critério permanece sem dado."
    return "Métrica indisponível com os insumos deste candidato."


def _metric_unavailable_reason(
    metric: ConstraintMetric,
    operation: Any,
    warnings: tuple[str, ...],
) -> str:
    warning = next((item for item in warnings if "custos pagos em datas intermediárias" in item.lower()), None)
    if metric in (ConstraintMetric.NOMINAL_RETURN, ConstraintMetric.ANNUALIZED_NOMINAL_RETURN) and warning:
        return warning
    if metric is ConstraintMetric.REAL_RETURN:
        if warning:
            return warning
        return "Retorno real indisponível sem níveis datados do índice em todas as datas dos fluxos."
    if metric in (ConstraintMetric.NOMINAL_RETURN, ConstraintMetric.ANNUALIZED_NOMINAL_RETURN):
        return "Retorno indisponível para os fluxos deste candidato."
    if warnings:
        return warnings[0]
    if operation is None:
        return "Avaliação financeira ausente para este candidato."
    return "Métrica indisponível para este candidato."


def _canonical_value(value: Decimal | date) -> str:
    if isinstance(value, date):
        return value.isoformat()
    if value == 0:
        return "0"
    text = format(value, "f")
    return text.rstrip("0").rstrip(".") if "." in text else text


def _string_or_none(value: Any) -> str | None:
    if value is None:
        return None
    if isinstance(value, (date, datetime)):
        return value.isoformat()
    return str(value)


def _evaluation_dict(value: ConstraintSetEvaluation | None) -> dict[str, Any] | None:
    if value is None:
        return None
    return {
        "status": value.status.value,
        "met": value.met,
        "fingerprint": value.fingerprint,
        "criteria": [
            {
                "id": item.constraint_id,
                "metric": item.metric.value,
                "operator": item.operator.value,
                "target_value": _string_or_none(item.target_value),
                "achieved_value": _string_or_none(item.achieved_value),
                "unit": item.unit,
                "margin": _string_or_none(item.margin),
                "margin_unit": item.margin_unit,
                "status": item.status.value,
                "quality": item.quality,
                "reference_date": _string_or_none(item.reference_date),
                "reason": item.reason,
            }
            for item in value.criteria
        ],
    }


def search_first_date(
    candidates: Any,
    constraints: ConstraintSetDefinition,
    evaluate_candidate: Any,
    *,
    budget: Any,
    fixed_exit_condition: Mapping[str, Any],
    date_domain: Mapping[str, Any],
) -> dict[str, Any]:
    """Find the earliest directly verified meeting date in a declared domain.

    ``candidates`` must yield eligible order sessions in chronological order.
    The callback re-resolves settlement and financial inputs for each date and
    returns either a known exclusion, an unknown candidate, or a direct
    ``ScenarioEvaluation`` plus its criteria evaluation. Unknown earlier dates
    are retained as blockers; a later success is never promoted to first.
    """
    previous: list[dict[str, Any]] = []
    best: dict[str, Any] | None = None
    unknown_before = False
    candidate_count = 0
    found: dict[str, Any] | None = None
    incomplete_reason: str | None = None

    for order_date in candidates:
        if not budget.try_consume():
            incomplete_reason = budget.reason or "SEARCH_BUDGET_EXHAUSTED"
            break
        candidate_count += 1
        attempt = evaluate_candidate(order_date)
        if attempt.get("status") == "EXCLUDED":
            previous.append({
                "order_date": order_date.isoformat(), "status": "EXCLUDED",
                "reason": attempt.get("reason") or "Data excluída por regra de elegibilidade.",
            })
            continue
        constraint_evaluation = attempt.get("constraint_evaluation")
        if constraint_evaluation is None:
            unknown_before = True
            previous.append({
                "order_date": order_date.isoformat(), "settlement_date": attempt.get("settlement_date"),
                "status": "UNKNOWN", "reason": attempt.get("reason") or "Candidato não pôde ser avaliado diretamente.",
            })
            continue

        evaluation_dict = _evaluation_dict(constraint_evaluation)
        candidate = {
            "order_date": order_date.isoformat(),
            "settlement_date": attempt.get("settlement_date"),
            "status": constraint_evaluation.status.value,
            "met": constraint_evaluation.met,
            "constraint_evaluation": evaluation_dict,
            "financial_result": attempt.get("financial_result"),
        }
        if best is None or _candidate_quality(candidate) > _candidate_quality(best):
            best = candidate
        if constraint_evaluation.status is ConstraintSetStatus.MET:
            found = candidate
            break
        if constraint_evaluation.status is ConstraintSetStatus.UNKNOWN:
            unknown_before = True
        previous.append({
            "order_date": order_date.isoformat(),
            "settlement_date": attempt.get("settlement_date"),
            "status": constraint_evaluation.status.value,
            "met": constraint_evaluation.met,
            "criteria": evaluation_dict["criteria"],
        })

    if found is not None:
        verified = not unknown_before
        status = "FOUND" if verified else "INCOMPLETE"
        reason = (
            "Primeira sessão verificada no domínio declarado; todas as sessões elegíveis anteriores foram avaliadas ou excluídas por regra explícita."
            if verified else
            "Há sessão elegível anterior sem dado; este é um candidato atendido, mas não é possível afirmar que seja a primeira data."
        )
        best = found
    elif incomplete_reason is not None:
        status = "INCOMPLETE"
        reason = "O orçamento de busca terminou antes de cobrir todas as sessões elegíveis do domínio."
    elif candidate_count == 0:
        status = "OUTSIDE_DOMAIN"
        reason = "O domínio não contém sessão de venda elegível para esta operação e calendário."
    elif unknown_before:
        status = "UNKNOWN"
        reason = "A busca cobriu o domínio, mas pelo menos um candidato não pôde ser avaliado com os dados disponíveis."
    else:
        status = "NO_SOLUTION"
        reason = "Todas as sessões elegíveis do domínio foram avaliadas e nenhuma atende ao conjunto de critérios."

    return {
        "status": status,
        "found_date": None if found is None else found["order_date"],
        "settlement_date": None if found is None else found["settlement_date"],
        "first_verified": bool(found is not None and not unknown_before),
        "fixed_exit_condition": dict(fixed_exit_condition),
        "date_domain": dict(date_domain),
        "candidate": found,
        "best_candidate": best,
        "previous_coverage": {
            "covered_candidates": len(previous),
            "unknown_candidates": sum(item["status"] == "UNKNOWN" for item in previous),
            "excluded_candidates": sum(item["status"] == "EXCLUDED" for item in previous),
            "entries": previous,
            "complete_before_found_date": found is not None and not unknown_before,
        },
        "coverage": {
            "evaluated_candidates": candidate_count,
            "exhaustive_in_declared_domain": incomplete_reason is None and found is None,
            "proof_scope": "Somente o domínio de datas declarado e o calendário identificado; não certifica datas fora dele nem exceções de sessão não cobertas.",
        },
        "budget": budget.to_dict(),
        "constraints_fingerprint": constraints.fingerprint,
        "reason": reason,
        "incomplete_reason": incomplete_reason,
    }


def _candidate_quality(candidate: Mapping[str, Any]) -> tuple[int, int, int]:
    criteria = (candidate.get("constraint_evaluation") or {}).get("criteria", ())
    met = sum(item.get("status") == "MET" for item in criteria)
    unknown = sum(item.get("status") == "UNKNOWN" for item in criteria)
    order_date = date.fromisoformat(str(candidate.get("order_date")))
    return met, -unknown, -order_date.toordinal()


def _request_deadline_exceeded(budget: Any) -> bool:
    """Observe the public budget deadline query without consuming an evaluation."""
    return budget.check_deadline()


def search_maximum_entry_pu(
    scenario: Scenario,
    constraints: ConstraintSetDefinition,
    evaluate_candidate: Callable[[Decimal], EntrySearchPoint],
    *,
    entry_mode: str,
    budget: Any,
    pu_domain: Mapping[str, Any],
    maximum_affordable_pu: Decimal | str | None = None,
    fixed_entry_fee: Decimal | str = "0",
) -> dict[str, Any]:
    """Find the greatest entry PU in a declared, tick-aligned domain.

    Fixed quantity uses the existing per-target monotonic solver when every
    criterion is a lower bound. Fixed budget enumerates each affordable PU tick
    from high to low because quantity steps can make the combined result
    non-monotonic. Both paths rebuild and directly verify the candidate and its
    next higher tick before claiming a maximum.
    """
    if entry_mode not in {"BUDGET", "QUANTITY"}:
        raise ValidationError("INVALID_ENTRY_MODE", "entry_mode precisa ser BUDGET ou QUANTITY.")
    if not constraints.criteria:
        raise ValidationError("MISSING_CONSTRAINTS", "A busca de entrada exige ao menos um critério.")
    if not isinstance(pu_domain, Mapping) or set(pu_domain) != {"minimum", "maximum", "tick"}:
        raise ValidationError("INVALID_TARGET_DOMAIN", "pu_domain exige minimum, maximum e tick.")
    increment = decimal_value(pu_domain["tick"], "tick de PU")
    minimum = decimal_value(pu_domain["minimum"], "PU mínimo")
    requested_maximum = decimal_value(pu_domain["maximum"], "PU máximo")
    if increment <= 0 or minimum <= 0 or requested_maximum < minimum:
        raise ValidationError("INVALID_TARGET_DOMAIN", "Domínio de PU precisa ser positivo e crescente.")
    minimum_ratio, maximum_ratio = minimum / increment, requested_maximum / increment
    if minimum_ratio != minimum_ratio.to_integral_value() or maximum_ratio != maximum_ratio.to_integral_value():
        raise ValidationError("INVALID_TARGET_DOMAIN", "Limites do domínio precisam coincidir com o tick de PU.")
    minimum_ticks, requested_maximum_ticks = int(minimum_ratio), int(maximum_ratio)
    fixed_fee = decimal_value(fixed_entry_fee, "despesa fixa de entrada")
    if fixed_fee < 0:
        raise ValidationError("INVALID_ENTRY_FEE", "Despesa fixa de entrada não pode ser negativa.")
    effective_maximum = requested_maximum
    if maximum_affordable_pu is not None:
        affordable = decimal_value(maximum_affordable_pu, "PU máximo dimensionável")
        if affordable < 0 or affordable / increment != (affordable / increment).to_integral_value():
            raise ValidationError("INVALID_TARGET_DOMAIN", "PU máximo dimensionável precisa coincidir com o tick.")
        effective_maximum = min(requested_maximum, affordable)
    if effective_maximum < minimum:
        return {
            "status": EntryBoundaryStatus.OUTSIDE_DOMAIN.value,
            "entry_mode": entry_mode,
            "maximum_entry_pu": None,
            "candidate": None,
            "verification": None,
            "domain": {"minimum_pu": str(minimum), "maximum_pu": str(requested_maximum),
                       "effective_maximum_pu": str(effective_maximum), "tick": str(increment)},
            "coverage": {"method": "direct_discrete_entry_sizing", "evaluated_candidates": 0,
                         "complete_for_maximum": True, "excluded_above_effective_maximum": "INSUFFICIENT_BUDGET"},
            "constraints_fingerprint": constraints.fingerprint,
            "reason": "O orçamento não compra a menor quantidade em nenhuma PU dentro do domínio declarado.",
        }
    effective_maximum_ticks = int(effective_maximum / increment)
    cache: dict[Decimal, tuple[EntrySearchPoint, ConstraintSetEvaluation | None]] = {}

    class _BudgetExceeded(Exception):
        pass

    class _CandidateUnavailable(Exception):
        pass

    def exit_condition_is_frozen(candidate: Scenario) -> bool:
        expected, actual = scenario.exit, candidate.exit
        return (
            candidate.instrument == scenario.instrument
            and candidate.entry.instrument_id == scenario.entry.instrument_id
            and candidate.entry.order_date == scenario.entry.order_date
            and candidate.entry.settlement_date == scenario.entry.settlement_date
            and candidate.as_of == scenario.as_of
            and (
                actual.instrument_id, actual.order_date, actual.settlement_date,
                actual.side, actual.unit_price, actual.real_yield,
                actual.quoted_side, actual.spread, actual.spread_source,
            ) == (
                expected.instrument_id, expected.order_date, expected.settlement_date,
                expected.side, expected.unit_price, expected.real_yield,
                expected.quoted_side, expected.spread, expected.spread_source,
            )
        )

    def point_at(pu: Decimal) -> tuple[EntrySearchPoint, ConstraintSetEvaluation | None]:
        if pu in cache:
            return cache[pu]
        if not budget.try_consume():
            raise _BudgetExceeded
        point = evaluate_candidate(pu)
        if not isinstance(point, EntrySearchPoint):
            raise ValidationError("INVALID_ENTRY_EVALUATION", "O avaliador precisa retornar EntrySearchPoint.")
        if point.status == "EVALUATED":
            if point.scenario is None or point.financial_result is None or point.quantity is None:
                raise ValidationError("INVALID_ENTRY_EVALUATION", "Candidato avaliado precisa conter cenário, motor e quantidade.")
            if point.scenario.entry.unit_price != pu or point.scenario.entry.quantity != point.quantity:
                raise ValidationError("ENTRY_CANDIDATE_MISMATCH", "PU e quantidade do candidato não correspondem à avaliação direta.")
            if not exit_condition_is_frozen(point.scenario):
                raise ValidationError("ENTRY_CANDIDATE_CONTEXT_CHANGED", "A busca alterou produto, datas ou condição de saída congelada.")
            evaluated = evaluate_constraint_set(point.scenario, point.financial_result, constraints)
        else:
            evaluated = None
        cache[pu] = (point, evaluated)
        return cache[pu]

    def candidate_dict(pu: Decimal, point: EntrySearchPoint,
                       evaluated: ConstraintSetEvaluation | None) -> dict[str, Any]:
        return {
            "entry_pu": str(pu),
            "quantity": None if point.quantity is None else {"value": str(point.quantity), "unit": "TITLE"},
            "cash_remainder": None if point.cash_remainder is None else {"value": str(point.cash_remainder), "unit": "BRL"},
            "status": evaluated.status.value if evaluated is not None else point.status,
            "constraint_evaluation": _evaluation_dict(evaluated),
            "financial_result": point.financial_result,
            "reason": point.reason,
        }

    def result(status: EntryBoundaryStatus, *, candidate_pu: Decimal | None = None,
               verification_pu: Decimal | None = None, reason: str | None = None,
               method: str, unknown_above: bool = False) -> dict[str, Any]:
        if _request_deadline_exceeded(budget):
            passing_candidates = [
                pu for pu, (_, evaluated) in cache.items()
                if evaluated is not None and evaluated.status is ConstraintSetStatus.MET
            ]
            if (candidate_pu is None or candidate_pu not in cache
                    or cache[candidate_pu][1] is None
                    or cache[candidate_pu][1].status is not ConstraintSetStatus.MET):
                candidate_pu = max(passing_candidates, default=None)
            status = EntryBoundaryStatus.INCOMPLETE
            deadline_reason = "O prazo total da requisição foi excedido antes do retorno final."
            if candidate_pu is not None:
                deadline_reason += " O maior candidato MET já avaliado foi preservado."
            if reason:
                deadline_reason += f" Estado parcial: {reason}"
            reason = deadline_reason
        candidate = None
        if candidate_pu is not None:
            point, evaluation = cache[candidate_pu]
            candidate = candidate_dict(candidate_pu, point, evaluation)
        verification = None
        if verification_pu is not None and verification_pu in cache:
            point, evaluation = cache[verification_pu]
            verification = candidate_dict(verification_pu, point, evaluation)
        candidate_tick = int(candidate_pu / increment) if candidate_pu is not None else None
        evaluated_count = len(cache)
        return {
            "status": status.value,
            "entry_mode": entry_mode,
            "maximum_entry_pu": str(candidate_pu) if candidate_pu is not None else None,
            "quantity": None if candidate is None else candidate["quantity"],
            "cash_remainder": None if candidate is None else candidate["cash_remainder"],
            "candidate": candidate,
            "verification": verification,
            "domain": {
                "minimum_pu": str(minimum), "maximum_pu": str(requested_maximum),
                "effective_maximum_pu": str(effective_maximum), "tick": str(increment),
                "fixed_sale_order_date": scenario.exit.order_date.isoformat(),
                "fixed_sale_settlement_date": scenario.exit.settlement_date.isoformat(),
                "fixed_exit_pu": _string_or_none(scenario.exit.unit_price),
            },
            "coverage": {
                "method": method,
                "evaluated_candidates": evaluated_count,
                "complete_for_maximum": status is EntryBoundaryStatus.SOLVED and not unknown_above,
                "exhaustive_above_candidate": status is EntryBoundaryStatus.SOLVED and not unknown_above,
                "unknown_above_candidate": unknown_above,
                "unvisited_lower_candidates": 0 if candidate_tick is None else max(0, candidate_tick - minimum_ticks),
                "excluded_above_effective_maximum": (
                    "INSUFFICIENT_BUDGET" if effective_maximum < requested_maximum else None
                ),
                "budget": budget.to_dict(),
                "proof_scope": "Somente o domínio e o modo de capital declarados; candidatos superiores foram verificados diretamente ou excluídos pelo dimensionamento.",
            },
            "constraints_fingerprint": constraints.fingerprint,
            "reason": reason,
        }

    # With fixed quantity and lower-bound criteria, combine proven per-metric
    # target solvers. Upper-bound criteria and budget sizing use an exact tick
    # walk so a quantity transition cannot be hidden by bisection.
    # For fixed quantity and frozen sale terms, nominal profit is nonincreasing
    # with purchase PU and net redemption is nondecreasing through the derived
    # tax basis. Return ratios can change direction as the denominator and tax
    # treatment move, so they stay on exact discrete enumeration even when
    # sampled values happen to look monotone.
    monotonic_quantity_metrics = {
        ConstraintMetric.NOMINAL_PROFIT,
        ConstraintMetric.NET_REDEMPTION,
        ConstraintMetric.REQUESTED_ORDER_DATE,
    }
    monotonic_quantity_path = entry_mode == "QUANTITY" and all(
        item.metric in monotonic_quantity_metrics
        and (item.operator is ConstraintOperator.AT_LEAST
             or item.metric is ConstraintMetric.REQUESTED_ORDER_DATE)
        for item in constraints.criteria
    )
    if monotonic_quantity_path:
        target_cache: dict[Decimal, ScenarioEvaluation] = {}
        bounds: list[dict[str, Any]] = []

        def financial_at(pu: Decimal) -> ScenarioEvaluation:
            point, _ = point_at(pu)
            if point.status != "EVALUATED" or point.financial_result is None:
                raise _CandidateUnavailable
            target_cache[pu] = point.financial_result
            return point.financial_result

        candidate_cap = effective_maximum
        try:
            for item in constraints.criteria:
                if item.metric is ConstraintMetric.REQUESTED_ORDER_DATE:
                    continue
                target_date = scenario.exit.settlement_date if item.metric is ConstraintMetric.REAL_RETURN else None
                target = TargetDefinition(TargetMetric(item.metric.value), item.value, item.unit, target_date)
                solution: TargetSolution = solve_maximum_entry_pu(
                    scenario, target, tick=increment, maximum_pu=effective_maximum,
                    minimum_pu=minimum, evaluation_cache=target_cache,
                    evaluate_at_pu=financial_at,
                )
                bounds.append({
                    "constraint_id": item.constraint_id, "metric": item.metric.value,
                    "threshold": str(item.value), "status": solution.status.value,
                    "pu": _string_or_none(solution.pu), "achieved_value": _string_or_none(solution.achieved_value),
                    "adjacent_pu": _string_or_none(solution.neighbor_pu),
                    "adjacent_value": _string_or_none(solution.neighbor_value),
                    "reason": solution.reason,
                })
                if solution.status is TargetStatus.BLOCKED_POLICY:
                    return {**result(EntryBoundaryStatus.BLOCKED_POLICY, reason=solution.reason,
                                     method="quantity_target_solvers"), "effective_bounds": bounds}
                if solution.status is TargetStatus.METRIC_UNAVAILABLE:
                    return {**result(EntryBoundaryStatus.UNKNOWN, reason=solution.reason,
                                     method="quantity_target_solvers"), "effective_bounds": bounds}
                if solution.status in (TargetStatus.AMBIGUOUS_ROOT, TargetStatus.VERIFICATION_FAILED, TargetStatus.NO_ROOT):
                    return {**result(EntryBoundaryStatus.INCOMPLETE, reason=solution.reason,
                                     method="quantity_target_solvers"), "effective_bounds": bounds}
                if solution.status is TargetStatus.UNATTAINABLE:
                    return {**result(EntryBoundaryStatus.NO_SOLUTION, reason=solution.reason,
                                     method="quantity_target_solvers"), "effective_bounds": bounds}
                if solution.status is TargetStatus.SOLVED and solution.pu is not None:
                    candidate_cap = min(candidate_cap, solution.pu)
            candidate_point, candidate_evaluation = point_at(candidate_cap)
            if candidate_point.status != "EVALUATED" or candidate_evaluation is None:
                return {**result(EntryBoundaryStatus.UNKNOWN, candidate_pu=candidate_cap,
                                 reason=candidate_point.reason or "Candidato sem avaliação direta.",
                                 method="quantity_target_solvers"), "effective_bounds": bounds}
            if candidate_evaluation.status is ConstraintSetStatus.UNKNOWN:
                return {**result(EntryBoundaryStatus.UNKNOWN, candidate_pu=candidate_cap,
                                 reason="Uma meta do candidato permanece sem dado suficiente.",
                                 method="quantity_target_solvers"), "effective_bounds": bounds}
            if candidate_evaluation.status is not ConstraintSetStatus.MET:
                return {**result(EntryBoundaryStatus.NO_SOLUTION, candidate_pu=candidate_cap,
                                 reason="Os limites individuais não se sobrepõem num PU que satisfaça todas as metas.",
                                 method="quantity_target_solvers"), "effective_bounds": bounds}
            next_pu = candidate_cap + increment
            if next_pu <= effective_maximum:
                _, next_evaluation = point_at(next_pu)
                if next_evaluation is None or next_evaluation.status is ConstraintSetStatus.UNKNOWN:
                    return {**result(EntryBoundaryStatus.INCOMPLETE, candidate_pu=candidate_cap,
                                     verification_pu=next_pu,
                                     reason="O tick superior não pôde ser excluído por falta de dado.",
                                     method="quantity_target_solvers", unknown_above=True), "effective_bounds": bounds}
                if next_evaluation.status is ConstraintSetStatus.MET:
                    return {**result(EntryBoundaryStatus.INCOMPLETE, candidate_pu=candidate_cap,
                                     verification_pu=next_pu,
                                     reason="O tick superior também atende; limite monotônico não confirmado.",
                                     method="quantity_target_solvers"), "effective_bounds": bounds}
            return {**result(EntryBoundaryStatus.SOLVED, candidate_pu=candidate_cap,
                             verification_pu=(candidate_cap + increment if candidate_cap < effective_maximum else None),
                             reason="Maior PU que atende às metas no domínio declarado; candidato e tick superior foram reavaliados diretamente.",
                             method="quantity_target_solvers"), "effective_bounds": bounds}
        except _BudgetExceeded:
            return {**result(EntryBoundaryStatus.INCOMPLETE, reason="Orçamento de avaliações terminou antes de provar o limite.",
                             method="quantity_target_solvers"), "effective_bounds": bounds}
        except _CandidateUnavailable:
            return {**result(EntryBoundaryStatus.UNKNOWN,
                             reason="Um PU necessário para verificar a monotonicidade não pôde ser avaliado diretamente.",
                             method="quantity_target_solvers"), "effective_bounds": bounds}

    # Budget sizing and non-monotonic/mixed criteria are discrete: scan each
    # declared PU tick from the highest affordable value down, directly.
    unknown_above = False
    previous_pu: Decimal | None = None
    previous_quantity: Decimal | None = None
    interrupted = False
    for ticks in range(effective_maximum_ticks, minimum_ticks - 1, -1):
        pu = increment * ticks
        if not budget.try_consume():
            interrupted = True
            break
        point = evaluate_candidate(pu)
        if not isinstance(point, EntrySearchPoint):
            raise ValidationError("INVALID_ENTRY_EVALUATION", "O avaliador precisa retornar EntrySearchPoint.")
        if point.status == "EXCLUDED":
            cache[pu] = (point, None)
            previous_pu = pu
            continue
        if point.status != "EVALUATED" or point.scenario is None or point.financial_result is None or point.quantity is None:
            cache[pu] = (point, None)
            unknown_above = True
            previous_pu = pu
            continue
        if point.scenario.entry.unit_price != pu or point.scenario.entry.quantity != point.quantity:
            raise ValidationError("ENTRY_CANDIDATE_MISMATCH", "PU e quantidade do candidato não correspondem à avaliação direta.")
        if not exit_condition_is_frozen(point.scenario):
            raise ValidationError("ENTRY_CANDIDATE_CONTEXT_CHANGED", "A busca alterou produto, datas ou condição de saída congelada.")
        if entry_mode == "BUDGET" and previous_quantity is not None and point.quantity < previous_quantity:
            raise ValidationError("ENTRY_SIZING_NOT_MONOTONIC", "Dimensionamento por orçamento aumentou quantidade com PU maior.")
        evaluation = evaluate_constraint_set(point.scenario, point.financial_result, constraints)
        cache[pu] = (point, evaluation)
        if evaluation.status is ConstraintSetStatus.MET:
            status = EntryBoundaryStatus.INCOMPLETE if unknown_above else EntryBoundaryStatus.SOLVED
            return result(status, candidate_pu=pu, verification_pu=previous_pu,
                          reason=("Candidato atendido, mas há PU superior sem avaliação verificável." if unknown_above
                                  else "Maior PU atendido por enumeração direta de todos os ticks superiores do domínio."),
                          method="descending_discrete_enumeration", unknown_above=unknown_above)
        if evaluation.status is ConstraintSetStatus.UNKNOWN:
            unknown_above = True
        previous_quantity = point.quantity
        previous_pu = pu

    if interrupted:
        return result(EntryBoundaryStatus.INCOMPLETE, reason="Orçamento/deadline terminou antes de cobrir os PUs superiores do domínio.",
                      method="descending_discrete_enumeration", unknown_above=unknown_above)
    status = EntryBoundaryStatus.UNKNOWN if unknown_above else EntryBoundaryStatus.NO_SOLUTION
    reason = (
        "O domínio foi coberto, mas há candidatos sem dados suficientes para provar o limite."
        if unknown_above else
        "Todos os PUs elegíveis do domínio foram avaliados diretamente e nenhum atende ao conjunto de metas."
    )
    return result(status, reason=reason, method="descending_discrete_enumeration", unknown_above=unknown_above)


def _rate_solution_dict(value: RateSolution | None) -> dict[str, Any] | None:
    if value is None:
        return None
    return {
        "status": value.status.value,
        "side": value.side,
        "target_pu": str(value.target_pu),
        "rate": _string_or_none(value.rate),
        "pu_at_rate": _string_or_none(value.pu_at_rate),
        "adjacent_rate": _string_or_none(value.adjacent_rate),
        "adjacent_pu": _string_or_none(value.adjacent_pu),
        "rate_bracket": [str(item) for item in value.rate_bracket],
        "evaluations": value.evaluations,
        "reason": value.reason,
    }
