"""Strict, offline imports for the market-marking simulator.

The importer deliberately does not authenticate an uploaded source. It retains
its raw bytes and hash at the storage boundary and exposes the dataset's
knowledge-time limitations to callers.
"""
from __future__ import annotations

import csv
from dataclasses import dataclass
from datetime import date
from decimal import Decimal, InvalidOperation
import io
import re
import unicodedata

from .contracts import ValidationError
from .provenance import EvidenceMode


SELL_D0_EFFECTIVE_DATE = date(2021, 9, 13)


def quote_settlement_date(observation_date: date, side: str, next_market_date: date | None) -> date | None:
    """Resolve morning quote timing; next Data Base only approximates the next session."""
    if side == "BASE" or (side == "SELL" and observation_date >= SELL_D0_EFFECTIVE_DATE):
        return observation_date
    if side in ("BUY", "SELL"):
        return next_market_date
    raise ValidationError("INVALID_SIDE", "Lado de cota\u00e7\u00e3o precisa ser BUY, SELL ou BASE.")


MAX_IMPORT_BYTES = 60 * 1024 * 1024
MAX_IMPORT_ROWS = 250_000
PRICE_HEADER = (
    "Tipo Titulo", "Data Vencimento", "Data Base", "Taxa Compra Manha",
    "Taxa Venda Manha", "PU Compra Manha", "PU Venda Manha", "PU Base Manha",
)
INDEX_HEADER = ("Data", "Conhecido em", "Tipo", "Valor", "Fonte")
INDEX_TYPES = frozenset({"VNA", "VNI", "IPCA_LEVEL", "IPCA_PROJECTION", "IPCA_MONTHLY_INDEX"})


@dataclass(frozen=True, slots=True)
class PriceObservation:
    family: str
    title_type: str
    instrument_id: str
    maturity_date: date
    observation_date: date
    next_market_date: date | None
    buy_yield_percent: Decimal | None
    sell_yield_percent: Decimal | None
    buy_pu: Decimal | None
    sell_pu: Decimal | None
    base_pu: Decimal | None

    def as_dict(self) -> dict[str, object]:
        return {
            "family": self.family,
            "title_type": self.title_type,
            "instrument_id": self.instrument_id,
            "maturity_date": self.maturity_date.isoformat(),
            "observation_date": self.observation_date.isoformat(),
            "next_market_date": self.next_market_date.isoformat() if self.next_market_date else None,
            "buy_yield_percent": _decimal_text(self.buy_yield_percent),
            "sell_yield_percent": _decimal_text(self.sell_yield_percent),
            "buy_pu": _decimal_text(self.buy_pu),
            "sell_pu": _decimal_text(self.sell_pu),
            "base_pu": _decimal_text(self.base_pu),
        }


@dataclass(frozen=True, slots=True)
class IndexObservation:
    reference_date: date
    known_on: date
    kind: str
    value: Decimal
    source: str

    def as_dict(self) -> dict[str, str]:
        return {
            "reference_date": self.reference_date.isoformat(),
            "known_on": self.known_on.isoformat(),
            "kind": self.kind,
            "value": _decimal_text(self.value) or "",
            "source": self.source,
        }


def _decimal_text(value: Decimal | None) -> str | None:
    return None if value is None else format(value, "f")


def _decode(raw: bytes) -> str:
    if not isinstance(raw, bytes) or not raw:
        raise ValidationError("EMPTY_IMPORT", "Escolha um arquivo CSV não vazio.")
    if len(raw) > MAX_IMPORT_BYTES:
        raise ValidationError("IMPORT_TOO_LARGE", "O arquivo ultrapassa 60 MB.")
    if b"\x00" in raw:
        raise ValidationError("INVALID_ENCODING", "O arquivo contém bytes nulos e não é um CSV de texto.")
    try:
        return raw.decode("utf-8-sig")
    except UnicodeDecodeError:
        try:
            return raw.decode("cp1252")
        except UnicodeDecodeError as exc:
            raise ValidationError("INVALID_ENCODING", "Use UTF-8 ou Windows-1252.") from exc


def _read_csv(raw: bytes, header: tuple[str, ...], label: str):
    text = _decode(raw)
    try:
        reader = csv.reader(io.StringIO(text, newline=""), delimiter=";", strict=True)
        columns = next(reader)
    except csv.Error as exc:
        raise ValidationError("MALFORMED_CSV", f"CSV {label} inválido: {exc}.") from exc
    except StopIteration as exc:
        raise ValidationError("EMPTY_IMPORT", f"CSV {label} sem cabeçalho.") from exc
    if tuple(cell.strip() for cell in columns) != header:
        expected = ";".join(header)
        raise ValidationError("UNEXPECTED_HEADER", f"Cabeçalho {label} inesperado. Esperado: {expected}.")
    def iter_rows():
        count = 0
        try:
            for line, row in enumerate(reader, start=2):
                if not any(cell.strip() for cell in row):
                    continue
                count += 1
                if count > MAX_IMPORT_ROWS:
                    raise ValidationError("TOO_MANY_ROWS", "O arquivo ultrapassa o limite de 250 mil linhas.")
                if len(row) != len(header):
                    raise ValidationError("TRUNCATED_ROW", f"Linha {line}: esperadas {len(header)} colunas; recebidas {len(row)}.")
                yield line, row
        except csv.Error as exc:
            raise ValidationError("MALFORMED_CSV", f"CSV {label} inválido: {exc}.") from exc
    return iter_rows()


def _date(value: str, label: str, line: int) -> date:
    raw = value.strip()
    try:
        if re.fullmatch(r"\d{2}/\d{2}/\d{4}", raw):
            return date(int(raw[6:]), int(raw[3:5]), int(raw[:2]))
        if re.fullmatch(r"\d{4}-\d{2}-\d{2}", raw):
            return date.fromisoformat(raw)
    except ValueError as exc:
        raise ValidationError("INVALID_DATE", f"Linha {line}: {label} não é uma data válida.") from exc
    raise ValidationError("INVALID_DATE_FORMAT", f"Linha {line}: {label} deve ser DD/MM/AAAA ou AAAA-MM-DD.")


def _number(value: str, label: str, line: int, *, positive: bool = False) -> Decimal | None:
    raw = value.strip().replace("\u00a0", "")
    if raw in ("", "-", "—"):
        return None
    raw = raw.replace("R$", "").replace("%", "").replace(" ", "")
    if "," in raw:
        if not re.fullmatch(r"[+-]?(?:\d+|\d{1,3}(?:\.\d{3})+),\d+", raw):
            raise ValidationError("INVALID_NUMBER", f"Linha {line}: {label} tem separadores ambíguos ou agrupamento pt-BR inválido.")
        raw = raw.replace(".", "").replace(",", ".")
    if not re.fullmatch(r"[+-]?(?:\d+(?:\.\d*)?|\.\d+)", raw):
        raise ValidationError("INVALID_NUMBER", f"Linha {line}: {label} não é um número decimal reconhecido.")
    try:
        result = Decimal(raw)
    except InvalidOperation as exc:
        raise ValidationError("INVALID_NUMBER", f"Linha {line}: {label} não é um número decimal reconhecido.") from exc
    if not result.is_finite() or (positive and result <= 0):
        raise ValidationError("INVALID_NUMBER", f"Linha {line}: {label} deve ser finito" + (" e positivo." if positive else "."))
    return result


def _family(title: str) -> str | None:
    normalized = unicodedata.normalize("NFKD", title).encode("ascii", "ignore").decode().upper()
    normalized = re.sub(r"\s+", " ", normalized).strip()
    if "JUROS SEMESTRAIS" in normalized or "COM CUPOM" in normalized:
        return None
    if normalized.startswith("TESOURO IPCA+"):
        return "IPCA_PRINCIPAL"
    if normalized.startswith("TESOURO RENDA+"):
        return "RENDA_PLUS"
    return None


def parse_price_csv(raw: bytes, *, imported_on: date) -> tuple[tuple[PriceObservation, ...], dict[str, object]]:
    """Parse the official eight-column Tesouro Transparente daily price file."""
    rows = _read_csv(raw, PRICE_HEADER, "de preços")
    parsed: list[tuple[str, str, date, date, Decimal | None, Decimal | None, Decimal | None, Decimal | None, Decimal | None]] = []
    market_dates: set[date] = set()
    identities: set[tuple[str, date]] = set()
    families: dict[str, set[str]] = {"IPCA_PRINCIPAL": set(), "RENDA_PLUS": set()}
    input_rows = 0
    unsupported_title_counts: dict[str, int] = {}
    excluded_row_counts = {
        "coupon_title_out_of_scope": 0,
        "unsupported_title_family": 0,
        "supported_title_without_quotes": 0,
    }
    for number, row in rows:
        input_rows += 1
        title, maturity_raw, observation_raw, *values = (cell.strip() for cell in row)
        if not title or len(title) > 160 or any(ord(char) < 32 for char in title):
            raise ValidationError("INVALID_TITLE", f"Linha {number}: tipo de título ausente ou extenso demais.")
        maturity = _date(maturity_raw, "vencimento", number)
        observation = _date(observation_raw, "data base", number)
        if observation > imported_on:
            raise ValidationError("FUTURE_OBSERVATION", f"Linha {number}: a data base é posterior à data de importação.")
        market_dates.add(observation)
        family = _family(title)
        if family is None:
            unsupported_title_counts[title] = unsupported_title_counts.get(title, 0) + 1
            normalized_title = unicodedata.normalize("NFKD", title).encode("ascii", "ignore").decode().upper()
            if "JUROS SEMESTRAIS" in normalized_title or "COM CUPOM" in normalized_title:
                excluded_row_counts["coupon_title_out_of_scope"] += 1
            else:
                excluded_row_counts["unsupported_title_family"] += 1
            continue
        buy_yield = _number(values[0], "taxa de compra", number)
        sell_yield = _number(values[1], "taxa de venda", number)
        buy_pu = _number(values[2], "PU de compra", number, positive=True)
        sell_pu = _number(values[3], "PU de venda", number, positive=True)
        base_pu = _number(values[4], "PU Base", number, positive=True)
        for name, yield_value in (("compra", buy_yield), ("venda", sell_yield)):
            if yield_value is not None and yield_value <= Decimal("-100"):
                raise ValidationError("INVALID_YIELD", f"Linha {number}: taxa de {name} deve ser maior que −100% a.a.")
        if all(value is None for value in (buy_yield, sell_yield, buy_pu, sell_pu, base_pu)):
            excluded_row_counts["supported_title_without_quotes"] += 1
            continue
        instrument_id = f"{title} | {maturity.isoformat()}"
        identity = (instrument_id, observation)
        if identity in identities:
            raise ValidationError("DUPLICATE_QUOTE", f"Linha {number}: título e data base duplicados ({instrument_id}, {observation}).")
        identities.add(identity)
        families[family].add(instrument_id)
        parsed.append((family, title, maturity, observation, buy_yield, sell_yield, buy_pu, sell_pu, base_pu))
    if not parsed:
        raise ValidationError("NO_SUPPORTED_QUOTES", "O CSV não contém cotações preenchidas de IPCA+ Principal sem cupom ou RendA+.")
    dates = sorted(market_dates)
    next_by_date = {current: later for current, later in zip(dates, dates[1:])}
    observations = tuple(PriceObservation(family, title, f"{title} | {maturity.isoformat()}", maturity, day,
                                          next_by_date.get(day), buy_yield, sell_yield, buy_pu, sell_pu, base_pu)
                         for family, title, maturity, day, buy_yield, sell_yield, buy_pu, sell_pu, base_pu in parsed)
    instruments = [{"instrument_id": identity, "family": family, "maturity_date": identity.rsplit(" | ", 1)[1],
                    "title_type": identity.rsplit(" | ", 1)[0]}
                   for family in ("IPCA_PRINCIPAL", "RENDA_PLUS") for identity in sorted(families[family])]
    metadata: dict[str, object] = {
        "format": "TESOURO_TRANSPARENTE_DAILY_PRICES_V1",
        "input_rows": input_rows,
        "rows": len(observations),
        "accepted_rows": len(observations),
        "excluded_rows": input_rows - len(observations),
        "excluded_row_counts": excluded_row_counts,
        "unsupported_title_counts": dict(sorted(unsupported_title_counts.items())),
        "first_observation": min(item.observation_date for item in observations).isoformat(),
        "last_observation": max(item.observation_date for item in observations).isoformat(),
        "instrument_count": len(instruments),
        "instruments": instruments,
        "settlement_rule": "Compra D+1 depende da pr\u00f3xima Data Base presente; venda matinal D+0 desde 13/09/2021 e D+1 antes. Venda moderna D+0 n\u00e3o exige registro seguinte.",
        "base_rule": "PU Base Manh\u00e3 em D0; compra matinal D+1; venda matinal D+0 desde 13/09/2021 e D+1 antes.",
        "knowledge_time": "desconhecido por linha; histórico revisável; somente EX_POST",
        "unsupported_families": [name for name, found in families.items() if not found],
    }
    return observations, metadata


def parse_index_csv(raw: bytes, *, imported_on: date) -> tuple[tuple[IndexObservation, ...], dict[str, object]]:
    """Parse the documented user-supplied reference/index format; no network access."""
    rows = _read_csv(raw, INDEX_HEADER, "de índices")
    parsed: list[IndexObservation] = []
    seen: set[tuple[str, date]] = set()
    for line, row in rows:
        observation_raw, known_raw, kind_raw, value_raw, source_raw = (cell.strip() for cell in row)
        observation = _date(observation_raw, "data de referência", line)
        known = _date(known_raw, "data conhecida/publicada declarada", line)
        kind = kind_raw.upper()
        source = source_raw.strip()
        if kind not in INDEX_TYPES:
            raise ValidationError("UNSUPPORTED_INDEX_TYPE", f"Linha {line}: tipo deve ser VNA, VNI, IPCA_LEVEL, IPCA_PROJECTION ou IPCA_MONTHLY_INDEX.")
        if known > imported_on:
            raise ValidationError("FUTURE_PUBLICATION", f"Linha {line}: a data de conhecimento é posterior à importação.")
        if kind != "IPCA_PROJECTION" and observation > imported_on:
            raise ValidationError("FUTURE_OBSERVATION", f"Linha {line}: índice observado está depois da importação.")
        if not source or len(source) > 250 or any(char in source for char in "\r\n"):
            raise ValidationError("INVALID_SOURCE", f"Linha {line}: informe uma fonte de até 250 caracteres.")
        if kind == 'IPCA_MONTHLY_INDEX':
            if observation.day != 1 or observation < date(2000, 6, 1) or known < observation:
                raise ValidationError('INVALID_IPCA_MONTH', f'Linha {line}: IPCA mensal exige dia 1 e conhecimento posterior ao mês.')
        value = _number(value_raw, "valor do índice", line, positive=True)
        assert value is not None
        key = (kind, observation)
        if key in seen:
            raise ValidationError("DUPLICATE_INDEX", f"Linha {line}: índice e data duplicados ({kind}, {observation}).")
        seen.add(key)
        parsed.append(IndexObservation(observation, known, kind, value, source))
    if not parsed:
        raise ValidationError("NO_INDEX_ROWS", "O arquivo de índices não contém observações.")
    parsed.sort(key=lambda item: (item.kind, item.reference_date))
    metadata: dict[str, object] = {
        "format": "MARKET_SIM_INDEX_REFERENCE_V1",
        "rows": len(parsed),
        "first_reference": min(item.reference_date for item in parsed).isoformat(),
        "last_reference": max(item.reference_date for item in parsed).isoformat(),
        "types": sorted({item.kind for item in parsed}),
        "known_on_policy": "data declarada pelo usuário, sem autenticação institucional",
        "projection_policy": "IPCA_PROJECTION permanece hipótese e nunca é convertido em nível realizado automaticamente",
    }
    return tuple(parsed), metadata


def filter_price_history(
    observations: tuple[PriceObservation, ...], *, instrument_id: str, start: date | None,
    end: date | None, as_of: date, mode: EvidenceMode, limit: int = 1260,
) -> list[dict[str, object]]:
    if not 1 <= limit <= 1260:
        raise ValidationError("HISTORY_LIMIT", "A consulta histórica limita-se a 1.260 observações.")
    chosen = [item for item in observations if item.instrument_id == instrument_id
              and (start is None or item.observation_date >= start)
              and (end is None or item.observation_date <= end)]
    if not chosen:
        raise ValidationError("NO_HISTORY", "Não há cotações neste instrumento e intervalo na versão escolhida.")
    chosen = chosen[-limit:]
    result = []
    for item in chosen:
        future_observation = item.observation_date > as_of
        available = mode is EvidenceMode.EX_POST or not future_observation
        if mode is EvidenceMode.CAUSAL:
            available = False  # the bulk file does not carry row-level publication dates
        status = "AVAILABLE_EX_POST" if available and mode is EvidenceMode.EX_POST else (
            "OBSERVATION_AFTER_AS_OF" if future_observation else "PUBLICATION_DATE_UNKNOWN")
        row = item.as_dict()
        if not available:
            for key in ("buy_yield_percent", "sell_yield_percent", "buy_pu", "sell_pu", "base_pu"):
                row[key] = None
        row.update({"available": available, "evidence_status": status,
                    "evidence_note": "EX_POST: arquivo atual pode conter revisões posteriores à observação." if available else "Valor ocultado: o CSV não declara quando esta linha foi publicada."})
        result.append(row)
    return result


def filter_index_history(
    observations: tuple[IndexObservation, ...], *, kind: str, start: date | None,
    end: date | None, as_of: date, mode: EvidenceMode, limit: int = 1260,
) -> list[dict[str, object]]:
    if kind not in INDEX_TYPES:
        raise ValidationError("UNSUPPORTED_INDEX_TYPE", "Tipo de índice não reconhecido.")
    if not 1 <= limit <= 1260:
        raise ValidationError("HISTORY_LIMIT", "A consulta histórica limita-se a 1.260 observações.")
    chosen = [item for item in observations if item.kind == kind
              and (start is None or item.reference_date >= start)
              and (end is None or item.reference_date <= end)]
    if not chosen:
        raise ValidationError("NO_HISTORY", "Não há observações deste índice e intervalo na versão escolhida.")
    chosen = chosen[-limit:]
    result = []
    for item in chosen:
        after_as_of = item.reference_date > as_of or item.known_on > as_of
        available = mode is EvidenceMode.EX_POST or not after_as_of
        if available:
            status = "AVAILABLE_EX_POST" if mode is EvidenceMode.EX_POST else "AVAILABLE"
        else:
            status = "PUBLISHED_AFTER_AS_OF" if item.known_on > as_of else "OBSERVATION_AFTER_AS_OF"
        row: dict[str, object] = item.as_dict()
        row.update({"available": available, "evidence_status": status,
                    "evidence_note": "Data de publicação declarada no arquivo; a origem não foi autenticada."})
        if not available:
            row["value"] = None
        if kind == "IPCA_PROJECTION":
            row["quality"] = "HYPOTHETICAL"
        else:
            row["quality"] = "INFORMED"
        result.append(row)
    return result


def lookup_price_exact(
    observations: tuple[PriceObservation, ...], *, instrument_id: str,
    observation_date: date, side: str, as_of: date | None, mode: EvidenceMode,
) -> dict[str, object]:
    """Resolve one explicitly selected quote; never search a neighboring date."""
    field_by_side = {"BUY": "buy_pu", "SELL": "sell_pu", "BASE": "base_pu"}
    field = field_by_side.get(side)
    if field is None:
        raise ValidationError("INVALID_SIDE", "Lado de cotação precisa ser BUY, SELL ou BASE.")
    matches = [item for item in observations
               if item.instrument_id == instrument_id and item.observation_date == observation_date]
    if not matches:
        return {
            "status": "needs_input", "reason_code": "NO_EXACT_QUOTE",
            "instrument_id": instrument_id, "observation_date": observation_date.isoformat(),
            "side": side, "value": None,
        }
    if len(matches) != 1:
        return {
            "status": "blocked_policy", "reason_code": "CONFLICTING_QUOTE",
            "instrument_id": instrument_id, "observation_date": observation_date.isoformat(),
            "side": side, "value": None,
        }
    item = matches[0]
    quote_settlement = quote_settlement_date(item.observation_date, side, item.next_market_date)
    common = {
        "instrument_id": item.instrument_id,
        "observation_date": item.observation_date.isoformat(),
        "side": side,
        "next_market_date": item.next_market_date.isoformat() if item.next_market_date else None,
        "quote_settlement_date": quote_settlement.isoformat() if quote_settlement else None,
        "value": None,
    }
    if mode is EvidenceMode.CAUSAL:
        status = "OBSERVATION_AFTER_AS_OF" if as_of is not None and item.observation_date > as_of else "PUBLICATION_DATE_UNKNOWN"
        return {"status": "blocked_policy", "reason_code": status, **common}
    value = getattr(item, field)
    if value is None:
        return {"status": "needs_input", "reason_code": "QUOTE_VALUE_MISSING", **common}
    return {
        "status": "available", "reason_code": "AVAILABLE_EX_POST",
        **{**common, "value": format(value, "f")},
        "family": item.family,
        "title_type": item.title_type,
        "maturity_date": item.maturity_date.isoformat(),
        "quality": "INFORMED",
        "evidence_status": "AVAILABLE_EX_POST",
        "evidence_note": "Arquivo local não autenticado; EX_POST explícito, publicação da linha desconhecida.",
    }


def lookup_index_exact(
    observations: tuple[IndexObservation, ...], *, kind: str,
    reference_date: date, as_of: date, mode: EvidenceMode,
) -> dict[str, object]:
    """Resolve one exact dated anchor; no forward-fill, interpolation, or projection."""
    if kind not in {"VNA", "VNI"}:
        raise ValidationError("UNSUPPORTED_INDEX_TYPE", "Âncora financeira precisa ser VNA ou VNI.")
    matches = [item for item in observations
               if item.kind == kind and item.reference_date == reference_date]
    if not matches:
        return {
            "status": "needs_input", "reason_code": "NO_EXACT_INDEX",
            "kind": kind, "reference_date": reference_date.isoformat(), "value": None,
        }
    if len(matches) != 1:
        return {
            "status": "blocked_policy", "reason_code": "CONFLICTING_INDEX",
            "kind": kind, "reference_date": reference_date.isoformat(), "value": None,
        }
    item = matches[0]
    common = {
        "kind": kind,
        "reference_date": item.reference_date.isoformat(),
        "known_on": item.known_on.isoformat(),
        "value": None,
        "source_ref": item.source,
    }
    if mode is EvidenceMode.CAUSAL and (item.reference_date > as_of or item.known_on > as_of):
        code = "PUBLISHED_AFTER_AS_OF" if item.known_on > as_of else "OBSERVATION_AFTER_AS_OF"
        return {"status": "blocked_policy", "reason_code": code, **common}
    return {
        "status": "available",
        "reason_code": "AVAILABLE_EX_POST" if mode is EvidenceMode.EX_POST else "AVAILABLE",
        **{**common, "value": format(item.value, "f")},
        "quality": "INFORMED",
        "evidence_status": "AVAILABLE_EX_POST" if mode is EvidenceMode.EX_POST else "AVAILABLE",
        "evidence_note": "Data e conhecimento declarados pelo usuário; origem não autenticada.",
    }
