"""Orquestração pura dos motores MTM; não acessa rede, banco ou arquivos."""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import date
from decimal import Decimal, localcontext
from enum import StrEnum
from hashlib import sha256
from typing import Any

from .contracts import ProductFamily, Scenario, ScenarioIntent, Side, ValidationError
from .operation import (
    CashFlow, IndexLevel, OperationRequest, OperationResult, calculate_operation,
)
from .principal import business_days_to_maturity, price_principal, PRICING_VERSION as PRINCIPAL_PRICING_VERSION
from .projections import (
    DatedLevel, InflationProjection, PROJECTION_PROFILE_ID, ProjectionPoint,
    project_level_series,
)
from .provenance import (
    EvidenceMode, EvidenceStatus, Provenance, Quality, assess_evidence,
)
from .renda_plus import RendaPlusSeries, price_renda_plus, PRICING_VERSION as RENDA_PLUS_PRICING_VERSION
from .nominal_index import MonthlyIPCA, NominalIndexResult, calculate_nominal_index, PROFILE_ID as NOMINAL_PROFILE_ID

from .memo import scoped_memo

D = Decimal


def engine_manifest() -> dict[str, object]:
    """Stable identifiers needed to interpret a saved simulation snapshot."""
    from .policies import (
        IOF_POLICY_ID, IR_POLICY_ID, PRINCIPAL_CUSTODY_POLICY_ID,
        RENDA_CUSTODY_POLICY_ID,
    )
    from .principal import PRICING_VERSION as PRINCIPAL_PRICING_VERSION
    from .renda_plus import PRICING_VERSION as RENDA_PLUS_PRICING_VERSION

    return {
        "api_schema_version": 1,
        "gross_dv01_method": GROSS_DV01_METHOD_VERSION,
        "nominal_index": NOMINAL_PROFILE_ID,
        "workspace_nominal_policy": "AUTOMATIC_IPCA_REQUIRED_v1",
        "quote_settlement_policy": "TESOURO_TRANSPARENTE_MORNING_B3_SELL_D0_20210913_v1",
        "calendar_id": "BR_FINANCIAL_RULES_PROJECTED_v1",
        "pricing": {
            "IPCA_PRINCIPAL": PRINCIPAL_PRICING_VERSION,
            "RENDA_PLUS": RENDA_PLUS_PRICING_VERSION,
        },
        "policies": sorted((
            IOF_POLICY_ID, IR_POLICY_ID,
            PRINCIPAL_CUSTODY_POLICY_ID, RENDA_CUSTODY_POLICY_ID,
        )),
    }


class IndexKind(StrEnum):
    VNA = "VNA"
    VNI = "VNI"


@dataclass(frozen=True, slots=True)
class IndexAnchor:
    kind: IndexKind
    value: Decimal
    reference_date: date
    quality: Quality
    source_ref: str
    provenance: Provenance | None = None

    def __post_init__(self) -> None:
        from .contracts import decimal_value
        if not isinstance(self.kind, IndexKind):
            object.__setattr__(self, "kind", IndexKind(self.kind))
        if not isinstance(self.quality, Quality):
            object.__setattr__(self, "quality", Quality(self.quality))
        value = decimal_value(self.value, self.kind.value)
        if value <= 0 or not self.source_ref.strip():
            raise ValidationError("INVALID_INDEX", "Âncora exige valor positivo e fonte.")
        if self.provenance is not None and self.provenance.quality is not self.quality:
            raise ValidationError("INVALID_PROVENANCE", "Qualidade e proveniência da âncora divergem.")
        object.__setattr__(self, "value", value)


@dataclass(frozen=True, slots=True)
class PriceIndexEvidence:
    reference_date: date
    quality: Quality
    provenance: Provenance | None = None

    def __post_init__(self) -> None:
        if not isinstance(self.quality, Quality):
            object.__setattr__(self, "quality", Quality(self.quality))
        if self.quality is Quality.MISSING:
            raise ValidationError("INVALID_INDEX", "Nível preenchido não pode ter qualidade MISSING.")
        if self.provenance is not None and self.provenance.quality is not self.quality:
            raise ValidationError("INVALID_PROVENANCE", "Qualidade e proveniência do nível de preços divergem.")


@dataclass(frozen=True, slots=True)
class EvaluationContext:
    calendar: Any | None = None
    index_anchors: tuple[IndexAnchor, ...] = ()
    tax_cost_basis: Decimal | None = None
    entry_expense_paid: Decimal = D(0)
    exit_expense: Decimal = D(0)
    custody_override: Decimal | None = None
    institution_net_override: Decimal | None = None
    intermediate_paid_costs: tuple[CashFlow, ...] = ()
    index_levels: tuple[IndexLevel, ...] = ()
    institution_release_date: date | None = None
    inflation_projection: InflationProjection | None = None
    price_index_evidence: tuple[PriceIndexEvidence, ...] = ()
    capital_mode: str | None = None
    tax_cost_basis_source: str | None = None
    settlement_quality: Quality | None = None
    ipca_monthly_indexes: tuple[MonthlyIPCA, ...] = ()
    ipca_monthly_rates: tuple[tuple[date, Decimal], ...] = ()
    require_automatic_nominal: bool = False


@dataclass(frozen=True, slots=True)
class CalculationStep:
    name: str
    formula: str
    inputs: tuple[tuple[str, str | None], ...]
    output: str | None
    quality: Quality
    policy_id: str | None = None
    source_ref: str | None = None


@dataclass(frozen=True, slots=True)
class ScenarioEvaluation:
    scenario_id: str
    status: str
    entry_pu: Decimal | None
    exit_pu: Decimal | None
    operation: OperationResult | None
    steps: tuple[CalculationStep, ...]
    warnings: tuple[str, ...] = ()
    evidence_statuses: tuple[EvidenceStatus, ...] = ()
    marked_value: Decimal | None = None


class ComparisonKind(StrEnum):
    ENTRY = "ENTRY"
    EXIT = "EXIT"


@dataclass(frozen=True, slots=True)
class ScenarioComparison:
    kind: ComparisonKind
    left: ScenarioEvaluation
    right: ScenarioEvaluation
    rankable_on_nominal_net: bool
    nominal_net_delta: Decimal | None
    common_date: date | None
    common_date_value_left: Decimal | None = None
    common_date_value_right: Decimal | None = None
    assumption: str | None = None
    warnings: tuple[str, ...] = ()


@dataclass(frozen=True, slots=True)
class ProjectionWindow:
    context: EvaluationContext
    index_points: tuple[ProjectionPoint, ...]
    price_index_points: tuple[ProjectionPoint, ...]
    warnings: tuple[str, ...] = ()
    nominal_calculations: tuple[NominalIndexResult, ...] = ()


def _real_metric_quality(context: EvaluationContext, dates: tuple[date, ...]) -> Quality:
    evidence_by_date = {item.reference_date: item for item in context.price_index_evidence}
    qualities = [
        evidence_by_date[day].quality if day in evidence_by_date else Quality.INFORMED
        for day in dates
    ]
    if Quality.HYPOTHETICAL in qualities:
        return Quality.HYPOTHETICAL
    if Quality.ESTIMATED in qualities:
        return Quality.ESTIMATED
    if any(item in (Quality.OBSERVED, Quality.REVISED, Quality.RECONSTRUCTED) for item in qualities):
        return Quality.RECONSTRUCTED
    return Quality.INFORMED


def _combine_metric_quality(*qualities: Quality | None) -> Quality:
    """Combine only the evidence used by this metric, without a numeric score."""
    present = tuple(item for item in qualities if item is not None and item is not Quality.MISSING)
    if not present:
        return Quality.MISSING
    if Quality.HYPOTHETICAL in present:
        return Quality.HYPOTHETICAL
    if Quality.ESTIMATED in present:
        return Quality.ESTIMATED
    if all(item is present[0] for item in present):
        return present[0]
    return Quality.RECONSTRUCTED


def _display_value(value: Decimal | int | float | str | None) -> str | None:
    return None if value is None else str(value)


def _scenario_id(scenario: Scenario) -> str:
    digest = sha256(repr(scenario).encode("utf-8")).hexdigest()[:16]
    return f"{scenario.instrument.instrument_id}:{digest}"


def _anchor_for(
    scenario: Scenario,
    context: EvaluationContext,
    target_date: date,
) -> IndexAnchor | None:
    required = IndexKind.VNA if scenario.instrument.family is ProductFamily.IPCA_PRINCIPAL else IndexKind.VNI
    candidates = [anchor for anchor in context.index_anchors if anchor.kind is required and anchor.reference_date == target_date]
    if len(candidates) > 1:
        # Independent alternatives at the same date require an explicit source choice.
        raise ValidationError("CONFLICTING_INDEX", "Há mais de uma âncora para a mesma data; selecione uma fonte.")
    return candidates[0] if candidates else None


def _evidence_gate(
    provenance: Provenance | None,
    quality: Quality,
    scenario: Scenario,
) -> tuple[EvidenceStatus | None, str | None]:
    if quality is Quality.MISSING:
        return EvidenceStatus.MISSING, "Evidência ausente."
    if quality is Quality.HYPOTHETICAL:
        return None, None
    if provenance is None:
        if quality in (Quality.OBSERVED, Quality.REVISED):
            return EvidenceStatus.PUBLICATION_DATE_UNKNOWN, "Dado rotulado como observado sem proveniência verificável."
        return None, None
    must_prove_publication = quality in (Quality.OBSERVED, Quality.REVISED)
    outside_as_of = (
        scenario.as_of.mode is EvidenceMode.CAUSAL
        and (
            (provenance.observed_on is not None and provenance.observed_on > scenario.as_of.date)
            or (
                provenance.published_at is not None
                and provenance.published_at.date() > scenario.as_of.date
            )
        )
    )
    if must_prove_publication or outside_as_of:
        decision = assess_evidence(provenance, scenario.as_of.date, scenario.as_of.mode)
        if not decision.usable:
            return decision.status, decision.reason or decision.label
        return decision.status, None
    return None, None


def _projection_input_usable(
    reference_date: date,
    quality: Quality,
    provenance: Provenance | None,
    as_of: date | None,
    mode: EvidenceMode,
) -> bool:
    if quality is Quality.HYPOTHETICAL:
        return True
    if mode is EvidenceMode.CAUSAL and as_of is None and quality in (
        Quality.OBSERVED, Quality.REVISED,
    ):
        return False
    if mode is EvidenceMode.CAUSAL and as_of is not None:
        if reference_date > as_of and quality is not Quality.HYPOTHETICAL:
            return False
        if quality in (Quality.OBSERVED, Quality.REVISED) and provenance is None:
            return False
    if provenance is not None:
        if as_of is None:
            return mode is EvidenceMode.EX_POST or quality is Quality.HYPOTHETICAL
        return assess_evidence(provenance, as_of, mode).usable
    return True


def prepare_projection_window(
    context: EvaluationContext,
    *,
    index_targets: dict[IndexKind, tuple[date, ...]] | None = None,
    price_index_targets: tuple[date, ...] = (),
    projection: InflationProjection | None = None,
    as_of: date | None = None,
    evidence_mode: EvidenceMode = EvidenceMode.CAUSAL,
) -> ProjectionWindow:
    """Prepare exact or hypothetical index inputs for one analysis window.

    VNA, VNI, and the general price index are resolved as separate series.
    Unsafe evidence is never a projection base, and an unsafe exact point is
    reported instead of being silently replaced by a forecast.
    """
    assumption = projection if projection is not None else context.inflation_projection
    annual_rate = assumption
    profile_id = assumption.profile_id if assumption is not None else PROJECTION_PROFILE_ID
    targets = index_targets or {}
    index_points: list[ProjectionPoint] = []
    price_points: tuple[ProjectionPoint, ...] = ()
    warnings: list[str] = []
    safe_anchors: list[IndexAnchor] = []
    unsafe_anchor_keys: set[tuple[IndexKind, date]] = set()
    for anchor in context.index_anchors:
        if _projection_input_usable(
            anchor.reference_date, anchor.quality, anchor.provenance, as_of, evidence_mode
        ):
            safe_anchors.append(anchor)
        else:
            unsafe_anchor_keys.add((anchor.kind, anchor.reference_date))

    projected_anchors: list[IndexAnchor] = []
    nominal_calculations: dict[date, NominalIndexResult] = {}

    def nominal_at(day: date) -> NominalIndexResult:
        if day not in nominal_calculations:
            nominal_calculations[day] = calculate_nominal_index(
                day, context.ipca_monthly_indexes,
                as_of=as_of or day, evidence_mode=evidence_mode,
                projection=assumption, monthly_rates=context.ipca_monthly_rates,
            )
        return nominal_calculations[day]

    for kind, requested_dates in targets.items():
        target_dates = tuple(dict.fromkeys(requested_dates))
        explicit = tuple(
            DatedLevel(item.reference_date, item.value, item.quality, item.source_ref)
            for item in safe_anchors if item.kind is kind
        )
        points = project_level_series(kind.value, explicit, target_dates, annual_rate)
        for point in points:
            exact_key = (kind, point.reference_date)
            if context.require_automatic_nominal or context.ipca_monthly_indexes:
                calculated = nominal_at(point.reference_date)
                point = ProjectionPoint(kind.value, point.reference_date, calculated.status,
                    calculated.reason_code, calculated.value, calculated.quality,
                    calculated.source_ref, calculated.previous_reference_date, calculated.profile_id)
                if calculated.status == 'available':
                    projected_anchors.append(IndexAnchor(kind, calculated.value, point.reference_date,
                        calculated.quality, calculated.source_ref))
                    index_points.append(point)
                    if calculated.quality is Quality.HYPOTHETICAL:
                        warnings.append(f'{kind.value} calculado com inflação projetada explícita em {point.reference_date.isoformat()}; {calculated.profile_id}.')
                    continue
                index_points.append(point)
                continue
            if (kind, point.reference_date) in unsafe_anchor_keys:
                index_points.append(ProjectionPoint(
                    point.series_id, point.reference_date, "blocked_policy",
                    "EXPLICIT_EVIDENCE_UNAVAILABLE", None, Quality.MISSING, None,
                ))
                continue
            index_points.append(point)
            if point.status == "available" and point.reason_code == "HYPOTHETICAL_PROJECTION":
                key_exists = any(
                    item.kind is kind and item.reference_date == point.reference_date
                    for item in context.index_anchors
                )
                if not key_exists:
                    projected_anchors.append(IndexAnchor(
                        kind, point.value, point.reference_date, Quality.HYPOTHETICAL,
                        point.source_ref or profile_id,
                    ))
                warnings.append(
                    f"{kind.value} projetado em {point.reference_date.isoformat()} sob {profile_id}; não equivale ao índice oficial."
                )

    evidence_by_date: dict[date, PriceIndexEvidence] = {}
    for evidence in context.price_index_evidence:
        if evidence.reference_date in evidence_by_date:
            raise ValidationError("CONFLICTING_INDEX", "Índice geral de preços tem proveniência duplicada na mesma data.")
        evidence_by_date[evidence.reference_date] = evidence
    level_dates = {item.date for item in context.index_levels}
    if set(evidence_by_date) - level_dates:
        raise ValidationError("INVALID_INDEX", "Proveniência sem nível correspondente no índice geral de preços.")
    safe_levels: list[IndexLevel] = []
    safe_level_evidence: list[PriceIndexEvidence] = []
    quality_by_date: dict[date, Quality] = {}
    unsafe_level_dates: set[date] = set()
    for level in context.index_levels:
        evidence = evidence_by_date.get(level.date)
        quality = evidence.quality if evidence is not None else Quality.INFORMED
        provenance = evidence.provenance if evidence is not None else None
        if _projection_input_usable(level.date, quality, provenance, as_of, evidence_mode):
            safe_levels.append(level)
            quality_by_date[level.date] = quality
            if evidence is not None:
                safe_level_evidence.append(evidence)
        else:
            unsafe_level_dates.add(level.date)
    seed = None if assumption is None else DatedLevel(
        assumption.anchor_date, assumption.anchor_level, Quality.HYPOTHETICAL,
        f"{profile_id}; hipótese declarada: {assumption.source_ref}",
    )
    level_inputs = tuple(
        DatedLevel(item.date, item.value, quality_by_date[item.date], item.source_ref)
        for item in safe_levels
    )
    # Reconstruct purchasing-power levels from the same monthly IPCA inputs.
    # Explicit general-index inputs retain precedence; no invented index of 1.
    if (context.require_automatic_nominal or context.ipca_monthly_indexes) and not context.index_levels:
        calculated_price_points = []
        for day in tuple(dict.fromkeys(price_index_targets)):
            calculated = nominal_at(day)
            calculated_price_points.append(ProjectionPoint('PRICE_INDEX', day,
                calculated.status, calculated.reason_code, calculated.value,
                calculated.quality, calculated.source_ref,
                calculated.previous_reference_date, calculated.profile_id))
        raw_price_points = tuple(calculated_price_points)
    else:
        raw_price_points = project_level_series(
            "PRICE_INDEX", level_inputs, tuple(dict.fromkeys(price_index_targets)),
            annual_rate, projection_seed=seed,
        )
    projected_levels: list[IndexLevel] = []
    projected_level_evidence: list[PriceIndexEvidence] = []
    safe_price_points: list[ProjectionPoint] = []
    for point in raw_price_points:
        if point.reference_date in unsafe_level_dates:
            safe_price_points.append(ProjectionPoint(
                point.series_id, point.reference_date, "blocked_policy",
                "EXPLICIT_EVIDENCE_UNAVAILABLE", None, Quality.MISSING, None,
            ))
            warnings.append(
                f"Nível explícito de preços indisponível no corte em {point.reference_date.isoformat()}."
            )
            continue
        safe_price_points.append(point)
        if point.status == "available" and (point.profile_id == NOMINAL_PROFILE_ID or point.reason_code in (
            "HYPOTHETICAL_PROJECTION", "HYPOTHETICAL_PROJECTION_ANCHOR",
        )):
            if any(item.date == point.reference_date for item in safe_levels):
                continue
            projected_levels.append(IndexLevel(
                point.reference_date, point.value,
                point.source_ref or profile_id,
            ))
            projected_level_evidence.append(PriceIndexEvidence(
                point.reference_date, point.quality,
            ))
            if point.profile_id == NOMINAL_PROFILE_ID:
                warnings.append(f'Nível para retorno real reconstruído do mesmo IPCA mensal em {point.reference_date.isoformat()}; {point.quality.value}.')
            else:
                warnings.append(
                    f"Nível geral de preços projetado em {point.reference_date.isoformat()} sob {profile_id}; hipótese distinta de VNA/VNI."
                )
        elif point.status != "available":
            if assumption is not None:
                warnings.append(
                    f"Nível geral de preços indisponível em {point.reference_date.isoformat()}: {point.reason_code}."
                )

    resolved_context = EvaluationContext(
        calendar=context.calendar,
        index_anchors=tuple(anchor for anchor in context.index_anchors
            if not ((context.require_automatic_nominal or context.ipca_monthly_indexes) and anchor.kind in targets
                    and anchor.reference_date in targets[anchor.kind])) + tuple(projected_anchors),
        tax_cost_basis=context.tax_cost_basis,
        entry_expense_paid=context.entry_expense_paid,
        exit_expense=context.exit_expense,
        custody_override=context.custody_override,
        institution_net_override=context.institution_net_override,
        intermediate_paid_costs=context.intermediate_paid_costs,
        index_levels=tuple(safe_levels) + tuple(projected_levels),
        institution_release_date=context.institution_release_date,
        inflation_projection=assumption,
        price_index_evidence=tuple(safe_level_evidence) + tuple(projected_level_evidence),
        capital_mode=context.capital_mode,
        tax_cost_basis_source=context.tax_cost_basis_source,
        settlement_quality=context.settlement_quality,
        ipca_monthly_indexes=context.ipca_monthly_indexes,
        ipca_monthly_rates=context.ipca_monthly_rates,
        require_automatic_nominal=context.require_automatic_nominal,
    )
    return ProjectionWindow(
        resolved_context, tuple(index_points), tuple(safe_price_points), tuple(dict.fromkeys(warnings)), tuple(nominal_calculations.values())
    )


def _resolve_price(
    scenario: Scenario,
    context: EvaluationContext,
    *,
    entry: bool,
) -> tuple[Decimal | None, Quality, str, tuple[EvidenceStatus, ...], tuple[str, ...], CalculationStep | None]:
    quote = scenario.entry if entry else scenario.exit
    target_date = quote.settlement_date
    is_entry = entry
    source_side = Side.BUY if is_entry else quote.quoted_side
    manual_pu = quote.unit_price
    rate = quote.real_yield
    spread = None if is_entry else quote.spread
    if not is_entry and quote.quoted_side is Side.BUY:
        rate = rate + spread if rate is not None and spread is not None else None
    provenance = quote.provenance
    evidence: tuple[EvidenceStatus, ...] = ()
    warnings: list[str] = []

    if provenance is not None:
        status, reason = _evidence_gate(provenance, provenance.quality, scenario)
        if status is not None:
            evidence = (status,)
        if reason is not None:
            return None, provenance.quality, status.value if status else "UNAVAILABLE", evidence, [reason], None
        if provenance.is_revision:
            warnings.append("A cotação usada é uma versão revisada.")
        elif provenance.quality not in (Quality.OBSERVED, Quality.REVISED):
            warnings.append(f"Valor {provenance.quality.value.lower()} informado; não é cotação executável certificada.")
    elif manual_pu is not None:
        warnings.append("PU informado sem proveniência; resultado tratado como hipótese manual.")

    if manual_pu is not None:
        quality = provenance.quality if provenance else Quality.INFORMED
        step = CalculationStep(
            "PU de entrada informado" if is_entry else "PU de venda informado",
            "PU efetivo digitado ou observado prevalece sobre a reconstrução teórica",
            (("lado", source_side.value), ("data_financeira", target_date.isoformat())),
            str(manual_pu), quality, source_ref=provenance.source_ref if provenance else "Entrada manual",
        )
        anchor = _anchor_for(scenario, context, target_date)
        if rate is not None and anchor is not None and context.calendar is not None:
            anchor_status, anchor_reason = _evidence_gate(anchor.provenance, anchor.quality, scenario)
            if anchor_reason is not None:
                warnings.append("Âncora teórica excluída da comparação: " + anchor_reason)
            else:
                theoretical = _theoretical_price(scenario, context.calendar, anchor, target_date, rate)
                if theoretical is not None and theoretical != manual_pu:
                    warnings.append(
                        f"PU observado/informado preservado; reconstrução teórica difere em {manual_pu - theoretical}."
                    )
        return manual_pu, quality, "READY", evidence, warnings, step

    if rate is None:
        return None, Quality.MISSING, "MISSING_PRICE", evidence, ["PU e taxa não foram informados."], None
    anchor = _anchor_for(scenario, context, target_date)
    if anchor is None:
        return None, Quality.MISSING, "MISSING_INDEX", evidence, [f"Falta {IndexKind.VNA.value if scenario.instrument.family is ProductFamily.IPCA_PRINCIPAL else IndexKind.VNI.value} na data financeira {target_date.isoformat()}."], None
    if anchor.reference_date != target_date:
        return None, Quality.MISSING, "MISSING_INDEX", evidence, ["A âncora não corresponde à data financeira; projeção não foi inventada."], None

    anchor_status, anchor_reason = _evidence_gate(anchor.provenance, anchor.quality, scenario)
    if anchor_status is not None:
        evidence += (anchor_status,)
    if anchor_reason is not None:
        return None, anchor.quality, anchor_status.value if anchor_status else "UNAVAILABLE", evidence, [anchor_reason], None
    if anchor.quality not in (Quality.OBSERVED, Quality.REVISED):
        warnings.append(f"Âncora {anchor.quality.value.lower()} usada como hipótese/informação declarada.")

    if context.calendar is None:
        return None, Quality.MISSING, "MISSING_CALENDAR", evidence, ["Precificação por taxa exige calendário identificado."], None
    price = _theoretical_price(scenario, context.calendar, anchor, target_date, rate)
    if price is None:
        return None, Quality.MISSING, "MISSING_INDEX", evidence, ["Índice insuficiente para o PU teórico."], None
    if (
        scenario.intent is ScenarioIntent.HYPOTHETICAL
        or anchor.quality is Quality.HYPOTHETICAL
        or (provenance is not None and provenance.quality is Quality.HYPOTHETICAL)
    ):
        quality = Quality.HYPOTHETICAL
    elif anchor.quality is Quality.ESTIMATED or (
        provenance is not None and provenance.quality is Quality.ESTIMATED
    ):
        quality = Quality.ESTIMATED
    else:
        # A PU derived from an index and a yield is a reconstructed price, even
        # when one or both source inputs were observed.
        quality = Quality.RECONSTRUCTED
    if not is_entry and quote.quoted_side is Side.BUY:
        warnings.append(
            f"Taxa de compra convertida em taxa de recompra com spread explícito de {quote.spread}."
        )
    step = CalculationStep(
        "PU teórico de entrada" if is_entry else "PU teórico de saída",
        "Preço reconstruído com taxa, índice compatível e método versionado",
        (("taxa_real", str(rate)), ("índice", str(anchor.value)), ("data_financeira", target_date.isoformat())),
        str(price), quality, source_ref=anchor.source_ref,
    )
    return price, quality, "READY", evidence, warnings, step


def _immutable_price_inputs(args, kwargs):
    from ..calendar_rules import FinancialCalendar
    from ..calendar_data import CalendarPack
    calendar = args[1] if len(args) > 1 else kwargs.get('calendar')
    instrument = args[0] if args else kwargs.get('instrument')
    anchor = args[2] if len(args) > 2 else kwargs.get('anchor')
    from .contracts import Instrument
    return (type(instrument) is Instrument and type(anchor) is IndexAnchor
            and type(calendar) is FinancialCalendar
            and (calendar.overlay is None or type(calendar.overlay) is CalendarPack))


@scoped_memo(guard=_immutable_price_inputs)
def price_indexed_security(
    instrument: Any,
    calendar: Any,
    anchor: IndexAnchor,
    target_date: date,
    rate: Decimal,
) -> Decimal | None:
    """Price a Principal or RendA+ at a date from its exact VNA/VNI anchor."""
    if instrument.family is ProductFamily.IPCA_PRINCIPAL:
        du = business_days_to_maturity(
            target_date, instrument.maturity_date, calendar
        )
        return price_principal(anchor.value, rate, du).published_pu
    series = RendaPlusSeries.for_conversion_year(instrument.conversion_date.year)
    return price_renda_plus(series, target_date, anchor.value, rate, calendar, anchor.quality).published_pu


GROSS_DV01_METHOD_VERSION = "DIRECT_REPRICING_GROSS_DV01_v1"
GROSS_DV01_RATE_SHOCK = Decimal("0.0001")


def evaluate_gross_dv01(
    instrument: Any,
    calendar: Any,
    anchor: IndexAnchor,
    financial_date: date,
    annual_real_rate: Decimal,
    quantity: Decimal | None = None,
) -> dict[str, Any]:
    """Measure gross price change from exactly two direct one-bp repricings."""
    from .contracts import decimal_value
    from .policies import round_money

    if calendar is None:
        raise ValidationError("MISSING_CALENDAR", "DV01 exige calendário financeiro.")
    if not isinstance(financial_date, date):
        raise ValidationError("MISSING_FINANCIAL_DATE", "DV01 exige data financeira resolvida.")
    if not isinstance(anchor, IndexAnchor):
        raise ValidationError("MISSING_INDEX", "DV01 exige âncora nominal compatível.")
    expected_kind = IndexKind.VNA if instrument.family is ProductFamily.IPCA_PRINCIPAL else IndexKind.VNI
    if anchor.kind is not expected_kind or anchor.reference_date != financial_date:
        raise ValidationError("INDEX_DATE_OR_KIND_MISMATCH", "A âncora precisa corresponder ao VNA/VNI da data financeira.")
    horizon = instrument.maturity_date if instrument.family is ProductFamily.IPCA_PRINCIPAL else instrument.first_income_date
    if horizon is None or financial_date >= horizon:
        raise ValidationError("OUTSIDE_HORIZON", "A data financeira está fora do horizonte elegível para DV01.")
    rate = decimal_value(annual_real_rate, "taxa real aplicada")
    shocked_rate = rate + GROSS_DV01_RATE_SHOCK
    if quantity is not None:
        quantity = decimal_value(quantity, "quantidade")
        if quantity <= 0 or quantity % Decimal("0.01") != 0:
            raise ValidationError("INVALID_QUANTITY", "Quantidade deve ser positiva em múltiplos de 0,01 título.")

    # Keep all financial conditions fixed. These are the only two price-kernel
    # evaluations in this calculation; quantity sizing is performed afterward.
    base_pu = price_indexed_security(instrument, calendar, anchor, financial_date, rate)
    shocked_pu = price_indexed_security(instrument, calendar, anchor, financial_date, shocked_rate)
    if base_pu is None or shocked_pu is None:
        raise ValidationError("PRICE_UNAVAILABLE", "O motor não retornou ambos os PUs para o choque.")

    signed_delta = shocked_pu - base_pu
    result: dict[str, Any] = {
        "metric": "GROSS_DV01",
        "method": GROSS_DV01_METHOD_VERSION,
        "instrument": {
            "family": instrument.family.value,
            "instrument_id": instrument.instrument_id,
            "maturity_date": instrument.maturity_date.isoformat(),
            "conversion_date": instrument.conversion_date.isoformat() if instrument.conversion_date else None,
            "first_income_date": instrument.first_income_date.isoformat() if instrument.first_income_date else None,
        },
        "financial_date": financial_date.isoformat(),
        "nominal": {
            "kind": anchor.kind.value,
            "value": str(anchor.value),
            "reference_date": anchor.reference_date.isoformat(),
            "quality": anchor.quality.value,
            "source_ref": anchor.source_ref,
            "provenance": None if anchor.provenance is None else {
                "source_id": anchor.provenance.source_id,
                "source_ref": anchor.provenance.source_ref,
                "quality": anchor.provenance.quality.value,
                "observed_on": anchor.provenance.observed_on.isoformat() if anchor.provenance.observed_on else None,
                "published_at": anchor.provenance.published_at.isoformat() if anchor.provenance.published_at else None,
                "version": anchor.provenance.version,
                "sha256": anchor.provenance.sha256,
                "revision_id": anchor.provenance.revision_id,
                "supersedes_revision": anchor.provenance.supersedes_revision,
                "settlement_date": anchor.provenance.settlement_date.isoformat() if anchor.provenance.settlement_date else None,
            },
        },
        "base_rate": str(rate),
        "shocked_rate": str(shocked_rate),
        "shock": {
            "rate_delta": str(GROSS_DV01_RATE_SHOCK),
            "basis_points": "1",
            "unit": "ratio",
        },
        "pu_base": str(base_pu),
        "pu_shocked": str(shocked_pu),
        "pu_unit": "BRL_PER_TITLE",
        "signed_unit_delta": str(signed_delta),
        "reduction_if_yield_up": str(base_pu - shocked_pu),
        "quality": anchor.quality.value,
        "source_versions": {},
        "provenance": {"nominal": None if anchor.provenance is None else {
            "source_id": anchor.provenance.source_id,
            "source_ref": anchor.provenance.source_ref,
            "quality": anchor.provenance.quality.value,
            "observed_on": anchor.provenance.observed_on.isoformat() if anchor.provenance.observed_on else None,
            "published_at": anchor.provenance.published_at.isoformat() if anchor.provenance.published_at else None,
            "version": anchor.provenance.version,
            "sha256": anchor.provenance.sha256,
            "revision_id": anchor.provenance.revision_id,
            "supersedes_revision": anchor.provenance.supersedes_revision,
            "settlement_date": anchor.provenance.settlement_date.isoformat() if anchor.provenance.settlement_date else None,
        }},
        "price_profile": (
            PRINCIPAL_PRICING_VERSION
            if instrument.family is ProductFamily.IPCA_PRINCIPAL
            else RENDA_PLUS_PRICING_VERSION
        ),
        "status": "available",
        "reason_code": "PUBLISHED_PU_UNCHANGED" if signed_delta == 0 else None,
        "is_gross": True,
        "is_analytic_approximation": False,
        "is_net_of_costs_or_taxes": False,
        "costs_and_taxes_included": False,
    }
    if quantity is not None:
        position_base = round_money(quantity * base_pu)
        position_shocked = round_money(quantity * shocked_pu)
        result.update({
            "quantity": str(quantity),
            "quantity_unit": "TITLE",
        "position_unit": "BRL",
            "position_base": str(position_base),
            "position_shocked": str(position_shocked),
            "gross_position_delta": str(position_shocked - position_base),
            "position_money_rounding": "ROUND_HALF_UP_PER_REPRICED_AMOUNT_v1",
        })
    else:
        result.update({
            "quantity": None,
            "quantity_unit": "TITLE",
            "position_base": None,
            "position_shocked": None,
            "gross_position_delta": None,
            "position_money_rounding": "ROUND_HALF_UP_PER_REPRICED_AMOUNT_v1",
        })
    return result


def _theoretical_price(scenario: Scenario, calendar: Any, anchor: IndexAnchor,
                       target_date: date, rate: Decimal) -> Decimal | None:
    return price_indexed_security(scenario.instrument, calendar, anchor, target_date, rate)


def evaluate_scenario(
    scenario: Scenario,
    context: EvaluationContext = EvaluationContext(),
) -> ScenarioEvaluation:
    """Calcula PU e caixa usando o mesmo motor financeiro do domínio."""
    required_kind = IndexKind.VNA if scenario.instrument.family is ProductFamily.IPCA_PRINCIPAL else IndexKind.VNI
    rate_dates = tuple(
        quote.settlement_date
        for quote in (scenario.entry, scenario.exit)
        if quote.real_yield is not None
    )
    real_dates = tuple(dict.fromkeys((
        scenario.entry.settlement_date,
        scenario.exit.settlement_date,
        *(item.date for item in context.intermediate_paid_costs),
    )))
    projection_window = prepare_projection_window(
        context,
        index_targets={required_kind: rate_dates},
        price_index_targets=real_dates,
        as_of=scenario.as_of.date,
        evidence_mode=scenario.as_of.mode,
    )
    context = projection_window.context
    scenario_id = _scenario_id(scenario)
    entry_pu, entry_quality, entry_status, entry_evidence, entry_warnings, entry_step = _resolve_price(
        scenario, context, entry=True
    )
    exit_pu, exit_quality, exit_status, exit_evidence, exit_warnings, exit_step = _resolve_price(
        scenario, context, entry=False
    )
    warnings = entry_warnings + exit_warnings
    steps = tuple(step for step in (entry_step, exit_step) if step is not None)
    evidence = entry_evidence + exit_evidence
    if entry_pu is None or exit_pu is None:
        status = next(
            (value for value in (entry_status, exit_status) if value != "READY"),
            "MISSING_PRICE",
        )
        return ScenarioEvaluation(
            scenario_id, status, entry_pu, exit_pu, None, steps, tuple(warnings), evidence
        )
    if scenario.exit.side is Side.BASE:
        marked_value = scenario.entry.quantity * exit_pu
        marked_step = CalculationStep(
            "Valor marcado por PU Base",
            "quantidade × PU Base; referência de marcação, sem caixa de venda",
            (("quantidade", str(scenario.entry.quantity)), ("PU Base", str(exit_pu))),
            str(marked_value), exit_quality,
            source_ref=scenario.exit.provenance.source_ref if scenario.exit.provenance else "Entrada manual",
        )
        return ScenarioEvaluation(
            scenario_id, "MARKED_ONLY", entry_pu, exit_pu, None,
            steps + (marked_step,), tuple(warnings), evidence, marked_value,
        )
    operation = calculate_operation(OperationRequest(
        scenario=scenario,
        entry_pu=entry_pu,
        exit_pu=exit_pu,
        tax_cost_basis=context.tax_cost_basis,
        entry_expense_paid=context.entry_expense_paid,
        exit_expense=context.exit_expense,
        custody_override=context.custody_override,
        institution_net_override=context.institution_net_override,
        intermediate_paid_costs=context.intermediate_paid_costs,
        index_levels=context.index_levels,
        calendar=context.calendar,
        institution_release_date=context.institution_release_date,
    ))
    real_metric_quality = (
        _real_metric_quality(context, real_dates)
        if operation.real_profit_in_exit_date_currency is not None or operation.real_return is not None
        else Quality.MISSING
    )
    quantity_quality = entry_quality if context.capital_mode == "BUDGET" else None
    gross_quality = _combine_metric_quality(exit_quality, quantity_quality)
    tax_basis_quality = (
        Quality.INFORMED if context.tax_cost_basis_source == "INFORMED" else entry_quality
    )
    iof_quality = _combine_metric_quality(gross_quality, context.settlement_quality)
    income_tax_quality = _combine_metric_quality(
        gross_quality, tax_basis_quality, context.settlement_quality,
    )
    informed_net = operation.status == "READY_INFORMED_NET"
    if informed_net:
        iof_quality = income_tax_quality = custody_quality = Quality.MISSING
        net_quality = Quality.INFORMED
    else:
        custody_quality = Quality.INFORMED if context.custody_override is not None else Quality.ESTIMATED
        net_quality = _combine_metric_quality(
            gross_quality, income_tax_quality, custody_quality, Quality.INFORMED,
        )
    profit_quality = _combine_metric_quality(
        net_quality, entry_quality,
        Quality.INFORMED if context.intermediate_paid_costs else None,
    )
    if real_metric_quality is not Quality.MISSING:
        real_metric_quality = _combine_metric_quality(real_metric_quality, profit_quality)
    detail_steps = list(steps)
    detail_steps.extend((
        CalculationStep(
            "Desembolso inicial", "quantidade × PU de compra + despesas pagas na entrada",
            (("quantidade", str(operation.quantity)), ("PU", str(entry_pu))),
            str(operation.initial_outflow), entry_quality,
        ),
        CalculationStep(
            "Valor bruto de venda", "quantidade × PU de recompra",
            (("quantidade", str(operation.quantity)), ("PU de venda", str(exit_pu))),
            str(operation.gross_redemption), gross_quality,
        ),
        CalculationStep(
            "IOF", "1% ao dia sobre o resgate, limitado ao Anexo legal por prazo",
            (("prazo em dias", str(operation.holding_days)),),
            _display_value(operation.iof), iof_quality,
            policy_id=operation.policies[0] if operation.policies else None,
        ),
        CalculationStep(
            "IR", "alíquota legal × rendimento nominal positivo após IOF",
            (("custo fiscal", str(operation.tax_cost_basis)), ("IOF", _display_value(operation.iof))),
            _display_value(operation.income_tax), income_tax_quality,
            policy_id=operation.policies[1] if len(operation.policies) > 1 else None,
        ),
        CalculationStep(
            "Custódia", "estimativa conforme política identificada do produto",
            (("valor bruto", str(operation.gross_redemption)),),
            _display_value(operation.custody), custody_quality,
            policy_id=operation.policies[2] if len(operation.policies) > 2 else None,
        ),
        CalculationStep(
            "Caixa líquido da venda",
            "bruto − IOF − IR − custódia a cobrar − despesas da saída",
            (("bruto", str(operation.gross_redemption)), ("IOF", _display_value(operation.iof)),
             ("IR", _display_value(operation.income_tax)), ("custódia", _display_value(operation.custody)),
             ("despesa saída", str(operation.exit_expense))),
            _display_value(operation.net_redemption), net_quality,
        ),
        CalculationStep(
            "Resultado econômico nominal",
            "caixa líquido − desembolso inicial + fluxos de custos intermediários",
            (("caixa líquido", str(operation.net_redemption)),
             ("desembolso inicial", str(operation.initial_outflow))),
            _display_value(operation.nominal_profit), profit_quality,
        ),
        CalculationStep(
            "Retorno nominal simples", "caixa líquido / desembolso inicial − 1",
            (("prazo em dias", str(operation.holding_days)),),
            _display_value(operation.nominal_return), profit_quality,
        ),
        CalculationStep(
            "Retorno nominal anualizado",
            "(caixa líquido / desembolso inicial) elevado a 365 / dias − 1; exige dois fluxos",
            (("prazo em dias", str(operation.holding_days)),),
            _display_value(operation.annualized_nominal_return), profit_quality,
        ),
        CalculationStep(
            "Retorno real", "deflação dos fluxos com níveis de índice nas datas compatíveis",
            (("lucro real em moeda da saída", _display_value(operation.real_profit_in_exit_date_currency)),),
            _display_value(operation.real_return), real_metric_quality,
        ),
    ))
    final_warnings = list(projection_window.warnings) + warnings + list(operation.warnings)
    status = operation.status
    if status not in ("BLOCKED_POLICY", "ESTIMATED_NET", "READY_INFORMED_NET"):
        if Quality.HYPOTHETICAL in (entry_quality, exit_quality):
            status = "READY_HYPOTHETICAL"
        elif Quality.OBSERVED in (entry_quality, exit_quality):
            status = "READY_OBSERVED"
    return ScenarioEvaluation(
        scenario_id, status, entry_pu, exit_pu, operation,
        tuple(detail_steps), tuple(final_warnings), evidence,
    )


def compare_scenarios(
    left: Scenario,
    right: Scenario,
    kind: ComparisonKind,
    context: EvaluationContext = EvaluationContext(),
    destination_date: date | None = None,
    cash_growth_rate: Decimal | None = None,
) -> ScenarioComparison:
    _validate_comparison_pair(left, right, kind, context)
    left_result = evaluate_scenario(left, context)
    right_result = evaluate_scenario(right, context)
    left_net = left_result.operation.net_redemption if left_result.operation else None
    right_net = right_result.operation.net_redemption if right_result.operation else None
    if left_net is None or right_net is None:
        return ScenarioComparison(
            kind, left_result, right_result, False, None, None,
            warnings=("Uma alternativa não tem caixa líquido disponível.",),
        )
    if kind is ComparisonKind.ENTRY:
        same_day = left.exit.settlement_date == right.exit.settlement_date
        delta = right_net - left_net if same_day else None
        return ScenarioComparison(
            kind, left_result, right_result, same_day, delta,
            left.exit.settlement_date if same_day else None,
            warnings=() if same_day else ("Saídas em datas diferentes não são ordenáveis sem hipótese comum.",),
        )

    if left.exit.settlement_date == right.exit.settlement_date:
        return ScenarioComparison(
            kind, left_result, right_result, True, right_net - left_net,
            left.exit.settlement_date,
        )
    if destination_date is None or cash_growth_rate is None:
        return ScenarioComparison(
            kind, left_result, right_result, False, None, None,
            warnings=("Datas de caixa diferentes; informe data comum e crescimento explícito do caixa para comparar.",),
        )
    from .contracts import decimal_value
    rate = decimal_value(cash_growth_rate, "taxa de crescimento do caixa")
    if destination_date < left.exit.settlement_date or destination_date < right.exit.settlement_date or rate <= -1:
        raise ValidationError("INVALID_COMPARISON_ASSUMPTION", "Data comum posterior às duas saídas e taxa maior que −100% são obrigatórias.")
    with localcontext() as ctx:
        ctx.prec = 36
        left_days = (destination_date - left.exit.settlement_date).days
        right_days = (destination_date - right.exit.settlement_date).days
        value_left = left_net * ((D(1) + rate) ** (D(left_days) / D(365)))
        value_right = right_net * ((D(1) + rate) ** (D(right_days) / D(365)))
    return ScenarioComparison(
        kind, left_result, right_result, True, value_right - value_left,
        destination_date, value_left, value_right,
        assumption=f"Caixa líquido cresce à taxa nominal anual declarada {rate} até {destination_date.isoformat()}.",
    )


def _validate_comparison_pair(
    left: Scenario,
    right: Scenario,
    kind: ComparisonKind,
    context: EvaluationContext,
) -> None:
    if left.instrument != right.instrument or left.as_of != right.as_of:
        raise ValidationError("INCOMPARABLE_SCENARIOS", "Comparação exige mesmo título e mesma data/modo de referência.")
    if kind is ComparisonKind.ENTRY:
        if left.exit != right.exit:
            raise ValidationError("INCOMPARABLE_SCENARIOS", "Alternativas de entrada precisam compartilhar a mesma saída.")
    elif kind is ComparisonKind.EXIT:
        if left.entry != right.entry:
            raise ValidationError("INCOMPARABLE_SCENARIOS", "Alternativas de saída precisam compartilhar a mesma compra.")
    else:
        raise ValidationError("INVALID_COMPARISON", "Dimensão de comparação inválida.")
    if context.institution_net_override is not None:
        raise ValidationError("INCOMPARABLE_SCENARIOS", "Líquidos informados distintos devem ser associados a cada cenário.")
