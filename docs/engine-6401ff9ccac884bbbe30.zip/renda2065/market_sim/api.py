"""Contrato HTTP versionado para simulação; sem rede, persistência ou acesso ao Store."""
from __future__ import annotations

from dataclasses import fields, is_dataclass
from datetime import date, datetime
from decimal import Decimal
from enum import StrEnum
from hashlib import sha256
import json
from math import isfinite
import re
from typing import Any, Mapping

from ..calendar_rules import FinancialCalendar
from .contracts import AsOf, Entry, Exit, Instrument, ProductFamily, Scenario, Side, ValidationError, decimal_value
from .operation import CashFlow, IndexLevel
from .provenance import EvidenceMode, Provenance, Quality
from .service import EvaluationContext, IndexAnchor, IndexKind, evaluate_scenario
from .surfaces import (
    ExitObservation, SurfaceMetric, SurfaceSession, build_date_curve,
    build_decision_map, build_exit_frontier, build_rate_curve, build_rate_date_map,
)
from .targets import TargetDefinition, TargetMetric
from .workspace import WORKSPACE_SEARCH_BUDGET, parse_workspace_analysis_context

SCHEMA_VERSION = 1
API_CALENDAR_ID = "BR_FINANCIAL_RULES_PROJECTED_v1"
MAX_ANCHORS = 1261
MAX_COST_FLOWS = 240
G5_BASIS_SEMANTICS_VERSION = "G5_DUAL_BASES_V1"
G5_REFERENCE_BASIS_ID = "G3_MANUAL_PU_REFERENCE"
G5_MANUAL_BASIS_ID = "G3_MANUAL_PU"
G5_REPRICED_BASIS_ID = "G5_REPRICED_RATE_0.069879_INFLATION_0.03"
WORKSPACE_INPUT_FIELDS = {
    "instrument", "capital", "purchase_date", "sale_date", "entry_price",
    "exit_price", "knowledge", "intent", "assumptions", "data", "source_versions", "constraints",
    "analysis_context",
}
_WORKSPACE_DECIMAL_KEYS = {
    "value", "pu", "annual_real_rate", "spread", "fixed_brl", "proportional_rate",
    "exit_fee_brl", "tax_cost_basis_brl", "custody_override_brl", "institution_net_brl",
    "anchor_level", "amount_brl",
}


def evaluate_payload(payload: object) -> dict[str, Any]:
    request = _object(payload, "requisição", {"schema_version", "scenario", "context"}, {"schema_version", "scenario"})
    _check_version(request)
    scenario = _scenario(request["scenario"])
    context, context_warnings = _context(request.get("context", {}), scenario)
    result = evaluate_scenario(scenario, context)
    warnings = list(result.warnings) + context_warnings
    return {
        "schema_version": SCHEMA_VERSION,
        "scenario_id": result.scenario_id,
        "status": result.status,
        "entry_pu": _json_ready(result.entry_pu),
        "exit_pu": _json_ready(result.exit_pu),
        "marked_value": _json_ready(result.marked_value),
        "operation": _json_ready(result.operation),
        "steps": _json_ready(result.steps),
        "warnings": warnings,
        "evidence_statuses": _json_ready(result.evidence_statuses),
        "context": {
            "calendar_id": getattr(context.calendar, "calendar_id", None),
            "calendar_knowledge_date": _json_ready(getattr(context.calendar, "knowledge_date", None)),
            "tax_cost_basis": _json_ready(context.tax_cost_basis),
        },
    }


def surface_payload(payload: object) -> dict[str, Any]:
    allowed = {
        "schema_version", "mode", "scenario", "context", "metric", "rates",
        "observations", "sessions", "selected_order_date", "selected_rate",
        "target", "targets", "rate_bounds", "rate_tolerance", "price_points", "selected_pu", "order_dates",
    }
    request = _object(payload, "requisição", allowed, {"schema_version", "mode", "scenario", "metric"})
    _check_version(request)
    scenario = _scenario(request["scenario"])
    context, context_warnings = _context(request.get("context", {}), scenario)
    metric = _surface_metric(request["metric"])
    mode = _text(request["mode"], "modo", 32)
    selected_order_date = _date(request.get("selected_order_date"), "data selecionada", optional=True)

    if mode == "RATE_CURVE":
        _mode_keys(request, {"schema_version", "mode", "scenario", "context", "metric", "rates", "selected_rate"}, {"rates"})
        rates = _sequence(request["rates"], "taxas", 101)
        selected_rate = _decimal(request.get("selected_rate"), "taxa selecionada", optional=True)
        result = build_rate_curve(scenario, rates, context, metric, selected_rate=selected_rate)
        return {"schema_version": SCHEMA_VERSION, "surface": _json_ready(result.to_dict()), "warnings": context_warnings}

    if mode == "DATE_CURVE":
        _mode_keys(request, {"schema_version", "mode", "scenario", "context", "metric", "observations", "selected_order_date"}, {"observations"})
        observations = tuple(_observation(item) for item in _sequence(request["observations"], "observações", 1260))
        result = build_date_curve(
            scenario, observations, context, metric,
            selected_order_date=selected_order_date,
        )
        return {"schema_version": SCHEMA_VERSION, "surface": _json_ready(result.to_dict()), "warnings": context_warnings}

    if mode == "RATE_DATE_MAP":
        _mode_keys(request, {"schema_version", "mode", "scenario", "context", "metric", "sessions", "rates", "selected_order_date", "selected_rate"}, {"sessions", "rates", "selected_order_date", "selected_rate"})
        sessions = tuple(_session(item) for item in _sequence(request["sessions"], "sessões", 1260))
        rates = _sequence(request["rates"], "taxas", 101)
        selected_rate = _decimal(request["selected_rate"], "taxa selecionada")
        result = build_rate_date_map(
            scenario, sessions, rates, context, metric,
            selected_order_date=selected_order_date,
            selected_rate=selected_rate,
        )
        return {"schema_version": SCHEMA_VERSION, "surface": _json_ready(result.to_dict()), "warnings": context_warnings}

    if mode == "DECISION_MAP":
        _mode_keys(request, {
            "schema_version", "mode", "scenario", "context", "metric", "order_dates",
            "price_points", "targets", "selected_order_date", "selected_pu",
        }, {"order_dates", "price_points", "targets", "selected_order_date", "selected_pu"})
        order_dates = tuple(_date(item, "data de venda") for item in _sequence(request["order_dates"], "datas", 1260))
        prices = _sequence(request["price_points"], "PUs", 101)
        targets = tuple(_target(item) for item in _sequence(request["targets"], "metas", 4))
        if any(item is None for item in targets):
            raise ValidationError("INVALID_TARGET", "Metas da grade precisam ser objetos completos.")
        selected_pu = _decimal(request["selected_pu"], "PU selecionado")
        result = build_decision_map(
            scenario, order_dates, prices, context, metric, targets,
            selected_order_date=selected_order_date, selected_pu=selected_pu,
        )
        return {"schema_version": SCHEMA_VERSION, "surface": _json_ready(result.to_dict()),
                "warnings": context_warnings + ["Grade de PUs hipotéticos; cores não são preços de mercado nem previsões."]}

    if mode == "EXIT_FRONTIER":
        _mode_keys(request, {
            "schema_version", "mode", "scenario", "context", "metric", "sessions",
            "selected_order_date", "target", "rate_bounds", "rate_tolerance",
        }, {"sessions"})
        sessions = tuple(_session(item) for item in _sequence(request["sessions"], "sessões", 1260))
        target = _target(request.get("target"))
        bounds = request.get("rate_bounds")
        if bounds is not None:
            bounds = _sequence(bounds, "limites de taxa", 2)
            if len(bounds) != 2:
                raise ValidationError("INVALID_RATE_DOMAIN", "Fronteira exige limite mínimo e máximo de taxa.")
        tolerance = _decimal(request.get("rate_tolerance", "0.000000001"), "tolerância de taxa")
        result = build_exit_frontier(
            scenario, sessions, context, target,
            selected_order_date=selected_order_date,
            rate_bounds=tuple(bounds) if bounds is not None else None,
            rate_tolerance=tolerance,
        )
        return {"schema_version": SCHEMA_VERSION, "frontier": _json_ready(result), "warnings": context_warnings}

    raise ValidationError("INVALID_SURFACE_MODE", "Modo de superfície não reconhecido.")


def _workspace_unit_price_query(raw: object, input_value: Mapping[str, Any]) -> dict[str, Any]:
    value = _object(raw, "query", {"kind", "rate_domain"}, {"kind"})
    kind = _text(value["kind"], "query.kind", 32)
    if kind == "POINT":
        _mode_keys(value, {"kind"}, {"kind"})
        context = parse_workspace_analysis_context(input_value.get("analysis_context"))
        if context.timeline_mode != "POINT":
            raise ValidationError("INVALID_ANALYSIS_CONTEXT", "POINT exige timeline POINT.")
        return {"kind": kind}
    if kind == "DATE_CURVE":
        _mode_keys(value, {"kind"}, {"kind"})
        context = parse_workspace_analysis_context(input_value.get("analysis_context"))
        if context.timeline_mode != "WINDOW" or context.start is None or context.end is None:
            raise ValidationError("INVALID_DATE_DOMAIN", "DATE_CURVE exige timeline WINDOW com início e fim.")
        if context.end < context.start:
            raise ValidationError("INVALID_DATE_DOMAIN", "O fim da janela não pode preceder o início.")
        if context.start.year < 2000 or context.end.year > 2085:
            raise ValidationError("INVALID_DATE_DOMAIN", "Janela DATE_CURVE excede o horizonte de calendário 2000–2085.")
        return {"kind": kind}
    if kind != "RATE_CURVE":
        raise ValidationError("INVALID_QUERY", "UNIT_PRICE aceita POINT, DATE_CURVE ou RATE_CURVE.")
    _mode_keys(value, {"kind", "rate_domain"}, {"kind", "rate_domain"})
    raw_domain = _object(
        value["rate_domain"], "query.rate_domain", {"minimum", "maximum", "step"},
        {"minimum", "maximum", "step"},
    )
    minimum = _decimal(raw_domain["minimum"], "query.rate_domain.minimum")
    maximum = _decimal(raw_domain["maximum"], "query.rate_domain.maximum")
    step = _decimal(raw_domain["step"], "query.rate_domain.step")
    if minimum <= -1 or maximum <= minimum or step <= 0:
        raise ValidationError("INVALID_RATE_DOMAIN", "Domínio de taxa precisa ser crescente, com taxas acima de −100% e passo positivo.")
    intervals = (maximum - minimum) / step
    if intervals != intervals.to_integral_value() or intervals > 100:
        raise ValidationError("INVALID_RATE_DOMAIN", "Extremos precisam alinhar à grade de no máximo 101 pontos.")
    family = (input_value.get("instrument") or {}).get("family") if isinstance(input_value.get("instrument"), Mapping) else None
    if family == "RENDA_PLUS" and (minimum < Decimal("-0.95") or maximum > Decimal("10")):
        raise ValidationError("INVALID_RATE_DOMAIN", "Taxa RendA+ precisa ficar entre −95% e 1.000% a.a.")
    context = parse_workspace_analysis_context(input_value.get("analysis_context"))
    if context.timeline_mode != "POINT":
        raise ValidationError("INVALID_RATE_DOMAIN", "RATE_CURVE exige timeline POINT.")
    return {"kind": kind, "rate_domain": {"minimum": minimum, "maximum": maximum, "step": step}}


def workspace_request(payload: object) -> dict[str, Any]:
    """Validate the strict v2 workspace envelope implemented by the local API."""
    request = _object(
        payload, "requisição workspace",
        {"schema_version", "action", "request_id", "revision", "input", "selection", "surface", "query",
         "reference", "alternatives", "comparison_mode", "horizon", "cash_growth", "shocks", "margin_searches",
         "max_evaluations", "deadline_ms", "fixed_position", "decision_margins", "quantity"},
        {"schema_version", "action", "request_id", "revision"},
    )
    if type(request["schema_version"]) is not int or request["schema_version"] != 2:
        raise ValidationError("UNSUPPORTED_SCHEMA", "Workspace requer schema_version 2.")
    action = _text(request["action"], "action", 32)
    if action not in {"RESOLVE", "EVALUATE", "UNIT_PRICE", "GROSS_DV01", "SURFACE", "CONSTRAINTS", "COMPARE", "STRESS"}:
        raise ValidationError("ACTION_NOT_AVAILABLE", "Ação workspace ainda não está disponível.")
    request_id = _text(request["request_id"], "request_id", 128)
    revision = request["revision"]
    if type(revision) is not int or revision <= 0:
        raise ValidationError("INVALID_REVISION", "revision precisa ser um inteiro positivo.")
    if action == "COMPARE":
        _mode_keys(
            request, {"schema_version", "action", "request_id", "revision", "reference", "alternatives", "comparison_mode", "horizon", "cash_growth"},
            {"schema_version", "action", "request_id", "revision", "reference", "alternatives"},
        )
        return _workspace_comparison_request(request)
    if action == "STRESS":
        _mode_keys(
            request,
            {"schema_version", "action", "request_id", "revision", "input", "shocks",
             "margin_searches", "max_evaluations", "deadline_ms", "fixed_position", "decision_margins"},
            {"schema_version", "action", "request_id", "revision", "input"},
        )
        return _workspace_stress_request(request)
    if "quantity" in request and action != "GROSS_DV01":
        raise ValidationError("UNKNOWN_FIELD", f"{action} não aceita quantity.")
    if any(field in request for field in (
        "reference", "alternatives", "comparison_mode", "horizon", "cash_growth", "shocks", "margin_searches",
        "max_evaluations", "deadline_ms",
         "decision_margins",
    )):
        raise ValidationError("UNKNOWN_FIELD", f"{action} não aceita campos de comparação.")
    if "fixed_position" in request and action != "SURFACE":
        raise ValidationError("UNKNOWN_FIELD", f"{action} n\u00e3o aceita fixed_position.")
    if "input" not in request:
        raise ValidationError("MISSING_FIELD", f"{action} exige input.")
    input_value = _object(request["input"], "input", WORKSPACE_INPUT_FIELDS)
    point_assumptions = input_value.get('assumptions')
    point_overrides = isinstance(point_assumptions, Mapping) and any(point_assumptions.get(key) is not None
                          for key in ('custody_override_brl','institution_net_brl','institution_release_date'))
    if point_overrides and action in {'SURFACE','CONSTRAINTS'}:
        raise ValidationError('POINT_OVERRIDE_NOT_TRANSFERABLE',
            'Valores efetivos da instituição pertencem somente à operação informada. Limpe-os antes de explorar outras datas ou preços.')
    analysis_context = (
        parse_workspace_analysis_context(input_value["analysis_context"])
        if "analysis_context" in input_value else None
    )
    if "constraints" in input_value:
        from .constraints import parse_constraint_set

        parse_constraint_set(input_value["constraints"])
    if action == "SURFACE":
        if "selection" in request or "query" in request:
            raise ValidationError("UNKNOWN_FIELD", "SURFACE usa somente a seleção em surface.selected.")
        if "surface" not in request:
            raise ValidationError("MISSING_FIELD", "SURFACE exige surface.")
        default_window_rate = None
        if analysis_context is not None and analysis_context.is_operation_window:
            entry = input_value.get("entry_price")
            if isinstance(entry, Mapping):
                if entry.get("mode") in {"MANUAL_RATE", "SAME_ENTRY_RATE"}:
                    default_window_rate = entry.get("annual_real_rate")
        surface_value = _workspace_surface(
            request["surface"], default_selected_value=default_window_rate,
        )
        fixed_position = None
        if "fixed_position" in request:
            if surface_value["mode"] != "RATE_DATE_MAP" or surface_value["value_unit"] != "ratio":
                raise ValidationError("INVALID_DOMAIN", "Explora\u00e7\u00e3o G4 exige um mapa por data e taxa.")
            if surface_value["order_dates"] is None or surface_value["values"] is None:
                raise ValidationError("INVALID_DOMAIN", "Explora\u00e7\u00e3o G4 exige datas e taxas expl\u00edcitas.")
            dates, rates = surface_value["order_dates"], surface_value["values"]
            if len(dates) > 5 or len(rates) > 21 or len(dates) * len(rates) > 105:
                raise ValidationError("SURFACE_LIMIT", "Explora\u00e7\u00e3o G4 aceita at\u00e9 cinco datas e 21 taxas por pedido.")
            if surface_value["selected_order_date"] not in dates or surface_value["selected_value"] not in rates:
                raise ValidationError("INVALID_SELECTION", "A sele\u00e7\u00e3o G4 precisa pertencer \u00e0 grade declarada.")
            raw_fixed = _object(
                request["fixed_position"], "fixed_position",
                {"reference", "horizon", "cash_growth"}, {"reference", "horizon"},
            )
            comparison_request = {
                "schema_version": 2, "action": "COMPARE", "request_id": request_id,
                "revision": revision, "comparison_mode": "FIXED_POSITION",
                "reference": raw_fixed["reference"],
                "alternatives": [{"id": "map", "label": "Grade G4", "input": input_value}],
                "horizon": raw_fixed["horizon"],
                "cash_growth": raw_fixed.get("cash_growth"),
            }
            fixed_position = _workspace_comparison_request(comparison_request)
            surface_value["g4_frontier"] = True
        if analysis_context is not None and analysis_context.is_operation_window:
            if analysis_context.start is None or analysis_context.end is None:
                raise ValidationError("MISSING_FIELD", "SURFACE com timeline WINDOW exige início e fim.")
            selected_date = surface_value["selected_order_date"]
            if not analysis_context.start <= selected_date <= analysis_context.end:
                raise ValidationError("INVALID_SELECTION", "A seleção precisa estar dentro da janela declarada.")
            if surface_value["order_dates"] is not None and any(
                current < analysis_context.start or current > analysis_context.end
                for current in surface_value["order_dates"]
            ):
                raise ValidationError("INVALID_DOMAIN", "Todas as datas da superfície precisam estar dentro da janela declarada.")
        return {
            "action": action, "request_id": request_id, "revision": revision,
            "input": input_value, "surface": surface_value,
            **({"fixed_position": fixed_position} if fixed_position is not None else {}),
        }
    if action == "UNIT_PRICE":
        if "surface" in request:
            raise ValidationError("UNKNOWN_FIELD", "UNIT_PRICE usa query, não surface.")
        if "selection" in request:
            raise ValidationError("UNKNOWN_FIELD", "UNIT_PRICE não aceita selection.")
        if analysis_context is None or analysis_context.kind != "UNIT_PRICE":
            raise ValidationError("INVALID_ANALYSIS_CONTEXT", "UNIT_PRICE exige analysis_context.kind UNIT_PRICE.")
        if "query" not in request:
            raise ValidationError("MISSING_FIELD", "UNIT_PRICE exige query.kind.")
        query = _workspace_unit_price_query(request["query"], input_value)
        return {
            "action": action, "request_id": request_id, "revision": revision,
            "input": input_value, "query": query,
        }
    if action == "GROSS_DV01":
        _mode_keys(
            request,
            {"schema_version", "action", "request_id", "revision", "input", "quantity"},
            {"schema_version", "action", "request_id", "revision", "input"},
        )
        if analysis_context is None or analysis_context.kind != "UNIT_PRICE":
            raise ValidationError("INVALID_ANALYSIS_CONTEXT", "GROSS_DV01 exige analysis_context.kind UNIT_PRICE.")
        if analysis_context.timeline_mode != "POINT":
            raise ValidationError("INVALID_ANALYSIS_CONTEXT", "GROSS_DV01 exige analysis_context.timeline.mode POINT.")
        quantity = _decimal(request.get("quantity"), "quantity", optional=True)
        if quantity is not None and (quantity <= 0 or quantity % Decimal("0.01") != 0):
            raise ValidationError("INVALID_QUANTITY", "quantity deve ser positiva em múltiplos de 0,01 título.")
        return {
            "action": action, "request_id": request_id, "revision": revision,
            "input": input_value, "quantity": quantity,
        }
    if "surface" in request:
        raise ValidationError("UNKNOWN_FIELD", f"{action} não aceita surface.")
    if action != "CONSTRAINTS" and "query" in request:
        raise ValidationError("UNKNOWN_FIELD", f"{action} não aceita query.")
    if action == "RESOLVE":
        if "selection" in request:
            raise ValidationError("UNKNOWN_FIELD", "RESOLVE não aceita selection.")
        return {"action": action, "request_id": request_id, "revision": revision, "input": input_value}

    if action == "CONSTRAINTS" and "query" in request:
        if "selection" in request:
            raise ValidationError("INVALID_QUERY", "A consulta define suas próprias condições e não aceita selection.")
        if "constraints" not in input_value:
            raise ValidationError("MISSING_CONSTRAINTS", "CONSTRAINTS exige critérios na entrada.")
        from .constraints import parse_constraint_set

        if not parse_constraint_set(input_value["constraints"]).criteria:
            raise ValidationError("MISSING_CONSTRAINTS", "FIRST_DATE exige ao menos um critério explícito.")
        raw_query = _object(
            request["query"], "query",
            {"kind", "date_domain", "fixed_exit_condition", "boundary_side", "entry_mode", "pu_domain", "rate_domain", "max_evaluations", "deadline_ms"},
            {"kind"},
        )
        kind = _text(raw_query["kind"], "query.kind", 32)
        if kind == "FIRST_DATE":
            raw_query = _object(
                raw_query, "query",
                {"kind", "date_domain", "fixed_exit_condition", "max_evaluations", "deadline_ms"},
                {"kind", "date_domain", "fixed_exit_condition"},
            )
            raw_domain = _object(raw_query["date_domain"], "query.date_domain", {"start", "end"}, {"start", "end"})
            start = _date(raw_domain["start"], "query.date_domain.start")
            end = _date(raw_domain["end"], "query.date_domain.end")
            if end < start:
                raise ValidationError("INVALID_DATE_DOMAIN", "O fim do domínio não pode preceder o início.")
            condition = _object(
                raw_query["fixed_exit_condition"], "query.fixed_exit_condition", {"value", "unit"}, {"value", "unit"},
            )
            unit = _text(condition["unit"], "query.fixed_exit_condition.unit", 32)
            if unit not in {"BRL_PER_TITLE", "ratio"}:
                raise ValidationError("INVALID_EXIT_CONDITION", "Hipótese fixa exige unidade BRL_PER_TITLE ou ratio.")
            value = _decimal(condition["value"], "query.fixed_exit_condition.value")
            if (unit == "BRL_PER_TITLE" and value <= 0) or (unit == "ratio" and value <= -1):
                raise ValidationError("INVALID_EXIT_CONDITION", "PU precisa ser positivo e taxa real precisa ser maior que −100%.")
            max_evaluations = raw_query.get("max_evaluations", WORKSPACE_SEARCH_BUDGET["max_evaluations"])
            deadline_ms = raw_query.get("deadline_ms", int(WORKSPACE_SEARCH_BUDGET["deadline_seconds"] * 1000))
            if type(max_evaluations) is not int or not 1 <= max_evaluations <= WORKSPACE_SEARCH_BUDGET["max_evaluations"]:
                raise ValidationError("INVALID_SEARCH_BUDGET", "max_evaluations precisa ficar entre 1 e o padrão de 4096.")
            if type(deadline_ms) is not int or not 1 <= deadline_ms <= int(WORKSPACE_SEARCH_BUDGET["deadline_seconds"] * 1000):
                raise ValidationError("INVALID_SEARCH_BUDGET", "deadline_ms precisa ficar entre 1 e o padrão de 10000.")
            normalized_query = {
                "kind": kind, "date_domain": {"start": start, "end": end},
                "fixed_exit_condition": {"value": value, "unit": unit},
                "max_evaluations": max_evaluations, "deadline_ms": deadline_ms,
            }
        elif kind == "ENTRY_BOUNDARY":
            raw_query = _object(
                raw_query, "query",
                {"kind", "boundary_side", "entry_mode", "pu_domain", "rate_domain", "max_evaluations", "deadline_ms"},
                {"kind"},
            )
            has_pu_domain, has_rate_domain = "pu_domain" in raw_query, "rate_domain" in raw_query
            if has_pu_domain == has_rate_domain:
                raise ValidationError("INVALID_TARGET_DOMAIN", "ENTRY_BOUNDARY exige exatamente um domínio: pu_domain ou rate_domain.")
            if has_pu_domain:
                if "boundary_side" in raw_query:
                    raise ValidationError("INVALID_QUERY", "boundary_side só é aceito com rate_domain.")
                if "entry_mode" not in raw_query:
                    raise ValidationError("MISSING_FIELD", "ENTRY_BOUNDARY por PU exige entry_mode.")
                entry_mode = _text(raw_query["entry_mode"], "query.entry_mode", 16)
                if entry_mode not in {"BUDGET", "QUANTITY"}:
                    raise ValidationError("INVALID_ENTRY_MODE", "entry_mode precisa ser BUDGET ou QUANTITY.")
                raw_domain = _object(
                    raw_query["pu_domain"], "query.pu_domain", {"minimum", "maximum", "tick"},
                    {"minimum", "maximum", "tick"},
                )
                if any(isinstance(raw_domain[key], (str, int)) and len(str(raw_domain[key])) > 48
                       for key in ("minimum", "maximum", "tick")):
                    raise ValidationError("INVALID_NUMBER_FORMAT", "Os limites e o tick de PU aceitam até 48 caracteres decimais.")
                minimum = _decimal(raw_domain["minimum"], "query.pu_domain.minimum")
                maximum = _decimal(raw_domain["maximum"], "query.pu_domain.maximum")
                tick = _decimal(raw_domain["tick"], "query.pu_domain.tick")
                maximum_supported_pu = Decimal("1000000000")
                if minimum <= 0 or tick <= 0 or maximum < minimum or maximum > maximum_supported_pu:
                    raise ValidationError("INVALID_TARGET_DOMAIN", "Domínio de PU positivo inválido ou acima do limite suportado de 1.000.000.000.")
                if tick < Decimal("0.01") or tick * 100 != (tick * 100).to_integral_value():
                    raise ValidationError("INVALID_TARGET_DOMAIN", "O tick de PU precisa ser múltiplo de R$ 0,01.")
                if (minimum / tick != (minimum / tick).to_integral_value()
                        or maximum / tick != (maximum / tick).to_integral_value()):
                    raise ValidationError("INVALID_TARGET_DOMAIN", "Limites do domínio precisam coincidir com o tick de PU.")
                normalized_domain = {"minimum": minimum, "maximum": maximum, "tick": tick}
            else:
                side = _text(raw_query.get("boundary_side", ""), "query.boundary_side", 8)
                if side not in {"ENTRY", "EXIT"}:
                    raise ValidationError("INVALID_RATE_SIDE", "boundary_side precisa ser ENTRY ou EXIT.")
                if side == "ENTRY":
                    entry_mode = _text(raw_query.get("entry_mode", ""), "query.entry_mode", 16)
                    if entry_mode not in {"BUDGET", "QUANTITY"}:
                        raise ValidationError("INVALID_ENTRY_MODE", "ENTRY por taxa exige entry_mode BUDGET ou QUANTITY.")
                elif "entry_mode" in raw_query:
                    raise ValidationError("INVALID_QUERY", "entry_mode só se aplica à fronteira de compra.")
                raw_domain = _object(
                    raw_query["rate_domain"], "query.rate_domain", {"minimum", "maximum", "step"},
                    {"minimum", "maximum", "step"},
                )
                if any(isinstance(raw_domain[key], (str, int)) and len(str(raw_domain[key])) > 48
                       for key in ("minimum", "maximum", "step")):
                    raise ValidationError("INVALID_NUMBER_FORMAT", "Os limites e o passo de taxa aceitam até 48 caracteres decimais.")
                minimum = _decimal(raw_domain["minimum"], "query.rate_domain.minimum")
                maximum = _decimal(raw_domain["maximum"], "query.rate_domain.maximum")
                step = _decimal(raw_domain["step"], "query.rate_domain.step")
                intervals = (maximum - minimum) / step if step > 0 else Decimal(0)
                if minimum <= -1 or maximum <= minimum or step <= 0:
                    raise ValidationError("INVALID_RATE_DOMAIN", "A taxa mínima precisa superar −100%; máximo e passo precisam formar um domínio crescente.")
                if intervals != intervals.to_integral_value():
                    raise ValidationError("INVALID_RATE_DOMAIN", "O passo precisa alinhar os extremos do domínio de taxa.")
                if intervals + 1 > 101:
                    raise ValidationError("INVALID_RATE_DOMAIN", "O domínio de taxa pode conter no máximo 101 pontos de verificação.")
                normalized_domain = {"minimum": minimum, "maximum": maximum, "step": step}
            max_evaluations = raw_query.get("max_evaluations", WORKSPACE_SEARCH_BUDGET["max_evaluations"])
            deadline_ms = raw_query.get("deadline_ms", int(WORKSPACE_SEARCH_BUDGET["deadline_seconds"] * 1000))
            if type(max_evaluations) is not int or not 1 <= max_evaluations <= WORKSPACE_SEARCH_BUDGET["max_evaluations"]:
                raise ValidationError("INVALID_SEARCH_BUDGET", "max_evaluations precisa ficar entre 1 e o padrão de 4096.")
            if type(deadline_ms) is not int or not 1 <= deadline_ms <= int(WORKSPACE_SEARCH_BUDGET["deadline_seconds"] * 1000):
                raise ValidationError("INVALID_SEARCH_DEADLINE", "deadline_ms precisa ficar entre 1 e 10000.")
            if has_pu_domain:
                normalized_query = {
                    "kind": kind, "entry_mode": entry_mode, "pu_domain": normalized_domain,
                    "max_evaluations": max_evaluations, "deadline_ms": deadline_ms,
                }
            else:
                normalized_query = {
                    "kind": kind, "boundary_side": side,
                    **({"entry_mode": entry_mode} if side == "ENTRY" else {}),
                    "rate_domain": normalized_domain,
                    "max_evaluations": max_evaluations, "deadline_ms": deadline_ms,
                }
        else:
            raise ValidationError("INVALID_QUERY", "CONSTRAINTS.query.kind aceita FIRST_DATE ou ENTRY_BOUNDARY.")
        return {
            "action": action, "request_id": request_id, "revision": revision,
            "input": input_value, "query": normalized_query,
        }

    if "selection" not in request:
        action_label = "CONSTRAINTS" if action == "CONSTRAINTS" else "EVALUATE"
        raise ValidationError("MISSING_FIELD", f"{action_label} exige selection.")
    selection = _object(
        request.get("selection"), "selection",
        {"sale_date", "exit_pu", "annual_real_rate"},
        {"sale_date"},
    )
    if ("exit_pu" in selection) == ("annual_real_rate" in selection):
        raise ValidationError("INVALID_SELECTION", "Selecione exatamente um entre exit_pu e annual_real_rate.")
    _date(selection["sale_date"], "selection.sale_date")
    if point_overrides:
        original = input_value.get('exit_price') or {}
        original_mode = original.get('mode')
        if original_mode == 'SAME_ENTRY_RATE':original = input_value.get('entry_price') or {}
        selected_key = 'pu' if 'exit_pu' in selection else 'annual_real_rate'
        selected_value = selection.get('exit_pu',selection.get('annual_real_rate'))
        original_value = original.get(selected_key)
        if (input_value.get('sale_date') != selection['sale_date'] or original_value is None
                or _decimal(original_value,'preço original') != _decimal(selected_value,'preço selecionado')):
            raise ValidationError('POINT_OVERRIDE_NOT_TRANSFERABLE',
                'A seleção alterou data ou preço. Limpe os valores efetivos da instituição para reavaliar outra operação.')
    if action == "CONSTRAINTS" and "constraints" not in input_value:
        raise ValidationError("MISSING_CONSTRAINTS", "CONSTRAINTS exige critérios na entrada.")
    if "exit_pu" in selection:
        if _decimal(selection["exit_pu"], "selection.exit_pu") <= 0:
            raise ValidationError("INVALID_SELECTION", "PU de saída precisa ser positivo.")
    else:
        rate = _decimal(selection["annual_real_rate"], "selection.annual_real_rate")
        if rate <= -1:
            raise ValidationError("INVALID_SELECTION", "Taxa real precisa ser maior que −100%.")
    resolved_input = dict(input_value)
    resolved_input["sale_date"] = selection["sale_date"]
    resolved_input["exit_price"] = (
        {"mode": "MANUAL_PU", "pu": selection["exit_pu"]}
        if "exit_pu" in selection
        else {"mode": "MANUAL_RATE", "annual_real_rate": selection["annual_real_rate"], "quoted_side": "SELL"}
    )
    # Selecting the original manual quote must not discard its declared source.
    # A different date or price is a new hypothesis and cannot inherit that proof.
    original_exit = input_value.get("exit_price")
    if ("exit_pu" in selection and input_value.get("sale_date") == selection["sale_date"]
            and isinstance(original_exit, dict) and original_exit.get("mode") == "MANUAL_PU"):
        try:
            same_quote = _decimal(original_exit.get("pu"), "input.exit_price.pu") == _decimal(
                selection["exit_pu"], "selection.exit_pu",
            )
        except ValidationError:
            same_quote = False
        if same_quote:
            resolved_input["exit_price"] = {**original_exit, "pu": selection["exit_pu"]}
    return {
        "action": action, "request_id": request_id, "revision": revision,
        "input": resolved_input, "selection": selection,
    }


def workspace_snapshot_request(payload: object) -> dict[str, Any]:
    """Validate the bounded, data-only v2 snapshot accepted by local storage."""
    from .workspace import prepare_workspace_defaults

    request = _object(
        payload, "snapshot",
        {"schema_version", "name", "consent", "input", "selection", "reference", "alternatives",
         "analysis", "view", "record_id", "expected_revision", "operation_id"},
        {"schema_version", "name", "consent", "input"},
    )
    if type(request["schema_version"]) is not int or request["schema_version"] != 2:
        raise ValidationError("UNSUPPORTED_SCHEMA", "Snapshot unificado requer schema_version 2.")
    name = _text(request["name"], "name", 120)
    if request["consent"] is not True:
        raise ValidationError("E-CONSENT", "Marque o consentimento para salvar este snapshot neste computador.")
    record_id = request.get("record_id")
    expected_revision = request.get("expected_revision")
    operation_id = request.get("operation_id")
    if "operation_id" in request and (not isinstance(operation_id, str) or not re.fullmatch(r"[0-9a-f]{32}", operation_id)):
        raise ValidationError("E-STORAGE", "Identidade de gravação inválida.")
    if record_id is not None:
        if not isinstance(record_id, str) or not re.fullmatch(r"[0-9a-f]{32}", record_id):
            raise ValidationError("E-STORAGE", "Identificador de cenário inválido.")
        if type(expected_revision) is not int or expected_revision < 1:
            raise ValidationError("E-CONFLICT", "Informe a revisão carregada antes de salvar uma nova revisão.")
    elif expected_revision is not None:
        raise ValidationError("E-CONFLICT", "Revisão só pode acompanhar um cenário existente.")

    def validate_input(raw: object, path: str) -> dict[str, Any]:
        value = _object(raw, path, WORKSPACE_INPUT_FIELDS)
        try:
            encoded = json.dumps(value, ensure_ascii=False, separators=(",", ":"), allow_nan=False).encode("utf-8")
        except (TypeError, ValueError) as exc:
            raise ValidationError("INVALID_INPUT", f"{path} precisa conter valores JSON finitos.") from exc
        if len(encoded) > 64 * 1024:
            raise ValidationError("SNAPSHOT_FIELD_LIMIT", f"{path} excede o limite de 64 KiB.")
        workspace_request({
            "schema_version": 2, "action": "RESOLVE", "request_id": "snapshot-validation",
            "revision": 1, "input": prepare_workspace_defaults(value),
        })
        return value

    def validate_selection(
        raw: object, path: str, context_input: Mapping[str, Any],
    ) -> dict[str, Any] | None:
        if raw is None:
            return None
        analysis_context = context_input.get("analysis_context")
        parsed_context = None
        if isinstance(analysis_context, Mapping):
            parsed_context = parse_workspace_analysis_context(analysis_context)
            if parsed_context.kind == "UNIT_PRICE":
                raise ValidationError(
                    "INVALID_SELECTION", f"{path} não aceita seleção de venda em uma fotografia de preço unitário.",
                )
        point = _object(
            raw, path,
            {"sale_date", "exit_pu", "annual_real_rate", "settlement_date", "origin"},
            {"sale_date"},
        )
        if ("exit_pu" in point) == ("annual_real_rate" in point):
            raise ValidationError("INVALID_SELECTION", f"{path} exige exatamente um entre exit_pu e annual_real_rate.")
        selected_date = _date(point["sale_date"], path + ".sale_date")
        if (parsed_context is not None and parsed_context.is_operation_window
                and parsed_context.start is not None and parsed_context.end is not None
                and not parsed_context.start <= selected_date <= parsed_context.end):
            raise ValidationError("INVALID_SELECTION", f"{path}.sale_date precisa pertencer à janela declarada.")
        direct = {key: point[key] for key in ("sale_date", "exit_pu", "annual_real_rate") if key in point}
        workspace_request({
            "schema_version": 2, "action": "EVALUATE", "request_id": "snapshot-validation",
            "revision": 1, "input": {"assumptions": {"settlement_profile": "SIMULATED_BUY_D1_SELL_D1"}},
            "selection": direct,
        })
        clean = dict(point)
        if "settlement_date" in clean:
            _date(clean["settlement_date"], path + ".settlement_date")
        if "origin" in clean:
            clean["origin"] = _text(clean["origin"], path + ".origin", 48)
        return clean

    input_value = validate_input(request["input"], "input")
    selection = validate_selection(request.get("selection"), "selection", input_value)
    raw_reference = request.get("reference")
    reference = None
    if raw_reference is not None:
        item = _object(raw_reference, "reference", {"id", "label", "input", "selection"}, {"label", "input"})
        if item.get("id", "reference") != "reference":
            raise ValidationError("INVALID_SNAPSHOT_ID", "reference.id precisa ser 'reference'.")
        reference_input = validate_input(item["input"], "reference.input")
        reference = {
            "id": "reference", "label": _text(item["label"], "reference.label", 80),
            "input": reference_input,
            "selection": validate_selection(item.get("selection"), "reference.selection", reference_input),
        }
    raw_alternatives = _sequence(request.get("alternatives", ()), "alternatives", 2)
    alternatives = []
    alternative_ids: set[str] = set()
    for index, raw_item in enumerate(raw_alternatives):
        path = f"alternatives[{index}]"
        item = _object(raw_item, path, {"id", "label", "input", "selection"}, {"id", "label", "input"})
        item_id = _text(item["id"], path + ".id", 64)
        if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._:-]{0,63}", item_id) or item_id == "reference" or item_id in alternative_ids:
            raise ValidationError("INVALID_SNAPSHOT_ID", f"{path}.id precisa ser único e usar um identificador válido.")
        alternative_ids.add(item_id)
        alternative_input = validate_input(item["input"], path + ".input")
        alternatives.append({
            "id": item_id, "label": _text(item["label"], path + ".label", 80),
            "input": alternative_input,
            "selection": validate_selection(item.get("selection"), path + ".selection", alternative_input),
        })

    raw_analysis = _object(request.get("analysis", {}), "analysis", {
        "mode", "included_alternative_ids", "comparison", "stress",
    })
    mode = raw_analysis.get("mode", "compare")
    if not isinstance(mode, str) or mode not in {"compare", "stress"}:
        raise ValidationError("INVALID_SNAPSHOT_ANALYSIS", "analysis.mode precisa ser compare ou stress.")
    included_raw = _sequence(raw_analysis.get("included_alternative_ids", ()), "analysis.included_alternative_ids", 2)
    included = []
    for item_id in included_raw:
        item_id = _text(item_id, "analysis.included_alternative_ids", 64)
        if item_id not in alternative_ids or item_id in included:
            raise ValidationError("INVALID_SNAPSHOT_ANALYSIS", "Alternativas incluídas precisam ser IDs únicos já guardados.")
        included.append(item_id)

    raw_comparison = _object(raw_analysis.get("comparison", {}), "analysis.comparison", {
        "comparison_mode", "horizon", "cash_growth", "highlight",
    })
    comparison_mode = raw_comparison.get("comparison_mode", "BUDGET")
    if not isinstance(comparison_mode, str) or comparison_mode not in {"BUDGET", "FIXED_POSITION"}:
        raise ValidationError("INVALID_SNAPSHOT_ANALYSIS", "analysis.comparison.comparison_mode precisa ser BUDGET ou FIXED_POSITION.")
    horizon = _date(raw_comparison["horizon"], "analysis.comparison.horizon", optional=True) if "horizon" in raw_comparison else None
    highlight = raw_comparison.get("highlight", "none")
    if not isinstance(highlight, str) or highlight not in {"none", "profit", "duration", "resilience"}:
        raise ValidationError("INVALID_SNAPSHOT_ANALYSIS", "Destaque da comparação não reconhecido.")
    cash_growth = None
    if "cash_growth" in raw_comparison and raw_comparison["cash_growth"] is not None:
        growth_fields = {"annual_net_rate", "profile"}
        if comparison_mode == "BUDGET":
            growth_fields.add("origin_date")
        growth = _object(
            raw_comparison["cash_growth"], "analysis.comparison.cash_growth",
            growth_fields, growth_fields,
        )
        profile = _text(growth["profile"], "analysis.comparison.cash_growth.profile", 48)
        if profile != "ACT_365_COMPOUND_v1" or horizon is None:
            raise ValidationError("INVALID_SNAPSHOT_ANALYSIS", "Crescimento de caixa exige perfil conhecido e horizonte explícito.")
        rate = _decimal(growth["annual_net_rate"], "analysis.comparison.cash_growth.annual_net_rate")
        if rate <= -1:
            raise ValidationError("INVALID_CASH_GROWTH_RATE", "A taxa líquida anual precisa ser maior que −100%.")
        cash_growth = {
            "annual_net_rate": rate, "profile": profile,
        }
        if comparison_mode == "BUDGET":
            cash_growth["origin_date"] = _date(growth["origin_date"], "analysis.comparison.cash_growth.origin_date")
    comparison = {
        "comparison_mode": comparison_mode, "horizon": horizon,
        "cash_growth": cash_growth, "highlight": highlight,
    }

    raw_stress = _object(raw_analysis.get("stress", {}), "analysis.stress", {
        "source_id", "shocks", "margin_searches", "max_evaluations", "deadline_ms",
    })
    stress = {"source_id": raw_stress.get("source_id", "current"), "shocks": [], "margin_searches": []}
    source_id = stress["source_id"]
    known_sources = {"current"}
    if reference is not None:
        known_sources.add("reference")
    known_sources.update(alternative_ids)
    if not isinstance(source_id, str) or source_id not in known_sources:
        raise ValidationError("INVALID_SNAPSHOT_ANALYSIS", "analysis.stress.source_id precisa apontar para um contexto guardado.")
    stress_input = input_value if source_id == "current" else reference["input"] if source_id == "reference" else next(item["input"] for item in alternatives if item["id"] == source_id)
    raw_shocks = _sequence(raw_stress.get("shocks", ()), "analysis.stress.shocks", 25)
    raw_margins = _sequence(raw_stress.get("margin_searches", ()), "analysis.stress.margin_searches", 4)
    clean_shocks = []
    labels = {}
    for index, raw in enumerate(raw_shocks):
        item = _object(raw, f"analysis.stress.shocks[{index}]", {
            "id", "label", "rate_shock_ratio", "annual_inflation_ratio",
            "entry_expense_delta_brl", "exit_expense_delta_brl",
        }, {"id"})
        clean_shocks.append({key: value for key, value in item.items() if key != "label"})
        if "label" in item:
            shock_id = _text(item["id"], f"analysis.stress.shocks[{index}].id", 64)
            labels[shock_id] = _text(item["label"], f"analysis.stress.shocks[{index}].label", 80)
    if clean_shocks or raw_margins:
        stress_envelope = {
            "schema_version": 2, "action": "STRESS", "request_id": "snapshot-validation", "revision": 1,
            "input": stress_input, "shocks": clean_shocks, "margin_searches": raw_margins,
        }
        for field in ("max_evaluations", "deadline_ms"):
            if field in raw_stress:
                stress_envelope[field] = raw_stress[field]
        checked_stress = workspace_request(stress_envelope)
        stress["shocks"] = [dict(item, **({"label": labels[item["id"]]} if item["id"] in labels else {}))
                            for item in checked_stress["shocks"]]
        stress["margin_searches"] = checked_stress["margin_searches"]
        stress["max_evaluations"] = checked_stress["max_evaluations"]
        stress["deadline_ms"] = checked_stress["deadline_ms"]
    analysis = {
        "mode": mode, "included_alternative_ids": included,
        "comparison": comparison, "stress": stress,
    }

    raw_view = _object(request.get("view", {}), "view", {"tab", "metric", "focus", "zoom", "decision", "single_screen"})
    tab = raw_view.get("tab", "map")
    if not isinstance(tab, str) or tab not in {"map", "limits", "compare"}:
        raise ValidationError("INVALID_SNAPSHOT_VIEW", "Aba visual não reconhecida.")
    metrics = {
        "net_redemption", "gross_redemption", "nominal_profit", "nominal_return",
        "annualized_nominal_return", "real_profit_in_exit_date_currency", "real_return",
    }
    metric = raw_view.get("metric", "net_redemption")
    if not isinstance(metric, str) or metric not in metrics:
        raise ValidationError("INVALID_SNAPSHOT_VIEW", "Métrica visual não reconhecida.")
    focus = raw_view.get("focus", "exit")
    if not isinstance(focus, str) or focus not in {"exit", "entry", "date"}:
        raise ValidationError("INVALID_SNAPSHOT_VIEW", "Foco visual não reconhecido.")
    zoom = {}
    if "zoom" in raw_view:
        raw_zoom = _object(raw_view["zoom"], "view.zoom", {"x", "y"})
        for axis, domain in raw_zoom.items():
            if not isinstance(domain, list) or len(domain) != 2:
                raise ValidationError("INVALID_SNAPSHOT_VIEW", f"view.zoom.{axis} precisa conter exatamente dois limites.")
            normalized_domain = []
            for value in domain:
                if axis == "x" and isinstance(value, str) and len(value) == 10:
                    normalized_domain.append(_date(value, f"view.zoom.{axis}"))
                elif axis == "y" and type(value) in (int, float) and isfinite(value) and abs(value) <= 1_000_000_000_000:
                    normalized_domain.append(value)
                else:
                    normalized_domain.append(_decimal(value, f"view.zoom.{axis}"))
            if normalized_domain[0] == normalized_domain[1]:
                raise ValidationError("INVALID_SNAPSHOT_VIEW", f"view.zoom.{axis} não pode ter limites iguais.")
            zoom[axis] = normalized_domain
    view = {"tab": tab, "metric": metric, "focus": focus, "zoom": zoom}
    if "single_screen" in raw_view:
        from ..simple_screen import validate_snapshot_view
        view["single_screen"] = validate_snapshot_view(raw_view["single_screen"], input_value, reference['input'] if reference else None)
    if "decision" in raw_view:
        # A bounded presentation cache, never an input to pricing or a replacement
        # for the server's point_evaluations. Opening it performs no calculation.
        decision = _object(raw_view["decision"], "view.decision", {
            "version", "cards", "controls", "view", "overlay_mode", "overlay_date", "overlay_focus", "timeline_layout", "timeline_reference", "result",
        }, {"version", "cards", "controls", "view", "overlay_mode", "overlay_date", "result"})
        if type(decision["version"]) is not int or decision["version"] != 1:
            raise ValidationError("INVALID_SNAPSHOT_VIEW", "Versão da comparação não reconhecida.")
        if not isinstance(decision["view"], str) or not isinstance(decision["overlay_mode"], str) or decision["view"] not in {"scenarios", "time", "budget", "goals", "products"} or decision["overlay_mode"] not in {"wealth", "gain", "change", "net_redemption", "nominal_profit", "nominal_return", "real_return", "annualized_nominal_return"}:
            raise ValidationError("INVALID_SNAPSHOT_VIEW", "Visualização da comparação não reconhecida.")
        if not isinstance(decision.get("overlay_focus", "all"), str) or decision.get("overlay_focus", "all") not in {"all", "A", "B", "C"}:
            raise ValidationError("INVALID_SNAPSHOT_VIEW", "Destaque da comparação não reconhecido.")
        for key, allowed, message in (
            ("timeline_layout", {"volume", "panels", "overlay", "difference"}, "Forma de comparação não reconhecida."),
            ("timeline_reference", {"A", "B", "C"}, "Referência da comparação não reconhecida."),
        ):
            if key in decision and (not isinstance(decision[key], str) or decision[key] not in allowed):
                raise ValidationError("INVALID_SNAPSHOT_VIEW", message)
        if decision["overlay_date"] is not None:
            _date(decision["overlay_date"], "view.decision.overlay_date")
        cards = decision["cards"]
        if not isinstance(cards, list) or not 0 <= len(cards) <= 2:
            raise ValidationError("INVALID_SNAPSHOT_VIEW", "Guarde até duas alternativas ao principal.")
        ids = []
        fields = {"name", "family", "year", "budget", "purchase-date", "sale-date", "buy-mode", "sell-mode", "buy-rate", "buy-pu", "sell-rate", "sell-pu", "inflation", "end-inflation", "inflation-end-date", "entry-fee", "entry-fee-rate", "exit-fee", "range"}
        for card in cards:
            item = _object(card, "view.decision.cards[]", {"id", "seed", "anchor_date", "fields"}, {"id", "seed", "anchor_date", "fields"})
            if not isinstance(item["id"], str) or item["id"] not in {"B", "C"} or item["id"] in ids:
                raise ValidationError("INVALID_SNAPSHOT_VIEW", "Identidades da comparação inválidas.")
            ids.append(item["id"])
            validate_input(item["seed"], "view.decision.cards[].seed")
            if item["anchor_date"] is not None:
                _date(item["anchor_date"], "view.decision.cards[].anchor_date")
            values = _object(item["fields"], "view.decision.cards[].fields", fields, fields)
            if any(not isinstance(value, str) or len(value) > 160 for value in values.values()):
                raise ValidationError("INVALID_SNAPSHOT_VIEW", "Campos da comparação precisam ser textos limitados.")
        control_ids = {"decision-overlay-base-range", "decision-product-cash-rate", "decision-overlay-start", "decision-overlay-end", "decision-overlay-months"}
        controls = _object(decision["controls"], "view.decision.controls", control_ids, control_ids)
        if any(not isinstance(value, str) or len(value) > 100 for value in controls.values()):
            raise ValidationError("INVALID_SNAPSHOT_VIEW", "Configuração da comparação inválida.")
        result = decision["result"]
        if result is not None:
            cache = _object(result, "view.decision.result", {"captured_at", "in_time", "dates", "config", "series"}, {"captured_at", "in_time", "dates", "config", "series"})
            _text(cache["captured_at"], "view.decision.result.captured_at", 40)
            if type(cache["in_time"]) is not bool or not isinstance(cache["dates"], list) or not 1 <= len(cache["dates"]) <= 25:
                raise ValidationError("INVALID_SNAPSHOT_VIEW", "Domínio do gráfico guardado inválido.")
            for value in cache["dates"]:
                if cache["in_time"]:
                    _date(value, "view.decision.result.dates[]")
                elif value is not None or len(cache["dates"]) != 1:
                    raise ValidationError("INVALID_SNAPSHOT_VIEW", "Comparação pontual exige uma saída por cenário.")
            config = _object(cache["config"], "view.decision.result.config", {"origin", "cashRate"}, {"origin", "cashRate"})
            _date(config["origin"], "view.decision.result.config.origin")
            _decimal(config["cashRate"], "view.decision.result.config.cashRate")
            series = cache["series"]
            if not isinstance(series, list) or [s.get("id") if isinstance(s, dict) else None for s in series] != ["A", *ids]:
                raise ValidationError("INVALID_SNAPSHOT_VIEW", "Séries guardadas não correspondem aos cenários.")
            for item in series:
                item = _object(item, "view.decision.result.series[]", {"id", "index", "label", "input", "budget", "color", "range", "note", "baseRate", "rates", "groups"}, {"id", "index", "label", "input", "budget", "color", "range", "baseRate", "rates", "groups"})
                if type(item.get("index")) is not int or item["index"] != {"A": 0, "B": 1, "C": 2}[item["id"]]:
                    raise ValidationError("INVALID_SNAPSHOT_VIEW", "Identidade visual inválida.")
                if item["color"] != ["#336eaa", "#176951", "#765a91"][item["index"]]:
                    raise ValidationError("INVALID_SNAPSHOT_VIEW", "Cor da comparação não corresponde ao cenário.")
                if not isinstance(item["range"], str) or len(item["range"]) > 100:
                    raise ValidationError("INVALID_SNAPSHOT_VIEW", "Amplitude da faixa guardada inválida.")
                if item["baseRate"] is not None:
                    _decimal(item["baseRate"], "view.decision.result.series[].baseRate")
                if not isinstance(item["rates"], list) or len(item["rates"]) not in (0, 3) or (cache["in_time"] or item["baseRate"] is not None) and len(item["rates"]) != 3:
                    raise ValidationError("INVALID_SNAPSHOT_VIEW", "Faixas guardadas exigem três taxas explícitas.")
                for value in item["rates"]:
                    _decimal(value, "view.decision.result.series[].rates[]")
                validate_input(item.get("input"), "view.decision.result.series[].input")
                _decimal(item.get("budget"), "view.decision.result.series[].budget")
                capital = item["input"].get("capital") or {}
                if Decimal(item["budget"]) <= 0 or capital.get("mode") != "BUDGET" or Decimal(str(capital.get("value"))) != Decimal(item["budget"]):
                    raise ValidationError("INVALID_SNAPSHOT_VIEW", "Capital do gráfico não corresponde ao orçamento do cenário.")
                _text(item.get("label"), "view.decision.result.series[].label", 200)
                groups = item.get("groups")
                if not isinstance(groups, list) or len(groups) != len(cache["dates"]):
                    raise ValidationError("INVALID_SNAPSHOT_VIEW", "Pontos guardados não correspondem às datas.")
                for group in groups:
                    group = _object(group, "view.decision.result.group", {"complete", "base", "minimum", "maximum", "horizon", "operation", "reason", "pending"}, {"complete", "base", "minimum", "maximum", "horizon", "operation", "reason"})
                    if not isinstance(group, dict) or type(group.get("complete")) is not bool:
                        raise ValidationError("INVALID_SNAPSHOT_VIEW", "Faixa guardada inválida.")
                    if group["horizon"] is not None:
                        _date(group["horizon"], "view.decision.result.group.horizon")
                    if not isinstance(group["reason"], str):
                        raise ValidationError("INVALID_SNAPSHOT_VIEW", "Motivo da lacuna precisa ser texto.")
                    if group["operation"] is not None:
                        operation = _object(group["operation"], "view.decision.result.operation", {"quantity", "net_redemption", "nominal_profit", "nominal_return", "real_return", "income_tax", "custody"})
                        for value in operation.values():
                            if value is not None:
                                _decimal(value, "view.decision.result.operation.value")
                    if "pending" in group:
                        if not isinstance(group["pending"], list) or len(group["pending"]) > 6:
                            raise ValidationError("INVALID_SNAPSHOT_VIEW", "Pendências guardadas inválidas.")
                        for raw_pending in group["pending"]:
                            pending = _object(raw_pending, "view.decision.result.pending", {"id", "field", "message", "proposed_order_date"}, {"id", "field", "message"})
                            if pending["id"] not in ["A", *ids] or pending["field"] not in ["purchase-date", "sale-date"] or not isinstance(pending["message"], str):
                                raise ValidationError("INVALID_SNAPSHOT_VIEW", "Pendência não corresponde a um campo do cenário.")
                            if "proposed_order_date" in pending:
                                _date(pending["proposed_order_date"], "view.decision.result.pending.proposed_order_date")
                    for key in ("base", "minimum", "maximum"):
                        point = group.get(key)
                        if point is not None:
                            point = _object(point, "view.decision.result.point", {"rate", "budget", "wealth", "change", "metrics"}, {"rate", "budget", "wealth", "change"})
                            for key in ("rate", "budget", "wealth", "change"):
                                value = point[key]
                                if key != "rate" or value is not None:
                                    _decimal(value, "view.decision.result.point.value")
                            if "metrics" in point:
                                metric_ids = {"net_redemption", "nominal_profit", "nominal_return", "real_return", "annualized_nominal_return"}
                                metrics = _object(point["metrics"], "view.decision.result.point.metrics", metric_ids, metric_ids)
                                for value in metrics.values():
                                    if value is not None:
                                        _decimal(value, "view.decision.result.point.metrics.value")
                    if group["complete"] and any(group.get(key) is None for key in ("base", "minimum", "maximum")):
                        raise ValidationError("INVALID_SNAPSHOT_VIEW", "Faixa completa exige os três pontos calculados.")
            for index in range(len(cache["dates"])):
                if len({item["groups"][index]["horizon"] for item in series}) != 1:
                    raise ValidationError("INVALID_SNAPSHOT_VIEW", "Cenários precisam compartilhar o horizonte de cada data.")
        # Cap nesting, strings and overall bytes even for descriptive result fields.
        def bounded(value, depth=0):
            if depth > 18:
                raise ValidationError("SNAPSHOT_FIELD_LIMIT", "Comparação excede a profundidade permitida.")
            if isinstance(value, dict):
                if len(value) > 100 or any(not isinstance(k, str) or len(k) > 160 or k in {"__proto__", "constructor", "prototype"} for k in value):
                    raise ValidationError("SNAPSHOT_FIELD_LIMIT", "Objeto da comparação inválido.")
                for item in value.values(): bounded(item, depth + 1)
            elif isinstance(value, list):
                if len(value) > 100:
                    raise ValidationError("SNAPSHOT_FIELD_LIMIT", "Lista da comparação excede o limite.")
                for item in value: bounded(item, depth + 1)
            elif isinstance(value, str):
                if len(value) > 4096:
                    raise ValidationError("SNAPSHOT_FIELD_LIMIT", "Texto da comparação excede o limite.")
            elif value is not None and type(value) not in (bool, int, float):
                raise ValidationError("INVALID_SNAPSHOT_VIEW", "Comparação precisa conter somente dados JSON.")
        bounded(decision)
        try:
            encoded_decision = json.dumps(decision, ensure_ascii=False, allow_nan=False).encode("utf-8")
        except (TypeError, ValueError) as exc:
            raise ValidationError("INVALID_SNAPSHOT_VIEW", "Comparação precisa conter dados finitos.") from exc
        if len(encoded_decision) > 128 * 1024:
            raise ValidationError("SNAPSHOT_FIELD_LIMIT", "Comparação excede o limite de 128 KiB.")
        view["decision"] = decision

    clean = {
        "schema_version": 2, "name": name, "consent": True,
        "input": input_value, "selection": selection,
        "reference": reference, "alternatives": alternatives,
        "analysis": analysis, "view": view,
    }
    if operation_id is not None:
        clean["operation_id"] = operation_id
    try:
        encoded = json.dumps(_json_ready(clean), ensure_ascii=False, separators=(",", ":"), allow_nan=False).encode("utf-8")
    except (TypeError, ValueError) as exc:
        raise ValidationError("INVALID_SNAPSHOT", "Snapshot precisa conter somente valores JSON finitos.") from exc
    from ..simple_screen import snapshot_size_limit
    if len(encoded) > snapshot_size_limit(view):
        raise ValidationError("SNAPSHOT_SIZE_LIMIT", "Snapshot excede o limite de armazenamento desta resolução.")
    if record_id is not None:
        clean["record_id"] = record_id
        clean["expected_revision"] = expected_revision
    return _json_ready(clean)


def _workspace_comparison_request(request: Mapping[str, Any]) -> dict[str, Any]:
    from .workspace import CapitalMode, normalize_workspace_input, prepare_workspace_defaults
    from .comparisons import fixed_position_input_identity

    comparison_mode = _text(request.get("comparison_mode", "BUDGET"), "comparison_mode", 32)
    if comparison_mode not in {"BUDGET", "FIXED_POSITION"}:
        raise ValidationError("INVALID_COMPARISON_MODE", "comparison_mode precisa ser BUDGET ou FIXED_POSITION.")

    raw_reference = _object(request["reference"], "reference", {"id", "label", "input"}, {"id", "label", "input"})
    if _text(raw_reference["id"], "reference.id", 64) != "reference":
        raise ValidationError("INVALID_COMPARISON_ID", "A referência precisa usar id 'reference'.")
    raw_alternatives = _sequence(request["alternatives"], "alternatives", 2)
    if not raw_alternatives:
        raise ValidationError("MISSING_ALTERNATIVE", "COMPARE exige ao menos uma alternativa além da referência.")
    if comparison_mode == "FIXED_POSITION" and len(raw_alternatives) != 1:
        raise ValidationError("FIXED_POSITION_REQUIRES_TWO_EXITS", "FIXED_POSITION exige uma referência e uma alternativa.")

    prepared: list[dict[str, Any]] = []
    ids = {"reference"}
    common_budget: Decimal | None = None
    fixed_identity: dict[str, Any] | None = None
    for index, raw_item in enumerate((raw_reference, *raw_alternatives)):
        name = "reference" if index == 0 else f"alternatives[{index - 1}]"
        item = raw_reference if index == 0 else _object(
            raw_item, name, {"id", "label", "input"}, {"id", "label", "input"},
        )
        item_id = _text(item["id"], f"{name}.id", 64)
        if item_id in ids and index != 0:
            raise ValidationError("DUPLICATE_COMPARISON_ID", "IDs da referência e das alternativas precisam ser únicos.")
        ids.add(item_id)
        label = _text(item["label"], f"{name}.label", 80)
        if not label.strip():
            raise ValidationError("INVALID_COMPARISON_LABEL", "Informe um rótulo não vazio de até 80 caracteres.")
        input_value = _object(item["input"], f"{name}.input", WORKSPACE_INPUT_FIELDS)
        normalized = normalize_workspace_input(prepare_workspace_defaults(input_value))
        prepared_input = prepare_workspace_defaults(input_value)
        normalized_json = normalized.to_dict()["normalized_input"]
        if comparison_mode == "BUDGET":
            if normalized.capital is None or normalized.capital.mode is not CapitalMode.BUDGET:
                raise ValidationError("COMMON_BUDGET_REQUIRED", "COMPARE dimensiona cada título por um orçamento comum explícito.")
            if common_budget is None:
                common_budget = normalized.capital.value
            elif normalized.capital.value != common_budget:
                raise ValidationError("COMMON_BUDGET_MISMATCH", "Todas as alternativas precisam usar exatamente o mesmo orçamento.")
        else:
            identity = fixed_position_input_identity(normalized_json)
            if fixed_identity is None:
                fixed_identity = identity
            elif identity != fixed_identity:
                raise ValidationError(
                    "FIXED_POSITION_MISMATCH",
                    "Título, quantidade, aquisição, compra e base fiscal precisam permanecer iguais entre as saídas.",
                )
        prepared.append({"id": item_id, "label": label, "input": prepared_input})

    horizon = _date(request.get("horizon"), "horizon", optional=True)
    raw_growth = request.get("cash_growth")
    cash_growth = None
    if raw_growth is not None:
        growth_fields = {"annual_net_rate", "profile"}
        if comparison_mode == "BUDGET":
            growth_fields.add("origin_date")
        growth = _object(raw_growth, "cash_growth", growth_fields, growth_fields)
        profile = _text(growth["profile"], "cash_growth.profile", 48)
        if profile != "ACT_365_COMPOUND_v1":
            raise ValidationError("UNSUPPORTED_CASH_GROWTH_PROFILE", "cash_growth.profile precisa ser ACT_365_COMPOUND_v1.")
        if isinstance(growth["annual_net_rate"], (str, int)) and len(str(growth["annual_net_rate"])) > 48:
            raise ValidationError("INVALID_NUMBER_FORMAT", "A taxa líquida anual aceita até 48 caracteres decimais.")
        annual_net_rate = _decimal(growth["annual_net_rate"], "cash_growth.annual_net_rate")
        if annual_net_rate <= -1:
            raise ValidationError("INVALID_CASH_GROWTH_RATE", "A taxa líquida anual precisa ser maior que −100%.")
        origin_date = None if comparison_mode == "FIXED_POSITION" else _date(growth["origin_date"], "cash_growth.origin_date")
        if horizon is None:
            raise ValidationError("HORIZON_REQUIRED", "cash_growth exige uma data horizon explícita.")
        cash_growth = {
            "annual_net_rate": annual_net_rate,
            "profile": profile,
            "origin_date": origin_date,
        }
    comparison_context = {"horizon": horizon, "cash_growth": cash_growth}
    prepared = [dict(item, comparison_context=comparison_context) for item in prepared]
    if comparison_mode == "FIXED_POSITION" and horizon is None:
        raise ValidationError("HORIZON_REQUIRED", "FIXED_POSITION exige horizonte comum explícito.")
    return {
        "action": "COMPARE", "request_id": request["request_id"], "revision": request["revision"],
        "reference": prepared[0], "alternatives": prepared[1:], "common_budget": common_budget,
        "comparison_mode": comparison_mode, "comparison_context": comparison_context,
    }


def _workspace_stress_request(request: Mapping[str, Any]) -> dict[str, Any]:
    from .constraints import STRESS_DIMENSION_UNITS, parse_constraint_set
    from .workspace import normalize_workspace_input, prepare_workspace_defaults, WORKSPACE_SEARCH_BUDGET

    input_value = _object(request["input"], "input", WORKSPACE_INPUT_FIELDS)
    prepared_input = prepare_workspace_defaults(input_value)
    normalized = normalize_workspace_input(prepared_input)
    fixed_position = None
    decision_margins = None
    is_g5 = "fixed_position" in request or "decision_margins" in request
    if is_g5:
        if "fixed_position" not in request or "decision_margins" not in request:
            raise ValidationError("INCOMPLETE_G5_CONTEXT", "STRESS G5 exige fixed_position e decision_margins juntos.")
        if request.get("shocks") not in (None, (), []):
            raise ValidationError("MIXED_STRESS_MODES", "STRESS G5 declara seus domínios sem combinar a lista legada de choques.")
        if request.get("margin_searches") not in (None, (), []):
            raise ValidationError("MIXED_STRESS_MODES", "STRESS G5 declara suas margens sem combinar buscas legadas.")
        raw_fixed = _object(
            request["fixed_position"], "fixed_position",
            {"reference", "horizon", "cash_growth"}, {"reference", "horizon", "cash_growth"},
        )
        parsed_comparison = _workspace_comparison_request({
            "schema_version": 2, "action": "COMPARE",
            "request_id": request["request_id"], "revision": request["revision"],
            "comparison_mode": "FIXED_POSITION",
            "reference": raw_fixed["reference"],
            "alternatives": [{"id": "alternative", "label": "Alternativa", "input": prepared_input}],
            "horizon": raw_fixed["horizon"], "cash_growth": raw_fixed["cash_growth"],
        })
        fixed_position = {
            "reference": parsed_comparison["reference"],
            "comparison_context": parsed_comparison["comparison_context"],
        }
        decision_margins = _workspace_g5_decision_margins(request["decision_margins"], prepared_input)
        context = fixed_position["comparison_context"]
        cash_growth = context.get("cash_growth")
        if not isinstance(cash_growth, Mapping):
            raise ValidationError("G5_CASH_REQUIRED", "STRESS G5 exige uma hipótese líquida explícita de caixa.")
        if cash_growth["annual_net_rate"] not in decision_margins["cash_rate_domain"]["values"]:
            raise ValidationError("G5_CASH_OUTSIDE_DOMAIN", "A hipótese-base de caixa precisa pertencer ao domínio finito G5.")
        if context["horizon"] != date(2027, 3, 15) or prepared_input.get("sale_date") != "2027-03-15":
            raise ValidationError("G5_BASE_HORIZON_MISMATCH", "A comparação-base G5 conserva o horizonte G3 de 15/03/2027.")
        raw_shocks = ()
    else:
        if "shocks" not in request:
            raise ValidationError("MISSING_FIELD", "STRESS legado exige shocks.")
        raw_shocks = _sequence(request["shocks"], "shocks", 25)
        if not raw_shocks:
            raise ValidationError("MISSING_STRESS_SCENARIO", "STRESS exige ao menos um choque nomeado.")

    shocks: list[dict[str, Any]] = []
    shock_ids: set[str] = set()
    shock_fields = {
        "id", "rate_shock_ratio", "annual_inflation_ratio",
        "entry_expense_delta_brl", "exit_expense_delta_brl",
    }
    for index, raw in enumerate(raw_shocks):
        path = f"shocks[{index}]"
        shock = _object(raw, path, shock_fields, {"id"})
        shock_id = _text(shock["id"], path + ".id", 64)
        if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._:-]{0,63}", shock_id):
            raise ValidationError("INVALID_STRESS_ID", f"{path}.id aceita letras, números, ponto, hífen, sublinhado e dois-pontos.")
        if shock_id == "reference" or shock_id in shock_ids:
            raise ValidationError("DUPLICATE_STRESS_ID", "IDs de cenários de estresse precisam ser únicos e não podem usar reference.")
        shock_ids.add(shock_id)
        normalized_shock: dict[str, Any] = {"id": shock_id}
        for field in shock_fields - {"id"}:
            if field not in shock:
                continue
            if isinstance(shock[field], (str, int)) and len(str(shock[field])) > 48:
                raise ValidationError("INVALID_NUMBER_FORMAT", f"{path}.{field} aceita até 48 caracteres decimais.")
            normalized_shock[field] = _decimal(shock[field], f"{path}.{field}")
        shocks.append(normalized_shock)

    constraint_set = parse_constraint_set(input_value["constraints"]) if "constraints" in input_value else None
    raw_margins = request.get("margin_searches", ())
    if raw_margins is None:
        raise ValidationError("INVALID_STRESS_MARGIN", "margin_searches deve ser uma lista, não null.")
    raw_margins = _sequence(raw_margins, "margin_searches", 4)
    if raw_margins and (constraint_set is None or not constraint_set.criteria):
        raise ValidationError("MISSING_CONSTRAINTS", "A busca de folga exige ao menos um critério nomeado em input.constraints.")
    criterion_ids = set() if constraint_set is None else {
        item.constraint_id for item in constraint_set.criteria
    }
    margin_searches: list[dict[str, Any]] = []
    margin_ids: set[str] = set()
    for index, raw in enumerate(raw_margins):
        path = f"margin_searches[{index}]"
        margin = _object(
            raw, path,
            {"id", "criterion_id", "dimension", "direction", "maximum_magnitude", "resolution"},
            {"id", "criterion_id", "dimension", "direction", "maximum_magnitude", "resolution"},
        )
        margin_id = _text(margin["id"], path + ".id", 64)
        if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._:-]{0,63}", margin_id) or margin_id in margin_ids:
            raise ValidationError("INVALID_STRESS_MARGIN_ID", f"{path}.id precisa ser único e usar um identificador válido.")
        margin_ids.add(margin_id)
        criterion_id = _text(margin["criterion_id"], path + ".criterion_id", 64)
        if criterion_id not in criterion_ids:
            raise ValidationError("UNKNOWN_STRESS_CRITERION", f"{path}.criterion_id precisa identificar um critério de input.constraints.")
        dimension = _text(margin["dimension"], path + ".dimension", 48)
        if dimension not in STRESS_DIMENSION_UNITS:
            raise ValidationError("INVALID_STRESS_DIMENSION", f"{path}.dimension não é suportada.")
        direction = _text(margin["direction"], path + ".direction", 16)
        if direction not in {"INCREASE", "DECREASE"}:
            raise ValidationError("INVALID_STRESS_DIRECTION", f"{path}.direction precisa ser INCREASE ou DECREASE.")
        maximum = _decimal(margin["maximum_magnitude"], path + ".maximum_magnitude")
        resolution = _decimal(margin["resolution"], path + ".resolution")
        if maximum <= 0 or resolution <= 0 or maximum / resolution != (maximum / resolution).to_integral_value():
            raise ValidationError("INVALID_STRESS_DOMAIN", f"{path} exige máximo positivo múltiplo inteiro da resolução.")
        if maximum / resolution > 4095:
            raise ValidationError("INVALID_STRESS_DOMAIN", f"{path} aceita no máximo 4096 pontos incluindo a referência.")
        margin_searches.append({
            "id": margin_id, "criterion_id": criterion_id, "dimension": dimension,
            "direction": direction, "maximum_magnitude": maximum, "resolution": resolution,
            "unit": STRESS_DIMENSION_UNITS[dimension],
        })

    maximum = 64 if is_g5 else WORKSPACE_SEARCH_BUDGET["max_evaluations"]
    max_evaluations = request.get("max_evaluations", maximum)
    deadline_ms = request.get("deadline_ms", int(WORKSPACE_SEARCH_BUDGET["deadline_seconds"] * 1000))
    if type(max_evaluations) is not int or not 1 <= max_evaluations <= maximum:
        upper = 64 if is_g5 else WORKSPACE_SEARCH_BUDGET["max_evaluations"]
        raise ValidationError("INVALID_SEARCH_BUDGET", f"max_evaluations precisa ficar entre 1 e {upper}.")
    if not is_g5 and max_evaluations < len(shocks) + 1:
        raise ValidationError("INVALID_SEARCH_BUDGET", "max_evaluations precisa cobrir a referência e cada choque nomeado.")
    if type(deadline_ms) is not int or not 1 <= deadline_ms <= int(WORKSPACE_SEARCH_BUDGET["deadline_seconds"] * 1000):
        raise ValidationError("INVALID_SEARCH_DEADLINE", "deadline_ms precisa ficar entre 1 e 10000.")
    return {
        "action": "STRESS", "request_id": request["request_id"], "revision": request["revision"],
        "input": prepared_input, "shocks": shocks, "margin_searches": margin_searches,
        "constraints": constraint_set, "max_evaluations": max_evaluations,
        "deadline_ms": deadline_ms, "fixed_position": fixed_position,
        "decision_margins": decision_margins,
    }


def _workspace_g5_decision_margins(raw: object, alternative_input: Mapping[str, Any]) -> dict[str, Any]:
    fields = {
        "nominal_profit_goal_brl", "cash_rate_domain", "exit_real_rate_domain",
        "annual_inflation_levels", "exit_expense_domain", "decomposition", "fiscal_pair",
    }
    value = _object(raw, "decision_margins", fields, fields)
    goal = _decimal(value["nominal_profit_goal_brl"], "decision_margins.nominal_profit_goal_brl")

    def fixed_domain(raw_domain: object, name: str, keys: set[str], unit: str,
                     minimum_key: str, maximum_key: str, step_key: str,
                     expected_min: str, expected_max: str, expected_step: str) -> dict[str, Any]:
        domain = _object(raw_domain, name, keys, keys - {"kind"})
        if domain.get("unit") != unit:
            raise ValidationError("INVALID_G5_DOMAIN", f"{name}.unit precisa ser {unit}.")
        minimum = _decimal(domain[minimum_key], f"{name}.{minimum_key}")
        maximum = _decimal(domain[maximum_key], f"{name}.{maximum_key}")
        step = _decimal(domain[step_key], f"{name}.{step_key}")
        if (minimum, maximum, step) != (Decimal(expected_min), Decimal(expected_max), Decimal(expected_step)):
            raise ValidationError("INVALID_G5_DOMAIN", f"{name} precisa conservar a grade finita congelada de G5.")
        count = int((maximum - minimum) / step) + 1
        return {
            "minimum": minimum, "maximum": maximum, "step": step,
            "unit": unit, "point_count": count,
            "values": tuple(minimum + step * index for index in range(count)),
        }

    cash_domain = fixed_domain(
        value["cash_rate_domain"], "decision_margins.cash_rate_domain",
        {"minimum_rate", "maximum_rate", "step", "unit", "kind"}, "ratio",
        "minimum_rate", "maximum_rate", "step", "0", "0.10", "0.01",
    )
    raw_rate = _object(
        value["exit_real_rate_domain"], "decision_margins.exit_real_rate_domain",
        {"base", "minimum_delta", "maximum_delta", "step", "unit"},
        {"base", "minimum_delta", "maximum_delta", "step", "unit"},
    )
    if raw_rate["unit"] != "ratio":
        raise ValidationError("INVALID_G5_DOMAIN", "decision_margins.exit_real_rate_domain.unit precisa ser ratio.")
    base_rate = _decimal(raw_rate["base"], "decision_margins.exit_real_rate_domain.base")
    exit_price = alternative_input.get("exit_price") or {}
    if exit_price.get("mode") != "MANUAL_PU":
        raise ValidationError(
            "G5_MANUAL_BASE_REQUIRED",
            "Margens, caixa e despesas G5 usam a alternativa G3 em MANUAL_PU; a base de reprecificação é separada.",
        )
    _decimal(exit_price.get("pu"), "input.exit_price.pu")
    if base_rate != Decimal("0.069879"):
        raise ValidationError(
            "G5_RATE_BASE_MISMATCH",
            "A base de reprecificação G5 precisa declarar explicitamente a taxa-base congelada 0.069879, independente do PU manual.",
        )
    rate_domain = fixed_domain(
        {"minimum_delta": raw_rate["minimum_delta"], "maximum_delta": raw_rate["maximum_delta"], "step": raw_rate["step"], "unit": raw_rate["unit"]},
        "decision_margins.exit_real_rate_domain",
        {"minimum_delta", "maximum_delta", "step", "unit"}, "ratio",
        "minimum_delta", "maximum_delta", "step", "0", "0.002", "0.0001",
    )
    rate_domain["base"] = base_rate

    raw_inflation = _sequence(value["annual_inflation_levels"], "decision_margins.annual_inflation_levels", 3)
    inflation_levels = tuple(_decimal(item, f"decision_margins.annual_inflation_levels[{index}]") for index, item in enumerate(raw_inflation))
    if inflation_levels != (Decimal("0.02"), Decimal("0.03"), Decimal("0.04")):
        raise ValidationError("INVALID_G5_DOMAIN", "annual_inflation_levels precisa declarar exatamente 2%, 3% e 4%.")
    assumptions = alternative_input.get("assumptions") or {}
    projection = assumptions.get("inflation_projection") if isinstance(assumptions, Mapping) else None
    if not isinstance(projection, Mapping):
        raise ValidationError("MISSING_G5_STRESS_BASE", "STRESS G5 exige projeção-base explícita para variar a inflação.")
    if (
        projection.get("mode") != "CONSTANT_ANNUAL"
        or _decimal(projection.get("annual_rate"), "input.assumptions.inflation_projection.annual_rate") != Decimal("0.03")
        or _date(projection.get("anchor_date"), "input.assumptions.inflation_projection.anchor_date") != date(2026, 10, 15)
        or _decimal(projection.get("anchor_level"), "input.assumptions.inflation_projection.anchor_level") != Decimal("1")
        or not _text(projection.get("source_ref"), "input.assumptions.inflation_projection.source_ref", 160)
    ):
        raise ValidationError("INVALID_G5_STRESS_BASE", "A projeção-base G5 precisa ser anual explícita de 3% e identificar sua origem.")
    repriced_projection = {
        "mode": projection["mode"],
        "annual_rate": _decimal(projection["annual_rate"], "input.assumptions.inflation_projection.annual_rate"),
        "anchor_date": _date(projection.get("anchor_date"), "input.assumptions.inflation_projection.anchor_date"),
        "anchor_level": _decimal(projection.get("anchor_level"), "input.assumptions.inflation_projection.anchor_level"),
        "source_ref": _text(projection["source_ref"], "input.assumptions.inflation_projection.source_ref", 160),
    }

    expense_domain = fixed_domain(
        value["exit_expense_domain"], "decision_margins.exit_expense_domain",
        {"minimum_brl", "maximum_brl", "step_brl", "unit"}, "BRL",
        "minimum_brl", "maximum_brl", "step_brl", "0", "500", "100",
    )
    if not isinstance(assumptions, Mapping) or "exit_fee_brl" not in assumptions:
        raise ValidationError("MISSING_G5_STRESS_BASE", "STRESS G5 exige despesa-base explícita para variar custos de saída.")
    if _decimal(assumptions["exit_fee_brl"], "input.assumptions.exit_fee_brl") < 0:
        raise ValidationError("INVALID_G5_STRESS_BASE", "A despesa-base de saída não pode ser negativa.")
    decomposition_raw = _object(
        value["decomposition"], "decision_margins.decomposition",
        {"rate_a_delta", "inflation_b_level"}, {"rate_a_delta", "inflation_b_level"},
    )
    rate_a = _decimal(decomposition_raw["rate_a_delta"], "decision_margins.decomposition.rate_a_delta")
    inflation_b = _decimal(decomposition_raw["inflation_b_level"], "decision_margins.decomposition.inflation_b_level")
    if rate_a not in rate_domain["values"] or inflation_b not in inflation_levels:
        raise ValidationError("INVALID_G5_DECOMPOSITION", "Os dois choques do quadro 2x2 precisam pertencer às grades declaradas.")

    fiscal_pair = None
    if "fiscal_pair" in value:
        raw_fiscal = _object(
            value["fiscal_pair"], "decision_margins.fiscal_pair",
            {"sale_dates", "real_rate", "inflation_projection", "common_horizon", "cash_growth_rate"},
            {"sale_dates", "real_rate", "inflation_projection", "common_horizon", "cash_growth_rate"},
        )
        sale_dates = tuple(_date(item, f"decision_margins.fiscal_pair.sale_dates[{index}]") for index, item in enumerate(_sequence(raw_fiscal["sale_dates"], "decision_margins.fiscal_pair.sale_dates", 2)))
        if sale_dates != (date(2027, 4, 13), date(2027, 4, 14)):
            raise ValidationError("INVALID_G5_FISCAL_PAIR", "O par fiscal congelado G5 usa 13/04/2027 e 14/04/2027.")
        fiscal_rate = _decimal(raw_fiscal["real_rate"], "decision_margins.fiscal_pair.real_rate")
        if fiscal_rate != base_rate or fiscal_rate != Decimal("0.069879"):
            raise ValidationError("INVALID_G5_FISCAL_PAIR", "O par fiscal conserva a taxa real-base congelada de 0,069879.")
        projection_raw = _object(
            raw_fiscal["inflation_projection"], "decision_margins.fiscal_pair.inflation_projection",
            {"mode", "annual_rate", "anchor_date", "anchor_level", "source_ref"},
            {"mode", "annual_rate", "anchor_date", "anchor_level", "source_ref"},
        )
        if (
            projection_raw["mode"] != "CONSTANT_ANNUAL"
            or _decimal(projection_raw["annual_rate"], "decision_margins.fiscal_pair.inflation_projection.annual_rate") != Decimal("0.03")
            or _date(projection_raw["anchor_date"], "decision_margins.fiscal_pair.inflation_projection.anchor_date") != date(2026, 10, 15)
            or _decimal(projection_raw["anchor_level"], "decision_margins.fiscal_pair.inflation_projection.anchor_level") != Decimal("1")
            or _text(projection_raw["source_ref"], "decision_margins.fiscal_pair.inflation_projection.source_ref", 160) != "G5 independent baseline projection"
        ):
            raise ValidationError("INVALID_G5_FISCAL_PAIR", "A projeção fiscal G5 precisa conservar a projeção-base congelada de 3%.")
        projection = {
            "mode": projection_raw["mode"],
            "annual_rate": _decimal(projection_raw["annual_rate"], "decision_margins.fiscal_pair.inflation_projection.annual_rate"),
            "anchor_date": _date(projection_raw["anchor_date"], "decision_margins.fiscal_pair.inflation_projection.anchor_date"),
            "anchor_level": _decimal(projection_raw["anchor_level"], "decision_margins.fiscal_pair.inflation_projection.anchor_level"),
            "source_ref": _text(projection_raw.get("source_ref", ""), "decision_margins.fiscal_pair.inflation_projection.source_ref", 160),
        }
        common_horizon = _date(raw_fiscal["common_horizon"], "decision_margins.fiscal_pair.common_horizon")
        if common_horizon != sale_dates[1]:
            raise ValidationError("INVALID_G5_FISCAL_PAIR", "O horizonte comum precisa coincidir com a data fiscal posterior.")
        cash_rate = _decimal(raw_fiscal["cash_growth_rate"], "decision_margins.fiscal_pair.cash_growth_rate")
        if cash_rate != Decimal("0.03"):
            raise ValidationError("INVALID_G5_FISCAL_PAIR", "A taxa líquida de caixa fiscal congelada G5 é 3% a.a.")
        fiscal_pair = {
            "sale_dates": sale_dates, "real_rate": fiscal_rate,
            "inflation_projection": projection, "common_horizon": common_horizon,
            "cash_growth_rate": cash_rate,
        }

    return {
        "nominal_profit_goal_brl": goal,
        "cash_rate_domain": cash_domain,
        "exit_real_rate_domain": rate_domain,
        "annual_inflation_levels": inflation_levels,
        "exit_expense_domain": expense_domain,
        "decomposition": {"rate_a_delta": rate_a, "inflation_b_level": inflation_b},
        "fiscal_pair": fiscal_pair,
        "basis_semantics": {
            "version": G5_BASIS_SEMANTICS_VERSION,
            "manual_basis_id": G5_MANUAL_BASIS_ID,
            "reference_basis_id": G5_REFERENCE_BASIS_ID,
            "repriced_basis_id": G5_REPRICED_BASIS_ID,
            "manual_exit_price_mode": "MANUAL_PU",
            "repriced_exit_price_mode": "MANUAL_RATE",
            "repriced_base_rate": base_rate,
            "repriced_base_inflation": Decimal("0.03"),
            "repriced_inflation_projection": repriced_projection,
        },
    }


def workspace_fingerprint(
    action: str, input_value: object, *, surface: Mapping[str, Any] | None = None,
    query: Mapping[str, Any] | None = None, quantity: Decimal | str | None = None,
) -> str:
    """Hash normalized financial inputs and the engine/data contract, excluding UI identity."""
    from .projections import INTERPOLATED_PROFILE_ID, PROJECTION_PROFILE_ID
    from .service import engine_manifest
    from .workspace import normalize_unit_price_input, normalize_workspace_input, prepare_workspace_defaults

    if action in {"UNIT_PRICE", "GROSS_DV01"}:
        normalized = normalize_unit_price_input(input_value).to_dict()["normalized_input"]
    else:
        normalized = normalize_workspace_input(prepare_workspace_defaults(input_value)).to_dict()["normalized_input"]
        assumptions = normalized["assumptions"]
        for field in (
            "tax_cost_basis_brl", "custody_override_brl", "institution_net_brl",
            "institution_release_date", "inflation_projection", "explicit_settlements",
        ):
            assumptions.setdefault(field, None)
    payload = {
        "schema_version": 2,
        "action": action,
        "input": _canonical_workspace_value(normalized),
        "engine_manifest": engine_manifest(),
        "projection_profile_ids": [PROJECTION_PROFILE_ID, INTERPOLATED_PROFILE_ID],
        "search_budget": dict(WORKSPACE_SEARCH_BUDGET),
    }
    if surface is not None:
        if action != "SURFACE":
            raise ValidationError("INVALID_DOMAIN", "Domínio de superfície só pode integrar a ação SURFACE.")
        candidate_dates = surface.get("candidate_order_dates", surface.get("order_dates")) or ()
        sampled_dates = surface.get("order_dates") or ()
        candidate_values = surface.get("candidate_values", surface.get("values")) or ()
        sampled_values = surface.get("values") or ()
        payload["surface_domain"] = {
            "mode": surface["mode"],
            "candidate_order_dates": [item.isoformat() if isinstance(item, date) else item for item in candidate_dates],
            "sampled_order_dates": [item.isoformat() if isinstance(item, date) else item for item in sampled_dates],
            "candidate_values": [_canonical_decimal(item) for item in candidate_values],
            "sampled_values": [_canonical_decimal(item) for item in sampled_values],
            "omitted_dates": [item.isoformat() if isinstance(item, date) else item for item in surface.get("omitted_dates", ())],
            "omitted_values": [_canonical_decimal(item) for item in surface.get("omitted_values", ())],
            "value_unit": surface["value_unit"],
            "selected": {
                "order_date": surface["selected_order_date"].isoformat(),
                "value": _canonical_decimal(surface["selected_value"]),
            },
        }
    if query is not None:
        if action == "UNIT_PRICE":
            if query.get("kind") not in {"POINT", "DATE_CURVE", "RATE_CURVE"}:
                raise ValidationError("INVALID_QUERY", "Consulta de preço unitário inválida.")
        elif action != "CONSTRAINTS" or query.get("kind") not in {"FIRST_DATE", "ENTRY_BOUNDARY"}:
            raise ValidationError("INVALID_QUERY", "Consulta de data/entrada só pode integrar CONSTRAINTS.")
        payload["query"] = _canonical_workspace_value(query)
    if quantity is not None:
        if action != "GROSS_DV01":
            raise ValidationError("INVALID_FINGERPRINT", "quantity só integra fingerprint de GROSS_DV01.")
        if isinstance(quantity, Decimal):
            if not quantity.is_finite():
                raise ValidationError("INVALID_NUMBER_FORMAT", "quantity deve ser Decimal finito no fingerprint.")
            normalized_quantity = quantity
        else:
            normalized_quantity = _decimal(quantity, "quantity")
        payload["quantity"] = _canonical_decimal(normalized_quantity)
    encoded = json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False).encode("utf-8")
    return sha256(encoded).hexdigest()


def workspace_comparison_fingerprint(items: object, *, comparison_mode: str = "BUDGET") -> str:
    """Fingerprint identities and independent financial inputs in a comparison."""
    from .service import engine_manifest

    if not isinstance(items, (list, tuple)):
        raise ValidationError("INVALID_COMPARISON", "Alternativas para fingerprint precisam ser uma lista.")
    payload = {
        "schema_version": 2,
        "action": "COMPARE",
        "comparison_mode": comparison_mode,
        "engine_manifest": engine_manifest(),
        "items": [
            {
                "id": item["id"], "label": item["label"],
                "input_fingerprint": workspace_fingerprint("EVALUATE", item["input"]),
                "comparison_context": _canonical_workspace_value(item.get("comparison_context")),
            }
            for item in items
        ],
    }
    encoded = json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False).encode("utf-8")
    return sha256(encoded).hexdigest()


def workspace_stress_fingerprint(
    input_value: object, shocks: object, margin_searches: object, *,
    fixed_position: Mapping[str, Any] | None = None,
    decision_margins: Mapping[str, Any] | None = None,
) -> str:
    """Fingerprint a legacy stress or a fixed-position G5 sensitivity request."""
    from .service import engine_manifest

    payload = {
        "schema_version": 2,
        "action": "STRESS",
        "engine_manifest": engine_manifest(),
        "input_fingerprint": workspace_fingerprint("EVALUATE", input_value),
        "shocks": _canonical_workspace_value(shocks),
        "margin_searches": _canonical_workspace_value(margin_searches),
    }
    if fixed_position is not None or decision_margins is not None:
        payload["fixed_position"] = _canonical_workspace_value(fixed_position)
        payload["decision_margins"] = _canonical_workspace_value(decision_margins)
        payload["g5_basis_semantics"] = {
            "version": G5_BASIS_SEMANTICS_VERSION,
            "reference_basis_id": G5_REFERENCE_BASIS_ID,
            "manual_basis_id": G5_MANUAL_BASIS_ID,
            "repriced_basis_id": G5_REPRICED_BASIS_ID,
        }
    encoded = json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False).encode("utf-8")
    return sha256(encoded).hexdigest()


def _workspace_surface(
    raw: object, *, default_selected_value: object | None = None,
) -> dict[str, Any]:
    from .surfaces import SurfaceMetric

    value = _object(
        raw, "surface",
        {"mode", "metric_id", "order_dates", "values", "value_unit", "selected"},
        {"mode", "metric_id", "value_unit", "selected"},
    )
    mode = _text(value["mode"], "surface.mode", 32)
    if mode not in {"PRICE_DATE_MAP", "RATE_DATE_MAP", "RATE_CURVE", "DATE_CURVE"}:
        raise ValidationError("INVALID_DOMAIN", "surface.mode não é suportado nesta ação.")
    metric_id = _text(value["metric_id"], "surface.metric_id", 64)
    try:
        metric = SurfaceMetric(metric_id)
    except ValueError as exc:
        raise ValidationError("INVALID_ENUM", "surface.metric_id não é suportado.") from exc
    expected_unit = _surface_metric_unit(metric)
    coordinate_unit = _text(value["value_unit"], "surface.value_unit", 32)
    if mode in {"PRICE_DATE_MAP"} and coordinate_unit != "BRL_PER_TITLE":
        raise ValidationError("INVALID_UNIT", "PRICE_DATE_MAP exige value_unit BRL_PER_TITLE.")
    if mode in {"RATE_DATE_MAP", "RATE_CURVE"} and coordinate_unit != "ratio":
        raise ValidationError("INVALID_UNIT", "Mapas e curvas de taxa exigem value_unit ratio.")
    if mode == "DATE_CURVE" and coordinate_unit not in {"ratio", "BRL_PER_TITLE"}:
        raise ValidationError("INVALID_UNIT", "DATE_CURVE exige value_unit ratio ou BRL_PER_TITLE.")
    raw_dates = _sequence(value["order_dates"], "surface.order_dates", 2048) if "order_dates" in value else None
    dates = None if raw_dates is None else tuple(_date(item, "surface.order_dates[]") for item in raw_dates)
    if dates is not None and (not dates or dates != tuple(sorted(set(dates)))):
        raise ValidationError("INVALID_DOMAIN", "surface.order_dates precisa ser crescente e sem duplicatas.")
    raw_values = _sequence(value["values"], "surface.values", 101 if mode in {"RATE_CURVE", "PRICE_DATE_MAP", "RATE_DATE_MAP"} else 1) if "values" in value else None
    values = None if raw_values is None else tuple(_decimal(item, "surface.values[]") for item in raw_values)
    if values is not None and (not values or values != tuple(sorted(set(values)))):
        raise ValidationError("INVALID_DOMAIN", "surface.values precisa ser crescente e sem duplicatas.")
    if coordinate_unit == "BRL_PER_TITLE" and values is not None and any(item <= 0 for item in values):
        raise ValidationError("INVALID_DOMAIN", "PUs da superfície precisam ser positivos.")
    if coordinate_unit == "ratio" and values is not None and any(item <= -1 for item in values):
        raise ValidationError("INVALID_DOMAIN", "Taxas da superfície precisam ser maiores que −100%.")
    if mode == "RATE_CURVE" and dates is not None and len(dates) != 1:
        raise ValidationError("INVALID_DOMAIN", "RATE_CURVE exige exatamente uma data.")
    if mode == "DATE_CURVE" and values is not None and len(values) != 1:
        raise ValidationError("INVALID_DOMAIN", "DATE_CURVE exige exatamente um valor para todas as datas.")
    selected = _object(value["selected"], "surface.selected", {"order_date", "value"}, {"order_date"})
    selected_date = _date(selected["order_date"], "surface.selected.order_date")
    selected_value_source = "USER_SELECTED"
    if "value" in selected and selected["value"] is None:
        raise ValidationError("MISSING_FIELD", "surface.selected.value não pode ser null.")
    raw_selected_value = selected.get("value")
    if "value" not in selected:
        if default_selected_value is None or coordinate_unit != "ratio":
            raise ValidationError("MISSING_FIELD", "surface.selected.value exige PU/taxa selecionados ou taxa utilizável na entrada.")
        raw_selected_value = default_selected_value
        selected_value_source = "SAME_ENTRY_RATE"
    selected_value = _decimal(raw_selected_value, "surface.selected.value")
    if mode == "RATE_CURVE" and dates is not None and selected_date not in dates:
        raise ValidationError("INVALID_SELECTION", "surface.selected.order_date precisa ser a única data da curva.")
    if coordinate_unit == "BRL_PER_TITLE" and selected_value <= 0:
        raise ValidationError("INVALID_SELECTION", "PU selecionado precisa ser positivo.")
    if coordinate_unit == "ratio" and selected_value <= -1:
        raise ValidationError("INVALID_SELECTION", "Taxa selecionada precisa ser maior que −100%.")
    return {
        "mode": mode, "metric_id": metric.value, "metric_unit": expected_unit,
        "order_dates": dates, "values": values, "value_unit": coordinate_unit,
        "selected_order_date": selected_date, "selected_value": selected_value,
        "selected_value_source": selected_value_source,
    }


def _surface_metric_unit(metric: Any) -> str:
    from .surfaces import SurfaceMetric

    if metric in (SurfaceMetric.GROSS_REDEMPTION, SurfaceMetric.NET_REDEMPTION,
                  SurfaceMetric.NOMINAL_PROFIT, SurfaceMetric.REAL_PROFIT):
        return "BRL"
    return "ratio_per_year" if metric is SurfaceMetric.ANNUALIZED_NOMINAL_RETURN else "ratio"


def _canonical_decimal(value: Any) -> str:
    decimal = value if isinstance(value, Decimal) else Decimal(str(value))
    if decimal == 0:
        return "0"
    text = format(decimal, "f")
    return text.rstrip("0").rstrip(".") if "." in text else text


def _canonical_workspace_value(value: Any, key: str | None = None) -> Any:
    if isinstance(value, (date, datetime)):
        return value.isoformat()
    if isinstance(value, Decimal):
        return _canonical_decimal(value)
    if isinstance(value, dict):
        return {name: _canonical_workspace_value(item, name) for name, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [_canonical_workspace_value(item) for item in value]
    if key in _WORKSPACE_DECIMAL_KEYS and isinstance(value, str) and re.fullmatch(r"[+-]?(?:0|[1-9]\d*)(?:\.\d+)?", value):
        text = format(Decimal(value), "f")
        if Decimal(value) == 0:
            return "0"
        text = text.rstrip("0").rstrip(".") if "." in text else text
        return text[1:] if text.startswith("+") else text
    return value


def _scenario(raw: object) -> Scenario:
    value = _object(raw, "cenário", {"instrument", "entry", "exit", "as_of"}, {"instrument", "entry", "exit", "as_of"})
    instrument_raw = _object(value["instrument"], "instrumento", {
        "family", "instrument_id", "maturity_date", "conversion_date", "first_income_date", "pays_coupon", "coupon_rate",
    }, {"family", "instrument_id", "maturity_date"})
    family = _enum(ProductFamily, instrument_raw["family"], "família")
    instrument_id = _text(instrument_raw["instrument_id"], "instrument_id", 128)
    instrument = Instrument(
        family, instrument_id, _date(instrument_raw["maturity_date"], "vencimento"),
        _date(instrument_raw.get("conversion_date"), "conversão", optional=True),
        _date(instrument_raw.get("first_income_date"), "primeira renda", optional=True),
        _boolean(instrument_raw.get("pays_coupon", False), "pays_coupon"),
        _decimal(instrument_raw.get("coupon_rate", "0"), "coupon_rate"),
    )
    entry_raw = _object(value["entry"], "compra", {
        "instrument_id", "order_date", "settlement_date", "quantity", "unit_price", "real_yield", "side", "provenance",
    }, {"order_date", "settlement_date", "quantity"})
    entry = Entry(
        _text(entry_raw.get("instrument_id", instrument_id), "instrument_id", 128),
        _date(entry_raw["order_date"], "data da ordem de compra"),
        _date(entry_raw["settlement_date"], "liquidação da compra"),
        _decimal(entry_raw["quantity"], "quantidade"),
        _decimal(entry_raw.get("unit_price"), "PU de compra", optional=True),
        _decimal(entry_raw.get("real_yield"), "taxa de compra", optional=True),
        _enum(Side, entry_raw.get("side", "BUY"), "lado da compra"),
        _provenance(entry_raw.get("provenance")),
    )
    exit_raw = _object(value["exit"], "saída", {
        "instrument_id", "order_date", "settlement_date", "side", "unit_price", "real_yield", "quoted_side", "spread", "spread_source", "provenance",
    }, {"order_date", "settlement_date", "side"})
    exit = Exit(
        _text(exit_raw.get("instrument_id", instrument_id), "instrument_id", 128),
        _date(exit_raw["order_date"], "data da ordem de saída"),
        _date(exit_raw["settlement_date"], "liquidação da saída"),
        _enum(Side, exit_raw["side"], "lado da saída"),
        _decimal(exit_raw.get("unit_price"), "PU de saída", optional=True),
        _decimal(exit_raw.get("real_yield"), "taxa de saída", optional=True),
        _enum(Side, exit_raw.get("quoted_side", "SELL"), "lado cotado"),
        _decimal(exit_raw.get("spread"), "spread", optional=True),
        _optional_text(exit_raw.get("spread_source"), "fonte do spread", 256),
        _provenance(exit_raw.get("provenance")),
    )
    asof_raw = _object(value["as_of"], "as_of", {"date", "mode"}, {"date"})
    asof = AsOf(
        _date(asof_raw["date"], "as_of"),
        _enum(EvidenceMode, asof_raw.get("mode", "CAUSAL"), "modo de evidência"),
    )
    return Scenario(instrument, entry, exit, asof)


def _context(raw: object, scenario: Scenario) -> tuple[EvaluationContext, list[str]]:
    value = _object(raw, "contexto", {
        "calendar_id", "calendar_knowledge_date", "index_anchors", "tax_cost_basis",
        "entry_expense_paid", "exit_expense", "custody_override", "institution_net_override",
        "intermediate_paid_costs", "index_levels", "institution_release_date",
    })
    calendar_id = value.get("calendar_id", API_CALENDAR_ID)
    if calendar_id != API_CALENDAR_ID:
        raise ValidationError("UNSUPPORTED_CALENDAR", "Calendário informado não está instalado localmente.")
    knowledge_date = _date(value.get("calendar_knowledge_date"), "data de conhecimento do calendário", optional=True)
    if knowledge_date is None:
        knowledge_date = scenario.as_of.date if scenario.as_of.mode is EvidenceMode.CAUSAL else date.today()
    if scenario.as_of.mode is EvidenceMode.CAUSAL and knowledge_date > scenario.as_of.date:
        raise ValidationError("CALENDAR_AFTER_AS_OF", "Calendário conhecido depois do as_of não pode alimentar modo causal.")
    calendar = FinancialCalendar(knowledge_date=knowledge_date)

    anchors_raw = _sequence(value.get("index_anchors", ()), "âncoras VNA/VNI", MAX_ANCHORS)
    anchors = tuple(_anchor(item) for item in anchors_raw)
    anchor_keys = [(item.kind, item.reference_date) for item in anchors]
    if len(anchor_keys) != len(set(anchor_keys)):
        raise ValidationError("CONFLICTING_INDEX", "Contexto contém mais de uma âncora do mesmo tipo/data.")
    cost_raw = _sequence(value.get("intermediate_paid_costs", ()), "custos intermediários", MAX_COST_FLOWS)
    costs = tuple(_cash_flow(item) for item in cost_raw)
    index_raw = _sequence(value.get("index_levels", ()), "níveis de índice", MAX_ANCHORS)
    levels = tuple(_index_level(item) for item in index_raw)
    level_dates = [item.date for item in levels]
    if len(level_dates) != len(set(level_dates)):
        raise ValidationError("INVALID_INDEX", "Níveis de índice duplicam uma data.")

    context = EvaluationContext(
        calendar=calendar,
        index_anchors=anchors,
        tax_cost_basis=_decimal(value.get("tax_cost_basis"), "custo fiscal", optional=True),
        entry_expense_paid=_decimal(value.get("entry_expense_paid", "0"), "despesa inicial"),
        exit_expense=_decimal(value.get("exit_expense", "0"), "despesa de saída"),
        custody_override=_decimal(value.get("custody_override"), "custódia informada", optional=True),
        institution_net_override=_decimal(value.get("institution_net_override"), "líquido informado", optional=True),
        intermediate_paid_costs=costs,
        index_levels=levels,
        institution_release_date=_date(value.get("institution_release_date"), "liberação institucional", optional=True),
    )
    return context, ["Calendário projetado local; feriados extraordinários e liberação da instituição não são certificados."]


def _anchor(raw: object) -> IndexAnchor:
    value = _object(raw, "âncora", {"kind", "value", "reference_date", "quality", "source_ref", "provenance"},
                    {"kind", "value", "reference_date", "quality", "source_ref"})
    return IndexAnchor(
        _enum(IndexKind, value["kind"], "tipo de índice"),
        _decimal(value["value"], "nível de índice"),
        _date(value["reference_date"], "data de referência do índice"),
        _enum(Quality, value["quality"], "qualidade do índice"),
        _text(value["source_ref"], "fonte do índice", 512),
        _provenance(value.get("provenance")),
    )


def _index_level(raw: object) -> IndexLevel:
    value = _object(raw, "nível de índice", {"date", "value", "source_ref"}, {"date", "value", "source_ref"})
    return IndexLevel(_date(value["date"], "data do índice"), _decimal(value["value"], "nível do índice"), _text(value["source_ref"], "fonte do índice", 512))


def _cash_flow(raw: object) -> CashFlow:
    value = _object(raw, "fluxo de custo", {"date", "amount", "label"}, {"date", "amount", "label"})
    return CashFlow(_date(value["date"], "data do custo"), _decimal(value["amount"], "custo intermediário"), _text(value["label"], "descrição do custo", 256))


def _provenance(raw: object) -> Provenance | None:
    if raw is None:
        return None
    value = _object(raw, "proveniência", {
        "source_id", "source_ref", "quality", "observed_on", "published_at", "version", "sha256",
        "revision_id", "supersedes_revision", "settlement_date",
    }, {"source_id", "source_ref", "quality"})
    published = None
    if value.get("published_at") is not None:
        try:
            published = datetime.fromisoformat(_text(value["published_at"], "data de publicação", 64).replace("Z", "+00:00"))
        except ValueError as exc:
            raise ValidationError("INVALID_PROVENANCE", "Data de publicação precisa ser ISO 8601 com fuso.") from exc
    return Provenance(
        _text(value["source_id"], "identificador da fonte", 128),
        _text(value["source_ref"], "referência da fonte", 512),
        _enum(Quality, value["quality"], "qualidade da evidência"),
        _date(value.get("observed_on"), "data observada", optional=True),
        published,
        _optional_text(value.get("version"), "versão da fonte", 128),
        _optional_text(value.get("sha256"), "hash da fonte", 64),
        _optional_text(value.get("revision_id"), "revisão da fonte", 128),
        _optional_text(value.get("supersedes_revision"), "revisão substituída", 128),
        _date(value.get("settlement_date"), "liquidação da cotação", optional=True),
    )


def _observation(raw: object) -> ExitObservation:
    value = _object(raw, "observação de saída", {
        "order_date", "settlement_date", "unit_price", "real_yield", "quality", "provenance",
    }, {"order_date", "settlement_date"})
    quality = _enum(Quality, value.get("quality", "INFORMED"), "qualidade da observação")
    return ExitObservation(
        _date(value["order_date"], "data da ordem"),
        _date(value["settlement_date"], "liquidação"),
        _decimal(value.get("unit_price"), "PU observado", optional=True),
        _decimal(value.get("real_yield"), "taxa observada", optional=True),
        _provenance(value.get("provenance")), quality,
    )


def _session(raw: object) -> SurfaceSession:
    value = _object(raw, "sessão da superfície", {"order_date", "settlement_date"}, {"order_date", "settlement_date"})
    return SurfaceSession(_date(value["order_date"], "data da ordem"), _date(value["settlement_date"], "liquidação"))


def _target(raw: object) -> TargetDefinition | None:
    if raw is None:
        return None
    value = _object(raw, "meta", {"metric", "minimum_value", "unit", "target_date"}, {"metric", "minimum_value", "unit"})
    return TargetDefinition(
        _enum(TargetMetric, value["metric"], "tipo da meta"),
        _decimal(value["minimum_value"], "valor da meta"),
        _text(value["unit"], "unidade da meta", 32),
        _date(value.get("target_date"), "data-base da meta real", optional=True),
    )


def _surface_metric(raw: object) -> SurfaceMetric:
    if not isinstance(raw, str):
        raise ValidationError("INVALID_ENUM", "métrica precisa ser um identificador textual conhecido.")
    try:
        return SurfaceMetric[raw]
    except KeyError as exc:
        raise ValidationError("INVALID_ENUM", "métrica não é suportada.") from exc


def _check_version(value: dict[str, Any]) -> None:
    version = value["schema_version"]
    if isinstance(version, bool) or not isinstance(version, int) or version != SCHEMA_VERSION:
        raise ValidationError("SCHEMA_VERSION_UNSUPPORTED", f"schema_version aceito: {SCHEMA_VERSION}.")


def _mode_keys(value: dict[str, Any], allowed: set[str], required: set[str]) -> None:
    extra = set(value) - allowed
    missing = required - set(value)
    if extra:
        raise ValidationError("UNKNOWN_FIELD", "Campo inesperado no modo: " + ", ".join(sorted(extra)))
    if missing:
        raise ValidationError("MISSING_FIELD", "Campo obrigatório ausente: " + ", ".join(sorted(missing)))


def _object(raw: object, name: str, allowed: set[str], required: set[str] | None = None) -> dict[str, Any]:
    if not isinstance(raw, dict) or any(not isinstance(key, str) for key in raw):
        raise ValidationError("INVALID_OBJECT", f"{name} precisa ser um objeto JSON.")
    extra = set(raw) - allowed
    missing = (required or set()) - set(raw)
    if extra:
        raise ValidationError("UNKNOWN_FIELD", f"Campo inesperado em {name}: " + ", ".join(sorted(extra)))
    if missing:
        raise ValidationError("MISSING_FIELD", f"Campo obrigatório ausente em {name}: " + ", ".join(sorted(missing)))
    return raw


def _sequence(raw: object, name: str, maximum: int) -> tuple[Any, ...]:
    if not isinstance(raw, (list, tuple)) or isinstance(raw, (str, bytes)):
        raise ValidationError("INVALID_ARRAY", f"{name} precisa ser uma lista JSON.")
    if len(raw) > maximum:
        raise ValidationError("ARRAY_LIMIT", f"{name} excede o limite de {maximum} itens.")
    return tuple(raw)


def _date(raw: object, name: str, *, optional: bool = False) -> date | None:
    if raw is None and optional:
        return None
    if not isinstance(raw, str) or len(raw) != 10:
        raise ValidationError("INVALID_DATE", f"{name} precisa estar no formato AAAA-MM-DD.")
    try:
        parsed = date.fromisoformat(raw)
    except ValueError as exc:
        raise ValidationError("INVALID_DATE", f"{name} não é uma data válida.") from exc
    if parsed.isoformat() != raw:
        raise ValidationError("INVALID_DATE", f"{name} precisa estar normalizada em AAAA-MM-DD.")
    return parsed


def _decimal(raw: object, name: str, *, optional: bool = False) -> Decimal | None:
    if raw is None and optional:
        return None
    if isinstance(raw, bool) or not isinstance(raw, (str, int)):
        raise ValidationError("INVALID_NUMBER_FORMAT", f"{name} deve ser texto decimal ou inteiro exato, nunca ponto flutuante JSON.")
    if isinstance(raw, str) and (not raw or raw.strip() != raw):
        raise ValidationError("INVALID_NUMBER_FORMAT", f"{name} está vazio ou contém espaços externos.")
    return decimal_value(raw, name)


def _text(raw: object, name: str, maximum: int) -> str:
    if not isinstance(raw, str) or not raw.strip() or len(raw) > maximum:
        raise ValidationError("INVALID_TEXT", f"{name} precisa ser texto não vazio de até {maximum} caracteres.")
    return raw.strip()


def _optional_text(raw: object, name: str, maximum: int) -> str | None:
    if raw is None:
        return None
    return _text(raw, name, maximum)


def _boolean(raw: object, name: str) -> bool:
    if not isinstance(raw, bool):
        raise ValidationError("INVALID_BOOLEAN", f"{name} precisa ser verdadeiro ou falso.")
    return raw


def _enum(enum_type: type[StrEnum], raw: object, name: str) -> Any:
    if not isinstance(raw, str):
        raise ValidationError("INVALID_ENUM", f"{name} precisa ser um identificador textual conhecido.")
    try:
        return enum_type(raw)
    except ValueError as exc:
        raise ValidationError("INVALID_ENUM", f"{name} não é suportado.") from exc


def _json_ready(value: Any) -> Any:
    if value is None or isinstance(value, (str, int, bool)):
        return value
    if isinstance(value, Decimal):
        return str(value)
    if isinstance(value, float):
        return value if isfinite(value) else None
    if isinstance(value, (date, datetime)):
        return value.isoformat()
    if isinstance(value, StrEnum):
        return value.value
    if is_dataclass(value):
        return {field.name: _json_ready(getattr(value, field.name)) for field in fields(value)}
    if isinstance(value, dict):
        return {str(key): _json_ready(item) for key, item in value.items()}
    if isinstance(value, (tuple, list)):
        return [_json_ready(item) for item in value]
    raise ValidationError("SERIALIZATION_ERROR", "Resposta contém tipo não previsto no schema HTTP.")
