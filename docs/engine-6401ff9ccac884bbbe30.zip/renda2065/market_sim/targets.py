"""Limites inversos validados pelo mesmo serviço usado na simulação direta."""
from __future__ import annotations

from dataclasses import dataclass, replace
from datetime import date
from decimal import Decimal, ROUND_FLOOR
from enum import StrEnum
from typing import Callable, MutableMapping

from .contracts import Scenario, Side, ValidationError, decimal_value
from .service import EvaluationContext, ScenarioEvaluation, evaluate_scenario

D = Decimal
_MAX_MINIMUM_SEARCH_TICKS = 4096


class TargetMetric(StrEnum):
    NET_REDEMPTION = "NET_REDEMPTION"
    NOMINAL_PROFIT = "NOMINAL_PROFIT"
    NOMINAL_RETURN = "NOMINAL_RETURN"
    REAL_RETURN = "REAL_RETURN"
    ANNUALIZED_NOMINAL_RETURN = "ANNUALIZED_NOMINAL_RETURN"


class TargetStatus(StrEnum):
    SOLVED = "SOLVED"
    UNATTAINABLE = "UNATTAINABLE"
    ALL_DOMAIN = "ALL_DOMAIN"
    METRIC_UNAVAILABLE = "METRIC_UNAVAILABLE"
    BLOCKED_POLICY = "BLOCKED_POLICY"
    VERIFICATION_FAILED = "VERIFICATION_FAILED"
    AMBIGUOUS_ROOT = "AMBIGUOUS_ROOT"
    NO_ROOT = "NO_ROOT"


@dataclass(frozen=True, slots=True)
class TargetDefinition:
    metric: TargetMetric
    minimum_value: Decimal
    unit: str
    target_date: date | None = None

    def __post_init__(self) -> None:
        if not isinstance(self.metric, TargetMetric):
            object.__setattr__(self, "metric", TargetMetric(self.metric))
        value = decimal_value(self.minimum_value, "meta")
        if not self.unit.strip():
            raise ValidationError("INVALID_TARGET", "Meta precisa declarar unidade.")
        expected_unit = {
            TargetMetric.NET_REDEMPTION: "BRL",
            TargetMetric.NOMINAL_PROFIT: "BRL",
            TargetMetric.NOMINAL_RETURN: "ratio",
            TargetMetric.REAL_RETURN: "ratio",
            TargetMetric.ANNUALIZED_NOMINAL_RETURN: "ratio_per_year",
        }[self.metric]
        if self.unit != expected_unit:
            raise ValidationError("INVALID_TARGET_UNIT", f"{self.metric.value} exige unidade {expected_unit}.")
        if self.metric is TargetMetric.REAL_RETURN and self.target_date is None:
            raise ValidationError("INVALID_TARGET_DATE", "Meta real exige data-base declarada.")
        object.__setattr__(self, "minimum_value", value)


@dataclass(frozen=True, slots=True)
class TargetSolution:
    status: TargetStatus
    side: str
    target: TargetDefinition
    pu: Decimal | None
    achieved_value: Decimal | None
    neighbor_pu: Decimal | None
    neighbor_value: Decimal | None
    tick: Decimal
    evaluations: int
    reason: str | None = None


@dataclass(frozen=True, slots=True)
class RateSolution:
    """Fronteira de taxa real que respeita um limite de PU, com bracket auditável."""

    status: TargetStatus
    side: str
    target_pu: Decimal
    rate: Decimal | None
    pu_at_rate: Decimal | None
    adjacent_rate: Decimal | None
    adjacent_pu: Decimal | None
    rate_bracket: tuple[Decimal, Decimal]
    evaluations: int
    reason: str | None = None


@dataclass(frozen=True, slots=True)
class ExitPuCeilingSolution:
    """Greatest discrete SELL PU that stays at or below a metric ceiling."""

    status: TargetStatus
    metric: TargetMetric
    ceiling: Decimal
    pu: Decimal | None
    achieved_value: Decimal | None
    adjacent_pu: Decimal | None
    adjacent_value: Decimal | None
    tick: Decimal
    evaluations: int
    reason: str | None = None


def _metric_value(evaluation: ScenarioEvaluation, target: TargetDefinition) -> Decimal | None:
    operation = evaluation.operation
    if operation is None:
        return None
    return {
        TargetMetric.NET_REDEMPTION: operation.net_redemption,
        TargetMetric.NOMINAL_PROFIT: operation.nominal_profit,
        TargetMetric.NOMINAL_RETURN: operation.nominal_return,
        TargetMetric.REAL_RETURN: operation.real_return,
        TargetMetric.ANNUALIZED_NOMINAL_RETURN: operation.annualized_nominal_return,
    }[target.metric]


def _minimum_comparison_value(
    evaluation: ScenarioEvaluation,
    target: TargetDefinition,
    value: Decimal | None,
    context: EvaluationContext,
) -> Decimal | None:
    if value is not None:
        return value
    operation = evaluation.operation
    if (
        target.metric is TargetMetric.ANNUALIZED_NOMINAL_RETURN
        and target.minimum_value >= 0
        and operation is not None
        and operation.initial_outflow > 0
        and operation.holding_days > 0
        and operation.net_redemption is not None
        and operation.net_redemption <= 0
        and not context.intermediate_paid_costs
    ):
        # With no positive net cash, a nonnegative annualized target cannot
        # be met. Keep the metric unavailable in the result; use this ordering
        # only to continue searching past that economically impossible point.
        return D("-Infinity")
    return None


def _with_exit_pu(scenario: Scenario, pu: Decimal) -> Scenario:
    exit_quote = replace(
        scenario.exit,
        unit_price=pu,
        real_yield=None,
        side=Side.SELL,
        quoted_side=Side.SELL,
        spread=None,
        spread_source=None,
        provenance=None,
    )
    return replace(scenario, exit=exit_quote)


def _with_entry_pu(scenario: Scenario, pu: Decimal) -> Scenario:
    entry_quote = replace(scenario.entry, unit_price=pu, real_yield=None, provenance=None)
    return replace(scenario, entry=entry_quote)


def solve_minimum_exit_pu(
    scenario: Scenario,
    target: TargetDefinition,
    context: EvaluationContext = EvaluationContext(),
    tick: Decimal | str = "0.01",
    maximum_pu: Decimal | str = "1000000000",
    *,
    minimum_pu: Decimal | str | None = None,
    evaluation_cache: MutableMapping[Decimal, ScenarioEvaluation] | None = None,
) -> TargetSolution:
    """Minimum SELL PU, proven only over the declared lower-PU domain."""
    _check_target_date(scenario, target)
    increment = decimal_value(tick, "tick de PU")
    maximum = decimal_value(maximum_pu, "PU máximo")
    if increment <= 0 or maximum < increment:
        raise ValidationError("INVALID_TARGET_DOMAIN", "Tick e domínio de PU inválidos.")
    minimum = increment if minimum_pu is None else decimal_value(minimum_pu, "PU mínimo")
    if minimum <= 0 or minimum / increment != (minimum / increment).to_integral_value():
        raise ValidationError("INVALID_TARGET_DOMAIN", "PU mínimo deve ser positivo e alinhado ao tick.")
    max_ticks = int((maximum / increment).to_integral_value(rounding=ROUND_FLOOR))
    minimum_ticks = int(minimum / increment)
    if minimum_ticks > max_ticks:
        raise ValidationError("INVALID_TARGET_DOMAIN", "PU mínimo excede o PU máximo declarado.")
    domain_ticks = max_ticks - minimum_ticks + 1
    evaluations = 0

    cache: dict[int, tuple[ScenarioEvaluation, Decimal | None]] = {}

    def result_at(ticks: int) -> tuple[ScenarioEvaluation, Decimal | None]:
        nonlocal evaluations
        if ticks in cache:
            return cache[ticks]
        pu = increment * ticks
        evaluation = evaluation_cache.get(pu) if evaluation_cache is not None else None
        if evaluation is None:
            evaluation = evaluate_scenario(_with_exit_pu(scenario, pu), context)
            evaluations += 1
            if evaluation_cache is not None:
                evaluation_cache[pu] = evaluation
        cache[ticks] = (evaluation, _metric_value(evaluation, target))
        return cache[ticks]

    def comparison_at(ticks: int) -> tuple[ScenarioEvaluation, Decimal | None, Decimal | None]:
        evaluation, value = result_at(ticks)
        return evaluation, value, _minimum_comparison_value(evaluation, target, value, context)

    def unavailable() -> TargetSolution:
        return _solution(
            TargetStatus.METRIC_UNAVAILABLE, "SELL_MINIMUM", target,
            None, None, None, None, increment, evaluations,
            "Métrica-alvo indisponível com os insumos informados; a cobertura não pode ser presumida.",
        )

    def blocked() -> TargetSolution:
        return _solution(
            TargetStatus.BLOCKED_POLICY, "SELL_MINIMUM", target,
            None, None, None, None, increment, evaluations,
            "Saída inelegível pela política do produto.",
        )

    def solved_at(ticks: int, previous: tuple[int, ScenarioEvaluation, Decimal | None] | None) -> TargetSolution:
        evaluation, value, ordered = comparison_at(ticks)
        if ordered is None or ordered < target.minimum_value or value is None:
            return _solution(
                TargetStatus.VERIFICATION_FAILED, "SELL_MINIMUM", target,
                increment * ticks, value, None, None, increment, evaluations,
                "O primeiro PU atendido não confirmou diretamente a meta.",
            )
        neighbor_pu = increment * previous[0] if previous is not None else None
        neighbor_value = previous[2] if previous is not None else None
        if neighbor_value is not None and neighbor_value >= target.minimum_value:
            return _solution(
                TargetStatus.VERIFICATION_FAILED, "SELL_MINIMUM", target,
                increment * ticks, value, neighbor_pu, neighbor_value, increment, evaluations,
                "O PU anterior também atende; o mínimo não foi confirmado.",
            )
        return _solution(
            TargetStatus.SOLVED, "SELL_MINIMUM", target,
            increment * ticks, value, neighbor_pu, neighbor_value, increment, evaluations,
            "Primeiro PU que atende na grade totalmente coberta dentro do domínio declarado.",
        )

    # Small declared domains are cheap enough to prove by direct enumeration.
    if domain_ticks <= _MAX_MINIMUM_SEARCH_TICKS:
        previous: tuple[int, ScenarioEvaluation, Decimal | None] | None = None
        for ticks in range(minimum_ticks, max_ticks + 1):
            evaluation, value, ordered = comparison_at(ticks)
            if evaluation.status == "BLOCKED_POLICY":
                return blocked()
            if ordered is None:
                return unavailable()
            if ordered >= target.minimum_value:
                return solved_at(ticks, previous)
            previous = (ticks, evaluation, value)
        return _solution(
            TargetStatus.UNATTAINABLE, "SELL_MINIMUM", target,
            None, None, None, None, increment, evaluations,
            f"Meta não foi atingida após enumerar os {domain_ticks} ticks do domínio PU "
            f"{increment * minimum_ticks} a {increment * max_ticks}.",
        )

    low_eval, low_value, low_ordered = comparison_at(minimum_ticks)
    if low_eval.status == "BLOCKED_POLICY":
        return blocked()
    if low_ordered is None:
        return unavailable()
    if low_ordered >= target.minimum_value:
        return solved_at(minimum_ticks, None)

    high = min(max_ticks, max(minimum_ticks + 1, minimum_ticks * 2))
    high_eval: ScenarioEvaluation | None = None
    high_value: Decimal | None = None
    high_ordered: Decimal | None = None
    while True:
        high_eval, high_value, high_ordered = comparison_at(high)
        if high_eval.status == "BLOCKED_POLICY":
            return blocked()
        if high_ordered is None:
            return unavailable()
        if high_ordered >= target.minimum_value:
            break
        if high == max_ticks:
            return _solution(
                TargetStatus.AMBIGUOUS_ROOT, "SELL_MINIMUM", target,
                None, None, None, None, increment, evaluations,
                "A meta não foi atingida nas amostras e o domínio não foi esgotado; cobertura incompleta.",
            )
        high = min(max_ticks, max(high + 1, high * 2))

    comparable_cache = {
        ticks: (evaluation, _minimum_comparison_value(evaluation, target, value, context))
        for ticks, (evaluation, value) in cache.items()
    }
    if not _monotonic(comparable_cache, increasing=True):
        return _solution(
            TargetStatus.AMBIGUOUS_ROOT, "SELL_MINIMUM", target,
            increment * high, high_value, None, None, increment, evaluations,
            "Candidato atende, mas as amostras não sustentam monotonicidade; mínimo não comprovado.",
        )

    left, right = minimum_ticks, high
    while left < right:
        mid = (left + right) // 2
        evaluation, value, ordered = comparison_at(mid)
        if ordered is None:
            return unavailable()
        if ordered >= target.minimum_value:
            right = mid
        else:
            left = mid + 1
    candidate_eval, achieved, ordered = comparison_at(left)
    if ordered is None:
        return unavailable()
    if ordered < target.minimum_value or achieved is None:
        return _solution(
            TargetStatus.VERIFICATION_FAILED, "SELL_MINIMUM", target,
            increment * left, achieved, None, None, increment, evaluations,
            "Candidato não confirmou diretamente a meta.",
        )

    prefix_ticks = left - minimum_ticks + 1
    if prefix_ticks <= _MAX_MINIMUM_SEARCH_TICKS:
        previous = None
        for ticks in range(minimum_ticks, left + 1):
            evaluation, value, ordered_value = comparison_at(ticks)
            if evaluation.status == "BLOCKED_POLICY":
                return blocked()
            if ordered_value is None:
                return unavailable()
            if ordered_value >= target.minimum_value:
                return solved_at(ticks, previous)
            previous = (ticks, evaluation, value)

    return _solution(
        TargetStatus.AMBIGUOUS_ROOT, "SELL_MINIMUM", target,
        increment * left, achieved, None, None, increment, evaluations,
        f"Candidato atende, mas os {prefix_ticks} ticks inferiores do domínio não foram cobertos; "
        "cobertura incompleta, mínimo não comprovado.",
    )


def solve_maximum_exit_pu(
    scenario: Scenario,
    metric: TargetMetric,
    ceiling: Decimal | str,
    unit: str,
    context: EvaluationContext = EvaluationContext(),
    tick: Decimal | str = "0.01",
    maximum_pu: Decimal | str = "1000000000",
    target_date: date | None = None,
    *,
    minimum_pu: Decimal | str | None = None,
    evaluation_cache: MutableMapping[Decimal, ScenarioEvaluation] | None = None,
) -> ExitPuCeilingSolution:
    """Find the greatest SELL PU that respects a ceiling in the declared domain.

    Small domains are fully evaluated. Larger domains use samples only to find
    a passing candidate, then directly cover its entire higher-PU suffix before
    certifying the maximum. The sample cannot certify a missing or maximal PU.
    """
    target = TargetDefinition(metric, decimal_value(ceiling, "teto do critério"), unit, target_date)
    _check_target_date(scenario, target)
    increment = decimal_value(tick, "tick de PU")
    maximum = decimal_value(maximum_pu, "PU máximo")
    minimum = increment if minimum_pu is None else decimal_value(minimum_pu, "PU mínimo")
    if increment <= 0 or minimum <= 0 or maximum < minimum:
        raise ValidationError("INVALID_TARGET_DOMAIN", "Tick e domínio de PU inválidos.")
    minimum_ratio = minimum / increment
    if minimum_ratio != minimum_ratio.to_integral_value():
        raise ValidationError("INVALID_TARGET_DOMAIN", "PU mínimo deve coincidir com o tick de PU.")
    min_ticks = int(minimum_ratio)
    max_ticks = int((maximum / increment).to_integral_value(rounding=ROUND_FLOOR))
    if min_ticks > max_ticks:
        raise ValidationError("INVALID_TARGET_DOMAIN", "PU mínimo excede o PU máximo declarado.")
    domain_ticks = max_ticks - min_ticks + 1
    cache: dict[int, tuple[ScenarioEvaluation, Decimal | None]] = {}
    evaluations = 0

    def result_at(ticks: int) -> tuple[ScenarioEvaluation, Decimal | None]:
        nonlocal evaluations
        if ticks not in cache:
            pu = increment * ticks
            evaluation = evaluation_cache.get(pu) if evaluation_cache is not None else None
            if evaluation is None:
                evaluation = evaluate_scenario(_with_exit_pu(scenario, pu), context)
                evaluations += 1
                if evaluation_cache is not None:
                    evaluation_cache[pu] = evaluation
            cache[ticks] = (evaluation, _metric_value(evaluation, target))
        return cache[ticks]

    def answer(
        status: TargetStatus,
        *,
        ticks: int | None = None,
        adjacent_ticks: int | None = None,
        reason: str | None = None,
    ) -> ExitPuCeilingSolution:
        value = result_at(ticks)[1] if ticks is not None else None
        adjacent_value = result_at(adjacent_ticks)[1] if adjacent_ticks is not None else None
        return ExitPuCeilingSolution(
            status, metric, target.minimum_value,
            increment * ticks if ticks is not None else None, value,
            increment * adjacent_ticks if adjacent_ticks is not None else None,
            adjacent_value, increment, evaluations, reason,
        )

    def sample_failure() -> TargetStatus | None:
        if any(evaluation.status == "BLOCKED_POLICY" for evaluation, _ in cache.values()):
            return TargetStatus.BLOCKED_POLICY
        if any(value is None for _, value in cache.values()):
            return TargetStatus.METRIC_UNAVAILABLE
        return None

    if domain_ticks <= _MAX_MINIMUM_SEARCH_TICKS:
        passing: list[int] = []
        for ticks in range(min_ticks, max_ticks + 1):
            result_at(ticks)
            failed = sample_failure()
            if failed is TargetStatus.BLOCKED_POLICY:
                return answer(failed, reason="Saída inelegível pela política do produto no domínio declarado.")
            if failed is TargetStatus.METRIC_UNAVAILABLE:
                return answer(failed, reason="Métrica do teto indisponível no domínio declarado.")
            if cache[ticks][1] <= target.minimum_value:
                passing.append(ticks)
        if not passing:
            return answer(
                TargetStatus.UNATTAINABLE,
                reason=f"Teto não atendido após enumerar todos os {domain_ticks} ticks do domínio declarado.",
            )
        if len(passing) == domain_ticks:
            return answer(
                TargetStatus.ALL_DOMAIN, ticks=max_ticks,
                reason="Teto respeitado em todos os ticks diretamente enumerados do domínio declarado.",
            )
        candidate = passing[-1]
        adjacent = candidate + 1 if candidate < max_ticks else None
        return answer(TargetStatus.SOLVED, ticks=candidate, adjacent_ticks=adjacent)

    sample_ticks = {min_ticks, max_ticks}
    for part in range(1, 16):
        sample_ticks.add(min_ticks + ((max_ticks - min_ticks) * part) // 16)
    for ticks in sorted(sample_ticks):
        result_at(ticks)
    failed = sample_failure()
    if failed is TargetStatus.BLOCKED_POLICY:
        return answer(failed, reason="Há um bloqueio de política no domínio de PU examinado.")
    if failed is TargetStatus.METRIC_UNAVAILABLE:
        return answer(failed, reason="Métrica do teto indisponível em parte do domínio examinado.")
    if not _monotonic(cache, increasing=True):
        return answer(
            TargetStatus.AMBIGUOUS_ROOT,
            reason="A métrica não permaneceu não decrescente nas amostras; o teto não foi inferido.",
        )

    maximum_value = cache[max_ticks][1]
    if maximum_value is not None and maximum_value <= target.minimum_value:
        # The declared upper endpoint is directly feasible and is therefore
        # the greatest possible PU, regardless of behavior below it.
        return answer(TargetStatus.SOLVED, ticks=max_ticks)

    sampled_passes = [ticks for ticks in sorted(sample_ticks)
                      if cache[ticks][1] is not None and cache[ticks][1] <= target.minimum_value]
    if not sampled_passes:
        return answer(
            TargetStatus.AMBIGUOUS_ROOT,
            reason="Nenhuma amostra atende ao teto e o domínio não foi esgotado; impossibilidade não comprovada.",
        )
    good = sampled_passes[-1]
    higher_failures = [ticks for ticks in sorted(sample_ticks)
                       if ticks > good and cache[ticks][1] is not None
                       and cache[ticks][1] > target.minimum_value]
    if not higher_failures:
        return answer(
            TargetStatus.AMBIGUOUS_ROOT, ticks=good,
            reason="Há candidato amostrado, mas o limite superior do domínio não pôde ser excluído.",
        )
    bad = higher_failures[0]
    while bad - good > 1:
        middle = (good + bad) // 2
        result_at(middle)
        failed = sample_failure()
        if failed is TargetStatus.BLOCKED_POLICY:
            return answer(failed, reason="Saída inelegível pela política durante o bracket do teto.")
        if failed is TargetStatus.METRIC_UNAVAILABLE:
            return answer(failed, reason="Métrica do teto indisponível durante o bracket.")
        if cache[middle][1] <= target.minimum_value:
            good = middle
        else:
            bad = middle

    result_at(good)
    result_at(good + 1)
    if cache[good][1] is None or cache[good][1] > target.minimum_value:
        return answer(TargetStatus.VERIFICATION_FAILED, ticks=good,
                      adjacent_ticks=good + 1, reason="Candidato não confirmou o teto diretamente.")
    suffix_ticks = max_ticks - good
    if suffix_ticks > _MAX_MINIMUM_SEARCH_TICKS:
        return answer(
            TargetStatus.AMBIGUOUS_ROOT, ticks=good, adjacent_ticks=good + 1,
            reason=(f"Candidato atende, mas os {suffix_ticks} ticks do sufixo até o PU máximo "
                    "não foram cobertos; máximo não comprovado."),
        )

    greatest = good
    for ticks in range(good + 1, max_ticks + 1):
        result_at(ticks)
        failed = sample_failure()
        if failed is TargetStatus.BLOCKED_POLICY:
            return answer(failed, reason="Saída inelegível pela política durante a prova do sufixo.")
        if failed is TargetStatus.METRIC_UNAVAILABLE:
            return answer(failed, reason="Métrica do teto indisponível durante a prova do sufixo.")
        if cache[ticks][1] <= target.minimum_value:
            greatest = ticks
    adjacent = greatest + 1 if greatest < max_ticks else None
    return answer(TargetStatus.SOLVED, ticks=greatest, adjacent_ticks=adjacent)


def solve_maximum_entry_pu(
    scenario: Scenario,
    target: TargetDefinition,
    context: EvaluationContext = EvaluationContext(),
    tick: Decimal | str = "0.01",
    maximum_pu: Decimal | str = "1000000000",
    minimum_pu: Decimal | str = "0.01",
    *,
    evaluation_cache: MutableMapping[Decimal, ScenarioEvaluation] | None = None,
    evaluate_at_pu: Callable[[Decimal], ScenarioEvaluation] | None = None,
) -> TargetSolution:
    """Greatest entry PU meeting a floor within a declared PU domain.

    Small domains are directly enumerated. For larger domains, samples locate
    a candidate but the complete higher-PU suffix must be checked before a
    maximum is certified.
    """
    _check_target_date(scenario, target)
    increment = decimal_value(tick, "tick de PU")
    maximum = decimal_value(maximum_pu, "PU máximo")
    minimum = decimal_value(minimum_pu, "PU mínimo")
    if increment <= 0 or minimum <= 0 or maximum < minimum:
        raise ValidationError("INVALID_TARGET_DOMAIN", "Tick e domínio de PU inválidos.")
    min_ratio, max_ratio = minimum / increment, maximum / increment
    if min_ratio != min_ratio.to_integral_value() or max_ratio != max_ratio.to_integral_value():
        raise ValidationError("INVALID_TARGET_DOMAIN", "Limites do domínio precisam coincidir com o tick de PU.")
    min_ticks, max_ticks = int(min_ratio), int(max_ratio)
    domain_ticks = max_ticks - min_ticks + 1
    evaluations = 0
    cache: dict[int, tuple[ScenarioEvaluation, Decimal | None]] = {}

    def result_at(ticks: int) -> tuple[ScenarioEvaluation, Decimal | None]:
        nonlocal evaluations
        if ticks not in cache:
            pu = increment * ticks
            evaluation = evaluation_cache.get(pu) if evaluation_cache is not None else None
            if evaluation is None:
                evaluation = (
                    evaluate_at_pu(pu) if evaluate_at_pu is not None
                    else evaluate_scenario(_with_entry_pu(scenario, pu), context)
                )
                evaluations += 1
                if evaluation_cache is not None:
                    evaluation_cache[pu] = evaluation
            cache[ticks] = (evaluation, _metric_value(evaluation, target))
        return cache[ticks]

    def unavailable_status() -> TargetStatus | None:
        if any(evaluation.status == "BLOCKED_POLICY" for evaluation, _ in cache.values()):
            return TargetStatus.BLOCKED_POLICY
        if any(value is None for _, value in cache.values()):
            return TargetStatus.METRIC_UNAVAILABLE
        return None

    if domain_ticks <= _MAX_MINIMUM_SEARCH_TICKS:
        passing: list[int] = []
        for ticks in range(min_ticks, max_ticks + 1):
            result_at(ticks)
            failed = unavailable_status()
            if failed is TargetStatus.BLOCKED_POLICY:
                return _solution(failed, "BUY_MAXIMUM", target, None, None, None, None,
                                 increment, evaluations, "Política bloqueou candidato no domínio declarado.")
            if failed is TargetStatus.METRIC_UNAVAILABLE:
                return _solution(failed, "BUY_MAXIMUM", target, None, None, None, None,
                                 increment, evaluations, "Métrica-alvo indisponível no domínio declarado.")
            if cache[ticks][1] >= target.minimum_value:
                passing.append(ticks)
        if not passing:
            return _solution(TargetStatus.UNATTAINABLE, "BUY_MAXIMUM", target, None, None,
                             None, None, increment, evaluations,
                             f"Meta não atendida após enumerar todos os {domain_ticks} ticks do domínio declarado.")
        if len(passing) == domain_ticks:
            return _solution(TargetStatus.ALL_DOMAIN, "BUY_MAXIMUM", target, None,
                             cache[max_ticks][1], None, None, increment, evaluations,
                             "Meta atendida em todos os ticks diretamente enumerados do domínio declarado.")
        candidate = passing[-1]
        adjacent = candidate + 1 if candidate < max_ticks else None
        adjacent_value = cache[adjacent][1] if adjacent is not None else None
        return _solution(TargetStatus.SOLVED, "BUY_MAXIMUM", target,
                         increment * candidate, cache[candidate][1],
                         increment * adjacent if adjacent is not None else None,
                         adjacent_value, increment, evaluations)

    sample_ticks = {min_ticks, max_ticks}
    for part in range(1, 4):
        sample_ticks.add(min_ticks + ((max_ticks - min_ticks) * part) // 4)
    for ticks in sorted(sample_ticks):
        result_at(ticks)
    failed = unavailable_status()
    if failed is TargetStatus.BLOCKED_POLICY:
        return _solution(failed, "BUY_MAXIMUM", target, None, None, None, None,
                         increment, evaluations, "Política bloqueou candidato no domínio examinado.")
    if failed is TargetStatus.METRIC_UNAVAILABLE:
        return _solution(failed, "BUY_MAXIMUM", target, None, None, None, None,
                         increment, evaluations, "Métrica-alvo indisponível em ponto amostrado.")

    increasing = target.metric is TargetMetric.NET_REDEMPTION
    if not _monotonic(cache, increasing=increasing):
        return _solution(TargetStatus.AMBIGUOUS_ROOT, "BUY_MAXIMUM", target,
                         None, None, None, None, increment, evaluations,
                         "A métrica não permaneceu monotônica nas amostras; limite não inferido.")

    high_value = cache[max_ticks][1]
    if high_value is not None and high_value >= target.minimum_value:
        # The declared upper endpoint is directly feasible and is the greatest
        # possible PU, even if points below it are not fully characterized.
        return _solution(TargetStatus.SOLVED, "BUY_MAXIMUM", target,
                         increment * max_ticks, high_value, None, None,
                         increment, evaluations,
                         "O PU máximo declarado atende diretamente à meta.")

    sampled_passes = [ticks for ticks in sorted(sample_ticks)
                      if cache[ticks][1] is not None and cache[ticks][1] >= target.minimum_value]
    if not sampled_passes:
        return _solution(TargetStatus.AMBIGUOUS_ROOT, "BUY_MAXIMUM", target,
                         None, None, None, None, increment, evaluations,
                         "Nenhuma amostra atende à meta e o domínio não foi esgotado; impossibilidade não comprovada.")
    good = sampled_passes[-1]
    higher_failures = [ticks for ticks in sorted(sample_ticks)
                       if ticks > good and cache[ticks][1] is not None
                       and cache[ticks][1] < target.minimum_value]
    if not higher_failures:
        return _solution(TargetStatus.AMBIGUOUS_ROOT, "BUY_MAXIMUM", target,
                         increment * good, cache[good][1], None, None,
                         increment, evaluations, "Candidato amostrado sem limite superior excluído.")
    bad = higher_failures[0]
    while bad - good > 1:
        middle = (good + bad) // 2
        result_at(middle)
        failed = unavailable_status()
        if failed is TargetStatus.BLOCKED_POLICY:
            return _solution(failed, "BUY_MAXIMUM", target, None, None, None, None,
                             increment, evaluations, "Política bloqueou candidato durante o bracket.")
        if failed is TargetStatus.METRIC_UNAVAILABLE:
            return _solution(failed, "BUY_MAXIMUM", target, None, None, None, None,
                             increment, evaluations, "Métrica-alvo indisponível durante o bracket.")
        if cache[middle][1] >= target.minimum_value:
            good = middle
        else:
            bad = middle

    candidate_value = result_at(good)[1]
    adjacent_value = result_at(good + 1)[1]
    suffix_ticks = max_ticks - good
    if suffix_ticks > _MAX_MINIMUM_SEARCH_TICKS:
        return _solution(TargetStatus.AMBIGUOUS_ROOT, "BUY_MAXIMUM", target,
                         increment * good, candidate_value, increment * (good + 1), adjacent_value,
                         increment, evaluations,
                         f"Candidato atende, mas os {suffix_ticks} ticks do sufixo até o PU máximo não foram cobertos.")

    greatest = good
    for ticks in range(good + 1, max_ticks + 1):
        result_at(ticks)
        failed = unavailable_status()
        if failed is TargetStatus.BLOCKED_POLICY:
            return _solution(failed, "BUY_MAXIMUM", target, None, None, None, None,
                             increment, evaluations, "Política bloqueou candidato durante prova do sufixo.")
        if failed is TargetStatus.METRIC_UNAVAILABLE:
            return _solution(failed, "BUY_MAXIMUM", target, None, None, None, None,
                             increment, evaluations, "Métrica-alvo indisponível durante prova do sufixo.")
        if cache[ticks][1] >= target.minimum_value:
            greatest = ticks
    adjacent = greatest + 1 if greatest < max_ticks else None
    return _solution(TargetStatus.SOLVED, "BUY_MAXIMUM", target,
                     increment * greatest, cache[greatest][1],
                     increment * adjacent if adjacent is not None else None,
                     cache[adjacent][1] if adjacent is not None else None,
                     increment, evaluations)


def _check_target_date(scenario: Scenario, target: TargetDefinition) -> None:
    if target.metric is TargetMetric.REAL_RETURN and target.target_date != scenario.exit.settlement_date:
        raise ValidationError("INVALID_TARGET_DATE", "Meta de retorno real deve usar a data de liquidação da saída.")


def _monotonic(cache: dict[int, tuple[ScenarioEvaluation, Decimal | None]], *, increasing: bool) -> bool:
    values = [evaluation_value for _, (_, evaluation_value) in sorted(cache.items())]
    if any(value is None for value in values):
        return False
    return all(
        left <= right if increasing else left >= right
        for left, right in zip(values, values[1:])
    )


def solve_rate_for_pu_limit(
    scenario: Scenario,
    side: str,
    target_pu: Decimal | str,
    context: EvaluationContext,
    *,
    minimum_yield: Decimal | str,
    maximum_yield: Decimal | str,
    tolerance: Decimal | str = "0.000000001",
    rate_step: Decimal | str | None = None,
) -> RateSolution:
    """Converte PU máximo de compra/mínimo de venda em fronteira de taxa.

    A saída é sempre reprecificada pelo serviço direto. O bracket devolvido
    preserva os lados satisfatório e insatisfatório, inclusive quando o perfil
    publicado cria degraus de PU; não presume raiz contínua única.
    """
    if side not in ("ENTRY", "EXIT"):
        raise ValidationError("INVALID_RATE_SIDE", "Lado deve ser ENTRY ou EXIT.")
    if side == "EXIT" and (scenario.exit.side is not Side.SELL or scenario.exit.quoted_side is not Side.SELL):
        raise ValidationError("RATE_SIDE_UNSUPPORTED", "Taxa de limite de saída exige PU SELL; BASE e spread BUY não são invertidos.")
    target = decimal_value(target_pu, "PU limite")
    lower = decimal_value(minimum_yield, "taxa mínima")
    upper = decimal_value(maximum_yield, "taxa máxima")
    epsilon = decimal_value(tolerance, "tolerância de taxa")
    if target <= 0 or lower <= -1 or upper <= lower or epsilon <= 0:
        raise ValidationError("INVALID_RATE_DOMAIN", "PU deve ser positivo; domínio de taxa e tolerância são inválidos.")

    from .contracts import ProductFamily
    from .renda_plus import MAX_YIELD, MIN_YIELD
    if scenario.instrument.family is ProductFamily.RENDA_PLUS and (lower < MIN_YIELD or upper > MAX_YIELD):
        raise ValidationError("INVALID_RATE_DOMAIN", "RendA+ aceita taxa entre −95% e 1.000% a.a.")

    cache: dict[Decimal, tuple[ScenarioEvaluation, Decimal | None]] = {}

    def result_at(rate: Decimal) -> tuple[ScenarioEvaluation, Decimal | None]:
        if rate in cache:
            return cache[rate]
        if side == "ENTRY":
            quote = replace(scenario.entry, unit_price=None, real_yield=rate, provenance=None)
            candidate = replace(scenario, entry=quote)
        else:
            quote = replace(scenario.exit, unit_price=None, real_yield=rate, provenance=None)
            candidate = replace(scenario, exit=quote)
        evaluated = evaluate_scenario(candidate, context)
        cache[rate] = (evaluated, evaluated.entry_pu if side == "ENTRY" else evaluated.exit_pu)
        return cache[rate]

    low_eval, low_pu = result_at(lower)
    high_eval, high_pu = result_at(upper)
    if low_pu is None or high_pu is None:
        return RateSolution(TargetStatus.METRIC_UNAVAILABLE, side, target, None, None, None, None,
                            (lower, upper), len(cache), "Âncora, calendário ou preço teórico indisponível no domínio declarado.")
    if high_pu > low_pu:
        return RateSolution(TargetStatus.AMBIGUOUS_ROOT, side, target, None, None, None, None,
                            (lower, upper), len(cache), "PU aumentou com a taxa nos extremos; monotonicidade não foi confirmada.")
    if rate_step is None:
        samples = (lower + (upper - lower) * D(sample) / D(16) for sample in range(1, 16))
    else:
        increment = decimal_value(rate_step, "passo da taxa")
        intervals = (upper - lower) / increment if increment > 0 else D(0)
        if increment <= 0 or intervals != intervals.to_integral_value():
            raise ValidationError("INVALID_RATE_DOMAIN", "O passo precisa ser positivo e alinhar os extremos do domínio de taxa.")
        if intervals + 1 > 101:
            raise ValidationError("INVALID_RATE_DOMAIN", "O domínio de taxa pode conter no máximo 101 pontos de verificação.")
        samples = (lower + increment * index for index in range(1, int(intervals)))
    for rate in samples:
        result_at(rate)
    ordered_pus = [value[1] for _, value in sorted(cache.items())]
    if any(value is None for value in ordered_pus) or any(
        left < right for left, right in zip(ordered_pus, ordered_pus[1:])
    ):
        return RateSolution(TargetStatus.AMBIGUOUS_ROOT, side, target, None, None, None, None,
                            (lower, upper), len(cache), "PU não permaneceu monotônico na amostra do domínio; inversão interrompida.")

    # ENTRY: PU <= limite torna-se viável quando a taxa sobe.
    # EXIT: PU >= limite deixa de ser viável quando a taxa sobe.
    feasible = (lambda pu: pu <= target) if side == "ENTRY" else (lambda pu: pu >= target)
    if side == "ENTRY":
        if feasible(low_pu):
            return RateSolution(TargetStatus.ALL_DOMAIN, side, target, lower, low_pu, None, None,
                                (lower, upper), len(cache), "Todo o domínio avaliado respeita o PU máximo de entrada.")
        if not feasible(high_pu):
            return RateSolution(TargetStatus.NO_ROOT, side, target, None, None, None, None,
                                (lower, upper), len(cache), "PU máximo não é atingido no domínio de taxa declarado.")
        bad, good = lower, upper  # inviável à esquerda, viável à direita
        while good - bad > epsilon:
            mid = (bad + good) / 2
            _, mid_pu = result_at(mid)
            if mid_pu is None:
                return RateSolution(TargetStatus.METRIC_UNAVAILABLE, side, target, None, None, None, None,
                                    (bad, good), len(cache), "Preço ficou indisponível dentro do bracket.")
            if feasible(mid_pu):
                good = mid
            else:
                bad = mid
        candidate_rate, adjacent_rate = good, bad
    else:
        if not feasible(low_pu):
            return RateSolution(TargetStatus.NO_ROOT, side, target, None, None, None, None,
                                (lower, upper), len(cache), "PU mínimo de venda não é atingido no domínio de taxa declarado.")
        if feasible(high_pu):
            return RateSolution(TargetStatus.ALL_DOMAIN, side, target, upper, high_pu, None, None,
                                (lower, upper), len(cache), "Todo o domínio avaliado respeita o PU mínimo de venda.")
        good, bad = lower, upper  # viável à esquerda, inviável à direita
        while bad - good > epsilon:
            mid = (good + bad) / 2
            _, mid_pu = result_at(mid)
            if mid_pu is None:
                return RateSolution(TargetStatus.METRIC_UNAVAILABLE, side, target, None, None, None, None,
                                    (good, bad), len(cache), "Preço ficou indisponível dentro do bracket.")
            if feasible(mid_pu):
                good = mid
            else:
                bad = mid
        candidate_rate, adjacent_rate = good, bad
    _, candidate_pu = result_at(candidate_rate)
    _, adjacent_pu = result_at(adjacent_rate)
    if candidate_pu is None or adjacent_pu is None or not feasible(candidate_pu) or feasible(adjacent_pu):
        return RateSolution(TargetStatus.VERIFICATION_FAILED, side, target, candidate_rate, candidate_pu,
                            adjacent_rate, adjacent_pu, (min(candidate_rate, adjacent_rate), max(candidate_rate, adjacent_rate)), len(cache),
                            "Reprecificação não confirmou lados opostos do limite.")
    return RateSolution(TargetStatus.SOLVED, side, target, candidate_rate, candidate_pu, adjacent_rate,
                        adjacent_pu, (min(candidate_rate, adjacent_rate), max(candidate_rate, adjacent_rate)), len(cache))


def _solution(status: TargetStatus, side: str, target: TargetDefinition, pu: Decimal | None,
              achieved: Decimal | None, neighbor: Decimal | None, neighbor_value: Decimal | None,
              tick: Decimal, evaluations: int, reason: str | None = None) -> TargetSolution:
    return TargetSolution(status, side, target, pu, achieved, neighbor, neighbor_value, tick, evaluations, reason)
