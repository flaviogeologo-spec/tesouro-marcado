"""Bounded presentation snapshots for the single-screen workspace; no pricing math."""
from copy import deepcopy

METRICS = ('net_redemption', 'nominal_profit', 'nominal_return', 'real_return')
MAX_DATES = 2048


def snapshot_size_limit(view):
    """Bound larger caches to the explicitly validated dense grid."""
    density = (view.get('single_screen') or {}).get('date_density', 15)
    return 32 * 1024 * 1024 if density == MAX_DATES else 2 * 1024 * 1024 if density > 15 else 224 * 1024


def merge_overlay_support(responses, dates):
    rows = {row['order_date']: row for response in responses
            for row in (response.get('result') or {}).get('overlay_support', [])}
    selected = sorted(set(dates) & rows.keys())
    if len(selected) > 121:
        selected = [selected[i * (len(selected) - 1) // 120] for i in range(121)]
    selected = set(selected)
    extra = sorted(rows.keys() - selected)
    room = 121 - len(selected)
    if len(extra) > room:
        extra = [extra[i * (len(extra) - 1) // max(1, room - 1)] for i in range(room)]
    return [deepcopy(rows[day]) for day in sorted(selected | set(extra))]


def compact_surface(response, *, packed=False, include_basis=True, include_support=True):
    """Keep engine decimals and coverage, without the large resolution/IPCA payload."""
    result = response.get('result') or {}
    points, reasons = [], []
    for source in result.get('points', []):
        point = {key: deepcopy(source.get(key)) for key in (
            'identity', 'order_date', 'settlement_date', 'coordinate', 'value', 'status', 'quality', 'reason')}
        if point['reason'] is not None:
            if point['reason'] not in reasons:
                reasons.append(point['reason'])
            point['reason'] = reasons.index(point['reason'])
        point['metrics'] = {metric: {key: source.get('metrics', {}).get(metric, {}).get(key)
                                    for key in ('value', 'status')} for metric in METRICS}
        if include_basis and 'conversion_basis' in source:
            point['conversion_basis'] = deepcopy(source['conversion_basis'])
        points.append(point)
    compact = {'points': points, 'reasons': reasons, 'coverage': deepcopy(response.get('coverage') or {}),
            'source_versions': deepcopy(response.get('source_versions') or {}),
            'engine_manifest': deepcopy(response.get('engine_manifest') or {})}
    if include_support and 'overlay_support' in result:
        compact['overlay_support'] = deepcopy(result['overlay_support'])
    if not packed:
        return compact
    result = {key: compact[key] for key in ('reasons', 'coverage', 'source_versions', 'engine_manifest')}
    if 'overlay_support' in compact:
        result['overlay_support'] = pack_overlay_support(compact['overlay_support'])
    result.update(encoding='grid-v2', dates=[], settlements=[], rates=[], statuses=[], qualities=[], metric_statuses=[], rows=[])

    def index(key, value):
        if value not in result[key]:
            result[key].append(value)
        return result[key].index(value)

    with_basis = any('conversion_basis' in point for point in points)
    if with_basis:
        result['conversion_bases'] = []
    for point in points:
        result['rows'].append([index('dates', point['order_date']), index('settlements', point['settlement_date']),
                               index('rates', point['coordinate']['value']), index('statuses', point['status']),
                               index('qualities', point['quality']), point['reason'],
                               *[point['metrics'][metric]['value'] for metric in METRICS],
                               [index('metric_statuses', point['metrics'][metric]['status']) for metric in METRICS]])
        if with_basis:
            result['rows'][-1].append(index('conversion_bases', point.get('conversion_basis')))
    return result


def unpack_surface(cache):
    if cache is None:
        return {'points': [], 'reasons': [], 'coverage': {}}
    if cache.get('encoding') != 'grid-v2':
        return cache
    points = []
    for row in cache['rows']:
        points.append({'identity': cache['dates'][row[0]] + '|' + cache['rates'][row[2]],
                       'order_date': cache['dates'][row[0]], 'settlement_date': cache['settlements'][row[1]],
                       'coordinate': {'value': cache['rates'][row[2]], 'unit': 'ratio'}, 'value': row[6],
                       'status': cache['statuses'][row[3]], 'quality': cache['qualities'][row[4]], 'reason': row[5],
                       'metrics': {metric: {'value': row[6 + index], 'status': cache['metric_statuses'][row[10][index]]}
                                   for index, metric in enumerate(METRICS)}})
        if 'conversion_bases' in cache:
            points[-1]['conversion_basis'] = deepcopy(cache['conversion_bases'][row[11]])
    return {**cache, 'points': points, **({'overlay_support': unpack_overlay_support(cache['overlay_support'])} if 'overlay_support' in cache else {})}


def calculate_surface(service, input_value, surface):
    """Preserve explicit axes with bounded 15-date by 15-rate engine batches."""
    from decimal import Decimal
    responses = []
    for date_start in range(0, len(surface['order_dates']), 15):
        dates = surface['order_dates'][date_start:date_start + 15]
        for start in range(0, len(surface['values']), 15):
            values = surface['values'][start:start + 15]
            batch = {**surface, 'order_dates': dates, 'values': values, 'selected': {'order_date': dates[0], 'value': values[0]}}
            responses.append(service.simulator_workspace({'schema_version': 2, 'action': 'SURFACE', 'request_id': 'snapshot-single-screen',
                                                         'revision': 1, 'input': input_value, 'surface': batch}))
    if len(responses) == 1:
        return responses[0]
    for response in responses:
        if not (response.get('result') or {}).get('points'):
            return response
    merged = deepcopy(responses[0])
    merged['result']['points'] = sorted([point for response in responses for point in (response.get('result') or {}).get('points', [])],
                                       key=lambda point: (point['order_date'], Decimal(point['coordinate']['value'])))
    coverage = merged['coverage']
    for key in ('evaluated_points', 'new_evaluations', 'reused_points', 'requested_points', 'resolved_points'):
        coverage[key] = sum(response['coverage'].get(key, 0) for response in responses)
    coverage['complete'] = all(response['coverage'].get('complete') for response in responses)
    coverage['status'] = 'complete' if coverage['complete'] else 'partial'
    coverage['method'], coverage['batch_count'], coverage['omitted_values'] = 'explicit_rate_batches', len(responses), []
    coverage['domain']['candidate_values'] = deepcopy(surface['values'])
    coverage['domain']['sampled_values'] = deepcopy(surface['values'])
    coverage['resolution']['values'] = len(surface['values'])
    if len(surface['order_dates']) > 15:
        coverage['method'] = 'explicit_grid_batches'
        coverage['domain']['candidate_order_dates'] = deepcopy(surface['order_dates'])
        coverage['domain']['sampled_order_dates'] = deepcopy(surface['order_dates'])
        coverage['domain']['date_range'] = {'start': surface['order_dates'][0], 'end': surface['order_dates'][-1]}
        coverage['resolution']['dates'] = len(surface['order_dates'])
        coverage['omitted_dates'], coverage['omitted_ranges'] = [], []
    support = merge_overlay_support(responses, surface['order_dates'])
    if support:
        merged['result']['overlay_support'] = support
    return merged


def validate_snapshot_view(raw, input_value, comparison_input=None, *, _comparison_member=False):
    from .market_sim.api import _object, _date, _decimal, _text, _json_ready, workspace_request
    from .market_sim.contracts import ValidationError

    view = _object(raw, 'view.single_screen', {
        'version', 'period', 'surface', 'overview_surface', 'metric', 'reading_date', 'result', 'overview_result',
        'divisions', 'overview_divisions', 'visibility', 'overlays', 'comparison', 'table', 'fit_overlays', 'overlay_fill', 'date_density', 'aligned_dates', 'date_step_days', 'overview_date_step_days', 'converged_dates', 'outside_period', 'outside_original', 'outside_reason', 'legend_hidden', 'chart_controls',
    }, {'version', 'period', 'surface', 'overview_surface', 'metric'})
    if type(view['version']) is not int or view['version'] not in (1, 2):
        raise ValidationError('INVALID_SNAPSHOT_VIEW', 'Versão da tela única não reconhecida.')
    version = view['version']
    if any(key in view and type(view[key]) is not bool for key in ('outside_period', 'outside_original')):
        raise ValidationError('INVALID_SNAPSHOT_VIEW', 'Estado fora do período inválido.')
    outside = view.get('outside_period', False)
    outside_original = view.get('outside_original', False)
    if outside_original and (not outside or view.get('overview_result') is not None):
        raise ValidationError('INVALID_SNAPSHOT_VIEW', 'Produto fora do período original não pode conter resultados ou visão geral calculada.')
    if 'outside_reason' in view and (not outside or view['outside_reason'] not in ('MATURITY', 'INCOME', 'LOCKUP', 'SETTLEMENT', 'NO_SESSION')):
        raise ValidationError('INVALID_SNAPSHOT_VIEW', 'Motivo de ausência do produto inválido.')
    if outside and (version != 2 or view.get('result') is not None or not (outside_original or view.get('overview_result'))
                    or not (_comparison_member or view.get('comparison'))):
        raise ValidationError('INVALID_SNAPSHOT_VIEW', 'Produto fora do trecho exige comparação e visão geral preservada, sem resultado ativo.')
    density = view.get('date_density', 15)
    if type(density) is not int or density not in (15, 31, 61, MAX_DATES) or (version == 1 and density != 15):
        raise ValidationError('INVALID_SNAPSHOT_VIEW', 'Resolução temporal inválida.')
    if density == MAX_DATES or any(key in view for key in ('date_step_days', 'overview_date_step_days', 'converged_dates')):
        if (density != MAX_DATES or version != 2
                or any(type(view.get(key)) is not int or not 1 <= view[key] <= 15 for key in ('date_step_days', 'overview_date_step_days'))
                or type(view.get('converged_dates')) is not bool or view.get('aligned_dates')):
            raise ValidationError('INVALID_SNAPSHOT_VIEW', 'Cadência ou convergência temporal inválida.')
    if 'aligned_dates' in view and type(view['aligned_dates']) is not bool:
        raise ValidationError('INVALID_SNAPSHOT_VIEW', 'Alinhamento temporal inválido.')
    point_limit = density * (10 if version == 1 else 22)
    if 'fit_overlays' in view and type(view['fit_overlays']) is not bool:
        raise ValidationError('INVALID_SNAPSHOT_VIEW', 'Ajuste de escala inválido.')
    if 'chart_controls' in view:
        controls = _object(view['chart_controls'], 'single_screen.chart_controls', {'view', 'rate', 'date', 'context'}, {'view', 'rate', 'date', 'context'})
        if controls['view'] not in ('overlay', 'separate') or type(controls['context']) is not bool:
            raise ValidationError('INVALID_SNAPSHOT_VIEW', 'Controles do gráfico inválidos.')
        if controls['rate'] is not None:
            _decimal(controls['rate'], 'single_screen.chart_controls.rate')
        if controls['date'] is not None:
            _date(controls['date'], 'single_screen.chart_controls.date')
    if 'overlay_fill' in view:
        fill = _object(view['overlay_fill'], 'single_screen.overlay_fill', {'goal', 'reference'}, {'goal', 'reference'})
        if any(type(value) is not bool for value in fill.values()):
            raise ValidationError('INVALID_SNAPSHOT_VIEW', 'Hachura das referências inválida.')
    if 'table' in view:
        table = _object(view['table'], 'single_screen.table', {'metrics', 'hidden_rates'}, {'metrics', 'hidden_rates'})
        metrics, rates = table['metrics'], table['hidden_rates']
        if (not isinstance(metrics, list) or len(metrics) > len(METRICS)
                or any(not isinstance(metric, str) or metric not in METRICS for metric in metrics)
                or len(set(metrics)) != len(metrics) or not isinstance(rates, list) or len(rates) > 44):
            raise ValidationError('INVALID_SNAPSHOT_VIEW', 'Seleção de colunas inválida.')
        for rate in rates:
            _decimal(rate, 'table.hidden_rates')
    for key in ('divisions', 'overview_divisions'):
        if key in view and (type(view[key]) is not int or not 1 <= view[key] <= 20):
            raise ValidationError('INVALID_SNAPSHOT_VIEW', 'Informe de 1 a 20 divisões.')
    if 'visibility' in view:
        visible = _object(view['visibility'], 'single_screen.visibility', {'a', 'b'}, {'a', 'b'})
        if any(type(value) is not bool for value in visible.values()):
            raise ValidationError('INVALID_SNAPSHOT_VIEW', 'Visibilidade inválida.')
    if 'overlays' in view:
        overlays = _object(view['overlays'], 'single_screen.overlays', {'goal', 'reference'}, {'goal', 'reference'})
        for kind, raw_overlay in overlays.items():
            if raw_overlay is None:
                continue
            allowed = {'metric', 'value'} if kind == 'goal' else {'mode', 'value'}
            overlay = _object(raw_overlay, 'single_screen.' + kind, allowed, allowed)
            value = _decimal(overlay['value'], 'overlay.value')
            if kind == 'goal' and (overlay['metric'] not in METRICS or value < 0):
                raise ValidationError('INVALID_SNAPSHOT_VIEW', 'Meta mínima inválida.')
            if kind == 'reference' and (overlay['mode'] not in ('PERCENT', 'NOMINAL') or (overlay['mode'] == 'PERCENT' and value <= -1)):
                raise ValidationError('INVALID_SNAPSHOT_VIEW', 'Referência anual inválida.')
    timeline = (input_value.get('analysis_context') or {}).get('timeline') or {}
    if timeline.get('mode') != 'WINDOW':
        raise ValidationError('INVALID_SNAPSHOT_VIEW', 'Tela única exige uma operação por período.')
    start, end = _date(timeline.get('start'), 'timeline.start'), _date(timeline.get('end'), 'timeline.end')
    period = _object(view['period'], 'single_screen.period', {'start', 'end'}, {'start', 'end'})
    first, last = _date(period['start'], 'period.start'), _date(period['end'], 'period.end')
    if not start <= first <= last <= end:
        raise ValidationError('INVALID_SNAPSHOT_VIEW', 'O trecho precisa ficar dentro do período original.')
    if outside and not outside_original and first == start and last == end:
        raise ValidationError('INVALID_SNAPSHOT_VIEW', 'Estado fora do trecho exige um detalhamento.')
    if view['metric'] not in METRICS:
        raise ValidationError('INVALID_SNAPSHOT_VIEW', 'Medida da tela única não reconhecida.')

    def surface(raw_surface, period_start, period_end):
        checked = workspace_request({'schema_version': 2, 'action': 'SURFACE', 'request_id': 'single-screen-validation',
                                     'revision': 1, 'input': input_value, 'surface': raw_surface})['surface']
        dates, values = checked['order_dates'], checked['values']
        if (checked['mode'] != 'RATE_DATE_MAP' or checked['metric_id'] != 'net_redemption'
                or checked['value_unit'] != 'ratio' or not dates or len(dates) > density
                or not values or len(values) > (10 if version == 1 else 22)
                or any(day < period_start or day > period_end for day in dates)
                or checked['selected_order_date'] not in dates or checked['selected_value'] not in values):
            raise ValidationError('INVALID_SNAPSHOT_VIEW', 'Grade da tela única incompatível com o período ou limite de pontos.')
        return {'mode': 'RATE_DATE_MAP', 'metric_id': 'net_redemption', 'value_unit': 'ratio',
                'order_dates': [day.isoformat() for day in dates], 'values': [str(value) for value in values],
                'selected': {'order_date': checked['selected_order_date'].isoformat(), 'value': str(checked['selected_value'])}}

    view = deepcopy(view)
    def empty_surface(raw_surface):
        active = _object(raw_surface, 'single_screen.surface', {'mode', 'metric_id', 'value_unit', 'order_dates', 'values', 'selected'},
                         {'mode', 'metric_id', 'value_unit', 'order_dates', 'values', 'selected'})
        if active['order_dates'] != [] or active['selected'] is not None or not isinstance(active['values'], list) or not active['values']:
            raise ValidationError('INVALID_SNAPSHOT_VIEW', 'Produto fora do trecho não pode conter datas ou seleção ativa.')
        day = start.isoformat()
        checked = surface({**active, 'order_dates': [day], 'selected': {'order_date': day, 'value': (active['values'] or [None])[0]}}, start, end)
        return {**checked, 'order_dates': [], 'selected': None}
    view['overview_surface'] = empty_surface(view['overview_surface']) if outside_original else surface(view['overview_surface'], start, end)
    view['surface'] = empty_surface(view['surface']) if outside else surface(view['surface'], first, last)
    from decimal import Decimal
    overview_values = [Decimal(value) for value in view['overview_surface']['values']]
    if any(not overview_values[0] <= Decimal(value) <= overview_values[-1] for value in view['surface']['values']):
        raise ValidationError('INVALID_SNAPSHOT_VIEW', 'As taxas do trecho precisam ficar dentro da janela original.')
    for key, divisions_key in (('surface', 'divisions'), ('overview_surface', 'overview_divisions')):
        values = view[key]['values']
        divisions = view.get(divisions_key)
        if divisions is not None and len(values) != 1 and len(values) not in (divisions + 1, divisions + 2):
            raise ValidationError('INVALID_SNAPSHOT_VIEW', 'A quantidade de curvas não corresponde às divisões registradas.')
    if view.get('reading_date') is not None:
        _date(view['reading_date'], 'single_screen.reading_date')
    for key in ('result', 'overview_result'):
        result = view.get(key)
        if result is None:
            continue
        if version == 2:
            result = _object(result, 'single_screen.' + key, {'encoding', 'dates', 'settlements', 'rates', 'statuses', 'qualities', 'metric_statuses', 'reasons', 'rows', 'coverage', 'source_versions', 'engine_manifest', 'conversion_bases', 'overlay_support'}, {'encoding', 'dates', 'settlements', 'rates', 'statuses', 'qualities', 'metric_statuses', 'reasons', 'rows', 'coverage', 'source_versions', 'engine_manifest'})
            if result['encoding'] != 'grid-v2':
                raise ValidationError('INVALID_SNAPSHOT_VIEW', 'Codificação da grade inválida.')
            for field in ('dates', 'settlements', 'rates', 'statuses', 'qualities', 'metric_statuses'):
                if not isinstance(result[field], list) or not 1 <= len(result[field]) <= point_limit:
                    raise ValidationError('INVALID_SNAPSHOT_VIEW', 'Dicionário da grade inválido.')
                for value in result[field]:
                    _text(value, 'grid.' + field, 64)
            if not isinstance(result['rows'], list) or not 1 <= len(result['rows']) <= point_limit:
                raise ValidationError('INVALID_SNAPSHOT_VIEW', 'Quantidade de pontos armazenados inválida.')
            bases = result.get('conversion_bases')
            if 'conversion_bases' in result and (not isinstance(bases, list) or not 1 <= len(bases) <= point_limit):
                raise ValidationError('INVALID_SNAPSHOT_VIEW', 'Bases de conversão inválidas.')
            for row in result['rows']:
                if not isinstance(row, list) or len(row) != (12 if bases is not None else 11):
                    raise ValidationError('INVALID_SNAPSHOT_VIEW', 'Linha da grade inválida.')
                if bases is not None and (type(row[11]) is not int or not 0 <= row[11] < len(bases)):
                    raise ValidationError('INVALID_SNAPSHOT_VIEW', 'Referência de conversão inválida.')
                fields = ['dates', 'settlements', 'rates', 'statuses', 'qualities']
                if any(type(row[i]) is not int or not 0 <= row[i] < len(result[field]) for i, field in enumerate(fields)):
                    raise ValidationError('INVALID_SNAPSHOT_VIEW', 'Referência da grade inválida.')
                if not isinstance(row[10], list) or len(row[10]) != 4 or any(type(i) is not int or not 0 <= i < len(result['metric_statuses']) for i in row[10]):
                    raise ValidationError('INVALID_SNAPSHOT_VIEW', 'Referência de medida inválida.')
            if 'overlay_support' in result:
                support = _object(result['overlay_support'], 'overlay_support', {'encoding', 'bases', 'rows'}, {'encoding', 'bases', 'rows'})
                if support['encoding'] != 'reference-v1' or not isinstance(support['bases'], list) or not 1 <= len(support['bases']) <= 121 or not isinstance(support['rows'], list) or not 1 <= len(support['rows']) <= 121:
                    raise ValidationError('INVALID_SNAPSHOT_VIEW', 'Grade de referências inválida.')
                for base in support['bases']:
                    if base is not None:
                        _object(base, 'support.base', {'initial_outflow', 'purchase_settlement_date', 'quality'}, {'initial_outflow', 'purchase_settlement_date', 'quality'})
                for row in support['rows']:
                    if not isinstance(row, list) or len(row) != 5 or type(row[2]) is not int or not 0 <= row[2] < len(support['bases']):
                        raise ValidationError('INVALID_SNAPSHOT_VIEW', 'Referência de base inválida.')
            result = unpack_surface(result)
        result = _object(result, 'single_screen.' + key, {'points', 'reasons', 'coverage', 'source_versions', 'engine_manifest', 'overlay_support'},
                         {'points', 'reasons', 'coverage', 'source_versions', 'engine_manifest'}) if version == 1 else result
        if not isinstance(result['reasons'], list) or len(result['reasons']) > point_limit:
            raise ValidationError('INVALID_SNAPSHOT_VIEW', 'Lista de motivos da grade inválida.')
        for reason in result['reasons']:
            _text(reason, 'single_screen.reason', 4096)
        if not isinstance(result['points'], list) or not 1 <= len(result['points']) <= point_limit:
            raise ValidationError('INVALID_SNAPSHOT_VIEW', 'Quantidade de pontos armazenados inválida.')
        if 'overlay_support' in result:
            support = result['overlay_support']
            if not isinstance(support, list) or not 1 <= len(support) <= 121:
                raise ValidationError('INVALID_SNAPSHOT_VIEW', 'Grade de referências inválida.')
            support_dates = []
            bounds = view['period'] if key == 'result' else timeline
            for row in support:
                row = _object(row, 'overlay_support.row', {'order_date', 'settlement_date', 'conversion_basis'}, {'order_date', 'settlement_date', 'conversion_basis'})
                day, settlement = _date(row['order_date'], 'support.order_date'), _date(row['settlement_date'], 'support.settlement_date')
                if not bounds['start'] <= day.isoformat() <= bounds['end'] or settlement < day:
                    raise ValidationError('INVALID_SNAPSHOT_VIEW', 'Referência fora do período.')
                support_dates.append(day)
                _validate_conversion_basis(row['conversion_basis'])
            if support_dates != sorted(set(support_dates)):
                raise ValidationError('INVALID_SNAPSHOT_VIEW', 'Datas das referências inválidas.')
        for point in result['points']:
            point = _object(point, 'single_screen.point', {'identity', 'order_date', 'settlement_date', 'coordinate', 'value', 'status', 'quality', 'reason', 'metrics', 'conversion_basis'})
            _validate_conversion_basis(point.get('conversion_basis'))
            _date(point.get('order_date'), 'point.order_date')
            _date(point.get('settlement_date'), 'point.settlement_date')
            _text(point.get('identity'), 'point.identity', 64)
            if point.get('reason') is not None and (type(point['reason']) is not int or not 0 <= point['reason'] < len(result['reasons'])):
                raise ValidationError('INVALID_SNAPSHOT_VIEW', 'Referência de motivo da grade inválida.')
            coordinate = _object(point.get('coordinate'), 'point.coordinate', {'value', 'unit'}, {'value', 'unit'})
            _decimal(coordinate['value'], 'point.rate')
            for metric in METRICS:
                value = _object(point.get('metrics', {}).get(metric), 'point.metric', {'value', 'status'}, {'value', 'status'})
                if value['value'] is not None:
                    _decimal(value['value'], 'point.metric.value')
                _text(value['status'], 'point.metric.status', 64)
    if 'comparison' in view:
        comparison = _object(view['comparison'], 'single_screen.comparison', {'view'}, {'view'})
        if comparison_input is None or not isinstance(comparison['view'], dict) or 'comparison' in comparison['view']:
            raise ValidationError('INVALID_SNAPSHOT_VIEW', 'Comparação exige uma compra B independente.')
        other_timeline = (comparison_input.get('analysis_context') or {}).get('timeline') or {}
        if other_timeline != timeline:
            raise ValidationError('INVALID_SNAPSHOT_VIEW', 'A e B precisam compartilhar o período original.')
        comparison['view'] = validate_snapshot_view(comparison['view'], comparison_input, _comparison_member=True)
        if outside and comparison['view'].get('outside_period'):
            raise ValidationError('INVALID_SNAPSHOT_VIEW', 'O detalhe exige pelo menos um produto no período.')
        if comparison['view']['period'] != view['period']:
            raise ValidationError('INVALID_SNAPSHOT_VIEW', 'A e B precisam compartilhar o trecho exibido.')
        detailed = first != start or last != end
        if detailed and any(not item.get('overview_result') and not item.get('outside_original') for item in (view, comparison['view'])):
            raise ValidationError('INVALID_SNAPSHOT_VIEW', 'O refinamento precisa preservar a visão geral de A e B.')
        for key in ('surface', 'overview_surface'):
            inactive_scope = (outside or comparison['view'].get('outside_period')) if key == 'surface' else (outside_original or comparison['view'].get('outside_original'))
            if not inactive_scope and view.get('aligned_dates') and view[key]['order_dates'] != comparison['view'][key]['order_dates']:
                raise ValidationError('INVALID_SNAPSHOT_VIEW', 'A e B precisam compartilhar as datas de saída.')
            if not inactive_scope and view.get('converged_dates'):
                a_dates, b_dates = view[key]['order_dates'], comparison['view'][key]['order_dates']
                first, last = max(a_dates[0], b_dates[0]), min(a_dates[-1], b_dates[-1])
                if [day for day in a_dates if first <= day <= last] != [day for day in b_dates if first <= day <= last]:
                    raise ValidationError('INVALID_SNAPSHOT_VIEW', 'A e B precisam convergir nas datas do período compartilhado.')
            a, b = view[key]['values'], comparison['view'][key]['values']
            if (Decimal(a[0]), Decimal(a[-1])) != (Decimal(b[0]), Decimal(b[-1])):
                raise ValidationError('INVALID_SNAPSHOT_VIEW', 'A e B precisam compartilhar os limites das taxas de saída.')
        for key in ('divisions', 'overview_divisions', 'date_density', 'aligned_dates', 'date_step_days', 'overview_date_step_days', 'converged_dates'):
            if view.get(key) != comparison['view'].get(key):
                raise ValidationError('INVALID_SNAPSHOT_VIEW', 'A e B precisam compartilhar as divisões da janela.')
        view['comparison'] = comparison
    if 'legend_hidden' in view:
        hidden = view['legend_hidden']
        if not isinstance(hidden, list) or len(hidden) > 128 or any(not isinstance(key, str) or len(key) > 100 for key in hidden) or len(set(hidden)) != len(hidden):
            raise ValidationError('INVALID_SNAPSHOT_VIEW', 'Seleção da legenda inválida.')
        for key in hidden:
            if key == 'goal':
                continue
            parts = key.split(':')
            member = view if len(parts) >= 2 and parts[1] == 'A' else (view.get('comparison') or {}).get('view') if len(parts) >= 2 and parts[1] == 'B' else None
            if member is None or parts[0] not in ('simulation', 'projection') or len(parts) != (3 if parts[0] == 'simulation' else 2):
                raise ValidationError('INVALID_SNAPSHOT_VIEW', 'Linha da legenda inválida.')
            if parts[0] == 'simulation':
                rate = _decimal(parts[2], 'legend.rate')
                if rate not in {Decimal(value) for field in ('surface', 'overview_surface') for value in member[field]['values']}:
                    raise ValidationError('INVALID_SNAPSHOT_VIEW', 'Taxa oculta não pertence às grades registradas.')
    return _json_ready(view)


def capture_snapshot(service, view, input_value, comparison_input=None):
    """Verify posted chart values with pinned sources, then store engine output only."""
    from .models import ValidationError
    captured = deepcopy(view)
    original = {key: input_value['analysis_context']['timeline'][key] for key in ('start', 'end')}
    if view.get('outside_original'):
        eligible, reason = period_eligibility(service, input_value, original)
        if eligible:
            raise ValidationError('E-SIMPLE-CHANGED', 'O produto tem saída elegível no período original.')
        captured['outside_reason'] = reason
    for key, surface, period in (
        ('result', view['surface'], view['period']),
        ('overview_result', view['overview_surface'], original),
    ):
        if key == 'result' and view.get('outside_period'):
            eligible, reason = period_eligibility(service, input_value, period)
            if eligible:
                raise ValidationError('E-SIMPLE-CHANGED', 'O produto tem saída elegível no trecho e não pode ser salvo como fora do período.')
            captured[key] = None
            captured['outside_reason'] = reason
            continue
        if key == 'overview_result' and view.get('outside_original'):
            captured[key] = None
            continue
        if key == 'overview_result' and surface == view['surface'] and period == view['period']:
            captured[key] = None
            continue
        financial_input = deepcopy(input_value)
        financial_input['analysis_context']['timeline'] = {'mode': 'WINDOW', 'start': period['start'], 'end': period['end']}
        result = calculate_surface(service, financial_input, surface)
        expected = view.get(key)
        with_basis = bool(expected and ('conversion_bases' in expected or any('conversion_basis' in point for point in expected.get('points', []))))
        compact = compact_surface(result, packed=view['version'] == 2, include_basis=with_basis, include_support=bool(expected and 'overlay_support' in expected))
        value_key = 'rows' if view['version'] == 2 else 'points'
        if not expected or compact.get('overlay_support') != expected.get('overlay_support') or compact[value_key] != expected.get(value_key) or compact['reasons'] != expected.get('reasons') or (view['version'] == 2 and any(compact.get(key) != expected.get(key) for key in ('dates', 'settlements', 'rates', 'statuses', 'qualities', 'metric_statuses', 'conversion_bases'))):
            raise ValidationError('E-SIMPLE-CHANGED', 'O gráfico difere dos dados ou regras atuais. Simule novamente antes de salvar; suas entradas foram preservadas.')
        captured[key] = compact
    if view.get('comparison'):
        captured['comparison'] = {'view': capture_snapshot(service, view['comparison']['view'], comparison_input)}
    return captured


def period_has_eligible_sale(service, input_value, period):
    return period_eligibility(service, input_value, period)[0]


def period_eligibility(service, input_value, period):
    """Certify date eligibility through the same resolver, without pricing sales."""
    from datetime import date, timedelta
    from .models import ValidationError
    from .market_sim.dates import minimum_renda_plus_sale_date
    probe = {key: deepcopy(input_value[key]) for key in ('instrument', 'purchase_date', 'knowledge', 'intent', 'source_versions') if key in input_value}
    assumptions = input_value.get('assumptions') or {}
    probe['assumptions'] = {key: deepcopy(assumptions[key]) for key in ('settlement_profile', 'explicit_settlements') if key in assumptions}
    def resolve(extra):
        return service.simulator_workspace({'schema_version': 2, 'action': 'RESOLVE', 'request_id': 'snapshot-outside-period',
                                            'revision': 1, 'input': {**probe, **extra}}).get('resolved') or {}
    initial = resolve({'analysis_context': {'kind': 'OPERATION', 'timeline': {'mode': 'WINDOW', **period}}})
    purchase = (initial.get('dates') or {}).get('purchase') or {}
    instrument = (initial.get('normalized_input') or {}).get('instrument') or {}
    horizon = instrument.get('first_income_date') or instrument.get('maturity_date')
    if purchase.get('status') != 'available' or not purchase.get('settlement_date') or not horizon:
        raise ValidationError('E-SIMPLE-CHANGED', 'Não foi possível confirmar a compra ou o horizonte do produto fora do trecho.')
    settlement = date.fromisoformat(purchase['settlement_date'])
    day = max(date.fromisoformat(period['start']), settlement + timedelta(days=1))
    last = min(date.fromisoformat(period['end']), date.fromisoformat(horizon) - timedelta(days=1))
    if instrument.get('family') == 'RENDA_PLUS':
        day = max(day, minimum_renda_plus_sale_date(settlement))
    if day > last:
        reason = 'INCOME' if instrument.get('family') == 'RENDA_PLUS' else 'MATURITY'
        if date.fromisoformat(period['end']) < date.fromisoformat(horizon):
            reason = 'SETTLEMENT' if date.fromisoformat(period['end']) <= settlement else 'LOCKUP' if instrument.get('family') == 'RENDA_PLUS' else 'NO_SESSION'
        return False, reason
    for _ in range(4):
        resolved = resolve({'sale_date': day.isoformat()})
        sale = (resolved.get('dates') or {}).get('sale') or {}
        if ((resolved.get('dates') or {}).get('purchase') or {}).get('status') != 'available':
            break
        minimum = day
        for key in ('minimum_eligible_order_date', 'proposed_order_date'):
            if sale.get(key):
                minimum = max(minimum, date.fromisoformat(sale[key]))
        if (sale.get('reason') or {}).get('code') == 'OUTSIDE_HORIZON':
            return False, 'INCOME' if instrument.get('family') == 'RENDA_PLUS' else 'MATURITY'
        if minimum > last:
            return False, 'LOCKUP' if (sale.get('reason') or {}).get('code') == 'LOCKED' else 'NO_SESSION'
        if minimum == day and sale.get('status') == 'available':
            return True, None
        if minimum <= day:
            break
        day = minimum
    raise ValidationError('E-SIMPLE-CHANGED', 'Não foi possível confirmar que o produto está fora do trecho. Simule novamente.')


def _validate_conversion_basis(raw):
    from .market_sim.api import _object, _date, _decimal, _text
    from .market_sim.contracts import ValidationError
    if raw is not None:
        basis = _object(raw, 'point.conversion_basis',
                        {'initial_outflow', 'inflation_factor', 'purchase_settlement_date', 'quality', 'inflation_quality'},
                        {'initial_outflow', 'inflation_factor', 'purchase_settlement_date', 'quality', 'inflation_quality'})
        if _decimal(basis['initial_outflow'], 'basis.initial_outflow') <= 0:
            raise ValidationError('INVALID_SNAPSHOT_VIEW', 'Desembolso de conversão inválido.')
        if basis['inflation_factor'] is not None and _decimal(basis['inflation_factor'], 'basis.inflation_factor') <= 0:
            raise ValidationError('INVALID_SNAPSHOT_VIEW', 'Fator de inflação inválido.')
        _date(basis['purchase_settlement_date'], 'basis.purchase_settlement_date')
        for field in ('quality', 'inflation_quality'):
            _text(basis[field], 'basis.' + field, 64)



def pack_overlay_support(support):
    bases, rows = [], []
    for row in support:
        basis = row['conversion_basis']
        base = None if basis is None else {key: basis[key] for key in ('initial_outflow', 'purchase_settlement_date', 'quality')}
        if base not in bases:
            bases.append(base)
        rows.append([row['order_date'], row['settlement_date'], bases.index(base),
                     None if basis is None else basis['inflation_factor'],
                     'MISSING' if basis is None else basis['inflation_quality']])
    return {'encoding': 'reference-v1', 'bases': bases, 'rows': rows}


def unpack_overlay_support(support):
    return [{'order_date': row[0], 'settlement_date': row[1],
             'conversion_basis': None if support['bases'][row[2]] is None else {
                 **support['bases'][row[2]], 'inflation_factor': row[3], 'inflation_quality': row[4]}}
            for row in support['rows']]
