"""Faixa de premissas, não intervalo estatístico. Não muda a meta ativa."""
from dataclasses import replace
from decimal import Decimal as D, ROUND_CEILING
from .exit_targets import target_price
from .models import ValidationError


def sensitivity_at_date(lot,day,target,fees,*,fee_uncertainty=D('0'),price_slippage_bps=0):
    amount=D(str(fee_uncertainty));slip=D(str(price_slippage_bps))/10000
    if amount<0 or not D(0)<=slip<D('.1'):raise ValidationError('E-SENSITIVITY','Use custo adicional não negativo e oscilação de preço entre 0 e menos de 1000 pontos-base.')
    low=target_price(lot,day,target,replace(fees,exit_fixed=max(D(0),fees.exit_fixed-amount)))
    high=target_price(lot,day,target,replace(fees,exit_fixed=fees.exit_fixed+amount))
    base=target_price(lot,day,target,fees)
    return {'active_target':float(target),'base_pu':float(base.tick),
      'optimistic_pu':float((low.tick/(1+slip)).quantize(D('.01'),rounding=ROUND_CEILING)),
      'pessimistic_pu':float((high.tick/(1-slip)).quantize(D('.01'),rounding=ROUND_CEILING)),
      'extra_cost':float(amount),'price_bps':float(price_slippage_bps),
      'note':'Faixa de sensibilidade a hipóteses de custos e execução; não é intervalo de confiança nem garantia.'}
