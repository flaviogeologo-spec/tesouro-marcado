"""Calendários projetados e explícitos; não certificam sessões até 2084.

DU: [referência, pagamento), segunda a sexta sem feriados financeiros nacionais.
Sessões: calendário financeiro + fechamento natalino/fim de ano e feriados locais
históricos. Exceções extraordinárias não conhecidas não são presumidas.
"""
from __future__ import annotations
from dataclasses import dataclass
from datetime import date, timedelta
from functools import lru_cache
import numpy as np
from dateutil.easter import easter
from .models import PurchaseLot, ValidationError

CALENDAR_START = date(2000, 1, 1)
CALENDAR_END = date(2085, 12, 31)


@lru_cache(maxsize=8)
def _calendars(black_awareness: bool, local_removal_known: bool):
    financial=set(); session=set()
    for year in range(1999,2087):
        e=easter(year)
        fixed=[(1,1),(4,21),(5,1),(9,7),(10,12),(11,2),(11,15),(12,25)]
        h={date(year,m,d) for m,d in fixed}
        h.update({e-timedelta(days=48),e-timedelta(days=47),e-timedelta(days=2),e+timedelta(days=60)})
        if black_awareness and year>=2024:
            h.add(date(year,11,20))
        financial.update(h); session.update(h)
        session.add(date(year,12,24)); session.add(date(year,12,31))
        last=date(year,12,31)
        while last.weekday()>=5:
            last-=timedelta(days=1)
        session.add(last)
        if year<=2021 or not local_removal_known:
            session.update({date(year,1,25),date(year,7,9),date(year,11,20)})
    def make(items):
        return np.busdaycalendar(holidays=np.array(sorted(items),dtype='datetime64[D]'))
    return make(financial),make(session)


@dataclass(frozen=True)
class FinancialCalendar:
    knowledge_date: date = date(2026,9,24)
    calendar_id: str = 'BR_FINANCIAL_RULES_PROJECTED_v1'
    verified_until: date | None = None
    overlay: object | None = None

    @property
    def financial(self):
        return self._effective(True)

    @property
    def sessions(self):
        return self._effective(False)

    @lru_cache(maxsize=32)
    def _effective(self,financial):
        base=_calendars(self.knowledge_date>=date(2023,12,22),self.knowledge_date>=date(2022,1,1))[0 if financial else 1]
        return self._overlay_calendar(base,financial)

    def _overlay_calendar(self, base, financial=False):
        pack=self.overlay
        if pack is None or pack.known_on>self.knowledge_date:return base
        holidays=set(base.holidays.astype(object).tolist())
        holidays.update(pack.financial_closures if financial else pack.closures)
        holidays.difference_update(pack.financial_openings if financial else pack.openings)
        return np.busdaycalendar(holidays=np.array(sorted(holidays),dtype='datetime64[D]'))

    def coverage(self,d):
        p=self.overlay
        if p and p.known_on<=self.knowledge_date and p.valid_from<=d<=p.valid_until:
            return f'Cobertura do pacote {p.version}; {p.source_quality}. Sessões extraordinárias exigem confirmação.'
        return 'Calendário projetado; não há cobertura verificada para esta data.'

    def _check(self,d:date):
        if d<CALENDAR_START or d>CALENDAR_END:
            raise ValidationError('E-CALENDAR','Calendário projetado cobre somente 2000 a 2085.')

    def is_session(self,d:date)->bool:
        self._check(d)
        return bool(np.is_busday(np.datetime64(d),busdaycal=self.sessions))

    def is_financial(self,d:date)->bool:
        self._check(d)
        return bool(np.is_busday(np.datetime64(d),busdaycal=self.financial))

    def next_session(self,d:date,include:bool=False)->date:
        self._check(d)
        d=d if include else d+timedelta(days=1)
        return np.busday_offset(np.datetime64(d),0,roll='forward',busdaycal=self.sessions).astype(object)

    @lru_cache(maxsize=1024)
    def roll_payment(self,d:date)->date:
        self._check(d)
        return np.busday_offset(np.datetime64(d),0,roll='forward',busdaycal=self.financial).astype(object)

    def business_days(self,start:date,end:date)->int:
        self._check(start); self._check(end)
        return int(np.busday_count(np.datetime64(start),np.datetime64(end),busdaycal=self.financial))

    def days_to_payments(self,valuation:date,payments)->np.ndarray:
        self._check(valuation)
        return np.busday_count(np.datetime64(valuation),np.array(payments,dtype='datetime64[D]'),busdaycal=self.financial)

    def first_eligible(self,lot:PurchaseLot)->date:
        return self.next_session(lot.lock_end,include=True)

    def eligible(self,lot:PurchaseLot,trade:date)->bool:
        return trade>=lot.lock_end and trade<=lot.max_redemption_date and self.is_session(trade)

    def redemption_settlement(self,trade:date,lag:int)->date:
        if lag not in (0,1):
            raise ValidationError('E-DATE','Liquidação aceita somente D+0 ou D+1.')
        if not self.is_session(trade):
            # Valor teórico do dia, explicitamente não executável; não deslocar seu rótulo.
            return trade
        return trade if lag==0 else self.next_session(trade)

    @property
    def warning(self)->str:
        prefix = f'Pacote {self.overlay.version}; fonte: {self.overlay.source}; conhecido em {self.overlay.known_on:%d/%m/%Y}. ' if self.overlay and self.overlay.known_on<=self.knowledge_date else ''
        return prefix + ('Calendário por regras projetadas (feriados financeiros nacionais e fechamentos de sessão); '
                'não certifica suspensões ou exceções futuras até 2084. Confirme a liberação na instituição.')
