"""Contratos imutáveis do avaliador. Valores monetários permanecem Decimal."""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import date, datetime, timedelta
from decimal import Decimal, InvalidOperation
from math import isfinite
from typing import Literal

D = Decimal
INSTRUMENT_ID = 'RENDA_PLUS_2065_2084_12_15'
CONVERSION_DATE = date(2065, 1, 15)
MATURITY_DATE = date(2084, 12, 15)
VERSION = '3.0.1-studio'


class ValidationError(ValueError):
    """Erro esperado, apropriado para exibir sem traceback."""
    def __init__(self, code: str, message: str):
        self.code = code
        super().__init__(f'{code}: {message}')


def decimal_value(value: object, name: str = 'valor') -> Decimal:
    try:
        result = D(str(value))
    except (InvalidOperation, ValueError, TypeError) as exc:
        raise ValidationError('E-AMOUNT', f'{name} não é um número válido.') from exc
    if not result.is_finite():
        raise ValidationError('E-AMOUNT', f'{name} precisa ser finito.')
    return result


def add_years(day: date, years: int) -> date:
    try:
        return day.replace(year=day.year + years)
    except ValueError:  # 29/02 -> 28/02 no aniversário sem ano bissexto
        return day.replace(year=day.year + years, day=28)


@dataclass(frozen=True)
class PurchaseLot:
    trade_date: date
    settlement_date: date
    quantity: Decimal
    unit_price: Decimal
    tax_cost_basis: Decimal | None = None
    entry_fee: Decimal = D('0')
    entry_yield: float | None = None
    source_kind: str = 'REAL_COMPRA'
    source_ref: str = 'Dados informados'
    per_unit: bool = False
    institution_release_date: date | None = None
    has_intermediate_flows: bool = False
    instrument_id: str = INSTRUMENT_ID

    def __post_init__(self):
        for name in ('quantity', 'unit_price', 'entry_fee'):
            object.__setattr__(self, name, decimal_value(getattr(self, name), name))
        basis = self.quantity * self.unit_price if self.tax_cost_basis is None else decimal_value(self.tax_cost_basis)
        object.__setattr__(self, 'tax_cost_basis', basis)
        if self.instrument_id != INSTRUMENT_ID:
            raise ValidationError('E-INSTRUMENT', 'Somente o RendA+ 2065 é aceito.')
        if self.settlement_date < self.trade_date:
            raise ValidationError('E-DATE', 'A liquidação não pode preceder a compra.')
        if self.quantity <= 0 or self.unit_price <= 0 or basis <= 0 or self.entry_fee < 0:
            raise ValidationError('E-AMOUNT', 'Quantidade, PU e custo fiscal devem ser positivos; despesa não negativa.')
        if self.quantity % D('.01') != 0:
            raise ValidationError('E-AMOUNT', 'Use quantidade em múltiplos de 0,01 título.')
        if self.per_unit and self.quantity != 1:
            raise ValidationError('E-AMOUNT', 'A análise por título usa quantidade igual a 1.')
        if self.entry_yield is not None and (not isfinite(self.entry_yield) or self.entry_yield <= -1):
            raise ValidationError('E-YIELD-DOMAIN', 'Taxa de entrada inválida.')
        if self.settlement_date >= CONVERSION_DATE:
            raise ValidationError('E-HORIZON', 'A primeira versão só aceita a fase anterior à conversão.')
        if self.has_intermediate_flows:
            raise ValidationError('E-INTERMEDIATE-FLOW', 'Pagamentos intermediários, vendas parciais ou múltiplos lotes não são suportados.')

    @property
    def initial_outflow(self) -> Decimal:
        return self.tax_cost_basis + self.entry_fee

    @property
    def theoretical_lock_end(self) -> date:
        return self.settlement_date + timedelta(days=60)

    @property
    def lock_end(self) -> date:
        # Informação da instituição pode postergar, jamais contornar os 60 dias.
        return max(self.theoretical_lock_end, self.institution_release_date or self.theoretical_lock_end)

    @property
    def max_redemption_date(self) -> date:
        return min(add_years(self.settlement_date, 10), CONVERSION_DATE) - timedelta(days=1)


@dataclass(frozen=True)
class Fees:
    custody_annual: Decimal = D('.005')
    exit_fixed: Decimal = D('0')
    exit_rate: Decimal = D('0')
    policy_id: str = 'RENDA_REDEMPTION_ACT365_ESTIMATED_v1'
    monetary_rounding: str = 'continuous'

    def __post_init__(self):
        for name in ('custody_annual', 'exit_fixed', 'exit_rate'):
            value = decimal_value(getattr(self, name), name)
            if value < 0:
                raise ValidationError('E-AMOUNT', 'Custos não podem ser negativos.')
            object.__setattr__(self, name, value)
        if self.monetary_rounding not in ('continuous','centavos_half_up'):
            raise ValidationError('E-POLICY','Perfil de arredondamento não reconhecido.')
        if self.custody_annual > D('.1') or self.exit_rate >= D('.5'):
            raise ValidationError('E-AMOUNT', 'Custo fora do domínio numérico da aplicação.')


@dataclass(frozen=True)
class Quote:
    observation_date: date
    buy_yield: float | None = None
    redemption_yield: float | None = None
    buy_pu: Decimal | None = None
    redemption_pu: Decimal | None = None
    reference_pu: Decimal | None = None
    source_kind: str = 'COTACAO_HISTORICA'
    source_ref: str = 'CSV da manhã'
    observed_at: datetime | None = None
    valuation_date: date | None = None
    redemption_settlement_date: date | None = None
    net_total: Decimal | None = None
    custody_override: Decimal | None = None
    session_declared_active: bool = False
    instrument_id: str = INSTRUMENT_ID

    def __post_init__(self):
        if self.instrument_id != INSTRUMENT_ID:
            raise ValidationError('E-INSTRUMENT', 'A cotação precisa pertencer ao RendA+ 2065.')
        for name in ('buy_pu', 'redemption_pu', 'reference_pu', 'net_total', 'custody_override'):
            value = getattr(self, name)
            if value is not None:
                value = decimal_value(value, name)
                if value < 0 or (name in ('buy_pu', 'redemption_pu', 'reference_pu') and value == 0):
                    raise ValidationError('E-AMOUNT', f'{name} inválido.')
                object.__setattr__(self, name, value)
        for name in ('buy_yield', 'redemption_yield'):
            value = getattr(self, name)
            if value is not None and (not isfinite(value) or value <= -1):
                raise ValidationError('E-YIELD-DOMAIN', 'Taxa da cotação inválida.')
        if self.net_total is not None and self.custody_override is not None:
            raise ValidationError('E-NET-DOUBLE', 'Informe líquido final OU custódia; não os dois.')
        if self.observed_at is not None:
            if self.observed_at.tzinfo is None:
                raise ValidationError('E-DATE', 'Horário da cotação precisa de fuso horário.')
            if self.observed_at.date() != self.observation_date:
                raise ValidationError('E-DATE', 'Data e horário da cotação não coincidem.')
        if self.redemption_settlement_date and self.redemption_settlement_date < self.observation_date:
            raise ValidationError('E-DATE', 'Liquidação de venda anterior à cotação.')


@dataclass(frozen=True)
class PricingAnchor:
    valuation_date: date
    vni: float
    known_on: date
    source_kind: str
    source_ref: str
    pair_error: float | None = None
    quality_flags: tuple[str, ...] = ()

    def __post_init__(self):
        if not isfinite(self.vni) or self.vni <= 0:
            raise ValidationError('E-ANCHOR', 'VNI deve ser positivo e finito.')


@dataclass(frozen=True)
class AnalysisRequest:
    lot: PurchaseLot
    as_of: date
    start_date: date
    end_date: date
    target: Decimal = D('.109')
    scenario_yields: tuple[float, ...] = (.068, .07, .072)
    scenario_kind: Literal['resgate', 'compra'] = 'resgate'
    spread: float | None = None
    spread_source: str = ''
    inflation: float = .04
    inflation_confirmed: bool = False
    settlement_lag: int = 0
    fees: Fees = field(default_factory=Fees)
    anchors: tuple[PricingAnchor, ...] = ()
    quotes: tuple[Quote, ...] = ()
    snapshot: Quote | None = None
    entry_reference: float = .0717
    quote_fresh_minutes: int = 5
    now: datetime | None = None
    inflation_monthly: tuple[tuple[str,float], ...] = ()

    def __post_init__(self):
        object.__setattr__(self, 'target', decimal_value(self.target, 'meta'))
        if not D('0') <= self.target <= D('2'):
            raise ValidationError('E-AMOUNT', 'A meta precisa estar entre 0% e 200%.')
        if self.start_date > self.end_date or self.start_date < self.lot.settlement_date:
            raise ValidationError('E-DATE', 'O intervalo deve começar após a liquidação e ter início não posterior ao fim.')
        if self.end_date > self.lot.max_redemption_date:
            raise ValidationError('E-HORIZON', f'Horizonte máximo: {self.lot.max_redemption_date:%d/%m/%Y} (antes de dez anos/conversão).')
        if self.as_of < self.lot.trade_date:
            raise ValidationError('E-DATE', 'A referência da análise não pode preceder a ordem de compra.')
        if self.as_of > self.lot.max_redemption_date:
            raise ValidationError('E-HORIZON', 'Referência da análise fora do domínio inferior a dez anos.')
        if self.settlement_lag not in (0, 1):
            raise ValidationError('E-DATE', 'Selecione resgate D+0 ou D+1.')
        if not 1 <= len(self.scenario_yields) <= 5:
            raise ValidationError('E-YIELD-DOMAIN', 'Informe de uma a cinco taxas.')
        if len(set(self.scenario_yields)) != len(self.scenario_yields):
            raise ValidationError('E-YIELD-DOMAIN', 'Remova as taxas duplicadas.')
        if self.scenario_kind not in ('resgate','compra'):
            raise ValidationError('E-YIELD-DOMAIN', 'Natureza da taxa inválida.')
        if self.scenario_kind == 'compra' and (self.spread is None or not self.spread_source.strip()):
            raise ValidationError('E-ANCHOR', 'Taxa de compra requer spread e origem ou hipótese declarada.')
        if self.spread is not None and (not isfinite(self.spread) or self.spread < 0 or self.spread > .1):
            raise ValidationError('E-YIELD-DOMAIN', 'Spread fora do domínio permitido (0 a 10 p.p.).')
        if not isfinite(self.inflation) or self.inflation <= -1 or self.inflation > 10:
            raise ValidationError('E-PROJECTION', 'Inflação deve ser maior que -100% e até 1.000% a.a.')
        if self.anchors and not self.inflation_confirmed:
            raise ValidationError('E-PROJECTION', 'Confirme que a inflação é uma hipótese de cenário.')
        if any(a.known_on > self.as_of for a in self.anchors):
            raise ValidationError('E-ANCHOR', 'A análise não pode usar uma âncora conhecida depois da data de referência.')
        if self.snapshot and self.snapshot.observation_date > self.as_of:
            raise ValidationError('E-DATE', 'A cotação selecionada é posterior à referência da análise.')
