"""Inversão do resultado líquido em um preço mínimo, sem precisar de VNI."""
from dataclasses import dataclass
from datetime import date
from decimal import Decimal as D, ROUND_CEILING, ROUND_FLOOR
from .models import Fees, PurchaseLot, ValidationError, decimal_value
from .tax_and_fees import tax_rate, net_proceeds


@dataclass(frozen=True)
class PriceTarget:
    continuous: D
    tick: D
    target_amount: D


def target_price(lot: PurchaseLot, settlement: date, target: D, fees: Fees) -> PriceTarget:
    target = decimal_value(target, 'meta')
    if not D(0) <= target <= D(2):
        raise ValidationError('E-AMOUNT', 'Meta fora do intervalo de 0% a 200%.')
    days = (settlement-lot.settlement_date).days
    a = tax_rate(days)
    if settlement > lot.max_redemption_date:
        raise ValidationError('E-HORIZON','Liquidação fora do domínio de dez anos/conversão.')
    gamma = fees.custody_annual * D(days)/D(365)
    denom = 1-a-gamma-fees.exit_rate
    if denom <= 0:
        raise ValidationError('E-NO-ROOT','Custos impedem uma solução crescente para o líquido.')
    desired = lot.initial_outflow*(1+target)
    # Para metas não negativas e custos não negativos a raiz está em X>=B.
    continuous = (desired+fees.exit_fixed-a*lot.tax_cost_basis)/(lot.quantity*denom)
    tick = continuous.quantize(D('.01'), rounding=ROUND_CEILING)
    if fees.monetary_rounding == 'centavos_half_up':
        # Cada arredondamento pode deslocar até meio centavo do total. Buscar
        # a última insuficiência no envelope, não apenas uma ilha favorável.
        # O retorno é um PU mínimo CONSERVADOR: todos os preços maiores atendem
        # na política declarada, apesar de degraus de centavos em lotes pequenos.
        error_bound=D('.02000001')
        lower=max(D('.01'),(continuous-error_bound/(lot.quantity*denom)).quantize(D('.01'),rounding=ROUND_FLOOR))
        upper=(continuous+error_bound/(lot.quantity*denom)).quantize(D('.01'),rounding=ROUND_CEILING)+D('.01')
        steps=int((upper-lower)*100)+1
        if steps>100000:raise ValidationError('E-NO-ROOT','Custos e quantidade tornam a busca monetária extrema; confira os valores.')
        last_bad=lower-D('.01')
        for i in range(steps):
            price=lower+D(i)/100
            if not net_proceeds(lot,price,settlement,fees).meets(lot,target):last_bad=price
        tick=last_bad+D('.01')
        if not net_proceeds(lot,tick,settlement,fees).meets(lot,target):
            raise ValidationError('E-NO-ROOT','Não foi possível verificar o preço monetário conservador.')
        return PriceTarget(continuous,tick,desired)
    # Verificar o tick de fato, sem epsilons financeiros excessivos.
    while not net_proceeds(lot,tick,settlement,fees).meets(lot,target):
        tick += D('.01')
    while tick > D('.01') and net_proceeds(lot,tick-D('.01'),settlement,fees).meets(lot,target):
        tick -= D('.01')
    return PriceTarget(continuous,tick,desired)
