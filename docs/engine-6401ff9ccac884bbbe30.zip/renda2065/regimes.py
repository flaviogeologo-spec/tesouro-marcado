"""Descrição causal de patamares: quantis usam apenas observações anteriores.

Os rótulos são diagnósticos, nunca probabilidades ou garantias de reversão.
"""
from __future__ import annotations
from datetime import date,timedelta
from collections import defaultdict
import numpy as np
from .calendar_rules import FinancialCalendar
from .models import ValidationError


def describe_regimes(quotes,*,as_of:date,entry:float=.0717,window:int=63):
    if window not in (21,63,126,252):raise ValidationError('E-WINDOW','Janela: 21, 63, 126 ou 252 observações.')
    qs=sorted((q for q in quotes if q.observation_date<=as_of and q.buy_yield is not None),key=lambda q:q.observation_date)
    if not qs:raise ValidationError('E-DATA','Não há taxas válidas até a referência selecionada.')
    cal=FinancialCalendar(knowledge_date=as_of);ys=np.array([q.buy_yield for q in qs]);rows=[];changes=[]
    active='insuficiente';candidate=None;count=0;entries=0;episodes=0;in_episode=False;mature=0
    months=defaultdict(list)
    for i,q in enumerate(qs):
        history=ys[max(0,i-window):i];recent=ys[max(0,i-21):i];prior=ys[max(0,i-42):max(0,i-21)]
        med=float(np.median(history)) if len(history)>=min(21,window) else None
        lo=float(np.quantile(history,.2)) if med is not None else None;hi=float(np.quantile(history,.8)) if med is not None else None
        drift=float(np.median(recent)-np.median(prior)) if len(prior)==21 else None
        width=hi-lo if med is not None else None
        label='insuficiente'
        if drift is not None and width is not None:
            tolerance=max(.001,width*.5)
            label='alta de patamar' if drift>tolerance else 'queda de patamar' if drift<-tolerance else 'lateralidade relativa'
        if label==candidate:count+=1
        else:candidate=label;count=1
        if count>=5 and label!=active:
            active=label;changes.append({'date':q.observation_date.isoformat(),'state':active,'confirmation_sessions':5})
        signals=q.buy_yield>=entry
        if signals:
            entries+=1
            if not in_episode:episodes+=1
            lock=cal.next_session(q.observation_date)+timedelta(days=60)
            if cal.next_session(lock,include=True)<=qs[-1].observation_date:mature+=1
        in_episode=signals
        med63=float(np.median(ys[max(0,i-63):i])) if i>=21 else None
        rows.append({'date':q.observation_date.isoformat(),'yield':q.buy_yield,'median':med,'median63':med63,'lower':lo,'upper':hi,'drift21':drift,'state':active,'percentile':float(np.mean(history<=q.buy_yield)) if len(history)>=21 else None})
        months[q.observation_date.strftime('%Y-%m')].append(q.buy_yield)
    monthly=[{'month':m,'count':len(v),'median':float(np.median(v)),'min':min(v),'max':max(v),'p20':float(np.quantile(v,.2)),'p80':float(np.quantile(v,.8))} for m,v in sorted(months.items())]
    last=rows[-1]
    return {'rows':rows,'monthly':monthly,'changes':changes,'summary':{'observations':len(qs),'start':qs[0].observation_date.isoformat(),'end':qs[-1].observation_date.isoformat(),'last_yield':float(ys[-1]),'median':last['median'],'lower':last['lower'],'upper':last['upper'],'state':last['state'],'eligible_entry_dates':entries,'mature_entry_dates':mature,'entry_runs':episodes,'over_7_5':int(sum(ys>.075)),'max_yield':float(max(ys))},
      'warnings':['Janelas incluem somente observações anteriores; a confirmação de 5 sessões ocorre na data exibida, sem retroagir.','Datas de entrada sobrepostas não são operações independentes. Contagens não são probabilidades futuras.','Patamar é diagnóstico descritivo; não altera o alvo ativo.']}


def signal_windows(quotes,lot,target,fees,calendar):
    from .tax_and_fees import net_proceeds
    rows=[];current=None
    for q in sorted(quotes,key=lambda x:x.observation_date):
        if q.observation_date<lot.settlement_date or q.redemption_pu is None:continue
        ok=calendar.eligible(lot,q.observation_date) and net_proceeds(lot,q.redemption_pu,q.observation_date,fees).meets(lot,target)
        if ok:
            if current is None:current={'start':q.observation_date.isoformat(),'end':q.observation_date.isoformat(),'observations':0}
            elif calendar.next_session(date.fromisoformat(current['end']))!=q.observation_date:
                rows.append(current);current={'start':q.observation_date.isoformat(),'end':q.observation_date.isoformat(),'observations':0}
            current['end']=q.observation_date.isoformat();current['observations']+=1
        elif current:rows.append(current);current=None
    if current:rows.append(current)
    return rows
