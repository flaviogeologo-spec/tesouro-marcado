"""Resolução explícita de duplicatas, sem perder os bytes da fonte original."""
import csv,io
from datetime import datetime
from .models import ValidationError
from .csv_loader import normalized

def inspect_duplicates(raw):
    if len(raw)>25*1024*1024:raise ValidationError('E-SIZE','Para resolver conflitos, filtre o RendA+ 2065 em arquivo de até 25 MB.')
    try:text=raw.decode('utf-8-sig')
    except UnicodeDecodeError:text=raw.decode('cp1252')
    reader=csv.DictReader(io.StringIO(text),delimiter=';');groups={};selected=[]
    if not reader.fieldnames or not {'Tipo Titulo','Data Vencimento','Data Base'}<=set(reader.fieldnames):raise ValidationError('E-SCHEMA','Cabeçalho Tesouro não encontrado.')
    for row in reader:
        if normalized(row.get('Tipo Titulo',''))!='tesouro renda+ aposentadoria extra' or row.get('Data Vencimento')!='15/12/2084':continue
        try:datetime.strptime(row['Data Base'],'%d/%m/%Y')
        except ValueError as exc:raise ValidationError('E-DATE','Data inválida no arquivo.') from exc
        selected.append(row);items=groups.setdefault(row['Data Base'],[])
        if row not in items:items.append(row)
    if not selected:raise ValidationError('E-INSTRUMENT','Não contém o RendA+ 2065 (2084).')
    conflicts=[{'date':d,'rows':r} for d,r in groups.items() if len(r)>1]
    return {'fieldnames':reader.fieldnames,'groups':conflicts,'rows_by_date':groups}

def resolve_duplicates(preview,choices):
    if not isinstance(choices,dict):raise ValidationError('E-CONFLICT','Selecione uma linha de cada data conflitante.')
    rows=[]
    for day,values in preview['rows_by_date'].items():
        if len(values)==1:rows.append(values[0]);continue
        choice=choices.get(day)
        if not isinstance(choice,int) or isinstance(choice,bool) or not 0<=choice<len(values):raise ValidationError('E-CONFLICT',f'Selecione explicitamente uma linha para {day}.')
        rows.append(values[choice])
    buf=io.StringIO();writer=csv.DictWriter(buf,fieldnames=preview['fieldnames'],delimiter=';',lineterminator='\n');writer.writeheader();writer.writerows(rows)
    return buf.getvalue().encode('utf-8-sig')
