"""Cenários de indexação e benchmark de caixa, com unidades e cobertura explícitas.

A série diária usa fração ao dia (entrada em percentual). Um CDB hipotético usa
IR regressivo e IOF somente no lucro ao resgatar, sem come-cotas. Não é um fundo.
"""
from __future__ import annotations
from dataclasses import dataclass
from datetime import date, timedelta
from bisect import bisect_right
import calendar as month_calendar
import csv, io, json, math
from urllib.request import urlopen, Request
from .models import ValidationError
from .formatting import parse_number
from .calendar_rules import FinancialCalendar
from .tax_and_fees import tax_rate

IOF = (100,96,93,90,86,83,80,76,73,70,66,63,60,56,53,50,46,43,40,36,33,30,26,23,20,16,13,10,6,3,0)


def parse_monthly_path(text: str) -> tuple[tuple[str,float], ...]:
    """Linhas AAAA-MM;percentual mensal. As lacunas usam a hipótese anual exposta."""
    if not str(text).strip(): return ()
    if len(str(text))>32000: raise ValidationError('E-SIZE','Trajetória mensal muito extensa.')
    rows={}
    for line in str(text).strip().splitlines():
        if not line.strip(): continue
        parts=line.split(';')
        if len(parts)!=2: raise ValidationError('E-PROJECTION','Use AAAA-MM;variação mensal em %.')
        key=parts[0].strip()
        try: day=date.fromisoformat(key+'-01')
        except ValueError as exc: raise ValidationError('E-PROJECTION','Mês inválido; use AAAA-MM.') from exc
        if key in rows: raise ValidationError('E-PROJECTION','Mês duplicado na inflação.')
        rate=float(parse_number(parts[1],'inflação mensal')/100)
        if not math.isfinite(rate) or not -.5<rate<1: raise ValidationError('E-PROJECTION','Inflação mensal fora do domínio (-50%,100%).')
        rows[key]=rate
    return tuple(sorted(rows.items()))


def monthly_projection(anchor, day:date, annual:float, path=()) -> float:
    if not math.isfinite(annual) or annual<=-1: raise ValidationError('E-PROJECTION','Inflação anual inválida.')
    if not path: return anchor.vni * math.exp(math.log1p(annual)*(day-anchor.valuation_date).days/365)
    if day<anchor.valuation_date: raise ValidationError('E-ANCHOR','Não projetar VNI para trás com informação futura.')
    mapping=dict(path);t=anchor.valuation_date;log_factor=0.
    while t<day:
        first=t.replace(day=1)
        nxt=(first.replace(year=first.year+1,month=1) if first.month==12 else first.replace(month=first.month+1))
        stop=min(day,nxt);key=t.strftime('%Y-%m')
        if key in mapping:
            log_factor+=math.log1p(mapping[key])*(stop-t).days/(nxt-first).days
        else: log_factor+=math.log1p(annual)*(stop-t).days/365
        t=stop
    return anchor.vni*math.exp(log_factor)


def parse_daily_rates(content: str | bytes) -> tuple[tuple[date,float], ...]:
    if isinstance(content,bytes):
        if len(content)>4_000_000: raise ValidationError('E-SIZE','Série de caixa excede 4 MB.')
        try:content=content.decode('utf-8-sig')
        except UnicodeDecodeError as exc:raise ValidationError('E-DATA','Série de caixa precisa usar UTF-8.') from exc
    elif isinstance(content,str):
        try:size=len(content.encode('utf-8'))
        except UnicodeEncodeError as exc:raise ValidationError('E-DATA','Série de caixa contém texto Unicode inválido.') from exc
        if size>4_000_000: raise ValidationError('E-SIZE','Série de caixa excede 4 MB.')
    else:raise ValidationError('E-DATA','Série diária precisa ser texto CSV ou JSON.')
    found={}
    if content.lstrip().startswith(('[','{')):
        try:raw=json.loads(content)
        except (json.JSONDecodeError,ValueError) as exc:raise ValidationError('E-DATA','JSON de taxas diárias inválido.') from exc
        if not isinstance(raw,list): raise ValidationError('E-DATA','Série diária precisa ser uma lista.')
        if any(not isinstance(row,dict) for row in raw):raise ValidationError('E-DATA','Cada taxa diária precisa ser um objeto JSON.')
        iterable=((r.get('data',r.get('date')),r.get('valor',r.get('rate_percent'))) for r in raw)
    else:
        raw=list(csv.reader(io.StringIO(content),delimiter=';'))
        iterable=(r[:2] for r in raw if len(r)>=2 and r[0].strip().lower() not in ('data','date'))
    for text,value in iterable:
        try:
            s=str(text).strip();d=date.fromisoformat(s) if '-' in s else date(*map(int,s.split('/')[::-1]))
            rate=float(parse_number(str(value),'taxa diária')/100)
        except (ValueError,TypeError) as exc: raise ValidationError('E-DATA','Data ou taxa inválida no benchmark.') from exc
        if not math.isfinite(rate) or not -.1<rate<.1: raise ValidationError('E-DATA','A taxa diária deve estar em percentual ao dia, não anual.')
        if d in found and found[d]!=rate: raise ValidationError('E-DUPLICATE','Taxas de caixa conflitantes na mesma data.')
        found[d]=rate
    if not found: raise ValidationError('E-DATA','Série de caixa vazia.')
    return tuple(sorted(found.items()))


@dataclass
class CashBenchmark:
    mode: str='fixed_net'
    annual: float=.10
    rows: tuple=()
    participation: float=1.
    ir: bool=True
    iof: bool=True
    annual_fee: float=0.
    source: str='Hipótese de caixa líquido constante'

    def __post_init__(self):
        if self.mode not in ('fixed_net','daily_gross','daily_net'): raise ValidationError('E-CASH','Modalidade de caixa desconhecida.')
        if not all(math.isfinite(x) for x in (self.annual,self.participation,self.annual_fee)) or not -1<self.annual<=2 or not 0<self.participation<=3 or not 0<=self.annual_fee<.2:
            raise ValidationError('E-CASH','Premissas de caixa fora do domínio.')
        self._dates=[r[0] for r in self.rows];self._rates=dict(self.rows)
        if self.mode!='fixed_net' and (not self.rows or len(self._rates)!=len(self.rows) or self._dates!=sorted(self._dates)):
            raise ValidationError('E-CASH','Importe uma série diária ordenada e sem duplicatas.')
        self._calendar=FinancialCalendar()
        self._logs=[0.]
        for _,r in self.rows:self._logs.append(self._logs[-1]+math.log1p(r*self.participation))

    def ensure_coverage(self,start:date,end:date):
        if self.mode=='fixed_net' or start==end:return
        if not self.rows or start<self._dates[0] or end>self._dates[-1]+timedelta(days=3):
            raise ValidationError('E-CASH-COVERAGE','O benchmark não cobre o intervalo. Não há preenchimento automático de juros faltantes.')
        t=start+timedelta(days=1)
        while t<=end:
            if self._calendar.is_financial(t) and t not in self._rates:
                raise ValidationError('E-CASH-COVERAGE',f'Falta taxa diária de caixa em {t:%d/%m/%Y}.')
            t+=timedelta(days=1)

    def gross_factor(self,start:date,end:date,*,checked=False)->float:
        if end<start:raise ValidationError('E-DATE','Prazo de caixa negativo.')
        if self.mode=='fixed_net':return (1+self.annual)**((end-start).days/365)
        if not checked:self.ensure_coverage(start,end)
        lo=bisect_right(self._dates,start);hi=bisect_right(self._dates,end)
        return math.exp(self._logs[hi]-self._logs[lo])

    def factor(self,start:date,end:date,*,checked=False)->float:
        gross=self.gross_factor(start,end,checked=checked)
        if self.mode=='fixed_net':return gross
        days=(end-start).days
        # Custo adicional anual sobre o bruto; não reduz a base de IR/IOF.
        cost=gross*self.annual_fee*days/365
        net=gross-cost
        if self.mode=='daily_gross' and gross>1:
            gain=gross-1
            iof=gain*(IOF[min(days,30)]/100) if self.iof else 0
            ir=(gain-iof)*float(tax_rate(days)) if self.ir else 0
            net-=iof+ir
        if not math.isfinite(net) or net<=0:
            raise ValidationError('E-CASH','Os custos de caixa eliminam o capital neste horizonte; revise prazo e custos informados.')
        return net

    @property
    def label(self):
        if self.mode=='fixed_net':return f'Caixa hipotético líquido: {self.annual*100:g}% a.a.'
        return f'{self.participation*100:g}% da série diária — '+('CDB hipotético com tributos no resgate' if self.mode=='daily_gross' else 'retornos líquidos informados')


def download_cdi(start:date,end:date)->bytes:
    if end<start or (end-start).days>3652: raise ValidationError('E-DATE','Selecione até dez anos por consulta CDI.')
    url=f'https://api.bcb.gov.br/dados/serie/bcdata.sgs.12/dados?formato=json&dataInicial={start:%d/%m/%Y}&dataFinal={end:%d/%m/%Y}'
    try:
        req=Request(url,headers={'User-Agent':'Renda2065-local/3.0'})
        from urllib.request import build_opener,HTTPRedirectHandler
        from urllib.parse import urlparse
        class BcbRedirect(HTTPRedirectHandler):
            def redirect_request(self,req,fp,code,msg,headers,newurl):
                u=urlparse(newurl)
                if u.scheme!='https' or u.hostname!='api.bcb.gov.br':raise ValueError('redirect')
                return super().redirect_request(req,fp,code,msg,headers,newurl)
        with build_opener(BcbRedirect()).open(req,timeout=18) as response:
            if not response.url.startswith('https://api.bcb.gov.br/'):raise ValueError('redirect')
            raw=response.read(4_000_001)
        parse_daily_rates(raw)
        return raw
    except Exception as exc:
        raise ValidationError('E-NETWORK','Não foi possível obter CDI no BCB. A base anterior foi preservada; importe CSV/JSON diário.') from exc
