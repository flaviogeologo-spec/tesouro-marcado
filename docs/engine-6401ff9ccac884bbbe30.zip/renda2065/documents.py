"""Extração assistida: nenhum campo extraído vira operação sem conferência."""
from __future__ import annotations
from datetime import date
from io import BytesIO
import csv, io, re, unicodedata
from .models import ValidationError
from .formatting import parse_number


def parse_purchase_text(text:str):
    if len(text)>200000:raise ValidationError('E-SIZE','Texto maior que 200 mil caracteres.')
    normalized=unicodedata.normalize('NFKD',text).encode('ascii','ignore').decode().lower()
    fields={};warnings=[]
    aliases={'trade':r'(?:data\s+(?:da\s+)?compra|data\s+(?:da\s+)?operacao|negociacao)',
             'settlement':r'(?:data\s+(?:de\s+)?)?liquidacao',
             'pu':r'(?:preco\s+unitario|pu(?:\s+de\s+compra)?)',
             'quantity':r'(?:quantidade|qtd)',
             'entry_yield':r'(?:taxa(?:\s+(?:de\s+)?compra)?)'}
    for key,pattern in aliases.items():
        matches=re.findall(pattern+r'\s*[:=]\s*(?:r\$\s*)?([0-9.,/\-]+)',normalized)
        if not matches:continue
        if len(set(matches))>1:warnings.append(f'Múltiplos valores para {key}; conferir.');continue
        val=matches[0]
        try:
            if key in ('trade','settlement'):
                d=date.fromisoformat(val) if '-' in val else date(*map(int,val.split('/')[::-1]));fields[key]=d.isoformat()
            else:fields[key]=str(parse_number(val,key))
        except (ValueError,ValidationError):warnings.append(f'Não foi possível interpretar {key}.')
    if not fields:warnings.append('Nenhum campo reconhecido. Use rótulos Data da compra, Liquidação, Quantidade, Preço unitário e Taxa.')
    return {'candidates':fields,'warnings':warnings,'requires_confirmation':True,'note':'Extração de texto; confira com o comprovante antes de aplicar. Não autenticamos o documento.'}


def read_document(raw:bytes,filename:str):
    if len(raw)>10*1024*1024:raise ValidationError('E-SIZE','Documento excede 10 MB.')
    name=str(filename).replace('\\','/').rsplit('/',1)[-1]
    extension='.'+name.rsplit('.',1)[-1].lower() if '.' in name else ''
    if extension not in {'.pdf','.txt','.csv'}:
        raise ValidationError('E-FILE-TYPE','Use um arquivo PDF, TXT ou CSV; o conteúdo não foi aplicado.')
    if extension=='.pdf':
        try:
            from pypdf import PdfReader
            doc=PdfReader(BytesIO(raw))
            if doc.is_encrypted:raise ValidationError('E-PDF','Documento protegido; cole os dados manualmente, sem informar senha ao app.')
            if len(doc.pages)>30:raise ValidationError('E-SIZE','Documento com mais de 30 páginas; selecione o comprovante.')
            text='\n'.join(page.extract_text() or '' for page in doc.pages)
        except ImportError as exc:raise ValidationError('E-DEPENDENCY','Instale pypdf ou cole o texto do comprovante.') from exc
        except ValidationError:raise
        except Exception as exc:raise ValidationError('E-PDF','Não foi possível ler o PDF. Use texto/CSV; nenhuma operação foi gravada.') from exc
        if not text.strip():raise ValidationError('E-PDF-SCAN','PDF sem texto extraível; não fazemos OCR. Cole ou preencha os dados.')
    else:
        try:text=raw.decode('utf-8-sig')
        except UnicodeDecodeError:
            try:text=raw.decode('cp1252')
            except UnicodeDecodeError as exc:raise ValidationError('E-ENCODING','Documento texto deve usar UTF-8 ou Windows-1252.') from exc
    return parse_purchase_text(text)


def parse_intraday(raw:bytes):
    """CSV: Data hora;PU resgate;Taxa resgate (%);Fonte;Vencimento."""
    from datetime import datetime
    from zoneinfo import ZoneInfo
    if len(raw)>4*1024*1024:raise ValidationError('E-SIZE','Cotações intradiárias excedem 4 MB.')
    try:text=raw.decode('utf-8-sig')
    except UnicodeDecodeError as exc:raise ValidationError('E-ENCODING','Cotações intradiárias precisam usar UTF-8.') from exc
    rows=list(csv.DictReader(io.StringIO(text),delimiter=';'));out=[];seen=set()
    for row in rows:
        try:
            stamp=datetime.fromisoformat(row['Data hora'])
            if stamp.tzinfo is None:stamp=stamp.replace(tzinfo=ZoneInfo('America/Sao_Paulo'))
            maturity=row.get('Vencimento','')
            if maturity not in ('15/12/2084','2084-12-15'):raise ValidationError('E-INSTRUMENT','Informe vencimento final 15/12/2084 em todas as cotações.')
            source=row.get('Fonte','').strip()
            if not source:raise ValidationError('E-SOURCE','Origem obrigatória para cada cotação.')
            pu=parse_number(row['PU resgate'],'PU');rate=parse_number(row['Taxa resgate (%)'],'taxa')/100
            if pu<=0:raise ValidationError('E-AMOUNT','PU deve ser positivo.')
        except (KeyError,ValueError) as exc:raise ValidationError('E-SCHEMA','Use Data hora;PU resgate;Taxa resgate (%);Fonte;Vencimento.') from exc
        key=stamp.isoformat()
        if key in seen:raise ValidationError('E-DUPLICATE','Timestamp duplicado. Resolva a fonte antes de importar.')
        seen.add(key);out.append({'observed_at':key,'pu':str(pu),'yield':float(rate),'source':source})
    if not out:raise ValidationError('E-DATA','Nenhuma cotação intradiária.')
    return sorted(out,key=lambda x:x['observed_at'])
