"""One informed acquisition, estimated cash-out and fixed-quantity rate shocks."""
from datetime import date, timedelta
from decimal import Decimal, localcontext
from hashlib import sha256
from itertools import permutations, product, repeat
import re

from .calendar_rules import FinancialCalendar
from .historical_evolution import TITLES, _day, _number, _fail, _ipca, evaluate_history
from .market_sim.contracts import Instrument, ProductFamily, Entry, Exit, Scenario, Side, AsOf, ScenarioIntent
from .market_sim.operation import OperationRequest, calculate_operation
from .market_sim.nominal_index import calculate_nominal_index
from .market_sim.policies import round_money
from .market_sim.principal import price_principal, business_days_to_maturity
from .market_sim.renda_plus import price_renda_plus, RendaPlusSeries
from .market_sim.provenance import EvidenceMode, Quality
from .models import ValidationError
from .storage import safe_json

D = Decimal


def normalize_actual_purchase(raw, *, today):
    allowed = {'title_id', 'date', 'yield', 'budget', 'pu', 'quantity', 'settlement_date'}
    if (not isinstance(raw, dict) or set(raw) - allowed
            or not isinstance(raw.get('title_id'), str) or raw['title_id'] not in TITLES):
        _fail('Informe os dados de um dos dois títulos disponíveis.')
    order, settlement = _day(raw.get('date')), _day(raw.get('settlement_date'))
    quantity, pu, rate = actual_purchase_amounts(raw)
    validate_actual_purchase_dates(order, settlement, raw['title_id'], today=today)
    return {'title_id': raw['title_id'], 'date': order.isoformat(), 'settlement_date': settlement.isoformat(),
            'quantity': str(quantity), 'pu': str(pu), 'yield': str(rate), 'budget': None}


def validate_actual_purchase_dates(order, settlement, title_id, *, today):
    calendar = FinancialCalendar(knowledge_date=today)
    horizon = date(2050, 8, 15) if title_id.startswith('IPCA') else date(2065, 1, 15)
    if (order < date(2000, 1, 1) or order > today or settlement > today or settlement >= horizon
            or settlement < calendar.next_session(order) or not calendar.is_session(settlement)):
        _fail('A liquidação do comprovante deve ser uma sessão após a compra, até hoje e antes do vencimento/início da renda.')


def actual_purchase_amounts(raw):
    quantity, pu, rate = _number(raw.get('quantity')), _number(raw.get('pu')), _number(raw.get('yield'), positive=False)
    if quantity % D('.01') or pu < D('.01') or not -1 < rate <= 1 or raw.get('budget') is not None:
        _fail('Informe quantidade em múltiplos de 0,01, PU a partir de R$0,01 e taxa válida; não combine quantidade real com orçamento.')
    with localcontext() as ctx:
        ctx.prec = 40
        if round_money(quantity * pu) <= 0:
            _fail('A posição precisa ter valor positivo em centavos.')
    return quantity, pu, rate


def normalize_costs(raw):
    if raw is None:
        raw = {}
    if not isinstance(raw, dict) or set(raw) - {'entry_fee', 'exit_fee', 'tax_cost_basis'}:
        _fail('Custos aceitam somente despesa da compra, despesa da venda e base fiscal.')
    result = {}
    for key in ('entry_fee', 'exit_fee', 'tax_cost_basis'):
        value = raw.get(key, '0' if key != 'tax_cost_basis' else None)
        value = None if value is None and key == 'tax_cost_basis' else _number(value, positive=False)
        if value is not None and (value < 0 or value != round_money(value)):
            _fail('Custos e base fiscal devem ser não negativos, com até duas casas decimais.')
        result[key] = value
    return result


def _instrument(title_id):
    if title_id == 'IPCA_PRINCIPAL_2050':
        return Instrument(ProductFamily.IPCA_PRINCIPAL, title_id, date(2050, 8, 15))
    return Instrument(ProductFamily.RENDA_PLUS, title_id, date(2084, 12, 15), date(2065, 1, 15), date(2065, 1, 15))


def _cash(result, point, gross, costs, calendar, today, custody_coverage=None):
    purchase = result['purchase']
    day, settlement = _day(point['date']), _day(purchase['settlement_date'])
    if gross is None or day <= settlement:
        return {'status': 'UNAVAILABLE', 'net_redemption': None, 'reason': point['status']}
    if D(gross) <= 0:
        return {'status': 'UNAVAILABLE', 'net_redemption': None, 'reason': 'Valor bruto inferior ao centavo após o arredondamento; líquido indisponível.'}
    instrument = _instrument(result['title_id'])
    quantity, entry_pu = D(purchase['quantity']), D(purchase['pu'])
    scenario = Scenario(instrument,
                        Entry(instrument.instrument_id, _day(purchase['date']), settlement, quantity, entry_pu),
                        Exit(instrument.instrument_id, day, day, Side.SELL, D(gross) / quantity),
                        AsOf(today, EvidenceMode.EX_POST), ScenarioIntent.HYPOTHETICAL)
    operation = calculate_operation(OperationRequest(scenario, entry_pu, D(gross) / quantity,
                    tax_cost_basis=costs['tax_cost_basis'], entry_expense_paid=costs['entry_fee'],
                    exit_expense=costs['exit_fee'], calendar=calendar,
                    custody_value_days=None if custody_coverage is None else D(custody_coverage['position_value_days'])))
    fields = ('gross_redemption', 'iof', 'income_tax', 'custody', 'exit_expense', 'net_redemption', 'nominal_profit')
    cash = {key: None if getattr(operation, key) is None else str(getattr(operation, key)) for key in fields}
    cash.update(status=operation.status, quality=operation.quality.value, holding_days=operation.holding_days,
                policies=list(operation.policies))
    if custody_coverage is not None:
        cash['custody_coverage'] = custody_coverage
    return cash


def _principal_custody_path(points, market, market_dates, settlement, quantity, calendar, today):
    """Accumulate R$×days once, from settlement inclusive to each exit exclusive."""
    cursor = settlement
    last_base = None
    observed_days = carried_days = missing_days = future_days = 0
    first_gap = last_gap = None
    covered_value_days = D(0)
    for point in points:
        exit_day = _day(point['date'])
        while cursor < exit_day:
            quote = market.get(cursor)
            if cursor > today:
                future_days += 1
            elif quote is not None and quote['base'] is not None:
                last_base = quote['base']
                covered_value_days += quantity * last_base
                observed_days += 1
            elif last_base is not None and cursor not in market_dates and not calendar.is_session(cursor):
                covered_value_days += quantity * last_base
                carried_days += 1
            else:
                last_base = None
                missing_days += 1
                last_gap = cursor.isoformat()
                first_gap = first_gap or last_gap
            cursor += timedelta(days=1)
        gross = point['market']
        if gross is None or exit_day <= settlement:
            yield None
            continue
        fallback_value_days = D(gross) * (missing_days + future_days)
        yield {
            'observed_days': observed_days,
            'carried_days': carried_days,
            'missing_days': missing_days,
            'future_days': future_days,
            'first_gap': first_gap,
            'last_gap': last_gap,
            'fallback_value': gross if missing_days or future_days else None,
            'position_value_days': str(covered_value_days + fallback_value_days),
            'pre_netting_settlement': settlement < date(2024, 12, 31),
        }


def _reconciliation(raw, result, today):
    if raw is None:
        return None
    if not isinstance(raw, dict) or set(raw) != {'date', 'net_redemption'}:
        _fail('A conferência exige data e líquido informado pela instituição.')
    day, net = _day(raw['date']), _number(raw['net_redemption'], positive=False)
    if day > today or net < 0 or net != round_money(net):
        _fail('Informe uma data passada e um líquido não negativo em centavos.')
    point = next((p for p in result['points'] if p['date'] == day.isoformat()), None)
    estimated = None if point is None else point.get('cash', {}).get('net_redemption')
    return {'date': day.isoformat(), 'informed_net': str(net), 'estimated_net': estimated,
            'difference': None if estimated is None else str(D(estimated) - net),
            'method': 'ESTIMATED_MINUS_INFORMED_NO_REPLACEMENT',
            'custody_coverage': None if point is None else point.get('cash', {}).get('custody_coverage'),
            'status': 'COMPARABLE' if estimated is not None else 'UNAVAILABLE'}


def enrich_position(result, body, *, today, market, market_dates, include_cash=True):
    costs = normalize_costs(body.get('costs'))
    calendar = FinancialCalendar(knowledge_date=today)
    quantity = D(result['purchase']['quantity'])
    principal = result['title_id'] == 'IPCA_PRINCIPAL_2050'
    custody_path = _principal_custody_path(
        result['points'], market, set(market_dates), _day(result['purchase']['settlement_date']), quantity, calendar, today
    ) if principal and include_cash else repeat(None)
    for point in result['points']:
        quote = market.get(_day(point['date']))
        point['marked_value'] = None if quote is None or quote['base'] is None else str(round_money(quantity * quote['base']))
        if include_cash:
            point['cash'] = _cash(result, point, point['market'], costs, calendar, today, next(custody_path))
    result['costs'] = {key: None if value is None else str(value) for key, value in costs.items()}
    result['cash_method'] = {
        'version': 'CANONICAL_OPERATION_ESTIMATED_CUSTODY_v2',
        'note': (
            'Custódia estimada pelo PU Base disponível, desde a liquidação até a véspera da saída. '
            'Aproximação diária com divisor 365 e arredondamento no total. '
            'Cobranças já pagas e arredondamentos da instituição exigem conferência no extrato.'
            if principal else
            'Custódia estimada sobre o valor de resgate, pela faixa de prazo do RendA+.'
        ) + ' A base fiscal padrão é o custo dos títulos.',
        'marked_value_note': 'Quantidade × PU Base oficial: valor indicativo de extrato, não caixa de resgate. Ausente nas datas projetadas.',
        'settlement_note': 'Venda matinal D+0, sujeita a sessão, horário, calendário e liberação da instituição.',
    }
    result['reconciliation'] = _reconciliation(body.get('reconciliation'), result, today)


def _unit_price_factor(title_id, day, rate, calendar):
    if title_id == 'IPCA_PRINCIPAL_2050':
        days = business_days_to_maturity(day, date(2050, 8, 15), calendar)
        return price_principal(D(1), rate, days).continuous_pu
    series = RendaPlusSeries.for_conversion_year(2065)
    return price_renda_plus(series, day, D(1), rate, calendar, Quality.HYPOTHETICAL).continuous_pu


def evaluate_position_risk(body, *, today=None):
    today = today or date.today()
    if not isinstance(body, dict) or not isinstance(body.get('risk'), dict):
        _fail('Informe a data e os choques de taxa para consultar o risco.')
    risk = body['risk']
    if set(risk) - {'date', 'shocks_bps', 'loss_limit'}:
        _fail('Campos de risco inválidos.')
    day = _day(risk.get('date'))
    shocks = risk.get('shocks_bps')
    if (not isinstance(shocks, list) or not 1 <= len(shocks) <= 21
            or any(type(value) is not int or abs(value) > 1000 for value in shocks) or len(set(shocks)) != len(shocks)
            or len(set(shocks) | {0}) > 21):
        _fail('Use até 21 choques distintos, inteiros, entre −1000 e 1000 pontos-base.')
    limit = risk.get('loss_limit')
    limit = None if limit is None else _number(limit, positive=False)
    if limit is not None and (limit < 0 or limit != round_money(limit)):
        _fail('O limite de queda deve ser não negativo e informado em centavos.')
    request = {key: value for key, value in body.items() if key != 'risk'}
    request['position'] = True
    result = evaluate_history(request, today=today, dates=(day,), allow_projected=True)
    if result['display'] != 'BRL':
        _fail('Informe o valor investido ou a quantidade real para consultar o risco em reais.')
    point = next((p for p in result['points'] if p['date'] == day.isoformat()), None)
    if point is None:
        _fail('Escolha uma das datas calculadas para a consulta de risco.')
    response = {'date': day.isoformat(), 'purchase': result['purchase'], 'title_id': result['title_id'], 'label': result['label'],
                'method': 'FIXED_QUANTITY_CALIBRATED_CONTINUOUS_REPRICING_v1', 'loss_limit': None if limit is None else str(limit),
                'base_gross': point['market'], 'base_rate': point['market_yield'], 'base_cash': point['cash'],
                'base_market_kind': point.get('market_kind', 'MISSING' if point['market'] is None else 'OBSERVED'),
                'rows': [], 'sources': result['sources'],
                'note': 'Choques hipotéticos na mesma data e inflação, para a mesma quantidade. Queda relativa ao valor bruto sem choque nessa data, não ao custo da compra. Não são probabilidades. Líquido usa custódia estimada.'}
    if point['market'] is None or point['market_yield'] is None or D(point['market']) <= 0:
        reason = point['status'] if point['market'] is None else 'Sem taxa de venda correspondente nesta data.' if point['market_yield'] is None else 'Valor bruto inferior ao centavo; reprecificação indisponível.'
        response.update(status='UNAVAILABLE', reason=reason)
        return response
    calendar = FinancialCalendar(knowledge_date=today)
    costs = normalize_costs(body.get('costs'))
    custody_coverage = point['cash'].get('custody_coverage')
    if custody_coverage is not None:
        response['note'] += ' A trajetória de custódia do IPCA+ fica fixa nos choques desta data.'

    def model(rate):
        return _unit_price_factor(result['title_id'], day, rate, calendar)
    with localcontext() as ctx:
        ctx.prec = 40
        base_rate, base_gross = D(point['market_yield']), D(point['market'])
        if not D('-.95') <= base_rate <= 1:
            response.update(status='UNAVAILABLE', reason='Taxa de referência fora do domínio de reprecificação.')
            return response
        try:
            base_model = model(base_rate)
        except (ArithmeticError, ValueError):
            response.update(status='UNAVAILABLE', reason='A reprecificação excede o domínio numérico do modelo.')
            return response
        for shock in sorted(set(shocks) | {0}):
            rate = base_rate + D(shock) / D(10000)
            row = {'shock_bps': shock, 'rate': str(rate), 'gross': None, 'net': None, 'gross_change': None,
                   'net_change': None, 'gross_change_percent': None, 'limit_exceeded': None, 'status': 'OUTSIDE_DOMAIN'}
            if D('-.95') <= rate <= 1:
                try:
                    gross = base_gross if shock == 0 else round_money(base_gross * model(rate) / base_model)
                    if gross <= 0:
                        raise ValueError('Preço inferior ao centavo.')
                    cash = _cash(result, point, gross, costs, calendar, today, custody_coverage)
                except (ArithmeticError, ValueError):
                    row.update(status='UNAVAILABLE', reason='Choque fora da precisão monetária do modelo.')
                    response['rows'].append(row)
                    continue
                change = gross - base_gross
                net, base_net = cash['net_redemption'], point['cash']['net_redemption']
                row.update(gross=str(gross), net=net, gross_change=str(change),
                           net_change=None if net is None or base_net is None else str(D(net) - D(base_net)),
                           gross_change_percent=str(change / base_gross * 100),
                           limit_exceeded=None if limit is None else change < -limit, status='AVAILABLE', cash=cash)
            response['rows'].append(row)
    response['status'] = 'AVAILABLE'
    return response


def evaluate_position_change(body, *, today=None):
    """Attribute observed gross sale change to three modeled factors and a residual."""
    today = today or date.today()
    comparison = body.get('comparison') if isinstance(body, dict) else None
    if not isinstance(comparison, dict) or set(comparison) != {'start_date', 'end_date'}:
        _fail('Escolha duas datas para explicar a variação da posição.')
    start, end = (_day(comparison[key]) for key in ('start_date', 'end_date'))
    if not start < end <= today:
        _fail('Escolha duas datas históricas em ordem crescente.')
    request = {key: value for key, value in body.items() if key != 'comparison'}
    result = evaluate_history(request, today=today, dates=(start, end), include_cash=False)
    if result['display'] != 'BRL':
        _fail('Informe a quantidade ou o valor investido para explicar a variação em reais.')
    points = {point['date']: point for point in result['points']}
    if start.isoformat() not in points or end.isoformat() not in points:
        _fail('Escolha duas datas da evolução calculada.')
    first, last = (points[day.isoformat()] for day in (start, end))
    response = {
        'start_date': start.isoformat(), 'end_date': end.isoformat(),
        'title_id': result['title_id'], 'quantity': result['purchase']['quantity'],
        'start_gross': first['market'], 'end_gross': last['market'], 'observed_change': None,
        'start_rate': first['market_yield'], 'end_rate': last['market_yield'],
        'status': 'UNAVAILABLE', 'effects': None, 'residual': None,
        'method': 'CALIBRATED_GROSS_CHANGE_SHAPLEY_3_v1', 'sources': result['sources'],
        'note': (
            'Variação da venda bruta para a mesma quantidade. O modelo parte do primeiro preço '
            'observado e distribui as interações pela média das seis ordens de cálculo. '
            'O residual inclui diferenças entre preço observado e modelo, como projeção de IPCA na cotação, '
            'spread e arredondamentos.'
        ),
    }
    if any(point['market'] is None or D(point['market']) <= 0 or point.get('market_kind') == 'HYPOTHETICAL'
           for point in (first, last)):
        return {**response, 'reason': 'A comparação exige preço de venda observado e elegível nas duas datas.'}
    with localcontext() as ctx:
        ctx.prec = 40
        start_gross = D(first['market'])
        observed = D(last['market']) - start_gross
        response['observed_change'] = str(observed)
        if any(point['market_yield'] is None for point in (first, last)):
            return {**response, 'reason': 'Falta a taxa de venda em pelo menos uma das datas.'}
        rates = (D(first['market_yield']), D(last['market_yield']))
        if any(not D('-.95') <= rate <= 1 for rate in rates):
            return {**response, 'reason': 'Taxa fora do domínio de reprecificação.'}
        monthly = _ipca(body['ipca'], today)
        indices = [calculate_nominal_index(day, monthly, as_of=today, evidence_mode=EvidenceMode.EX_POST)
                   for day in (start, end)]
        missing = sorted({index.missing_month.strftime('%m/%Y') for index in indices if index.missing_month})
        if any(index.value is None for index in indices):
            months = f" ({', '.join(missing)})" if missing else ''
            return {**response, 'reason': f'IPCA realizado insuficiente{months} para separar os efeitos.'}
        calendar = FinancialCalendar(knowledge_date=today)
        try:
            factors = [[_unit_price_factor(result['title_id'], day, rate, calendar) for rate in rates]
                       for day in (start, end)]
            inflation = (D(1), indices[1].value / indices[0].value)
            values = {(time, ipca, rate): start_gross * (factors[time][rate] / factors[0][0]) * inflation[ipca]
                      for time, ipca, rate in product(range(2), repeat=3)}
            values[(0, 0, 0)] = start_gross
            effects = [D(0), D(0), D(0)]
            for order in permutations(range(3)):
                state = [0, 0, 0]
                previous = start_gross
                for factor in order:
                    state[factor] = 1
                    value = values[tuple(state)]
                    effects[factor] += value - previous
                    previous = value
            rounded = [round_money(effect / 6) or D('0.00') for effect in effects]
            modeled = sum(rounded)
        except (ArithmeticError, ValueError):
            return {**response, 'reason': 'A reprecificação excede a precisão do modelo.'}
        response.update(status='AVAILABLE', effects=dict(zip(('time', 'ipca', 'rate'), map(str, rounded))),
                        modeled_change=str(modeled), residual=str(observed - modeled),
                        index_change_percent=str((inflation[1] - 1) * 100),
                        business_days=calendar.business_days(start, end))
    return response


def position_records(service, method, body=None, query=None):
    """Explicit local saves; immutable revisions, CAS and retry receipts stay in LocalStore."""
    service._ensure()
    if method == 'GET':
        record_id = (query or {}).get('id')
        if not record_id:
            return {'positions': service.store.list_records('position')}
        record = service.store.get_record(record_id)
        if record['kind'] != 'position' or record['payload'].get('application') != 'tesouro.position.v1':
            raise ValidationError('E-POSITION', 'Compra não encontrada.')
        payload=record['payload']
        if set(payload) != {'application','purchase','costs'}:
            raise ValidationError('E-POSITION','Registro de compra incompleto; os dados existentes foram preservados.')
        normalize_actual_purchase(payload['purchase'],today=service.now().date())
        normalize_costs(payload['costs'])
        return record
    allowed = {'schema_version', 'name', 'purchase', 'costs', 'consent', 'id', 'expected_revision', 'operation_id'}
    if (not isinstance(body, dict) or set(body) - allowed or type(body.get('schema_version')) is not int
            or body['schema_version'] != 1 or body.get('consent') is not True):
        raise ValidationError('E-CONSENT', 'Use Salvar compra para confirmar a gravação local.')
    if not isinstance(body.get('name'), str) or not body['name'].strip() or len(body['name'].strip()) > 120:
        raise ValidationError('E-POSITION', 'Informe um nome de até 120 caracteres para a compra.')
    operation = body.get('operation_id')
    if not isinstance(operation, str) or not re.fullmatch(r'[a-f0-9]{32}', operation):
        raise ValidationError('E-POSITION', 'Identidade de gravação inválida.')
    record_id, revision = body.get('id'), body.get('expected_revision')
    if record_id is None and revision is not None:
        raise ValidationError('E-POSITION', 'Uma compra nova não possui revisão anterior.')
    if record_id is not None and (not isinstance(record_id, str) or not re.fullmatch(r'[a-f0-9]{32}', record_id)
                                or type(revision) is not int or revision < 1):
        raise ValidationError('E-POSITION', 'Reabra a compra antes de salvar uma revisão.')
    purchase = normalize_actual_purchase(body.get('purchase'), today=service.now().date())
    costs = {key: None if value is None else str(value) for key, value in normalize_costs(body.get('costs')).items()}
    payload = {'application': 'tesouro.position.v1', 'purchase': purchase, 'costs': costs}
    identity = sha256(safe_json({'payload': payload, 'name': body['name'].strip(), 'id': record_id, 'expected_revision': revision}).encode()).hexdigest()
    return service.store.save_record('position', body['name'], payload, record_id=record_id,
                    expected_revision=revision, consent=True, operation_id=operation, operation_sha256=identity)
