"""Livro local de compras e resgates parciais do mesmo RendA+ 2065.

PEPS, custo fiscal e despesas iniciais proporcionais. Eventos representam fluxos
externos: resgates não são automaticamente reinvestidos nem remunerados em caixa.
"""
from __future__ import annotations
from dataclasses import replace
from datetime import date, datetime
from decimal import Decimal as D, ROUND_HALF_UP, localcontext
from copy import deepcopy
from hashlib import sha256
import json, math
from scipy.optimize import brentq
from .models import PurchaseLot,Fees,ValidationError,decimal_value,INSTRUMENT_ID
from .tax_and_fees import net_proceeds

_XIRR_MIN_RATE = -0.999
_XIRR_MAX_RATE = 100.0
_XIRR_RESIDUAL_TOLERANCE = 1e-10


def _lot(row):
    return PurchaseLot(date.fromisoformat(row['trade_date']),date.fromisoformat(row['settlement_date']),D(row['quantity']),D(row['unit_price']),D(row['tax_cost_basis']) if row.get('tax_cost_basis') is not None else None,D(row.get('entry_fee','0')),float(row['entry_yield']) if row.get('entry_yield') is not None else None,source_kind=row.get('source_kind','REAL_COMPRA'),source_ref=row.get('source','Dados do livro local'),institution_release_date=date.fromisoformat(row['release_date']) if row.get('release_date') else None)


def _validate_book(book):
    if not isinstance(book,dict) or not isinstance(book.get('lots'),list) or not isinstance(book.get('events'),list):raise ValidationError('E-BOOK','Livro inválido.')
    if len(book['lots'])>200 or len(book['events'])>2000:raise ValidationError('E-SIZE','Limite: 200 lotes e 2.000 eventos por livro.')
    ids=[r.get('id') for r in book['lots']];eids=[e.get('id') for e in book['events']]
    if any(not isinstance(x,str) or not x for x in ids+eids) or len(ids)!=len(set(ids)) or len(eids)!=len(set(eids)):raise ValidationError('E-BOOK','Identificadores inválidos ou duplicados.')
    purchases={e['id']:e for e in book['events'] if e['type']=='purchase'}
    if set(ids)!=set(purchases):raise ValidationError('E-BOOK','Lotes e compras não se reconciliam.')
    sold={i:[] for i in ids};last=None
    for event in book['events']:
        d=date.fromisoformat(event['date']);settled=date.fromisoformat(event['settlement'])
        if (last and d<last) or settled<d:raise ValidationError('E-BOOK','Ordem ou liquidação dos eventos inválida.')
        last=d
        if event['type']=='redemption':
            allocations=event.get('allocations',[])
            if not allocations or any(r['lot_id'] not in sold for r in allocations):raise ValidationError('E-BOOK','Resgate sem alocação PEPS válida.')
            if sum((D(r['net']) for r in allocations),D(0))!=D(event['amount']):raise ValidationError('E-BOOK','Líquido do resgate não fecha.')
            if sum((D(r['quantity']) for r in allocations),D(0))!=D(str(event['quantity'])):raise ValidationError('E-BOOK','Quantidade do resgate não fecha.')
            for row in allocations:sold[row['lot_id']].append(row)
        elif event['type']!='purchase':raise ValidationError('E-BOOK','Evento desconhecido.')
    for row in book['lots']:
        q=decimal_value(row['quantity'],'Quantidade');basis=decimal_value(row['tax_cost_basis'],'Custo');fee=decimal_value(row.get('entry_fee','0'),'Despesa')
        if min(q,basis,fee)<0 or q%D('.01'):raise ValidationError('E-BOOK','Quantidade ou custo remanescente inválido.')
        if q>0:_lot(row)
        original=purchases[row['id']];parts=sold[row['id']]
        if q+sum((D(x['quantity']) for x in parts),D(0))!=D(str(original['quantity'])):raise ValidationError('E-BOOK','Estoque remanescente não se reconcilia com compras e vendas.')
        total=basis+fee+sum((D(x['tax_cost_basis'])+D(x['entry_cost']) for x in parts),D(0))
        if abs(total+D(original['amount']))>D('.00000001'):raise ValidationError('E-BOOK','Custo remanescente não se reconcilia com os eventos.')


def _new_event(book,event_id,event_date):
    if not isinstance(event_id,str) or not 1<=len(event_id)<=120:raise ValidationError('E-ID','Identificador de evento obrigatório.')
    if any(e['id']==event_id for e in book['events']):raise ValidationError('E-DUPLICATE','Evento já registrado; não repita o resgate.')
    if book['events'] and event_date<max(date.fromisoformat(e['date']) for e in book['events']):raise ValidationError('E-DATE','Registre os eventos em ordem cronológica; não inserir no passado de um resgate.')


def add_purchase(book:dict,values:dict,*,event_id:str):
    _validate_book(book);out=deepcopy(book);lot=_lot(values);_new_event(out,event_id,lot.trade_date)
    row={**values,'id':event_id,'instrument_id':INSTRUMENT_ID,'trade_date':lot.trade_date.isoformat(),'settlement_date':lot.settlement_date.isoformat(),'quantity':str(lot.quantity),'unit_price':str(lot.unit_price),'tax_cost_basis':str(lot.tax_cost_basis),'entry_fee':str(lot.entry_fee)}
    out['lots'].append(row)
    out['lots'].sort(key=lambda r:(r['settlement_date'],r['trade_date'],r['id']))
    out['events'].append({'id':event_id,'type':'purchase','date':lot.trade_date.isoformat(),'settlement':lot.settlement_date.isoformat(),'quantity':str(lot.quantity),'amount':str(-lot.initial_outflow),'lot_id':event_id,'source':values.get('source','Informado')})
    return out


def redeem(book:dict,quantity,pu:D,day:date,fees:Fees,calendar,*,event_id:str,lag:int=0):
    _validate_book(book);_new_event(book,event_id,day)
    q=decimal_value(quantity,'quantidade do resgate');pu=decimal_value(pu,'PU de resgate')
    if q<=0 or q%D('.01') or pu<=0:raise ValidationError('E-AMOUNT','Resgate exige quantidade positiva múltipla de 0,01 e preço positivo.')
    if not calendar.is_session(day):raise ValidationError('E-DATE','Resgate deve ocorrer em sessão válida do calendário.')
    available=sum(D(r['quantity']) for r in book['lots'] if r['trade_date']<=day.isoformat())
    if q>available:raise ValidationError('E-QUANTITY','Quantidade superior ao estoque adquirido.')
    out=deepcopy(book);remaining=q;alloc=[];settlement=calendar.redemption_settlement(day,lag)
    active=sorted(out['lots'],key=lambda r:(r['settlement_date'],r['trade_date'],r['id']))
    fixed_left=fees.exit_fixed;fixed_allocated=D(0)
    for row in active:
        original_q=D(row['quantity'])
        if original_q<=0:continue
        if remaining<=0:break
        lot=_lot(row)
        if not calendar.eligible(lot,day):raise ValidationError('E-LOCK','PEPS alcança um lote ainda bloqueado; reduza o resgate. Nenhum lote foi alterado.')
        take=min(remaining,original_q);ratio=take/original_q
        cumulative=(fees.exit_fixed*(q-remaining+take)/q).quantize(D('.01'),rounding=ROUND_HALF_UP)
        fixed=fixed_left if take==remaining else max(D(0),min(fixed_left,cumulative-fixed_allocated))
        fixed_left-=fixed;fixed_allocated+=fixed
        sold=replace(lot,quantity=take,tax_cost_basis=lot.tax_cost_basis*ratio,entry_fee=lot.entry_fee*ratio)
        financial=net_proceeds(sold,pu,settlement,replace(fees,exit_fixed=fixed))
        alloc.append({'lot_id':row['id'],'quantity':str(take),'tax_cost_basis':str(sold.tax_cost_basis),'entry_cost':str(sold.entry_fee),'gross':str(financial.gross),'tax':str(financial.tax),'custody':str(financial.custody),'other_fees':str(financial.other_fees),'net':str(financial.net),'profit':str(financial.profit),'age_days':financial.age_days})
        row['quantity']=str(original_q-take);row['tax_cost_basis']=str(lot.tax_cost_basis-sold.tax_cost_basis);row['entry_fee']=str(lot.entry_fee-sold.entry_fee)
        remaining-=take
    if remaining>0:raise ValidationError('E-QUANTITY','Saldo insuficiente.')
    net=sum(D(r['net']) for r in alloc)
    receipt={'id':event_id,'type':'redemption','date':day.isoformat(),'settlement':settlement.isoformat(),'quantity':float(q),'pu':str(pu),'amount':str(net),'allocations':alloc,'net':str(net),'note':'Registro local/hipotético. Nenhuma ordem foi enviada.'}
    out['events'].append(receipt)
    return out,receipt


def _xirr_result(status, reason, *, value=None, roots=None, roots_complete=False, residual_ratio=None):
    return {
        'value': value,
        'roots': [] if roots is None else roots,
        'reason': reason,
        'status': status,
        'roots_complete': roots_complete,
        'residual_ratio': residual_ratio,
    }


def _log_sum_exp(values):
    maximum = max(values)
    return maximum + math.log(math.fsum(math.exp(value - maximum) for value in values))


def money_weighted_return(flows):
    """Return an ACT/365 money-weighted rate only when uniqueness is established."""
    grouped = {}
    try:
        iterator = iter(flows)
    except TypeError as exc:
        raise ValidationError('E-AMOUNT', 'Fluxos para TIR devem ser iteráveis.') from exc

    for flow in iterator:
        try:
            day, raw_amount = flow
        except (TypeError, ValueError) as exc:
            raise ValidationError('E-AMOUNT', 'Cada fluxo para TIR precisa conter data e valor.') from exc
        if not isinstance(day, date) or isinstance(day, datetime):
            raise ValidationError('E-DATE', 'Data de fluxo para TIR inválida.')
        grouped.setdefault(day, []).append(decimal_value(raw_amount, 'Fluxo para TIR'))

    data = []
    for day, amounts in grouped.items():
        nonzero = [amount for amount in amounts if not amount.is_zero()]
        if not nonzero:
            continue
        # Keep same-day monetary aggregation exact even when magnitudes or decimal
        # places differ substantially; the default Decimal precision is too small.
        precision = max(
            28,
            max(amount.adjusted() for amount in nonzero)
            - min(amount.as_tuple().exponent for amount in nonzero)
            + len(str(len(nonzero)))
            + 2,
        )
        with localcontext() as context:
            context.prec = precision
            total = sum(nonzero, D(0))
        if not total.is_zero():
            data.append((day, total))
    data.sort(key=lambda row: row[0])

    if len(data) < 2:
        return _xirr_result('INSUFFICIENT', 'Fluxos insuficientes para calcular TIR.')

    signs = tuple(1 if amount > 0 else -1 for _, amount in data)
    changes = [index for index in range(1, len(signs)) if signs[index] != signs[index - 1]]
    if not changes:
        return _xirr_result(
            'NO_ROOT_IN_DOMAIN',
            'Não há TIR para fluxos que mantêm o mesmo sinal.',
            roots_complete=True,
        )
    if len(changes) > 1:
        return _xirr_result(
            'UNIQUENESS_UNPROVEN',
            'unicidade não comprovada para estes fluxos',
        )

    first_day = data[0][0]
    times = tuple((day - first_day).days / 365 for day, _ in data)
    pivot = (times[changes[0] - 1] + times[changes[0]]) / 2
    with localcontext() as context:
        context.prec = 50
        log_amounts = tuple(float(amount.copy_abs().ln()) for _, amount in data)
    log_total_absolute = _log_sum_exp(log_amounts)

    def scaled_npv(log_rate):
        exponents = tuple(
            log_amount - log_rate * (time - pivot)
            for log_amount, time in zip(log_amounts, times)
        )
        maximum = max(exponents)
        scaled_value = math.fsum(
            sign * math.exp(exponent - maximum)
            for sign, exponent in zip(signs, exponents)
        )
        return scaled_value, maximum

    def residual_ratio(log_rate):
        scaled_value, maximum = scaled_npv(log_rate)
        if scaled_value == 0:
            return 0.0
        log_ratio = (
            maximum
            + math.log(abs(scaled_value))
            - log_rate * pivot
            - log_total_absolute
        )
        if log_ratio < -745:
            return 0.0
        if log_ratio > 709:
            return math.inf
        return math.exp(log_ratio)

    pivot_twice_days = (
        (data[changes[0] - 1][0] - first_day).days
        + (data[changes[0]][0] - first_day).days
    )

    def precise_endpoint_sign(rate_factor):
        # A double can round an exact boundary root to a tiny nonzero with the
        # wrong sign. Re-evaluate only near that cancellation using Decimal.
        with localcontext() as context:
            context.prec = 80
            log_rate = rate_factor.ln()
            log_terms = tuple(
                amount.copy_abs().ln()
                - log_rate * D(2 * (day - first_day).days - pivot_twice_days) / D(730)
                for day, amount in data
            )
            maximum = max(log_terms)
            scaled_value = sum(
                (D(sign) * (log_term - maximum).exp() for sign, log_term in zip(signs, log_terms)),
                D(0),
            )
            if abs(scaled_value) <= D('1e-60'):
                return 0
            return 1 if scaled_value > 0 else -1

    def endpoint_sign(float_value, decimal_rate_factor):
        if abs(float_value) > 1e-12:
            return 1 if float_value > 0 else -1
        return precise_endpoint_sign(decimal_rate_factor)

    lower = math.log1p(_XIRR_MIN_RATE)
    upper = math.log1p(_XIRR_MAX_RATE)
    lower_value, _ = scaled_npv(lower)
    upper_value, _ = scaled_npv(upper)
    lower_sign = endpoint_sign(lower_value, D('0.001'))
    upper_sign = endpoint_sign(upper_value, D('101'))
    if lower_sign == 0:
        root_log_rate = lower
    elif upper_sign == 0:
        root_log_rate = upper
    elif lower_sign != upper_sign:
        try:
            root_log_rate, convergence = brentq(
                lambda rate: scaled_npv(rate)[0],
                lower,
                upper,
                xtol=5e-324,
                rtol=4 * 2.220446049250313e-16,
                maxiter=200,
                full_output=True,
                disp=False,
            )
        except (ValueError, RuntimeError, OverflowError):
            return _xirr_result(
                'NUMERICAL_FAILURE',
                'Falha numérica ao validar a TIR no domínio suportado.',
            )
        if not convergence.converged:
            return _xirr_result(
                'NUMERICAL_FAILURE',
                'Falha numérica ao validar a TIR no domínio suportado.',
            )
    else:
        return _xirr_result(
            'NO_ROOT_IN_DOMAIN',
            'Não há raiz no domínio -99,9% a 10.000% a.a.',
            roots_complete=True,
        )

    if root_log_rate == lower:
        rate = _XIRR_MIN_RATE
    elif root_log_rate == upper:
        rate = _XIRR_MAX_RATE
    else:
        rate = math.expm1(root_log_rate)
    if not math.isfinite(rate) or not _XIRR_MIN_RATE <= rate <= _XIRR_MAX_RATE:
        return _xirr_result(
            'NUMERICAL_FAILURE',
            'Falha numérica ao validar a TIR no domínio suportado.',
        )

    residual = residual_ratio(root_log_rate)
    if not math.isfinite(residual) or residual > _XIRR_RESIDUAL_TOLERANCE:
        return _xirr_result(
            'NUMERICAL_FAILURE',
            'Falha numérica ao validar a TIR no domínio suportado.',
        )
    return _xirr_result(
        'UNIQUE',
        'TIR única validada, nominal anualizada ACT/365; não é previsão.',
        value=rate,
        roots=[rate],
        roots_complete=True,
        residual_ratio=residual,
    )


def valuate(book,pu:D,day:date,fees:Fees,calendar):
    _validate_book(book)
    if any(date.fromisoformat(e['date'])>day for e in book['events']):raise ValidationError('E-DATE','Avaliação não pode preceder eventos já registrados. Use uma revisão anterior do livro.')
    rows=[];open_net=D(0);locked_net=D(0);open_qty=D(0);locked_qty=D(0)
    active=[r for r in book['lots'] if D(r['quantity'])>0]
    total_qty=sum((D(r['quantity']) for r in active if date.fromisoformat(r['settlement_date'])<=day),D(0));cum_qty=D(0);allocated_fee=D(0)
    # Uma taxa fixa de ordem na marcação de liquidação total, não uma taxa por lote.
    for row in active:
        lot=_lot(row)
        if day<lot.settlement_date:
            rows.append({'id':row['id'],'quantity':float(lot.quantity),'net':None,'state':'Em liquidação','tax':None,'first_eligible':calendar.first_eligible(lot).isoformat()});continue
        cum_qty+=lot.quantity
        total_fee=(fees.exit_fixed*cum_qty/total_qty).quantize(D('.01'),rounding=ROUND_HALF_UP)
        f=replace(fees,exit_fixed=total_fee-allocated_fee);allocated_fee=total_fee
        result=net_proceeds(lot,pu,day,f);eligible=calendar.eligible(lot,day)
        open_net+=result.net;open_qty+=lot.quantity
        if not eligible:locked_qty+=lot.quantity;locked_net+=result.net
        rows.append({'id':row['id'],'quantity':float(lot.quantity),'cost':float(lot.initial_outflow),'net':float(result.net),'profit':float(result.profit),'net_return':float(result.net_return),'tax':float(result.tax),'custody':float(result.custody),'first_eligible':calendar.first_eligible(lot).isoformat(),'state':'Liberado' if eligible else 'Em carência'})
    contributed=-sum(D(e['amount']) for e in book['events'] if e['type']=='purchase')
    redemptions=sum((D(e['amount']) for e in book['events'] if e['type']=='redemption'),D(0))
    received=sum((D(e['amount']) for e in book['events'] if e['type']=='redemption' and date.fromisoformat(e['settlement'])<=day),D(0))
    flows=[(date.fromisoformat(e['settlement']),D(e['amount'])) for e in book['events'] if date.fromisoformat(e['settlement'])<=day]
    if open_net:flows.append((day,open_net))
    pending_purchase=sum((D(r['quantity'])*D(r['unit_price'])+D(r.get('entry_fee','0')) for r in active if date.fromisoformat(r['settlement_date'])>day),D(0))
    value=open_net+pending_purchase+redemptions
    xirr=money_weighted_return(flows) if not pending_purchase and received==redemptions else _xirr_result('INSUFFICIENT','Há liquidações pendentes; TIR consolidada indisponível nesta fotografia.')
    return {'lots':rows,'open_quantity':float(open_qty),'locked_quantity':float(locked_qty),'open_net':float(open_net),'locked_net':float(locked_net),'net_available_positions':float(open_net-locked_net),'pending_purchase':float(pending_purchase),'redemptions_received':float(received),'redemptions_pending':float(redemptions-received),'total_contributed':float(contributed),'economic_value':float(value),'profit':float(value-contributed),'xirr':xirr,'note':'Resgates são fluxos externos, não caixa remunerado. Valor econômico soma resgates históricos e marcação do saldo; não é saldo bancário. TIR considera fluxos por data.'}
