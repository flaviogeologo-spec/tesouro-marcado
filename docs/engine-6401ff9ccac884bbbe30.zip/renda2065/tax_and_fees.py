"""Apuração nominal líquida. Custódia linear sobre resgate é uma estimativa explícita."""
from __future__ import annotations
from dataclasses import dataclass
from datetime import date
from decimal import Decimal as D, ROUND_HALF_UP
import math
from .models import PurchaseLot, Fees, ValidationError, decimal_value


def tax_rate(days: int) -> D:
    if days < 0:
        raise ValidationError('E-DATE', 'Idade tributária negativa.')
    return D('.225') if days <= 180 else D('.20') if days <= 360 else D('.175') if days <= 720 else D('.15')


def annualized_return(net: D, initial: D, days: int) -> float | None:
    if days <= 0 or net <= 0 or initial <= 0:
        return None
    try:
        answer = math.expm1(math.log(float(net / initial)) * 365.0 / days)
    except (OverflowError, ValueError):
        return None
    return answer if math.isfinite(answer) else None


@dataclass(frozen=True)
class NetResult:
    gross: D | None
    taxable_gain: D | None
    tax_rate: D
    tax: D | None
    custody: D | None
    other_fees: D | None
    net: D
    profit: D
    net_return: D
    annualized: float | None
    age_days: int
    source: str = 'Líquido estimado'

    def meets(self, lot: PurchaseLot, target: D) -> bool:
        # Nunca arredondar a porcentagem para decidir o gatilho.
        return self.net >= lot.initial_outflow * (D(1) + target)


def net_proceeds(lot: PurchaseLot, pu: D | None, settlement: date, fees: Fees,
                 *, custody_override: D | None = None, net_override: D | None = None) -> NetResult:
    days = (settlement - lot.settlement_date).days
    a = tax_rate(days)
    if settlement > lot.max_redemption_date:
        raise ValidationError('E-HORIZON', 'A liquidação precisa ocorrer antes de dez anos e da conversão.')
    if custody_override is not None and net_override is not None:
        raise ValidationError('E-NET-DOUBLE', 'Valor líquido não recebe nova dedução de custódia.')
    gross = None
    if pu is not None:
        pu = decimal_value(pu, 'PU de resgate')
        if pu <= 0:
            raise ValidationError('E-AMOUNT', 'PU de resgate deve ser positivo.')
        gross = lot.quantity * pu
    if net_override is not None:
        net = decimal_value(net_override, 'líquido informado')
        if net < 0:
            raise ValidationError('E-AMOUNT', 'Líquido informado negativo.')
        gain = tax = custody = other = None
        source = 'Líquido informado pela instituição; sem novas deduções'
    else:
        if gross is None:
            raise ValidationError('E-AMOUNT', 'Informe PU de resgate ou total líquido.')
        if fees.monetary_rounding == 'centavos_half_up':
            gross = gross.quantize(D('.01'), rounding=ROUND_HALF_UP)
        gain = max(gross - lot.tax_cost_basis, D(0))
        tax = gain * a
        custody = fees.custody_annual * D(days) / D(365) * gross
        if custody_override is not None:
            custody = decimal_value(custody_override, 'custódia informada')
            if custody < 0:
                raise ValidationError('E-AMOUNT','Custódia informada negativa.')
        other = fees.exit_fixed + fees.exit_rate * gross
        if fees.monetary_rounding == 'centavos_half_up':
            gross = gross.quantize(D('.01'), rounding=ROUND_HALF_UP)
            tax = tax.quantize(D('.01'), rounding=ROUND_HALF_UP)
            custody = custody.quantize(D('.01'), rounding=ROUND_HALF_UP)
            other = other.quantize(D('.01'), rounding=ROUND_HALF_UP)
        net = gross - tax - custody - other
        source = 'Líquido estimado; custódia informada' if custody_override is not None else 'Líquido estimado'
    initial = lot.initial_outflow
    return NetResult(gross, gain, a, tax, custody, other, net, net-initial, net/initial-1,
                     annualized_return(net, initial, days), days, source)
