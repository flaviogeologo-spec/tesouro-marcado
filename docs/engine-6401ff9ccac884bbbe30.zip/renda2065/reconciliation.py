"""Reconciliação discriminada: diferenças preservadas, nunca corrigidas por ajuste arbitrário."""
from decimal import Decimal as D
from .models import ValidationError
from .formatting import parse_number
from .tax_and_fees import net_proceeds
from .pricing import infer_anchor


def reconcile(lot,settlement,fees,observed,target):
    keys=('pu','gross','tax','custody','other','net')
    obs={k:parse_number(str(observed[k]),k) if observed.get(k) not in (None,'') else None for k in keys}
    if any(v is not None and v<0 for v in obs.values()):raise ValidationError('E-RECONCILE','Valores da instituição não podem ser negativos.')
    if obs['pu'] is not None and obs['pu']<=0:raise ValidationError('E-RECONCILE','PU deve ser positivo.')
    pu=obs['pu']
    if pu is None and obs['gross'] is not None:
        pu=obs['gross']/lot.quantity
    model=net_proceeds(lot,pu,settlement,fees) if pu else None
    model_values={'gross':model.gross,'tax':model.tax,'custody':model.custody,'other':model.other_fees,'net':model.net} if model else {}
    rows=[]
    for key,label in [('gross','Valor bruto'),('tax','Imposto de renda'),('custody','Custódia'),('other','Outros custos'),('net','Líquido')]:
        a=model_values.get(key);b=obs[key]
        gap=b-a if a is not None and b is not None else None
        rows.append({'key':key,'label':label,'model':float(a) if a is not None else None,'institution':float(b) if b is not None else None,'difference':float(gap) if gap is not None else None})
    complete=all(obs[k] is not None for k in ('gross','tax','custody','other','net'))
    balance=obs['gross']-obs['tax']-obs['custody']-obs['other'] if complete else None
    unexplained=obs['net']-balance if complete else None
    netgap=obs['net']-model.net if obs['net'] is not None and model else None
    pu_gap=obs['gross']-lot.quantity*obs['pu'] if obs['gross'] is not None and obs['pu'] is not None else None
    warnings=[]
    if pu_gap is not None and abs(pu_gap)>D('.02'):warnings.append('Quantidade × PU não coincide com o bruto informado; confira os campos e a referência temporal.')
    if not complete:warnings.append('Decomposição incompleta: não é possível atribuir toda a diferença. Campo ausente não é zero.')
    if unexplained is not None and abs(unexplained)>D('.02'):warnings.append('Bruto menos os descontos não coincide com o líquido informado.')
    warnings.append('Conferência da fotografia informada, não certificação ou recalibração automática. Custódia futura permanece estimada.')
    return {'rows':rows,'model':{k:float(v) for k,v in model_values.items()} if model else None,
      'components_consistent':abs(unexplained)<=D('.02') if unexplained is not None else None,
      'net_gap':float(netgap) if netgap is not None else None,'unexplained_gap':float(unexplained) if unexplained is not None else None,
      'model_meets':model.meets(lot,target) if model else None,
      'institution_meets':obs['net']>=lot.initial_outflow*(1+target) if obs['net'] is not None else None,
      'institution_return':float(obs['net']/lot.initial_outflow-1) if obs['net'] is not None else None,
      'warnings':warnings,'observed':{k:str(v) if v is not None else None for k,v in obs.items()}}


def compare_vni(vni,valuation_date,quote,engine,source):
    if not source or not source.strip():raise ValidationError('E-ANCHOR','Informe a fonte independente do VNI.')
    if quote.redemption_pu is None or quote.redemption_yield is None:
        raise ValidationError('E-ANCHOR','A conferência independente exige PU e taxa de resgate pareados.')
    if valuation_date!=(quote.valuation_date or quote.observation_date):
        raise ValidationError('E-ANCHOR','VNI e par de resgate precisam da mesma referência financeira; não retroprojetar para forçar coincidência.')
    expected=engine.price(valuation_date,quote.redemption_yield,float(vni))
    implied=infer_anchor(quote,engine)
    error=float(expected-quote.redemption_pu)
    tolerance=max(.03,float(quote.redemption_pu)*.0005)
    return {'vni_independent':float(vni),'vni_inferred':implied.vni,'vni_difference_percent':100*(float(vni)/implied.vni-1),
      'model_pu':float(expected),'observed_pu':float(quote.redemption_pu),'redemption_error':error,'tolerance':tolerance,
      'matched':abs(error)<=tolerance,'source':source,'date':valuation_date.isoformat(),
      'note':'Confronto independente de valor informado; fonte não autenticada pelo aplicativo. Não altera a âncora automaticamente.'}
