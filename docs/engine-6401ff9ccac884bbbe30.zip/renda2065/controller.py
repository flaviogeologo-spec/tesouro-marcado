"""Conversão de formulário em pedido financeiro; independente de Streamlit."""
from datetime import date, datetime, timedelta
from decimal import Decimal as D
from zoneinfo import ZoneInfo
from .models import PurchaseLot, Fees, Quote, PricingAnchor, AnalysisRequest, ValidationError
from .calendar_rules import FinancialCalendar
from .formatting import parse_number, parse_rates
from .pricing import PricingEngine, infer_anchor, select_anchor, projected_vni
from .analysis_service import anchors_from_quotes, lot_from_budget
from .benchmarks import parse_monthly_path
TZ=ZoneInfo('America/Sao_Paulo')
ANCHORS=['Histórico disponível','VNI datado informado','Par PU + taxa informado','Sem âncora — calcular preço mínimo']

def build_request(v, history, now=None, calendar=None, independent_anchors=None):
    now = now or datetime.now(TZ)
    asof=v['asof']
    if asof is None:raise ValidationError('E-DATE','Preencha a data de referência.')
    if asof>now.date():raise ValidationError('E-DATE','A referência observada não pode estar no futuro; use o horizonte para cenários futuros.')
    cal=calendar or FinancialCalendar(knowledge_date=asof); engine=PricingEngine(cal)
    quotes=history.quotes if history else ()
    source_quotes=tuple(q for q in quotes if q.observation_date<=asof)
    anchors=()
    if v['anchor_mode']=='VNI independente importado':
        anchors=tuple(a for a in (independent_anchors or ()) if a.known_on<=asof)
        if not anchors:raise ValidationError('E-ANCHOR','Não há VNI independente conhecido até a referência.')
    elif v['anchor_mode']==ANCHORS[0]:
        anchors=anchors_from_quotes(source_quotes,asof,engine)
    elif v['anchor_mode'] in (ANCHORS[1],ANCHORS[2]):
        ad,known=v.get('a_date'),v.get('a_known')
        if ad is None or known is None or not v.get('a_ref','').strip():
            raise ValidationError('E-ANCHOR','Preencha as datas e a origem da referência.')
        if known>asof or ad>asof:
            raise ValidationError('E-ANCHOR','Referência posterior à data da análise.')
        if v['anchor_mode']==ANCHORS[1]:
            anchors=(PricingAnchor(ad,float(parse_number(v['vni'],'VNI')),known,'VNI_OFICIAL_INFORMADO',v['a_ref'],quality_flags=('VNI de fonte informada; aplicativo não verifica a publicação.',)),)
        else:
            pu=parse_number(v['a_pu'],'PU de referência');y=float(parse_number(v['a_yield'],'taxa pareada')/100)
            q=Quote(ad,redemption_yield=y if v['a_side']=='resgate' else None,
                    redemption_pu=pu if v['a_side']=='resgate' else None,buy_yield=y if v['a_side']=='compra' else None,
                    buy_pu=pu if v['a_side']=='compra' else None,source_kind='COTACAO_INFORMADA',source_ref=v['a_ref'])
            inferred=infer_anchor(q,engine,side=v['a_side'])
            anchors=(PricingAnchor(inferred.valuation_date,inferred.vni,known,inferred.source_kind,inferred.source_ref,inferred.pair_error,inferred.quality_flags),)
    trade=v['trade']
    if trade is None:raise ValidationError('E-DATE','Preencha ou selecione a data de compra.')
    if v['mode']=='Histórico / período' and v['selected'] is None:
        raise ValidationError('E-DATE','Selecione uma cotação histórica.')
    if v['mode']=='Compra real' and v['settlement'] is None:
        raise ValidationError('E-DATE','A compra real requer a liquidação do comprovante.')
    settlement=v['settlement'] or cal.next_session(trade)
    efee=parse_number(v['entry_fee'],'despesas iniciais')
    inflation=float(parse_number(v['inflation'],'inflação')/100)
    target=parse_number(v['target'],'meta')/100
    qty=D(1) if v['qmode']=='Por título' else parse_number(v['quantity'],'quantidade') if v['qmode']=='Quantidade' else None
    y=float(parse_number(v['entry_yield'],'taxa da compra')/100) if v.get('entry_yield','').strip() else None
    leftover=None
    if v['mode']=='Compra real':
        if qty is None:raise ValidationError('E-AMOUNT','Na compra real, informe a quantidade ou use o modo por título; orçamento é para simulação.')
        basis=parse_number(v['basis'],'custo fiscal') if v['basis'].strip() else None
        pu=parse_number(v['pu'],'PU de compra') if v['pu'].strip() else (basis/qty if basis and qty>0 else None)
        if pu is None:raise ValidationError('E-AMOUNT','Informe PU ou custo fiscal e quantidade.')
        lot=PurchaseLot(trade,settlement,qty,pu,basis,efee,y,'REAL_COMPRA',per_unit=v['qmode']=='Por título',institution_release_date=v['release'],has_intermediate_flows=v['intermediate'])
    else:
        if not cal.is_session(trade):raise ValidationError('E-DATE','Data sem sessão no calendário adotado; selecione explicitamente outra data.')
        if v['mode']=='Histórico / período':
            q=v['selected'];pu=q.buy_pu;y=q.buy_yield
        else:
            if y is None:raise ValidationError('E-YIELD-DOMAIN','Taxa e data requer uma taxa de compra.')
            # Calcula um PU do cenário sem usar âncora conhecida após a compra.
            anchor = select_anchor(anchors, settlement, trade, trade)
            if anchor is None:
                raise ValidationError('E-ANCHOR', 'Taxa e data requer uma referência conhecida até a compra.')
            pu = engine.price(settlement, y, projected_vni(anchor, settlement, inflation,parse_monthly_path(v.get("inflation_monthly",""))))
        if qty is None:
            lot,leftover=lot_from_budget(trade,settlement,pu,parse_number(v['budget'],'orçamento'),efee,y)
        else:
            lot=PurchaseLot(trade,settlement,qty,pu,entry_fee=efee,entry_yield=y,source_kind='HIPOTETICA',per_unit=v['qmode']=='Por título')
        if v['intermediate']:raise ValidationError('E-INTERMEDIATE-FLOW','A primeira versão avalia somente um lote sem fluxos intermediários.')
    start=v['start'] or max(asof,cal.first_eligible(lot))
    end=v['end'] or min(start+timedelta(days=730),lot.max_redemption_date)
    rates,rate_warnings=parse_rates(v['rates'])
    fees=Fees(parse_number(v['custody'],'custódia')/100,parse_number(v['exit_fixed'],'taxa fixa'),parse_number(v['exit_rate'],'taxa de saída')/100)
    if v.get('financial_profile'):
        from .policies import fees_for_profile
        fees=fees_for_profile(v['financial_profile'],fees.custody_annual,fees.exit_fixed,fees.exit_rate)
    spread=float(parse_number(v['spread'],'spread')/100) if v['spread'].strip() else None
    snapshot=None
    if v['snapshot_mode'] in ('PU de resgate informado','Líquido informado pela instituição'):
        qdate=v['q_date']
        if qdate is None:raise ValidationError('E-DATE','Informe a data da cotação.')
        timestamp=None
        if v['q_time'].strip():
            try:clock=datetime.strptime(v['q_time'].strip(),'%H:%M').time()
            except ValueError as exc:raise ValidationError('E-DATE','Horário deve usar HH:MM.') from exc
            timestamp=datetime.combine(qdate,clock,tzinfo=TZ)
        kwargs={}
        if v['snapshot_mode']=='PU de resgate informado':
            kwargs['redemption_pu']=parse_number(v['q_pu'],'PU de resgate')
            kwargs['custody_override']=parse_number(v['q_custody'],'custódia informada') if v['q_custody'].strip() else None
        else:kwargs['net_total']=parse_number(v['q_net'],'líquido oferecido')
        snapshot=Quote(qdate,source_kind='COTACAO_INFORMADA',source_ref='Informada pelo usuário, não verificada pelo aplicativo',
                       observed_at=timestamp,redemption_settlement_date=v['q_settle'],session_declared_active=v['q_active'],**kwargs)
    if v['snapshot_mode']=='Sem cotação':
        source_quotes=()  # As âncoras já foram calculadas; omitir avaliação de posição é deliberado.
    request=AnalysisRequest(lot=lot,as_of=asof,start_date=start,end_date=end,target=target,scenario_yields=rates,
        scenario_kind=v['kind'],spread=spread,spread_source=v['spread_source'],inflation=inflation,
        inflation_confirmed=v['inflation_ok'],settlement_lag=0 if v['lag']=='D+0' else 1,fees=fees,
        anchors=anchors,quotes=source_quotes,snapshot=snapshot,entry_reference=float(parse_number(v['entry_ref'],'referência de entrada')/100),now=now,inflation_monthly=parse_monthly_path(v.get("inflation_monthly","")))
    return request,leftover,rate_warnings

