"""Browser-only transport adapter; financial and snapshot validation stay shared."""
from collections import OrderedDict
from datetime import datetime
from threading import RLock
from zoneinfo import ZoneInfo
import base64
import json

from .group1_service import Group1Service
from .models import ValidationError, VERSION
from .storage import LocalStore


class BrowserService(Group1Service):
    def __init__(self, root, *, now=None):
        # Never use the desktop constructor, its personal-data paths or bootstrap.
        self.store = LocalStore(root)
        self.now = now or (lambda: datetime.now(ZoneInfo('America/Sao_Paulo')))
        self._lock = RLock()
        self._market_sim_cache = {}
        self.results = OrderedDict()
        self.pending = {}
        self.update_outcomes = OrderedDict()
        self.recovery_error = None
        try:
            self.store.check()
        except ValidationError:
            self.recovery_error = 'Os dados deste navegador precisam de recuperação. Use Restaurar cópia no rodapé; a base atual foi preservada.'

    def bootstrap(self):
        from .market_sim.renda_plus import SUPPORTED_CONVERSION_YEARS
        from pathlib import Path
        ipca_status = Path(__file__).resolve().parents[1] / 'data/ipca_public_status.json'
        return {'version':VERSION, 'defaults':{'asof':self.now().date().isoformat()},
                'public_ipca': json.loads(ipca_status.read_text(encoding='utf-8')) if ipca_status.is_file() else None,
                **({'recovery_error':self.recovery_error} if self.recovery_error else {}),
                'csrf_token':'browser-local', 'market_sim_active':{},
                'simple_screen':{'max_dates':2048, 'date_step_days':15, 'converged_dates':True,
                                 'outside_period':True, 'outside_original':True, 'batch_dates':True},
                'instrument_series_options':{'RENDA_PLUS':sorted(SUPPORTED_CONVERSION_YEARS)}}

    def dispatch(self, path, method, body=None, query=None):
        query = query or {}
        if path == '/api/bootstrap' and method == 'GET':
            return self.bootstrap()
        if path == '/api/simulator/historical' and method == 'POST':
            from .historical_evolution import evaluate_history
            return evaluate_history(body, today=self.now().date())
        if path == '/api/simulator/position-risk' and method == 'POST':
            from .position_analysis import evaluate_position_risk
            return evaluate_position_risk(body, today=self.now().date())
        if path == '/api/simulator/position-change' and method == 'POST':
            from .position_analysis import evaluate_position_change
            return evaluate_position_change(body, today=self.now().date())
        if path != '/api/browser/restore':
            self._ensure()
        if path == '/api/simulator/positions' and method in ('GET', 'POST'):
            from .position_analysis import position_records
            return position_records(self, method, body, query)
        if path == '/api/simulator/dates' and method == 'POST':
            from .browser_dates import resolve_date_batch
            from .market_sim.contracts import ValidationError as MarketValidationError
            try:
                return resolve_date_batch(body)
            except MarketValidationError as error:
                raise ValidationError(error.code, str(error)) from error
        if path == '/api/simulator/workspace' and method == 'POST':
            if not isinstance(body,dict) or body.get('action') not in ('RESOLVE','SURFACE','EVALUATE'):
                raise ValidationError('E-ACTION','Ação indisponível nesta versão web.')
            return self.simulator_workspace(body)
        if path == '/api/simulator/save' and method == 'POST':
            if not isinstance(body,dict) or body.get('schema_version') != 2:
                raise ValidationError('E-SCHEMA','Use uma simulação da tela atual.')
            return self.simulator_save(body)
        if path == '/api/simulator/scenarios' and method == 'GET':
            return self.simulator_scenarios()
        if path == '/api/simulator/scenario' and method == 'GET':
            return self.simulator_scenario(query.get('id'), int(query['revision']) if query.get('revision') else None)
        if path == '/api/browser/backup' and method == 'POST':
            return self.store.export_backup()
        if path == '/api/browser/restore' and method == 'POST':
            if not isinstance(body,dict) or body.get('confirmed') is not True:
                raise ValidationError('E-CONSENT','Confirme a restauração da cópia neste navegador.')
            encoded = body.get('content_base64')
            if not isinstance(encoded,str) or len(encoded) > 80*1024*1024:
                raise ValidationError('E-SIZE','Escolha uma cópia ZIP de até 60 MB.')
            try:
                raw = base64.b64decode(encoded,validate=True)
            except ValueError as error:
                raise ValidationError('E-BACKUP','Cópia inválida.') from error
            imported = self.store.import_backup(raw)
            return self.store.restore_backup(imported['id'],confirmed=True)
        raise ValidationError('E-ROUTE','Recurso indisponível nesta versão web.')


def handle(raw, root='/persist/tesouro'):
    """Return JSON strings so Decimal never crosses a JS number conversion."""
    try:
        message = json.loads(raw)
        result = BrowserService(root).dispatch(message['path'],message['method'],message.get('body'),message.get('query'))
        return json.dumps({'status':200,'body':result},ensure_ascii=False,allow_nan=False)
    except ValidationError as error:
        return json.dumps({'status':400,'body':{'code':error.code,'error':str(error)}},ensure_ascii=False)
