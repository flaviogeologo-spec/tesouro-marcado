"""Visões complementares do MESMO lote e motor: sem estratégia implícita nova."""
from __future__ import annotations
from datetime import date,timedelta
from decimal import Decimal as D
from dataclasses import replace
import math
import numpy as np
from .models import ValidationError
from .pricing import PricingEngine,solve_yield,infer_anchor,projected_vni
from .tax_and_fees import net_proceeds,tax_rate
from .exit_targets import target_price
from .benchmarks import CashBenchmark
from .regimes import signal_windows


def build_insights(result,calendar,*,cash=None,selected_date=None,low=.065,high=.078):
    req=result.request;lot=req.lot;cash=cash or CashBenchmark();engine=PricingEngine(calendar)
    if not math.isfinite(low+high) or not -.1<=low<high<=.5:raise ValidationError('E-RANGE','Intervalo de taxas inválido.')
    candidates=[d for d in result.daily if d.vni is not None and d.eligible]
    if not candidates:raise ValidationError('E-ANCHOR','Esta visão requer âncora de preço/taxa e pelo menos uma sessão elegível.')
    chosen=next((d for d in candidates if d.date.isoformat()==selected_date),None)
    if chosen is None:chosen=min(candidates,key=lambda d:abs((d.date-req.as_of).days))
    sample=candidates[::max(1,math.ceil(len(candidates)/90))]
    if sample[-1]!=candidates[-1]:sample.append(candidates[-1])
    yields=np.linspace(low,high,31);grid=[]
    for y in yields:
        values=[]
        for d in sample:
            p=engine.price(d.valuation_date,float(y),d.vni)
            values.append(float(net_proceeds(lot,p,d.settlement_date,req.fees).net_return) if p>0 else None)
        grid.append(values)
    snap=result.snapshot
    observed=next((q for q in result.observations if q.observation_date==chosen.date and q.redemption_pu is not None),None)
    if observed:
        base_pu=observed.redemption_pu;base_yield=observed.redemption_yield
        reference_kind='Cotação histórica' if observed.source_kind=='COTACAO_HISTORICA' else 'Cotação informada'
    else:
        base_yield=req.scenario_yields[0]+(req.spread or 0) if req.scenario_kind=='compra' else req.scenario_yields[0]
        base_pu=engine.price(chosen.valuation_date,base_yield,chosen.vni);reference_kind='Cenário hipotético'
    financial=net_proceeds(lot,base_pu,chosen.settlement_date,req.fees)
    if base_yield is None:
        base_yield=solve_yield(engine,chosen.valuation_date,chosen.vni,base_pu,base_pu).continuous
    shocks=[]
    if base_yield is not None:
        for bp in (-10,-5,-1,0,1,5,10):
            pu=engine.price(chosen.valuation_date,base_yield+bp/10000,chosen.vni)
            f=net_proceeds(lot,pu,chosen.settlement_date,req.fees)
            shocks.append({'basis_points':bp,'yield':base_yield+bp/10000,'net':float(f.net),'profit':float(f.profit),'return':float(f.net_return),'delta_net':float(f.net-financial.net),'note':'A base do choque usa o modelo; uma cotação real pode ter pequeno resíduo.'})
    zero=target_price(lot,chosen.settlement_date,D(0),req.fees)
    zero_yield=solve_yield(engine,chosen.valuation_date,chosen.vni,zero.continuous,zero.tick).verified_boundary
    comparisons=[]
    future=[d for d in sample if d.date>=chosen.date]
    effective_yields=[y+(req.spread or 0) if req.scenario_kind=='compra' else y for y in req.scenario_yields]
    for y in effective_yields:
        for d in future:
            pu=engine.price(d.valuation_date,y,d.vni);f=net_proceeds(lot,pu,d.settlement_date,req.fees)
            try:factor=cash.factor(chosen.settlement_date,d.settlement_date)
            except ValidationError:factor=None
            cash_value=float(financial.net)*factor if factor is not None else None
            comparisons.append({'date':d.date.isoformat(),'yield':y,'net_hold':float(f.net),'net_sell_then_cash':cash_value,'advantage_holding':float(f.net)-cash_value if cash_value is not None else None})
    tax_events=[]
    for limit in (181,361,721):
        threshold=lot.settlement_date+timedelta(days=limit)
        if threshold<=chosen.settlement_date or threshold>lot.max_redemption_date:continue
        after=calendar.next_session(threshold,include=True)
        before=after-timedelta(days=1)
        while not calendar.is_session(before):before-=timedelta(days=1)
        b=net_proceeds(lot,base_pu,before,req.fees);a=net_proceeds(lot,base_pu,after,req.fees)
        gain_due_ir=float(b.tax-a.tax)
        # Same original capital with new target net equal to before-net (not a new return target).
        temp_target=b.net/lot.initial_outflow-1
        required=target_price(lot,after,temp_target,req.fees)
        tax_events.append({'before':before.isoformat(),'after':after.isoformat(),'tax_before':float(b.tax_rate),'tax_after':float(a.tax_rate),'tax_savings_same_price':gain_due_ir,'net_change_same_price':float(a.net-b.net),'price_drop_to_offset':float(base_pu-required.tick),'note':'Mantém PU constante apenas para isolar imposto/custos; o mercado pode mudar.'})
    attribution=None
    observed_quotes=[q for q in result.observations if q.redemption_pu and q.redemption_yield is not None and q.observation_date>=lot.settlement_date and q.observation_date<=req.as_of]
    if len(observed_quotes)>=2:
        old,new=observed_quotes[-2:]
        try:
            a0=infer_anchor(old,engine,side='resgate');a1=infer_anchor(new,engine,side='resgate')
            p0=engine.price_continuous(a0.valuation_date,old.redemption_yield,a0.vni)
            p_rate=engine.price_continuous(a0.valuation_date,new.redemption_yield,a0.vni)
            p_time=engine.price_continuous(a1.valuation_date,new.redemption_yield,a0.vni)
            p_final=engine.price_continuous(a1.valuation_date,new.redemption_yield,a1.vni)
            f0=net_proceeds(lot,old.redemption_pu,old.observation_date,req.fees);f1=net_proceeds(lot,new.redemption_pu,new.observation_date,req.fees)
            q=float(lot.quantity)
            components=[{'label':'Taxa de mercado','amount':q*(p_rate-p0)},{'label':'Passagem do tempo (desconto)','amount':q*(p_time-p_rate)},{'label':'VNI implícito / indexação','amount':q*(p_final-p_time)}]
            costs=-float((f1.tax+f1.custody+f1.other_fees)-(f0.tax+f0.custody+f0.other_fees));components.append({'label':'Variação de impostos e custos','amount':costs})
            residual=float(f1.net-f0.net)-sum(r['amount'] for r in components);components.append({'label':'Resíduo / arredondamento','amount':residual})
            attribution={'start':old.observation_date.isoformat(),'end':new.observation_date.isoformat(),'net_change':float(f1.net-f0.net),'components':components,'note':'Atribuição sequencial: taxa → tempo → VNI → custos. A ordem afeta as parcelas. VNI inferido também absorve arredondamento e convenção; não é IPCA realizado isolado.'}
        except ValidationError:pass
    return {'heatmap':{'dates':[d.date.isoformat() for d in sample],'yields':yields.tolist(),'z':grid,'target':float(req.target)},'reference':{'date':chosen.date.isoformat(),'kind':reference_kind,'pu':float(base_pu),'yield':base_yield,'net':float(financial.net),'return':float(financial.net_return),'target_yield':chosen.maximum_yield,'break_even_yield':zero_yield,'margin_to_target_bps':(chosen.maximum_yield-base_yield)*10000 if chosen.maximum_yield is not None and base_yield is not None else None,'margin_to_zero_bps':(zero_yield-base_yield)*10000 if zero_yield is not None and base_yield is not None else None},'shocks':shocks,'wait_comparison':comparisons,'comparison_is_conditional':True,'cash_label':cash.label,'tax_events':tax_events,'attribution':attribution,'signal_windows':signal_windows(result.observations,lot,req.target,req.fees,calendar),'warnings':['Todas as comparações mantêm o mesmo lote. Cenários não representam cotações futuras disponíveis.','Vender e aplicar em caixa somente é operacional se o lote estiver liberado e a cotação for confirmada.','O mapa usa até 91 datas e 31 taxas; não interpola uma oportunidade executável.']}
