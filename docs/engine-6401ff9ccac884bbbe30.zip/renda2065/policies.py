"""Políticas congeladas. As projeções NÃO garantem legislação futura."""
from decimal import Decimal as D
from .models import Fees, ValidationError

POLICY_VERSION='POLICIES_2026_09_28_v1'
RULES={
 'RENDA_REDEMPTION_ACT365_ESTIMATED_v1':{'name':'Legado — precisão matemática','rounding':'continuous','estimated':True},
 'RENDA_CENTS_ESTIMATED_2026':{'name':'Custódia estimada + componentes em centavos','rounding':'centavos_half_up','order':'bruto; tributo e despesas sobre bruto centesimal; líquido por subtração; PU-alvo conservador','estimated':True},
}
PROFILES=[
 {'id':'original_10_9_v1','label':'Original — 10,9%','target':'10,9','version':1,'origin':'Calibração retrospectiva 19/12/2024–18/09/2026','experimental':False},
 {'id':'recente_5_5_v1','label':'Patamar recente — 5,5% experimental','target':'5,5','version':1,'origin':'Hipótese do recorte iniciado em maio de 2026; não validada prospectivamente','experimental':True},
 {'id':'custom_v1','label':'Personalizado','target':None,'version':1,'origin':'Definido pelo usuário','experimental':True},
]


def fees_for_profile(profile_id,custody=D('.005'),fixed=D('0'),rate=D('0')):
    if profile_id not in RULES:raise ValidationError('E-POLICY','Política desconhecida; não substituir silenciosamente regras antigas.')
    return Fees(custody,fixed,rate,profile_id,RULES[profile_id]['rounding'])


def policy_manifest():
    return {'version':POLICY_VERSION,'reviewed_at':'2026-09-28',
      'tax':{'id':'BR_RF_11033_ART1_v1','final_band_starts':721,'bands':[[0,180,'0.225'],[181,360,'0.20'],[361,720,'0.175'],[721,None,'0.15']],
             'source':'https://www.planalto.gov.br/ccivil_03/_ato2004-2006/2004/lei/l11033.htm'},
      'custody':{'policies':RULES,'base':'valor bruto do resgate','annual_rate':'.005','scope':'antes de 10 anos e da conversão','precision':'estimativa linear ACT/365; sem certificação centesimal da B3',
        'source':'https://clientes.b3.com.br/w/novo-titulo-do-tesouro-direto-tesouro-renda-aposentadoria-extra-'},
      'pricing':{'id':'NTNB1_240_DU252_TD_v1','source':'https://www.tesourodireto.com.br/documents/d/guest/tesouro_renda_mais'},
      'warning':'Nenhum perfil prevê juros ou garante lucro. Alterações de regra não são aplicadas automaticamente a análises salvas.'}
