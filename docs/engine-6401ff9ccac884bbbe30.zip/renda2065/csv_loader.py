"""Importador sem interpolação, com validação de família/vencimento e hash do conteúdo."""
from dataclasses import dataclass
from datetime import datetime
from decimal import Decimal as D
import csv
import hashlib
import io
import unicodedata
from .formatting import parse_number
from .models import Quote, ValidationError, MATURITY_DATE

MAX_BYTES=25*1024*1024


def normalized(text: str) -> str:
    return ' '.join(''.join(c for c in unicodedata.normalize('NFKD',str(text)) if not unicodedata.combining(c)).lower().split())


@dataclass(frozen=True)
class ImportResult:
    quotes: tuple[Quote, ...]
    content_hash: str
    total_rows: int
    ignored_rows: int
    duplicate_rows: int
    encoding: str
    warnings: tuple[str, ...]


def load_treasury_csv(content: bytes) -> ImportResult:
    if not content or len(content)>MAX_BYTES:
        raise ValidationError('E-CSV-SCHEMA','Arquivo vazio ou maior que 25 MB.')
    encoding='utf-8-sig'
    try:
        text=content.decode(encoding)
    except UnicodeDecodeError:
        encoding='cp1252'
        try:
            text=content.decode(encoding)
        except UnicodeDecodeError as exc:
            raise ValidationError('E-CSV-SCHEMA','Codificação não reconhecida.') from exc
    reader=csv.DictReader(io.StringIO(text),delimiter=';')
    if not reader.fieldnames:
        raise ValidationError('E-CSV-SCHEMA','Cabeçalho não encontrado.')
    columns={normalized(c):c for c in reader.fieldnames}
    required=['tipo titulo','data vencimento','data base']
    missing=[c for c in required if c not in columns]
    if missing:
        raise ValidationError('E-CSV-SCHEMA','Colunas ausentes: '+', '.join(missing)+'. Use o CSV separado por ;.')
    if not any(x in columns for x in ('pu compra manha','pu venda manha')):
        raise ValidationError('E-CSV-SCHEMA','É necessária ao menos a coluna PU Compra Manha ou PU Venda Manha.')
    quotes={}; seen={}; total=ignored=duplicates=invalid=0; flags=[]
    for row in reader:
        total+=1
        if total>250000:
            raise ValidationError('E-CSV-SCHEMA','Limite de 250 mil linhas excedido.')
        get=lambda name: row.get(columns.get(name,''),'')
        if normalized(get('tipo titulo'))!='tesouro renda+ aposentadoria extra':
            ignored+=1; continue
        try:
            maturity=datetime.strptime(str(get('data vencimento')).strip(),'%d/%m/%Y').date()
        except ValueError:
            ignored+=1; invalid+=1; continue
        if maturity!=MATURITY_DATE:
            ignored+=1; continue
        try:
            d=datetime.strptime(str(get('data base')).strip(),'%d/%m/%Y').date()
        except ValueError as exc:
            raise ValidationError('E-DATE',f'Data Base inválida na linha {total+1}.') from exc
        def number(name,rate=False):
            nonlocal invalid
            raw=str(get(name) or '').strip()
            if not raw or raw.lower() in ('nan','null','none','-'):
                return None
            try:
                v=parse_number(raw,name)
                if (not rate and v<=0) or (rate and v<=-100):
                    invalid+=1; return None
                return float(v/100) if rate else v
            except ValidationError:
                invalid+=1; return None
        values=(number('taxa compra manha',True),number('taxa venda manha',True),
                number('pu compra manha'),number('pu venda manha'),number('pu base manha'))
        if d in seen:
            if seen[d] != values:
                raise ValidationError('E-DUPLICATE',f'Cotações conflitantes em {d:%d/%m/%Y}; corrija a fonte.')
            duplicates+=1; continue
        seen[d]=values
        quotes[d]=Quote(d,*values,source_ref=f'CSV, linha {total+1}; manhã, sem horário exato')
    if not quotes:
        raise ValidationError('E-INSTRUMENT','Não há Tesouro RendA+ com vencimento 15/12/2084 (nome comercial 2065) neste arquivo.')
    if invalid:
        flags.append(f'{invalid} campos numéricos ou datas de vencimento inválidos ignorados; não substituídos por zero.')
    if encoding=='cp1252':
        flags.append('Arquivo interpretado como Windows-1252.')
    if duplicates:
        flags.append(f'{duplicates} duplicatas idênticas removidas.')
    return ImportResult(tuple(quotes[d] for d in sorted(quotes)),hashlib.sha256(content).hexdigest(),
                        total,ignored,duplicates,encoding,tuple(flags))
