"""Calendários importáveis com fonte e data de conhecimento, sem código executável."""
from dataclasses import dataclass
from datetime import date
import hashlib
import json
from .models import ValidationError

@dataclass(frozen=True)
class CalendarPack:
    version:str
    source:str
    known_on:date
    valid_from:date
    valid_until:date
    closures:tuple[date,...]
    openings:tuple[date,...]
    financial_closures:tuple[date,...]=()
    financial_openings:tuple[date,...]=()
    content_hash:str=''
    source_quality:str='Fonte informada pelo usuário'


def parse_calendar_pack(raw:bytes)->CalendarPack:
    try:
        if len(raw)>1024*1024:raise ValueError('limite')
        x=json.loads(raw)
        start=date.fromisoformat(x['valid_from']);end=date.fromisoformat(x['valid_until']);known=date.fromisoformat(x['known_on'])
        if not isinstance(x['source'],str) or not x['source'].strip() or not x['version'].strip() or start>end:raise ValueError('fonte/período')
        fields={k:tuple(sorted({date.fromisoformat(d) for d in x.get(k,[])})) for k in ('closures','openings','financial_closures','financial_openings')}
        for k,values in fields.items():
            if len(values)>20000 or any(not start<=d<=end for d in values):raise ValueError('datas')
            if 'openings' in k and any(d.weekday()>=5 for d in values):raise ValueError('abertura de fim de semana não suportada')
        if set(fields['closures'])&set(fields['openings']) or set(fields['financial_closures'])&set(fields['financial_openings']):raise ValueError('conflito')
        return CalendarPack(x['version'],x['source'],known,start,end,**fields,content_hash=hashlib.sha256(raw).hexdigest())
    except (ValueError,KeyError,TypeError,AttributeError) as exc:
        raise ValidationError('E-CALENDAR','Pacote de calendário inválido: confira fonte, datas, cobertura e exceções.') from exc
