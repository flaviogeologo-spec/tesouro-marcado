"""Laboratório de regras explícitas: máximo retrospectivo não é previsão.

Utiliza PU observado, compra integral, impostos por lote e reinvestimento somente
após resgate disponível. Walk-forward conserva a posição aberta na fronteira.
"""
from __future__ import annotations
from dataclasses import dataclass,replace,asdict
from datetime import date,timedelta
from decimal import Decimal as D,ROUND_DOWN
from hashlib import sha256
import json,math,time
import numpy as np
from .models import PurchaseLot,Fees,Quote,ValidationError
from .calendar_rules import FinancialCalendar
from .tax_and_fees import net_proceeds
from .benchmarks import CashBenchmark

EXIT_FAMILIES={'net_target':'Lucro líquido','fixed_rate':'Taxa nominal','spread':'Queda desde a entrada','excess_cash':'Excesso sobre o caixa','decay':'Meta com redução temporal','trailing':'Realização após devolução','regime_band':'Base congelada do patamar','deadline':'Data-limite explícita'}


@dataclass(frozen=True)
class ResearchConfig:
    start:date
    end:date
    entry:float=.0717
    exit_mode:str='net_target'
    exit_value:float=.109
    mode:str='cycles'
    capital:float=100000.
    execution_delay:int=0
    slippage:float=0.
    confirmation:int=1
    settlement_lag:int=0
    custody:float=.005
    deadline:date|None=None
    decay_after:int=180
    decay_floor:float=.04
    decay_rate:float=.06
    trailing_giveback:float=.025
    entry_percentile:float|None=None
    regime_window:int=63
    half_life_days:int=180

    def __post_init__(self):
        if self.start>=self.end or (self.end-self.start).days>3650:raise ValidationError('E-DATE','Pesquisa requer intervalo positivo inferior a dez anos.')
        if self.exit_mode not in EXIT_FAMILIES or self.mode not in ('cycles','single'):raise ValidationError('E-RULE','Regra ou objetivo não reconhecido.')
        numeric=(self.entry,self.exit_value,self.capital,self.slippage,self.custody,self.decay_floor,self.decay_rate,self.trailing_giveback)
        if not all(math.isfinite(x) for x in numeric):raise ValidationError('E-RULE','Parâmetro não finito.')
        if not -0.5<self.entry<1 or not -0.5<=self.exit_value<=2:raise ValidationError('E-RULE','Limites de taxa/meta fora do domínio.')
        if self.capital<1 or self.capital>1e9 or not 0<=self.slippage<=.05:raise ValidationError('E-RULE','Capital ou slippage fora do domínio.')
        if self.execution_delay not in range(4) or self.confirmation not in range(1,6) or self.settlement_lag not in (0,1):raise ValidationError('E-RULE','Atraso 0–3, confirmação 1–5 e liquidação 0/1.')
        if self.regime_window not in (21,63,126,252) or not 1<=self.half_life_days<=3650:raise ValidationError('E-RULE','Janela de regime ou meia-vida inválida.')
        if self.entry_percentile is not None and not .5<=self.entry_percentile<=.99:raise ValidationError('E-RULE','Percentil entre 50% e 99%.')
        if not 0<=self.decay_after<=3650 or not 0<=self.decay_floor<=2 or not 0<=self.decay_rate<=1 or not 0<self.trailing_giveback<=1:raise ValidationError('E-RULE','Parâmetros de saída adaptativa inválidos.')
        if self.exit_mode=='deadline' and (self.deadline is None or not self.start<=self.deadline<=self.end):raise ValidationError('E-DATE','Data-limite obrigatória dentro do recorte.')

    @property
    def id(self):
        return sha256(json.dumps(asdict(self),default=str,sort_keys=True).encode()).hexdigest()[:16]


def _cancel(event):
    if event is not None and event.is_set():raise ValidationError('E-CANCELLED','Pesquisa cancelada pelo usuário; a operação aberta foi preservada.')


def simulate(quotes,config:ResearchConfig,cash:CashBenchmark|None=None,*,trace:bool=True,cancel=None):
    cash=cash or CashBenchmark();fees=Fees(D(str(config.custody)),policy_id='RENDA_CENTS_ESTIMATED_2026',monetary_rounding='centavos_half_up')
    allqs=sorted((q for q in quotes if q.observation_date<=config.end),key=lambda q:q.observation_date)
    qs=[q for q in allqs if config.start<=q.observation_date<=config.end]
    if len(qs)<2:raise ValidationError('E-DATA','Poucas observações para avaliar o recorte.')
    if len({q.observation_date for q in allqs})!=len(allqs):raise ValidationError('E-DUPLICATE','Pesquisa diária requer datas únicas.')
    start,end=qs[0].observation_date,qs[-1].observation_date
    cash.ensure_coverage(start,end)
    calendar=FinancialCalendar(knowledge_date=config.start)
    rates={q.observation_date:q.buy_yield for q in allqs if q.buy_yield is not None}
    prior={};prior_values=[]
    for q in allqs:
        window=prior_values[-config.regime_window:]
        prior[q.observation_date]=tuple(window)
        if q.buy_yield is not None:prior_values.append(q.buy_yield)
    amount=D(str(config.capital));cash_since=start;lot=None;events=[];curve=[];navs=[];dates=[]
    sale_days=[];last_price=None;last_price_date=None;completed=0;realized=D(0);total_tax=D(0);total_custody=D(0)
    pending_entry=None;pending_exit=None;confirm_count=0;peak=-math.inf;armed=False;band=None;last_sale_index=-1;ever_bought=False;entry_events=0;residual_pre_sale=0.
    holding_observations=0;previous_day=None;first_purchase=None;durations=[]
    for i,q in enumerate(qs):
        _cancel(cancel);day=q.observation_date
        if q.redemption_pu is not None:
            last_price=q.redemption_pu*D(str(1-config.slippage));last_price_date=day
        def cash_now():
            return amount*D(str(cash.factor(cash_since,day,checked=True))) if amount and day>=cash_since else amount
        session=calendar.is_session(day)
        sold_today=False
        if lot is not None:
            holding_observations+=1
            value=net_proceeds(lot,last_price,calendar.redemption_settlement(day,config.settlement_lag),fees) if last_price is not None and day>=lot.settlement_date else None
            eligible=session and calendar.eligible(lot,day) and q.redemption_pu is not None
            if eligible and value is not None:
                age=value.age_days;g=float(value.net_return);peak=max(peak,g)
                if g>=config.exit_value:armed=True
                benchmark_gain=cash.factor(lot.settlement_date,day,checked=True)-1 if day>=lot.settlement_date else 0.
                target=config.exit_value
                if config.exit_mode=='net_target':hit=g>=target
                elif config.exit_mode=='fixed_rate':hit=q.buy_yield is not None and q.buy_yield<=target+1e-12
                elif config.exit_mode=='spread':hit=q.buy_yield is not None and q.buy_yield<=lot.entry_yield-target+1e-12
                elif config.exit_mode=='excess_cash':hit=g>=benchmark_gain+target
                elif config.exit_mode=='decay':hit=g>=max(config.decay_floor,target-max(0,age-config.decay_after)/365*config.decay_rate)
                elif config.exit_mode=='trailing':hit=armed and g<=peak-config.trailing_giveback
                elif config.exit_mode=='regime_band':hit=band is not None and q.buy_yield is not None and q.buy_yield<=band+1e-12
                else:hit=day>=config.deadline
                contiguous=previous_day is not None and calendar.next_session(previous_day)==day
                confirm_count=(confirm_count+1 if contiguous else 1) if hit else 0
                if not hit:pending_exit=None
                elif confirm_count>=config.confirmation:
                    if pending_exit is None:pending_exit=i+config.execution_delay
                    if i>=pending_exit:
                        settle=calendar.redemption_settlement(day,config.settlement_lag)
                        current_cash=cash_now();residual_pre_sale=float(current_cash)
                        amount=current_cash+value.net;cash_since=settle
                        event={'type':'sell','date':day.isoformat(),'settlement':settle.isoformat(),'quantity':float(lot.quantity),'pu':float(last_price),'net':float(value.net),'gross':float(value.gross),'tax':float(value.tax),'custody':float(value.custody),'cost':float(lot.initial_outflow),'profit':float(value.profit),'return':g,'age_days':age,'buy_yield':q.buy_yield,'entry_date':lot.trade_date.isoformat(),'rule':config.exit_mode}
                        events.append(event);completed+=1;realized+=value.profit;total_tax+=value.tax;total_custody+=value.custody;sale_days.append(day);durations.append(age)
                        lot=None;pending_exit=None;confirm_count=0;peak=-math.inf;armed=False;last_sale_index=i;sold_today=True
            else:confirm_count=0;pending_exit=None
        if lot is None and not sold_today and i>last_sale_index and day>=cash_since and not (config.mode=='single' and ever_bought):
            window=prior[day];threshold=config.entry
            allowed=True
            if config.entry_percentile is not None:
                if len(window)<21:allowed=False
                else:threshold=max(threshold,float(np.quantile(window,config.entry_percentile)))
            signal=allowed and session and q.buy_pu is not None and q.buy_yield is not None and q.buy_yield>=threshold-1e-12
            if not signal:pending_entry=None
            else:
                if pending_entry is None:pending_entry=i+config.execution_delay
                if i>=pending_entry:
                    available=cash_now();pu=q.buy_pu*D(str(1+config.slippage));qty=(available/pu).quantize(D('.01'),rounding=ROUND_DOWN)
                    if qty>0:
                        settlement=calendar.next_session(day)
                        lot=PurchaseLot(day,settlement,qty,pu,entry_yield=q.buy_yield,source_kind='HIPOTETICA_PESQUISA')
                        amount=available-lot.initial_outflow;cash_since=day;ever_bought=True;entry_events+=1;first_purchase=first_purchase or day
                        band=float(np.quantile(window,.2)) if len(window)>=21 else None
                        events.append({'type':'buy','date':day.isoformat(),'settlement':settlement.isoformat(),'quantity':float(qty),'pu':float(pu),'cost':float(lot.initial_outflow),'buy_yield':q.buy_yield,'band_at_entry':band})
                        peak=-math.inf;armed=False
                    pending_entry=None
        cash_value=cash_now();open_value=D(0);locked=D(0)
        if lot is not None:
            if day<lot.settlement_date:open_value=lot.initial_outflow;locked=open_value
            elif last_price is not None:
                open_value=net_proceeds(lot,last_price,calendar.redemption_settlement(day,config.settlement_lag),fees).net
                if not calendar.eligible(lot,day):locked=open_value
        nav=float(cash_value+open_value);navs.append(nav);dates.append(day)
        if trace:curve.append({'date':day.isoformat(),'nav':nav,'cash':float(cash_value) if day>=cash_since else 0.,'receivable':float(cash_value) if day<cash_since else 0.,'open':float(open_value),'locked':float(locked),'mark_date':last_price_date.isoformat() if last_price_date else None})
        previous_day=day
    horizon=(end-start).days;final=navs[-1];return_total=final/config.capital-1
    peak_nav=np.maximum.accumulate(np.r_[config.capital,navs]);drawdown=float(np.min(np.r_[config.capital,navs]/peak_nav-1))
    weights=np.exp2(-np.array([(end-d).days for d in dates[1:]],dtype=float)/config.half_life_days)
    changes=np.diff(np.log(np.maximum(navs,1e-50)));steps=np.array([(b-a).days for a,b in zip(dates[:-1],dates[1:])],dtype=float)
    weighted=math.expm1(float(np.dot(changes,weights)/np.dot(steps,weights)*365)) if len(weights) and np.dot(steps,weights)>0 else None
    final_cash=float(cash_now());final_open=final-final_cash;lastrow=curve[-1] if trace else None
    final_locked=final_open if lot is not None and not calendar.eligible(lot,end) else 0.
    summary={'id':config.id,'family':config.exit_mode,'entry':config.entry,'exit_value':config.exit_value,'start':start.isoformat(),'end':end.isoformat(),'days':horizon,'net_final':final,'return':return_total,'annualized':(final/config.capital)**(365/horizon)-1 if final>0 and horizon>0 else None,'max_drawdown':drawdown,'buys':entry_events,'sales':completed,'open_value':final_open,'locked_value':final_locked,'cash':final_cash if end>=cash_since else 0,'receivable':final_cash if end<cash_since else 0,'realized_profit':float(realized),'realized_tax':float(total_tax),'realized_custody':float(total_custody),'average_holding_days':float(np.mean(durations)) if durations else None,'mean_exposure':holding_observations/len(qs),'weighted_recent_annualized':weighted,'cash_residual_before_sale':residual_pre_sale,'first_purchase':first_purchase.isoformat() if first_purchase else None,'pending_target':config.exit_value if lot else None,'benchmark_net':config.capital*cash.factor(start,end,checked=True)}
    return {'summary':summary,'trades':events,'curve':curve,'config':asdict(config),'benchmark':cash.label,'warnings':['Simulação retrospectiva. As cotações da manhã não garantem execução; o calendário histórico é uma aproximação por regras.','Líquido marcado inclui posições abertas; carência não é encurtada por um alvo atingido. Custódia estimada ACT/365.','Número de configurações não é número de experimentos independentes.']}


def bootstrap_nav(curve,paths=100,block=21,seed=2065):
    if len(curve)<block*2:return {'status':'Amostra insuficiente para dois blocos.','paths':0}
    if not 1<=paths<=500 or not 2<=block<=126:raise ValidationError('E-BOOTSTRAP','Até 500 trajetórias, blocos entre 2 e 126.')
    vals=np.array([r['nav'] for r in curve]);rets=np.diff(np.log(vals));rng=np.random.default_rng(seed);out=[]
    for _ in range(paths):
        samples=[]
        while len(samples)<len(rets):
            start=int(rng.integers(0,len(rets)-block+1));samples.extend(rets[start:start+block])
        out.append(math.expm1(sum(samples[:len(rets)])))
    return {'status':'Concluído','paths':paths,'block_observations':block,'seed':seed,'p10':float(np.quantile(out,.1)),'median':float(np.median(out)),'p90':float(np.quantile(out,.9)),'values':out,'note':'Reamostragem em blocos dos retornos marcados de uma estratégia fixa. Não recalcula preços, custos ou sinais em mundos alternativos; não é probabilidade futura nem intervalo de confiança para a estratégia.'}


def build_research_grid(base:ResearchConfig,entries,targets,*,families=('net_target',),fixed_targets=None,spread_targets=None):
    """Build, deduplicate, and validate a research grid before starting a job."""
    configs=[]
    try:
        entries=tuple(entries);targets=tuple(targets);families=tuple(families)
        fixed_targets=tuple(fixed_targets) if fixed_targets is not None else None
        spread_targets=tuple(spread_targets) if spread_targets is not None else None
    except TypeError as exc:
        raise ValidationError('E-GRID','Grade de pesquisa inválida.') from exc
    if not entries or not targets:raise ValidationError('E-GRID','Defina entradas e alvos.')
    if not families:raise ValidationError('E-GRID','Selecione ao menos uma família de saída.')
    if any(len(values)>25 for values in (entries,targets,fixed_targets or (),spread_targets or ())):
        raise ValidationError('E-GRID','Limite de 25 valores por lista da grade.')
    if len(families)>8:raise ValidationError('E-GRID','Selecione até 8 famílias.')
    for family in families:
        if family not in EXIT_FAMILIES:raise ValidationError('E-RULE','Família desconhecida.')
        if family=='fixed_rate':values=fixed_targets if fixed_targets is not None else (.068,.07,.071)
        elif family=='spread':values=spread_targets if spread_targets is not None else (.0025,.0035,.0045)
        elif family=='regime_band':values=(0.,)
        elif family=='deadline':values=(0.,)
        else:values=targets
        if not values:raise ValidationError('E-GRID',f'Defina pelo menos um alvo para a família {family}.')
        for e in entries:
            for value in values:configs.append(replace(base,entry=e,exit_mode=family,exit_value=value))
    configs=list({c.id:c for c in configs}.values())
    if not configs:raise ValidationError('E-GRID','A grade não contém configurações executáveis.')
    if len(configs)>600:raise ValidationError('E-GRID','Limite de 600 configurações por pesquisa. Reduza a grade para manter a tela responsiva.')
    return tuple(configs)


def run_study(quotes,base:ResearchConfig,entries,targets,*,families=('net_target',),cash=None,cutoff=None,rolling=True,bootstrap_paths=100,cancel=None,progress=None,fixed_targets=None,spread_targets=None,prepared_configs=None):
    cash=cash or CashBenchmark();started=time.perf_counter()
    if prepared_configs is None:
        configs=build_research_grid(base,entries,targets,families=families,fixed_targets=fixed_targets,spread_targets=spread_targets)
    else:
        try:configs=tuple(prepared_configs)
        except TypeError as exc:raise ValidationError('E-GRID','Grade de pesquisa inválida.') from exc
        if not configs or any(not isinstance(config,ResearchConfig) for config in configs):
            raise ValidationError('E-GRID','Grade de pesquisa inválida.')
        configs=tuple({config.id:config for config in configs}.values())
        if len(configs)>600:raise ValidationError('E-GRID','Limite de 600 configurações por pesquisa. Reduza a grade para manter a tela responsiva.')
    ranking=[]
    for i,c in enumerate(configs):
        _cancel(cancel);r=simulate(quotes,c,cash,trace=False,cancel=cancel);ranking.append(r['summary'])
        if progress:progress(i+1,len(configs),'Comparando regras')
    ranking.sort(key=lambda s:(-s['net_final'],s['id']));best_config=next(c for c in configs if c.id==ranking[0]['id']);best=simulate(quotes,best_config,cash,cancel=cancel)
    benchmark=simulate(quotes,replace(base,entry=.99,exit_mode='net_target'),cash,cancel=cancel)
    original=simulate(quotes,replace(base,entry=.0726,exit_mode='fixed_rate',exit_value=.07),cash,cancel=cancel)
    fixed=simulate(quotes,replace(base,entry=.0717,exit_mode='net_target',exit_value=.109),cash,cancel=cancel)
    near=[r for r in ranking if r['return']>=ranking[0]['return']-.02]
    validation=None
    if cutoff is not None and base.start<cutoff<base.end:
        training=[]
        training_quotes=tuple(q for q in quotes if q.observation_date<=cutoff)
        for c in configs:
            _cancel(cancel)
            row=simulate(training_quotes,c,cash,trace=False,cancel=cancel)['summary']
            row['id']=c.id;training.append(row)
        training.sort(key=lambda r:(-r['net_final'],r['id']))
        if training:
            winner=next(c for c in configs if c.id==training[0]['id']);full=simulate(quotes,winner,cash,cancel=cancel)
            boundary=[r for r in full['curve'] if r['date']<=cutoff.isoformat()][-1]
            test_return=full['summary']['net_final']/boundary['nav']-1;days=(date.fromisoformat(full['summary']['end'])-date.fromisoformat(boundary['date'])).days
            validation={'selected_id':winner.id,'training_ranking':training[:15],'cutoff':cutoff.isoformat(),'continued_without_reset':True,'capital_at_boundary':boundary['nav'],'locked_at_boundary':boundary['locked'],'test_return':test_return,'test_annualized':(1+test_return)**(365/days)-1 if days else None,'full':full,'note':'Escolha somente até o corte; carteira continua sem venda artificial. Esta análise reutiliza histórico já estudado, não é validação prospectiva virgem.'}
    cuts=[];cut_exclusions=[]
    qs=sorted((q for q in quotes if base.start<=q.observation_date<=base.end),key=lambda q:q.observation_date)
    if rolling and len(qs)>100:
        indices=sorted(set([0,len(qs)//6,len(qs)//3,len(qs)//2]))
        for i in indices:
            if (base.end-qs[i].observation_date).days<90:continue
            for cfg in (best_config,replace(base,entry=.0717,exit_mode='net_target',exit_value=.109)):
                _cancel(cancel)
                cut_start=qs[i].observation_date
                if cfg.exit_mode=='deadline' and cfg.deadline is not None and cut_start>cfg.deadline:
                    cut_exclusions.append({
                        'type':'start_after_deadline',
                        'interval':{'start':cut_start.isoformat(),'end':base.end.isoformat()},
                        'rule':{'family':cfg.exit_mode,'id':cfg.id,'deadline':cfg.deadline.isoformat()},
                        'reason':f"Data-limite em {cfg.deadline.isoformat()} anterior ao início em {cut_start.isoformat()}; recorte incompatível.",
                    })
                    continue
                r=simulate(quotes,replace(cfg,start=cut_start),cash,trace=False,cancel=cancel)
                cuts.append(r['summary'])
    if rolling and len(qs)>100:
        for index in sorted(set([len(qs)*2//3,len(qs)*5//6])):
            cut_end=qs[index].observation_date
            if (cut_end-base.start).days<90:continue
            for cfg in (best_config,replace(base,entry=.0717,exit_mode='net_target',exit_value=.109)):
                _cancel(cancel)
                truncated=tuple(q for q in quotes if q.observation_date<=cut_end)
                cuts.append(simulate(truncated,cfg,cash,trace=False,cancel=cancel)['summary'])
    sales=[e for e in best['trades'] if e['type']=='sell']
    positive=sum(max(0,e['profit']) for e in sales)
    max_contribution=max([max(0,e['profit']) for e in sales],default=0)/positive if positive else None
    sensitivity=[]
    for label,update in [('atraso de uma observação',{'execution_delay':1}),('preço 0,10% menos favorável',{'slippage':.001}),('confirmação em 2 sessões',{'confirmation':2})]:
        _cancel(cancel);r=simulate(quotes,replace(best_config,**update),cash,trace=False,cancel=cancel);sensitivity.append({'scenario':label,**r['summary']})
    body=json.dumps([(q.observation_date.isoformat(),q.buy_yield,str(q.buy_pu),str(q.redemption_pu)) for q in quotes],sort_keys=True)
    return {'summary':{'configurations':len(configs),'best':ranking[0],'near_count':len(near),'near_entry_range':[min(r['entry'] for r in near),max(r['entry'] for r in near)],'near_target_range':[min(r['exit_value'] for r in near if r['family']==ranking[0]['family']),max(r['exit_value'] for r in near if r['family']==ranking[0]['family'])],'best_cycle_share_of_positive_profit':max_contribution,'elapsed_seconds':time.perf_counter()-started},'ranking':ranking,'best':best,'original':original,'reference':fixed,'cash':benchmark,'validation':validation,'rolling_cuts':cuts,'rolling_cut_exclusions':cut_exclusions,'sensitivity':sensitivity,'bootstrap':bootstrap_nav(best['curve'],bootstrap_paths) if bootstrap_paths else None,'history_hash':sha256(body.encode()).hexdigest(),'protocol':{'base':asdict(base),'entries':entries,'targets':targets,'fixed_targets':fixed_targets,'spread_targets':spread_targets,'families':list(families),'cash':cash.label,'cutoff':str(cutoff) if cutoff else None},'warnings':['Máximo retrospectivo, não uma recomendação automática. Nenhum alvo do avaliador é alterado.','A faixa estável é definida por até 2 pontos percentuais de retorno acumulado abaixo do máximo; não é teste de significância.','Recortes sobrepostos compartilham operações. Dependência de ciclos e execução devem ser examinadas.','Saída por taxa usa a taxa anunciada de compra como sinal e o PU efetivo de resgate como preço.']}
