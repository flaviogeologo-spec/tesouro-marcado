"""RendA+: 240 amortizações, VNI e DU/252. Nunca aproxima por um único vencimento."""
from __future__ import annotations
from dataclasses import dataclass
from datetime import date
from decimal import Decimal as D, ROUND_DOWN, ROUND_FLOOR
from functools import lru_cache
import math
import numpy as np
from .calendar_rules import FinancialCalendar
from .models import PricingAnchor, Quote, ValidationError

WEIGHTS_DECIMAL = (D('.00416666'),)*239+(D('.00416826'),)
WEIGHTS = np.array([float(x) for x in WEIGHTS_DECIMAL])
PERCENT_WEIGHTS = WEIGHTS*100
MIN_YIELD=-.95
MAX_YIELD=10.0


@lru_cache(maxsize=4)
def payment_dates(conversion_year:int=2065)->tuple[date,...]:
    return tuple(date(conversion_year+i//12,i%12+1,15) for i in range(240))


def validate_yield(y:float):
    if not math.isfinite(y) or not MIN_YIELD<=y<=MAX_YIELD:
        raise ValidationError('E-YIELD-DOMAIN','Taxa fora do domínio numérico: -95% a 1.000% a.a.; sempre maior que -100%.')


def continuous_factor(y:float,du:np.ndarray)->float:
    validate_yield(y)
    du=np.asarray(du,dtype=float)
    if du.shape!=(240,) or np.any(du<0):
        raise ValidationError('E-HORIZON','Precificação exige os 240 fluxos futuros, antes da conversão.')
    f=float(np.dot(WEIGHTS,np.exp(-np.log1p(y)*du/252.0)))
    if not math.isfinite(f) or f<=0:
        raise ValidationError('E-YIELD-DOMAIN','Desconto fora da precisão numérica disponível.')
    return f


def published_price_from_du(vni:float,y:float,du:np.ndarray)->D:
    """Perfil do documento TD: VNI 6, DU/252 14, parcela 10, cotação 4, PU 2."""
    validate_yield(y)
    if not math.isfinite(vni) or vni<=0:
        raise ValidationError('E-ANCHOR','VNI inválido.')
    du=np.asarray(du,dtype=float)
    if du.shape!=(240,) or np.any(du<0):
        raise ValidationError('E-HORIZON','Esperados 240 fluxos ainda não pagos.')
    exponent=np.trunc(du/252.0*1e14)/1e14
    pv=PERCENT_WEIGHTS*np.exp(-math.log1p(y)*exponent)
    # Valores presentes são positivos: arredondamento half-up a 10 casas.
    pv=np.floor(pv*1e10+.5)/1e10
    quotation=D(str(math.fsum(pv.tolist()))).quantize(D('.0001'),rounding=ROUND_DOWN)
    vni_d=D(str(vni)).quantize(D('.000001'),rounding=ROUND_DOWN)
    return (vni_d*quotation/100).quantize(D('.01'),rounding=ROUND_DOWN)


class PricingEngine:
    def __init__(self,calendar:FinancialCalendar,conversion_year:int=2065):
        self.calendar=calendar
        self.nominal_dates=payment_dates(conversion_year)
        self.financial_dates=tuple(calendar.roll_payment(d) for d in self.nominal_dates)
        self._du_cache:dict[date,np.ndarray]={}

    def du(self,valuation:date)->np.ndarray:
        if valuation>=self.nominal_dates[0]:
            raise ValidationError('E-HORIZON','A precificação desta versão termina antes da conversão.')
        if valuation not in self._du_cache:
            a=self.calendar.days_to_payments(valuation,self.financial_dates)
            a.flags.writeable=False
            self._du_cache[valuation]=a
        return self._du_cache[valuation]

    def price_continuous(self,valuation:date,y:float,vni:float)->float:
        return vni*continuous_factor(y,self.du(valuation))

    def price(self,valuation:date,y:float,vni:float)->D:
        return published_price_from_du(vni,y,self.du(valuation))


def projected_vni(anchor:PricingAnchor,valuation:date,inflation:float,monthly_path=())->float:
    if valuation<anchor.valuation_date:
        raise ValidationError('E-ANCHOR','Não retroprojetar uma âncora futura como dado conhecido.')
    if not math.isfinite(inflation) or inflation<=-1 or inflation>10:
        raise ValidationError('E-PROJECTION','Inflação fora do domínio numérico.')
    try:
        from .benchmarks import monthly_projection
        value=monthly_projection(anchor,valuation,inflation,monthly_path)
    except OverflowError as exc:
        raise ValidationError('E-PROJECTION','A inflação produz valores fora da precisão disponível.') from exc
    if not math.isfinite(value) or value<=0 or value>1e18:
        raise ValidationError('E-PROJECTION','VNI projetado fora da precisão disponível.')
    return value


def infer_anchor(quote:Quote,engine:PricingEngine,side:str='auto')->PricingAnchor:
    """Preferir resgate D+0; compra D+1 é a alternativa explícita, nunca cruzar lados."""
    use_sell=side=='resgate' or (side=='auto' and quote.redemption_pu is not None and quote.redemption_yield is not None)
    if use_sell:
        pu,y=quote.redemption_pu,quote.redemption_yield
        day=quote.valuation_date or quote.observation_date
        label='PU/taxa de resgate na data-base (modelo D+0)'
    else:
        pu,y=quote.buy_pu,quote.buy_yield
        day=quote.valuation_date or engine.calendar.next_session(quote.observation_date)
        label='PU/taxa de compra; referência financeira D+1 projetada'
    if pu is None or y is None:
        raise ValidationError('E-ANCHOR','Âncora exige PU e taxa do mesmo lado, título e observação.')
    vni=float(pu)/continuous_factor(y,engine.du(day))
    error=None; flags=[]
    if use_sell and quote.buy_pu is not None and quote.buy_yield is not None:
        paired_day=engine.calendar.next_session(quote.observation_date)
        paired=engine.price(paired_day,quote.buy_yield,vni)
        error=float(paired-quote.buy_pu)
        tolerance=max(.03,float(quote.buy_pu)*.0005)
        if abs(error)>tolerance:
            flags.append('A reconstrução da outra ponta excede a tolerância; convenção de PU/VNI aproximada. PU observado preservado.')
    return PricingAnchor(day,vni,quote.observation_date,'VNI_INFERIDO',quote.source_ref+'; '+label,error,tuple(flags))


def select_anchor(anchors:tuple[PricingAnchor,...],valuation:date,as_of:date,
                  trade_date:date|None=None)->PricingAnchor|None:
    known_cutoff=min(as_of,trade_date or valuation)
    eligible=[a for a in anchors if a.known_on<=known_cutoff and a.valuation_date<=valuation]
    if not eligible:
        return None
    # Mesma referência: VNI informado de fonte independente prevalece.
    return max(eligible,key=lambda a:(a.valuation_date,a.source_kind=='VNI_OFICIAL_INFORMADO',a.known_on))


@dataclass(frozen=True)
class YieldTarget:
    continuous:float|None
    verified_boundary:float|None
    tick:float|None
    status:str
    residual_pu:float|None
    bracket:tuple[float,float]
    reason:str=''


def solve_yield(engine:PricingEngine,valuation:date,vni:float,required:D,required_tick:D)->YieldTarget:
    """Raiz contínua e limite conservador revalidado no perfil monetário."""
    from scipy.optimize import brentq
    target=float(required)
    du=engine.du(valuation)
    def f(y):
        return vni*continuous_factor(y,du)-target
    bracket=(-.05,.30)
    for low,high in [bracket,(-.5,1.),(MIN_YIELD,MAX_YIELD)]:
        bracket=(low,high); a,b=f(low),f(high)
        if a>=0 and b<=0:
            break
    else:
        status='UNATTAINABLE' if a<0 else 'ALL_DOMAIN'
        reason='Meta não alcançada no domínio pesquisado.' if a<0 else 'Meta atendida em todo o domínio pesquisado; não há taxa máxima finita identificada.'
        return YieldTarget(None,None,None,status,None,bracket,reason)
    root=brentq(f,low,high,xtol=1e-12,rtol=1e-14,maxiter=100)
    residual=f(root)
    if abs(residual)>max(1e-6,abs(target)*1e-9):
        return YieldTarget(None,None,None,'RESIDUAL',residual,bracket,'Raiz não satisfez a tolerância econômica.')
    # A raiz contínua não inclui truncamentos. Encontrar a borda que atende no PU publicado.
    a,b=low,high
    if published_price_from_du(vni,a,du)<required_tick:
        return YieldTarget(root,None,None,'UNATTAINABLE_TICK',residual,bracket,'Meta não atendida no preço monetário do limite inferior.')
    for _ in range(60):
        mid=(a+b)/2
        if published_price_from_du(vni,mid,du)>=required_tick:
            a=mid
        else:
            b=mid
        if b-a<1e-11:
            break
    tick=D(str(a)).quantize(D('.0001'),rounding=ROUND_FLOOR)
    for _ in range(50):
        if published_price_from_du(vni,float(tick),du)>=required_tick:
            break
        tick-=D('.0001')
    else:
        raise ValidationError('E-NO-ROOT','Não foi possível validar o limiar monetário conservador.')
    for _ in range(50):
        next_tick=tick+D('.0001')
        if float(next_tick)>MAX_YIELD or published_price_from_du(vni,float(next_tick),du)<required_tick:
            break
        tick=next_tick
    return YieldTarget(root,a,float(tick),'OK',residual,bracket)
