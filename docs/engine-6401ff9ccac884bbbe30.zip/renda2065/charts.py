"""Visualização sem cálculo fiscal e sem exportação na barra dos gráficos."""
from datetime import date, timedelta
import math
from .analysis_service import AnalysisResult
from .formatting import pct, money, day_label, br_number

PLOT_CONFIG={'displaylogo':False,'modeBarButtonsToRemove':['toImage'],
             'scrollZoom':False,'responsive':True}


def _mark(fig,day,label,level=0):
    x=day.isoformat()
    fig.add_shape(type='line',xref='x',yref='paper',x0=x,x1=x,y0=0,y1=1,line=dict(dash='dot',width=1))
    if label:
        fig.add_annotation(x=x,y=1+level*.075,xref='x',yref='paper',text=label,showarrow=False,
                           xanchor='left',yanchor='bottom',font=dict(size=10))


def _layout(fig,r,ytitle,selected_date=None):
    fig.update_layout(height=475,margin=dict(l=24,r=24,t=64,b=22),
                      xaxis_title='Data hipotética de negociação',yaxis_title=ytitle,
                      hovermode='x unified',legend=dict(orientation='h',y=-.18,x=0),
                      uirevision=r.fingerprint,separators=',.',
                      font=dict(size=12))
    fig.update_xaxes(tickformat='%d/%m/%Y',showgrid=True)
    fig.update_yaxes(showgrid=True,zeroline=False)
    lo,hi=r.request.start_date,r.request.end_date
    if lo<=r.first_eligible<=hi:
        _mark(fig,r.first_eligible,'Liberação')
    if lo<=r.request.as_of<hi:
        _mark(fig,r.request.as_of,'Referência / futuro',level=1)
    eligible_rows=[row for row in r.daily if row.eligible]
    for previous,current in zip(eligible_rows,eligible_rows[1:]):
        if previous.tax_rate != current.tax_rate:
            # Os pontos já incorporam a liquidação D+0/D+1 e o calendário.
            _mark(fig,current.date,'IR: mudança de faixa')
    if selected_date and lo<=selected_date<=hi:
        _mark(fig,selected_date,'')
    return fig


def condition_chart(r:AnalysisResult,view='rate',*,selected_date:date|None=None,show_all=False,
                    buy_equivalent=False,overlay=True):
    import plotly.graph_objects as go
    fig=go.Figure()
    rows=[x for x in r.daily if show_all or x.eligible]
    spread=(r.request.spread or 0) if buy_equivalent else 0
    title='PU mínimo de resgate (R$ por título)' if view=='price' else ('Taxa máxima equivalente de compra (% a.a.)' if buy_equivalent else 'Taxa máxima de resgate (% a.a.)')
    for future in (False,True):
        part=[x for x in rows if (x.date>r.request.as_of)==future]
        if not part:continue
        y=[float(x.target_pu) if view=='price' else (100*(x.maximum_yield-spread) if x.maximum_yield is not None else None) for x in part]
        data=[[day_label(x.settlement_date),str(x.age_days),pct(x.tax_rate),money(x.target_pu),
               pct(x.conservative_yield-spread,2) if x.conservative_yield is not None else '—',
               money(x.target_net),money(x.target_custody),x.vni_source,
               'Elegível pelo calendário' if x.eligible else 'Não executável'] for x in part]
        fig.add_trace(go.Scatter(x=[x.date.isoformat() for x in part],y=y,
            name='Limite · cenário futuro' if future else 'Limite · cálculo datado',
            mode='lines',line=dict(width=2,dash='dash' if future else 'solid'),connectgaps=False,
            customdata=data,hovertemplate='%{x|%d/%m/%Y}<br>Limite: %{y:.4f}<br>'
            'Liquidação: %{customdata[0]} · %{customdata[1]} dias<br>IR: %{customdata[2]}'
            '<br>PU mínimo: %{customdata[3]}<br>Taxa no passo conservador: %{customdata[4]}'
            '<br>Líquido-alvo: %{customdata[5]}<br>Custódia no alvo: %{customdata[6]}'
            '<br>%{customdata[7]} · %{customdata[8]}<extra></extra>'))
    if overlay and r.observations:
        obs={q.observation_date:q for q in r.observations}
        last=max(obs)
        dates=[d.date for d in rows if d.date<=last]
        values=[]
        for d in dates:
            q=obs.get(d)
            v=None
            if q:
                if view=='price':v=float(q.redemption_pu) if q.redemption_pu is not None else None
                else:
                    z=q.buy_yield if buy_equivalent else q.redemption_yield
                    v=None if z is None else z*100
            values.append(v)
        fig.add_trace(go.Scatter(x=[x.isoformat() for x in dates],y=values,name='Cotação observada (histórico)',
                                mode='lines+markers',marker=dict(size=3),line=dict(width=1),connectgaps=False))
    return _layout(fig,r,title,selected_date)


def profit_chart(r:AnalysisResult,measure='accumulated',*,selected_date:date|None=None,show_all=False):
    import plotly.graph_objects as go
    fig=go.Figure()
    rows=[d for d in r.daily if show_all or d.eligible]
    valid_dates={d.date for d in rows}
    title={'accumulated':'Lucro líquido nominal acumulado (%)','money':'Lucro líquido (R$)',
           'annualized':'Retorno líquido equivalente anual (% a.a.)'}[measure]
    for rate in r.request.scenario_yields:
        part=[s for s in r.scenarios if s.input_yield==rate and s.date in valid_dates]
        crossing=next((c.first_date for c in r.crossings if c.input_yield==rate),None)
        values=[];detail=[]
        for s in part:
            n=s.financial
            v=None
            if n:
                v=float(n.net_return)*100 if measure=='accumulated' else float(n.profit) if measure=='money' else (n.annualized*100 if n.annualized is not None else None)
            values.append(v)
            detail.append([money(s.pu),money(n.net if n else None),money(n.tax if n else None),
                           money(n.custody if n else None),pct(n.net_return,4) if n else '—',
                           pct(s.effective_yield), ('Primeiro cruzamento neste cenário' if s.date==crossing else 'Cenário; elegível pelo calendário') if s.eligible else 'Cenário não executável'])
        fig.add_trace(go.Scatter(x=[s.date.isoformat() for s in part],y=values,
            name=f'{pct(rate)} a.a. · {r.request.scenario_kind}',mode='lines+markers',line=dict(width=2),connectgaps=False,
            marker=dict(size=[8 if s.date==crossing else 0 for s in part]),
            customdata=detail,hovertemplate='%{x|%d/%m/%Y}<br>Resultado: %{y:.4f}<br>'
            'PU: %{customdata[0]}<br>Líquido: %{customdata[1]}<br>IR: %{customdata[2]}'
            '<br>Custódia: %{customdata[3]}<br>Acumulado: %{customdata[4]}'
            '<br>Taxa efetiva de resgate: %{customdata[5]}<br>%{customdata[6]}<extra></extra>'))
    if measure=='annualized':
        goal=[None if d.target_annualized is None else 100*d.target_annualized for d in rows]
    elif measure=='money':
        goal=[float(r.request.lot.initial_outflow*r.request.target)]*len(rows)
    else:
        goal=[float(r.request.target)*100]*len(rows)
    fig.add_trace(go.Scatter(x=[d.date.isoformat() for d in rows],y=goal,
                            name=f'Meta: {pct(r.request.target)} acumulados',mode='lines',line=dict(dash='dot',width=2)))
    return _layout(fig,r,title,selected_date)
